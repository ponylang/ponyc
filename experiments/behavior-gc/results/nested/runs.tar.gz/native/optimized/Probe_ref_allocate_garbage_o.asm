
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000000410a0 <Probe_ref_allocate_garbage_o>:
   410a0:	41 57                	push   %r15
   410a2:	41 56                	push   %r14
   410a4:	53                   	push   %rbx
   410a5:	45 31 f6             	xor    %r14d,%r14d
   410a8:	e8 43 d1 fe ff       	call   2e1f0 <pony_ctx>
   410ad:	48 89 c3             	mov    %rax,%rbx
   410b0:	4c 8d 3d e9 2f 00 00 	lea    0x2fe9(%rip),%r15        # 440a0 <Cell_Desc>
   410b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   410be:	00 00 
   410c0:	48 89 df             	mov    %rbx,%rdi
   410c3:	31 f6                	xor    %esi,%esi
   410c5:	e8 96 6b fd ff       	call   17c60 <pony_alloc_small>
   410ca:	4c 89 38             	mov    %r15,(%rax)
   410cd:	4c 89 70 08          	mov    %r14,0x8(%rax)
   410d1:	48 89 c7             	mov    %rax,%rdi
   410d4:	e8 47 1c fe ff       	call   22d20 <nested_garbage>
   410d9:	49 ff c6             	inc    %r14
   410dc:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
   410e3:	75 db                	jne    410c0 <Probe_ref_allocate_garbage_o+0x20>
   410e5:	48 8d 05 a4 37 00 00 	lea    0x37a4(%rip),%rax        # 44890 <None_Inst>
   410ec:	5b                   	pop    %rbx
   410ed:	41 5e                	pop    %r14
   410ef:	41 5f                	pop    %r15
   410f1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
