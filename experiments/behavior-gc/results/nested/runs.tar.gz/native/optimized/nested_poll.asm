
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000022f20 <nested_poll>:
   22f20:	55                   	push   %rbp
   22f21:	48 89 e5             	mov    %rsp,%rbp
   22f24:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
   22f2b:	b0 00                	mov    $0x0,%al
   22f2d:	e8 be b2 00 00       	call   2e1f0 <pony_ctx>
   22f32:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
   22f36:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   22f3a:	48 8b 40 08          	mov    0x8(%rax),%rax
   22f3e:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
   22f42:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22f49:	25 00 00 00 00 
   22f4e:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   22f55:	31 c0                	xor    %eax,%eax
   22f57:	48 83 79 08 02       	cmpq   $0x2,0x8(%rcx)
   22f5c:	88 45 e7             	mov    %al,-0x19(%rbp)
   22f5f:	75 6b                	jne    22fcc <nested_poll+0xac>
   22f61:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22f65:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
   22f69:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22f70:	25 00 00 00 00 
   22f75:	48 8b 4d d8          	mov    -0x28(%rbp),%rcx
   22f79:	48 8d 90 10 df fe ff 	lea    -0x120f0(%rax),%rdx
   22f80:	31 c0                	xor    %eax,%eax
   22f82:	48 3b 0a             	cmp    (%rdx),%rcx
   22f85:	88 45 e7             	mov    %al,-0x19(%rbp)
   22f88:	75 42                	jne    22fcc <nested_poll+0xac>
   22f8a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22f91:	25 00 00 00 00 
   22f96:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   22f9d:	31 c0                	xor    %eax,%eax
   22f9f:	80 b9 8c 20 00 00 00 	cmpb   $0x0,0x208c(%rcx)
   22fa6:	88 45 e7             	mov    %al,-0x19(%rbp)
   22fa9:	75 21                	jne    22fcc <nested_poll+0xac>
   22fab:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22fb2:	25 00 00 00 00 
   22fb7:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   22fbe:	48 81 78 38 00 04 00 	cmpq   $0x400,0x38(%rax)
   22fc5:	00 
   22fc6:	0f 94 c0             	sete   %al
   22fc9:	88 45 e7             	mov    %al,-0x19(%rbp)
   22fcc:	8a 45 e7             	mov    -0x19(%rbp),%al
   22fcf:	0f b6 f8             	movzbl %al,%edi
   22fd2:	83 e7 01             	and    $0x1,%edi
   22fd5:	48 8d 35 07 73 fe ff 	lea    -0x18cf9(%rip),%rsi        # a2e3 <_IO_stdin_used+0x6eb3>
   22fdc:	e8 7f f9 ff ff       	call   22960 <require>
   22fe1:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   22fe5:	31 c0                	xor    %eax,%eax
   22fe7:	48 83 79 20 00       	cmpq   $0x0,0x20(%rcx)
   22fec:	88 45 d7             	mov    %al,-0x29(%rbp)
   22fef:	0f 85 81 00 00 00    	jne    23076 <nested_poll+0x156>
   22ff5:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   22ff9:	31 c0                	xor    %eax,%eax
   22ffb:	48 83 79 48 00       	cmpq   $0x0,0x48(%rcx)
   23000:	88 45 d7             	mov    %al,-0x29(%rbp)
   23003:	75 71                	jne    23076 <nested_poll+0x156>
   23005:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
   23009:	48 83 c7 28          	add    $0x28,%rdi
   2300d:	e8 7e 76 ff ff       	call   1a690 <ponyint_actormap_size>
   23012:	48 89 c1             	mov    %rax,%rcx
   23015:	31 c0                	xor    %eax,%eax
   23017:	48 83 f9 00          	cmp    $0x0,%rcx
   2301b:	88 45 d7             	mov    %al,-0x29(%rbp)
   2301e:	75 56                	jne    23076 <nested_poll+0x156>
   23020:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   23024:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   2302b:	48 83 c7 10          	add    $0x10,%rdi
   2302f:	e8 8c f0 ff ff       	call   220c0 <ponyint_objectmap_size>
   23034:	48 89 c1             	mov    %rax,%rcx
   23037:	31 c0                	xor    %eax,%eax
   23039:	48 83 f9 00          	cmp    $0x0,%rcx
   2303d:	88 45 d7             	mov    %al,-0x29(%rbp)
   23040:	75 34                	jne    23076 <nested_poll+0x156>
   23042:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   23046:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   2304d:	48 83 c7 30          	add    $0x30,%rdi
   23051:	e8 3a 76 ff ff       	call   1a690 <ponyint_actormap_size>
   23056:	48 89 c1             	mov    %rax,%rcx
   23059:	31 c0                	xor    %eax,%eax
   2305b:	48 83 f9 00          	cmp    $0x0,%rcx
   2305f:	88 45 d7             	mov    %al,-0x29(%rbp)
   23062:	75 12                	jne    23076 <nested_poll+0x156>
   23064:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   23068:	48 83 c7 40          	add    $0x40,%rdi
   2306c:	e8 8f 14 00 00       	call   24500 <ponyint_heap_has_finalisers>
   23071:	34 ff                	xor    $0xff,%al
   23073:	88 45 d7             	mov    %al,-0x29(%rbp)
   23076:	8a 45 d7             	mov    -0x29(%rbp),%al
   23079:	0f b6 f8             	movzbl %al,%edi
   2307c:	83 e7 01             	and    $0x1,%edi
   2307f:	48 8d 35 4f 6e fe ff 	lea    -0x191b1(%rip),%rsi        # 9ed5 <_IO_stdin_used+0x6aa5>
   23086:	e8 d5 f8 ff ff       	call   22960 <require>
   2308b:	e8 a0 fb ff ff       	call   22c30 <check_slots>
   23090:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
   23097:	00 
   23098:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   2309c:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
   230a0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   230a7:	25 00 00 00 00 
   230ac:	48 89 c1             	mov    %rax,%rcx
   230af:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   230b3:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   230ba:	48 3b 41 08          	cmp    0x8(%rcx),%rax
   230be:	73 64                	jae    23124 <nested_poll+0x204>
   230c0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   230c7:	25 00 00 00 00 
   230cc:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   230d3:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
   230d7:	48 83 7c c8 40 00    	cmpq   $0x0,0x40(%rax,%rcx,8)
   230dd:	74 32                	je     23111 <nested_poll+0x1f1>
   230df:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   230e3:	89 c1                	mov    %eax,%ecx
   230e5:	b8 01 00 00 00       	mov    $0x1,%eax
   230ea:	d3 e0                	shl    %cl,%eax
   230ec:	89 45 c4             	mov    %eax,-0x3c(%rbp)
   230ef:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   230f6:	25 00 00 00 00 
   230fb:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
   230fe:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   23105:	0b 88 80 20 00 00    	or     0x2080(%rax),%ecx
   2310b:	89 88 80 20 00 00    	mov    %ecx,0x2080(%rax)
   23111:	eb 00                	jmp    23113 <nested_poll+0x1f3>
   23113:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   23117:	48 83 c0 01          	add    $0x1,%rax
   2311b:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
   2311f:	e9 74 ff ff ff       	jmp    23098 <nested_poll+0x178>
   23124:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   23128:	48 8b 80 c0 00 00 00 	mov    0xc0(%rax),%rax
   2312f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
   23133:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2313a:	25 00 00 00 00 
   2313f:	48 89 c1             	mov    %rax,%rcx
   23142:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   23146:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   2314d:	48 3b 41 20          	cmp    0x20(%rcx),%rax
   23151:	0f 94 c0             	sete   %al
   23154:	0f b6 f8             	movzbl %al,%edi
   23157:	83 e7 01             	and    $0x1,%edi
   2315a:	48 8d 35 a1 3c fe ff 	lea    -0x1c35f(%rip),%rsi        # 6e02 <_IO_stdin_used+0x39d2>
   23161:	e8 fa f7 ff ff       	call   22960 <require>
   23166:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   2316a:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   23171:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
   23175:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2317c:	25 00 00 00 00 
   23181:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
   23185:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2318c:	48 89 48 28          	mov    %rcx,0x28(%rax)
   23190:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   23197:	25 00 00 00 00 
   2319c:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   231a3:	80 b8 88 20 00 00 00 	cmpb   $0x0,0x2088(%rax)
   231aa:	0f 84 d7 00 00 00    	je     23287 <nested_poll+0x367>
   231b0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   231b7:	25 00 00 00 00 
   231bc:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   231c3:	48 8b 40 28          	mov    0x28(%rax),%rax
   231c7:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
   231cb:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   231d2:	25 00 00 00 00 
   231d7:	48 89 c1             	mov    %rax,%rcx
   231da:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
   231de:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   231e5:	48 3b 41 20          	cmp    0x20(%rcx),%rax
   231e9:	0f 86 98 00 00 00    	jbe    23287 <nested_poll+0x367>
   231ef:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   231f6:	25 00 00 00 00 
   231fb:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   23202:	83 b8 80 20 00 00 03 	cmpl   $0x3,0x2080(%rax)
   23209:	75 7c                	jne    23287 <nested_poll+0x367>
   2320b:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   2320f:	48 89 45 88          	mov    %rax,-0x78(%rbp)
   23213:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   23217:	48 89 45 90          	mov    %rax,-0x70(%rbp)
   2321b:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   23222:	25 00 00 00 00 
   23227:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2322e:	48 8b 40 08          	mov    0x8(%rax),%rax
   23232:	48 89 45 98          	mov    %rax,-0x68(%rbp)
   23236:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2323d:	25 00 00 00 00 
   23242:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
   23246:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
   2324a:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
   2324e:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   23255:	48 83 c1 40          	add    $0x40,%rcx
   23259:	4c 8d 05 30 01 00 00 	lea    0x130(%rip),%r8        # 23390 <check_marks>
   23260:	e8 0b 2f ff ff       	call   16170 <probe_collect_roots>
   23265:	88 45 a7             	mov    %al,-0x59(%rbp)
   23268:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2326f:	25 00 00 00 00 
   23274:	8a 4d a7             	mov    -0x59(%rbp),%cl
   23277:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2327e:	80 e1 01             	and    $0x1,%cl
   23281:	88 88 8b 20 00 00    	mov    %cl,0x208b(%rax)
   23287:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   2328b:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   23292:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
   23299:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   232a0:	25 00 00 00 00 
   232a5:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
   232ac:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   232b3:	48 89 48 30          	mov    %rcx,0x30(%rax)
   232b7:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   232be:	25 00 00 00 00 
   232c3:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   232ca:	b0 01                	mov    $0x1,%al
   232cc:	80 b9 8b 20 00 00 00 	cmpb   $0x0,0x208b(%rcx)
   232d3:	88 45 87             	mov    %al,-0x79(%rbp)
   232d6:	74 75                	je     2334d <nested_poll+0x42d>
   232d8:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   232df:	25 00 00 00 00 
   232e4:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   232eb:	31 c0                	xor    %eax,%eax
   232ed:	83 b9 84 20 00 00 03 	cmpl   $0x3,0x2084(%rcx)
   232f4:	88 85 77 ff ff ff    	mov    %al,-0x89(%rbp)
   232fa:	75 48                	jne    23344 <nested_poll+0x424>
   232fc:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   23303:	25 00 00 00 00 
   23308:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2330f:	48 8b 40 30          	mov    0x30(%rax),%rax
   23313:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
   2331a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   23321:	25 00 00 00 00 
   23326:	48 89 c1             	mov    %rax,%rcx
   23329:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
   23330:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   23337:	48 3b 41 18          	cmp    0x18(%rcx),%rax
   2333b:	0f 94 c0             	sete   %al
   2333e:	88 85 77 ff ff ff    	mov    %al,-0x89(%rbp)
   23344:	8a 85 77 ff ff ff    	mov    -0x89(%rbp),%al
   2334a:	88 45 87             	mov    %al,-0x79(%rbp)
   2334d:	8a 45 87             	mov    -0x79(%rbp),%al
   23350:	0f b6 f8             	movzbl %al,%edi
   23353:	83 e7 01             	and    $0x1,%edi
   23356:	48 8d 35 96 29 fe ff 	lea    -0x1d66a(%rip),%rsi        # 5cf3 <_IO_stdin_used+0x28c3>
   2335d:	e8 fe f5 ff ff       	call   22960 <require>
   23362:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   23369:	25 00 00 00 00 
   2336e:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   23375:	c6 80 8c 20 00 00 01 	movb   $0x1,0x208c(%rax)
   2337c:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   23383:	5d                   	pop    %rbp
   23384:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
