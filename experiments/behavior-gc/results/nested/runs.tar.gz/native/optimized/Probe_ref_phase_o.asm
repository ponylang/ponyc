
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000041440 <Probe_ref_phase_o>:
   41440:	53                   	push   %rbx
   41441:	e8 5a fc ff ff       	call   410a0 <Probe_ref_allocate_garbage_o>
   41446:	48 89 c3             	mov    %rax,%rbx
   41449:	e8 d2 1a fe ff       	call   22f20 <nested_poll>
   4144e:	e8 ed 1f fe ff       	call   23440 <nested_leave_phase>
   41453:	48 89 d8             	mov    %rbx,%rax
   41456:	5b                   	pop    %rbx
   41457:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
