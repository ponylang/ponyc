
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000041150 <Probe_ref_middle_o>:
   41150:	55                   	push   %rbp
   41151:	41 57                	push   %r15
   41153:	41 56                	push   %r14
   41155:	41 55                	push   %r13
   41157:	41 54                	push   %r12
   41159:	53                   	push   %rbx
   4115a:	48 83 ec 48          	sub    $0x48,%rsp
   4115e:	48 89 fb             	mov    %rdi,%rbx
   41161:	e8 8a d0 fe ff       	call   2e1f0 <pony_ctx>
   41166:	49 89 c6             	mov    %rax,%r14
   41169:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   4116e:	48 8d 05 7c 3f fc ff 	lea    -0x3c084(%rip),%rax        # 50f1 <_IO_stdin_used+0x1cc1>
   41175:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   4117a:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
   4117f:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   41184:	48 8d 6c 24 38       	lea    0x38(%rsp),%rbp
   41189:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   4118e:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   41195:	00 
   41196:	4c 8d 3d 13 ad fc ff 	lea    -0x352ed(%rip),%r15        # beb0 <class_spans+0x1710>
   4119d:	4c 89 f7             	mov    %r14,%rdi
   411a0:	48 89 de             	mov    %rbx,%rsi
   411a3:	4c 89 fa             	mov    %r15,%rdx
   411a6:	b9 18 00 00 00       	mov    $0x18,%ecx
   411ab:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   411b1:	45 31 c9             	xor    %r9d,%r9d
   411b4:	e8 67 12 fe ff       	call   22420 <ponyint_gc_root_audit>
   411b9:	4c 89 f7             	mov    %r14,%rdi
   411bc:	31 f6                	xor    %esi,%esi
   411be:	e8 9d 6a fd ff       	call   17c60 <pony_alloc_small>
   411c3:	49 89 c4             	mov    %rax,%r12
   411c6:	48 8d 05 d3 2e 00 00 	lea    0x2ed3(%rip),%rax        # 440a0 <Cell_Desc>
   411cd:	49 89 04 24          	mov    %rax,(%r12)
   411d1:	49 c7 44 24 08 0f 01 	movq   $0x10f,0x8(%r12)
   411d8:	00 00 
   411da:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
   411df:	48 8d 05 32 2a fc ff 	lea    -0x3d5ce(%rip),%rax        # 3c18 <_IO_stdin_used+0x7e8>
   411e6:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   411eb:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   411f0:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   411f5:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   411fc:	00 
   411fd:	4c 89 f7             	mov    %r14,%rdi
   41200:	48 89 de             	mov    %rbx,%rsi
   41203:	4c 89 fa             	mov    %r15,%rdx
   41206:	b9 19 00 00 00       	mov    $0x19,%ecx
   4120b:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
   41211:	45 31 c9             	xor    %r9d,%r9d
   41214:	e8 07 12 fe ff       	call   22420 <ponyint_gc_root_audit>
   41219:	e8 22 02 00 00       	call   41440 <Probe_ref_phase_o>
   4121e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   41223:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   41227:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   4122c:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   41233:	00 00 
   41235:	48 8d 2d 94 ac fc ff 	lea    -0x3536c(%rip),%rbp        # bed0 <class_spans+0x1730>
   4123c:	4c 89 f7             	mov    %r14,%rdi
   4123f:	48 89 de             	mov    %rbx,%rsi
   41242:	4c 89 fa             	mov    %r15,%rdx
   41245:	b9 1a 00 00 00       	mov    $0x1a,%ecx
   4124a:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   41250:	49 89 e9             	mov    %rbp,%r9
   41253:	e8 c8 11 fe ff       	call   22420 <ponyint_gc_root_audit>
   41258:	4c 89 f7             	mov    %r14,%rdi
   4125b:	31 f6                	xor    %esi,%esi
   4125d:	e8 fe 69 fd ff       	call   17c60 <pony_alloc_small>
   41262:	49 89 c5             	mov    %rax,%r13
   41265:	48 8d 05 34 2e 00 00 	lea    0x2e34(%rip),%rax        # 440a0 <Cell_Desc>
   4126c:	49 89 45 00          	mov    %rax,0x0(%r13)
   41270:	49 c7 45 08 d3 00 00 	movq   $0xd3,0x8(%r13)
   41277:	00 
   41278:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4127c:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   41281:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   41288:	00 00 
   4128a:	4c 89 f7             	mov    %r14,%rdi
   4128d:	48 89 de             	mov    %rbx,%rsi
   41290:	4c 89 fa             	mov    %r15,%rdx
   41293:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   41298:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   4129e:	49 89 e9             	mov    %rbp,%r9
   412a1:	e8 7a 11 fe ff       	call   22420 <ponyint_gc_root_audit>
   412a6:	4c 89 ef             	mov    %r13,%rdi
   412a9:	e8 62 22 fe ff       	call   23510 <nested_fresh>
   412ae:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   412b2:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   412b7:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   412be:	00 00 
   412c0:	4c 89 f7             	mov    %r14,%rdi
   412c3:	48 89 de             	mov    %rbx,%rsi
   412c6:	4c 89 fa             	mov    %r15,%rdx
   412c9:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   412ce:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
   412d4:	49 89 e9             	mov    %rbp,%r9
   412d7:	e8 44 11 fe ff       	call   22420 <ponyint_gc_root_audit>
   412dc:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
   412e1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   412e5:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   412ea:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   412f1:	00 00 
   412f3:	4c 89 f7             	mov    %r14,%rdi
   412f6:	48 89 de             	mov    %rbx,%rsi
   412f9:	4c 89 fa             	mov    %r15,%rdx
   412fc:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   41301:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   41307:	49 89 e9             	mov    %rbp,%r9
   4130a:	e8 11 11 fe ff       	call   22420 <ponyint_gc_root_audit>
   4130f:	49 8d 45 07          	lea    0x7(%r13),%rax
   41313:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   41318:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4131c:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   41321:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   41328:	00 00 
   4132a:	4c 89 f7             	mov    %r14,%rdi
   4132d:	48 89 de             	mov    %rbx,%rsi
   41330:	4c 89 fa             	mov    %r15,%rdx
   41333:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   41338:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   4133e:	49 89 e9             	mov    %rbp,%r9
   41341:	e8 da 10 fe ff       	call   22420 <ponyint_gc_root_audit>
   41346:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
   4134b:	bf 01 00 00 00       	mov    $0x1,%edi
   41350:	4c 89 e6             	mov    %r12,%rsi
   41353:	4c 89 ea             	mov    %r13,%rdx
   41356:	e8 85 23 fe ff       	call   236e0 <nested_value>
   4135b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4135f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   41364:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4136b:	00 00 
   4136d:	4c 89 f7             	mov    %r14,%rdi
   41370:	48 89 de             	mov    %rbx,%rsi
   41373:	4c 89 fa             	mov    %r15,%rdx
   41376:	b9 18 00 00 00       	mov    $0x18,%ecx
   4137b:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   41381:	49 89 e9             	mov    %rbp,%r9
   41384:	e8 97 10 fe ff       	call   22420 <ponyint_gc_root_audit>
   41389:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   4138e:	48 83 c4 48          	add    $0x48,%rsp
   41392:	5b                   	pop    %rbx
   41393:	41 5c                	pop    %r12
   41395:	41 5d                	pop    %r13
   41397:	41 5e                	pop    %r14
   41399:	41 5f                	pop    %r15
   4139b:	5d                   	pop    %rbp
   4139c:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
