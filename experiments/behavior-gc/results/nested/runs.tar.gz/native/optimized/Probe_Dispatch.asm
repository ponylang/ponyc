
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000040ec0 <Probe_Dispatch>:
   40ec0:	55                   	push   %rbp
   40ec1:	41 57                	push   %r15
   40ec3:	41 56                	push   %r14
   40ec5:	41 55                	push   %r13
   40ec7:	41 54                	push   %r12
   40ec9:	53                   	push   %rbx
   40eca:	48 83 ec 38          	sub    $0x38,%rsp
   40ece:	48 89 f3             	mov    %rsi,%rbx
   40ed1:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
   40ed5:	4c 8b 6a 10          	mov    0x10(%rdx),%r13
   40ed9:	0f 85 81 01 00 00    	jne    41060 <Probe_Dispatch+0x1a0>
   40edf:	e8 0c d3 fe ff       	call   2e1f0 <pony_ctx>
   40ee4:	49 89 c6             	mov    %rax,%r14
   40ee7:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   40eec:	48 8d 05 fe 41 fc ff 	lea    -0x3be02(%rip),%rax        # 50f1 <_IO_stdin_used+0x1cc1>
   40ef3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   40ef8:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
   40efd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   40f02:	48 8d 6c 24 28       	lea    0x28(%rsp),%rbp
   40f07:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   40f0c:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   40f13:	00 
   40f14:	4c 8d 3d c5 ae fc ff 	lea    -0x3513b(%rip),%r15        # bde0 <class_spans+0x1640>
   40f1b:	4c 89 f7             	mov    %r14,%rdi
   40f1e:	48 89 de             	mov    %rbx,%rsi
   40f21:	4c 89 fa             	mov    %r15,%rdx
   40f24:	b9 11 00 00 00       	mov    $0x11,%ecx
   40f29:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   40f2f:	45 31 c9             	xor    %r9d,%r9d
   40f32:	e8 e9 14 fe ff       	call   22420 <ponyint_gc_root_audit>
   40f37:	4c 89 f7             	mov    %r14,%rdi
   40f3a:	31 f6                	xor    %esi,%esi
   40f3c:	e8 1f 6d fd ff       	call   17c60 <pony_alloc_small>
   40f41:	49 89 c4             	mov    %rax,%r12
   40f44:	48 8d 05 55 31 00 00 	lea    0x3155(%rip),%rax        # 440a0 <Cell_Desc>
   40f4b:	49 89 04 24          	mov    %rax,(%r12)
   40f4f:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
   40f54:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   40f59:	48 8d 05 b8 2c fc ff 	lea    -0x3d348(%rip),%rax        # 3c18 <_IO_stdin_used+0x7e8>
   40f60:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   40f65:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
   40f6a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   40f6f:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   40f74:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   40f7b:	00 
   40f7c:	4c 89 f7             	mov    %r14,%rdi
   40f7f:	48 89 de             	mov    %rbx,%rsi
   40f82:	4c 89 fa             	mov    %r15,%rdx
   40f85:	b9 12 00 00 00       	mov    $0x12,%ecx
   40f8a:	41 b8 0b 00 00 00    	mov    $0xb,%r8d
   40f90:	45 31 c9             	xor    %r9d,%r9d
   40f93:	e8 88 14 fe ff       	call   22420 <ponyint_gc_root_audit>
   40f98:	48 89 df             	mov    %rbx,%rdi
   40f9b:	e8 b0 01 00 00       	call   41150 <Probe_ref_middle_o>
   40fa0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   40fa4:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   40fa9:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   40fb0:	00 00 
   40fb2:	4c 8d 2d 17 af fc ff 	lea    -0x350e9(%rip),%r13        # bed0 <class_spans+0x1730>
   40fb9:	4c 89 f7             	mov    %r14,%rdi
   40fbc:	48 89 de             	mov    %rbx,%rsi
   40fbf:	4c 89 fa             	mov    %r15,%rdx
   40fc2:	b9 13 00 00 00       	mov    $0x13,%ecx
   40fc7:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
   40fcd:	4d 89 e9             	mov    %r13,%r9
   40fd0:	e8 4b 14 fe ff       	call   22420 <ponyint_gc_root_audit>
   40fd5:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
   40fda:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   40fde:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   40fe3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   40fea:	00 00 
   40fec:	4c 89 f7             	mov    %r14,%rdi
   40fef:	48 89 de             	mov    %rbx,%rsi
   40ff2:	4c 89 fa             	mov    %r15,%rdx
   40ff5:	b9 14 00 00 00       	mov    $0x14,%ecx
   40ffa:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   41000:	4d 89 e9             	mov    %r13,%r9
   41003:	e8 18 14 fe ff       	call   22420 <ponyint_gc_root_audit>
   41008:	48 8d 45 05          	lea    0x5(%rbp),%rax
   4100c:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   41011:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   41015:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   4101a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   41021:	00 00 
   41023:	4c 89 f7             	mov    %r14,%rdi
   41026:	48 89 de             	mov    %rbx,%rsi
   41029:	4c 89 fa             	mov    %r15,%rdx
   4102c:	b9 15 00 00 00       	mov    $0x15,%ecx
   41031:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   41037:	4d 89 e9             	mov    %r13,%r9
   4103a:	e8 e1 13 fe ff       	call   22420 <ponyint_gc_root_audit>
   4103f:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
   41044:	31 ff                	xor    %edi,%edi
   41046:	4c 89 e6             	mov    %r12,%rsi
   41049:	48 89 ea             	mov    %rbp,%rdx
   4104c:	e8 8f 26 fe ff       	call   236e0 <nested_value>
   41051:	48 83 c4 38          	add    $0x38,%rsp
   41055:	5b                   	pop    %rbx
   41056:	41 5c                	pop    %r12
   41058:	41 5d                	pop    %r13
   4105a:	41 5e                	pop    %r14
   4105c:	41 5f                	pop    %r15
   4105e:	5d                   	pop    %rbp
   4105f:	c3                   	ret
   41060:	49 89 fe             	mov    %rdi,%r14
   41063:	e8 88 d1 fe ff       	call   2e1f0 <pony_ctx>
   41068:	31 ff                	xor    %edi,%edi
   4106a:	be 01 00 00 00       	mov    $0x1,%esi
   4106f:	e8 3c 63 fd ff       	call   173b0 <pony_alloc_msg>
   41074:	4c 89 68 10          	mov    %r13,0x10(%rax)
   41078:	4c 89 f7             	mov    %r14,%rdi
   4107b:	48 89 de             	mov    %rbx,%rsi
   4107e:	48 89 c2             	mov    %rax,%rdx
   41081:	48 89 c1             	mov    %rax,%rcx
   41084:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   4108a:	48 83 c4 38          	add    $0x38,%rsp
   4108e:	5b                   	pop    %rbx
   4108f:	41 5c                	pop    %r12
   41091:	41 5d                	pop    %r13
   41093:	41 5e                	pop    %r14
   41095:	41 5f                	pop    %r15
   41097:	5d                   	pop    %rbp
   41098:	e9 63 63 fd ff       	jmp    17400 <pony_sendv>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
