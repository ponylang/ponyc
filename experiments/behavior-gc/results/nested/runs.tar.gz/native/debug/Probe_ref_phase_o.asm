
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000043250 <Probe_ref_phase_o>:
   43250:	50                   	push   %rax
   43251:	48 89 3c 24          	mov    %rdi,(%rsp)
   43255:	e8 46 fb ff ff       	call   42da0 <Probe_ref_allocate_garbage_o>
   4325a:	e8 01 1b fe ff       	call   24d60 <nested_poll>
   4325f:	e8 1c 20 fe ff       	call   25280 <nested_leave_phase>
   43264:	48 8d 3d 65 50 00 00 	lea    0x5065(%rip),%rdi        # 482d0 <None_Inst>
   4326b:	e8 d0 08 00 00       	call   43b40 <None_val_create_o>
   43270:	59                   	pop    %rcx
   43271:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
