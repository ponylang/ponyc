
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000043390 <Probe_tag_measure_pWo>:
   43390:	55                   	push   %rbp
   43391:	41 57                	push   %r15
   43393:	41 56                	push   %r14
   43395:	41 55                	push   %r13
   43397:	41 54                	push   %r12
   43399:	53                   	push   %rbx
   4339a:	48 83 ec 58          	sub    $0x58,%rsp
   4339e:	49 89 f4             	mov    %rsi,%r12
   433a1:	48 89 fb             	mov    %rdi,%rbx
   433a4:	e8 87 cc fe ff       	call   30030 <pony_ctx>
   433a9:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   433ae:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
   433b3:	49 89 c6             	mov    %rax,%r14
   433b6:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   433bb:	48 8d 05 8e 27 fc ff 	lea    -0x3d872(%rip),%rax        # 5b50 <_IO_stdin_used+0x1cd0>
   433c2:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   433c7:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   433cc:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   433d1:	48 8d 6c 24 38       	lea    0x38(%rsp),%rbp
   433d6:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   433db:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   433e2:	00 
   433e3:	4c 8d 3d 96 94 fc ff 	lea    -0x36b6a(%rip),%r15        # c880 <__NumSizeTable+0x20>
   433ea:	4c 89 f7             	mov    %r14,%rdi
   433ed:	48 89 de             	mov    %rbx,%rsi
   433f0:	4c 89 fa             	mov    %r15,%rdx
   433f3:	b9 11 00 00 00       	mov    $0x11,%ecx
   433f8:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   433fe:	45 31 c9             	xor    %r9d,%r9d
   43401:	e8 5a 0e fe ff       	call   24260 <ponyint_gc_root_audit>
   43406:	4c 89 f7             	mov    %r14,%rdi
   43409:	31 f6                	xor    %esi,%esi
   4340b:	e8 90 66 fd ff       	call   19aa0 <pony_alloc_small>
   43410:	49 89 c5             	mov    %rax,%r13
   43413:	48 8d 05 06 3c 00 00 	lea    0x3c06(%rip),%rax        # 47020 <Cell_Desc>
   4341a:	49 89 45 00          	mov    %rax,0x0(%r13)
   4341e:	4c 89 ef             	mov    %r13,%rdi
   43421:	4c 89 e6             	mov    %r12,%rsi
   43424:	e8 57 ff ff ff       	call   43380 <Cell_ref_create_pWo>
   43429:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   4342e:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
   43433:	48 8d 05 32 12 fc ff 	lea    -0x3edce(%rip),%rax        # 466c <_IO_stdin_used+0x7ec>
   4343a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   4343f:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
   43444:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   43449:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   4344e:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   43455:	00 
   43456:	4c 89 f7             	mov    %r14,%rdi
   43459:	48 89 de             	mov    %rbx,%rsi
   4345c:	4c 89 fa             	mov    %r15,%rdx
   4345f:	b9 12 00 00 00       	mov    $0x12,%ecx
   43464:	41 b8 0b 00 00 00    	mov    $0xb,%r8d
   4346a:	45 31 c9             	xor    %r9d,%r9d
   4346d:	e8 ee 0d fe ff       	call   24260 <ponyint_gc_root_audit>
   43472:	48 89 df             	mov    %rbx,%rdi
   43475:	e8 26 fa ff ff       	call   42ea0 <Probe_ref_middle_o>
   4347a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4347e:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   43483:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4348a:	00 00 
   4348c:	4c 8d 0d 1d 95 fc ff 	lea    -0x36ae3(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   43493:	4c 89 f7             	mov    %r14,%rdi
   43496:	48 89 de             	mov    %rbx,%rsi
   43499:	4c 89 fa             	mov    %r15,%rdx
   4349c:	b9 13 00 00 00       	mov    $0x13,%ecx
   434a1:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
   434a7:	e8 b4 0d fe ff       	call   24260 <ponyint_gc_root_audit>
   434ac:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   434b1:	48 8b 40 08          	mov    0x8(%rax),%rax
   434b5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   434ba:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   434be:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   434c3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   434ca:	00 00 
   434cc:	4c 8d 0d dd 94 fc ff 	lea    -0x36b23(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   434d3:	4c 89 f7             	mov    %r14,%rdi
   434d6:	48 89 de             	mov    %rbx,%rsi
   434d9:	4c 89 fa             	mov    %r15,%rdx
   434dc:	b9 14 00 00 00       	mov    $0x14,%ecx
   434e1:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   434e7:	e8 74 0d fe ff       	call   24260 <ponyint_gc_root_audit>
   434ec:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   434f1:	48 83 c0 05          	add    $0x5,%rax
   434f5:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   434fa:	48 89 41 08          	mov    %rax,0x8(%rcx)
   434fe:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   43502:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   43507:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4350e:	00 00 
   43510:	4c 8d 0d 99 94 fc ff 	lea    -0x36b67(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   43517:	4c 89 f7             	mov    %r14,%rdi
   4351a:	48 89 de             	mov    %rbx,%rsi
   4351d:	4c 89 fa             	mov    %r15,%rdx
   43520:	b9 15 00 00 00       	mov    $0x15,%ecx
   43525:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   4352b:	e8 30 0d fe ff       	call   24260 <ponyint_gc_root_audit>
   43530:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   43535:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   4353a:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   4353e:	31 ff                	xor    %edi,%edi
   43540:	e8 db 1f fe ff       	call   25520 <nested_value>
   43545:	48 83 c4 58          	add    $0x58,%rsp
   43549:	5b                   	pop    %rbx
   4354a:	41 5c                	pop    %r12
   4354c:	41 5d                	pop    %r13
   4354e:	41 5e                	pop    %r14
   43550:	41 5f                	pop    %r15
   43552:	5d                   	pop    %rbp
   43553:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
