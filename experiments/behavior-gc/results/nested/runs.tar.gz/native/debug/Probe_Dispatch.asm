
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042d80 <Probe_Dispatch>:
   42d80:	50                   	push   %rax
   42d81:	48 89 f7             	mov    %rsi,%rdi
   42d84:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
   42d88:	75 0b                	jne    42d95 <Probe_Dispatch+0x15>
   42d8a:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   42d8e:	e8 fd 05 00 00       	call   43390 <Probe_tag_measure_pWo>
   42d93:	58                   	pop    %rax
   42d94:	c3                   	ret
   42d95:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   42d99:	e8 c2 07 00 00       	call   43560 <Probe_tag_create_pWo>
   42d9e:	58                   	pop    %rax
   42d9f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
