
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042da0 <Probe_ref_allocate_garbage_o>:
   42da0:	41 57                	push   %r15
   42da2:	41 56                	push   %r14
   42da4:	41 54                	push   %r12
   42da6:	53                   	push   %rbx
   42da7:	48 83 ec 18          	sub    $0x18,%rsp
   42dab:	49 89 fe             	mov    %rdi,%r14
   42dae:	e8 7d d2 fe ff       	call   30030 <pony_ctx>
   42db3:	48 89 c3             	mov    %rax,%rbx
   42db6:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   42dbb:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   42dc2:	00 00 
   42dc4:	31 c0                	xor    %eax,%eax
   42dc6:	84 c0                	test   %al,%al
   42dc8:	75 55                	jne    42e1f <Probe_ref_allocate_garbage_o+0x7f>
   42dca:	4c 8d 25 4f 42 00 00 	lea    0x424f(%rip),%r12        # 47020 <Cell_Desc>
   42dd1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   42dd8:	0f 1f 84 00 00 00 00 
   42ddf:	00 
   42de0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   42de5:	48 89 df             	mov    %rbx,%rdi
   42de8:	31 f6                	xor    %esi,%esi
   42dea:	e8 b1 6c fd ff       	call   19aa0 <pony_alloc_small>
   42def:	49 89 c7             	mov    %rax,%r15
   42df2:	4c 89 20             	mov    %r12,(%rax)
   42df5:	48 89 c7             	mov    %rax,%rdi
   42df8:	4c 89 f6             	mov    %r14,%rsi
   42dfb:	e8 80 05 00 00       	call   43380 <Cell_ref_create_pWo>
   42e00:	4c 89 ff             	mov    %r15,%rdi
   42e03:	e8 58 1d fe ff       	call   24b60 <nested_garbage>
   42e08:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   42e0d:	48 ff c0             	inc    %rax
   42e10:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   42e15:	48 3d 00 04 00 00    	cmp    $0x400,%rax
   42e1b:	72 c3                	jb     42de0 <Probe_ref_allocate_garbage_o+0x40>
   42e1d:	eb 0c                	jmp    42e2b <Probe_ref_allocate_garbage_o+0x8b>
   42e1f:	48 8d 3d aa 54 00 00 	lea    0x54aa(%rip),%rdi        # 482d0 <None_Inst>
   42e26:	e8 15 0d 00 00       	call   43b40 <None_val_create_o>
   42e2b:	48 8d 3d 9e 54 00 00 	lea    0x549e(%rip),%rdi        # 482d0 <None_Inst>
   42e32:	e8 09 0d 00 00       	call   43b40 <None_val_create_o>
   42e37:	48 83 c4 18          	add    $0x18,%rsp
   42e3b:	5b                   	pop    %rbx
   42e3c:	41 5c                	pop    %r12
   42e3e:	41 5e                	pop    %r14
   42e40:	41 5f                	pop    %r15
   42e42:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
