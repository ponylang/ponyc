
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042ea0 <Probe_ref_middle_o>:
   42ea0:	55                   	push   %rbp
   42ea1:	41 57                	push   %r15
   42ea3:	41 56                	push   %r14
   42ea5:	41 55                	push   %r13
   42ea7:	41 54                	push   %r12
   42ea9:	53                   	push   %rbx
   42eaa:	48 83 ec 58          	sub    $0x58,%rsp
   42eae:	48 89 fb             	mov    %rdi,%rbx
   42eb1:	e8 7a d1 fe ff       	call   30030 <pony_ctx>
   42eb6:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   42ebb:	49 89 c6             	mov    %rax,%r14
   42ebe:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
   42ec3:	48 8d 05 86 2c fc ff 	lea    -0x3d37a(%rip),%rax        # 5b50 <_IO_stdin_used+0x1cd0>
   42eca:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   42ecf:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
   42ed4:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   42ed9:	4c 8d 6c 24 40       	lea    0x40(%rsp),%r13
   42ede:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   42ee3:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   42eea:	00 
   42eeb:	4c 8d 3d 9e 9a fc ff 	lea    -0x36562(%rip),%r15        # c990 <__NumSizeTable+0x130>
   42ef2:	4c 89 f7             	mov    %r14,%rdi
   42ef5:	48 89 de             	mov    %rbx,%rsi
   42ef8:	4c 89 fa             	mov    %r15,%rdx
   42efb:	b9 18 00 00 00       	mov    $0x18,%ecx
   42f00:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   42f06:	45 31 c9             	xor    %r9d,%r9d
   42f09:	e8 52 13 fe ff       	call   24260 <ponyint_gc_root_audit>
   42f0e:	4c 89 f7             	mov    %r14,%rdi
   42f11:	31 f6                	xor    %esi,%esi
   42f13:	e8 88 6b fd ff       	call   19aa0 <pony_alloc_small>
   42f18:	49 89 c4             	mov    %rax,%r12
   42f1b:	48 8d 05 fe 40 00 00 	lea    0x40fe(%rip),%rax        # 47020 <Cell_Desc>
   42f22:	49 89 04 24          	mov    %rax,(%r12)
   42f26:	be 0f 01 00 00       	mov    $0x10f,%esi
   42f2b:	4c 89 e7             	mov    %r12,%rdi
   42f2e:	e8 4d 04 00 00       	call   43380 <Cell_ref_create_pWo>
   42f33:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   42f38:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
   42f3d:	48 8d 05 28 17 fc ff 	lea    -0x3e8d8(%rip),%rax        # 466c <_IO_stdin_used+0x7ec>
   42f44:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   42f49:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   42f4e:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   42f53:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   42f5a:	00 
   42f5b:	4c 89 f7             	mov    %r14,%rdi
   42f5e:	48 89 de             	mov    %rbx,%rsi
   42f61:	4c 89 fa             	mov    %r15,%rdx
   42f64:	b9 19 00 00 00       	mov    $0x19,%ecx
   42f69:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
   42f6f:	45 31 c9             	xor    %r9d,%r9d
   42f72:	e8 e9 12 fe ff       	call   24260 <ponyint_gc_root_audit>
   42f77:	48 89 df             	mov    %rbx,%rdi
   42f7a:	e8 d1 02 00 00       	call   43250 <Probe_ref_phase_o>
   42f7f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   42f83:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   42f88:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   42f8f:	00 00 
   42f91:	4c 8d 0d 18 9a fc ff 	lea    -0x365e8(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   42f98:	4c 89 f7             	mov    %r14,%rdi
   42f9b:	48 89 de             	mov    %rbx,%rsi
   42f9e:	4c 89 fa             	mov    %r15,%rdx
   42fa1:	b9 1a 00 00 00       	mov    $0x1a,%ecx
   42fa6:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
   42fac:	e8 af 12 fe ff       	call   24260 <ponyint_gc_root_audit>
   42fb1:	4c 89 f7             	mov    %r14,%rdi
   42fb4:	31 f6                	xor    %esi,%esi
   42fb6:	e8 e5 6a fd ff       	call   19aa0 <pony_alloc_small>
   42fbb:	49 89 c4             	mov    %rax,%r12
   42fbe:	48 8d 05 5b 40 00 00 	lea    0x405b(%rip),%rax        # 47020 <Cell_Desc>
   42fc5:	49 89 04 24          	mov    %rax,(%r12)
   42fc9:	be d3 00 00 00       	mov    $0xd3,%esi
   42fce:	4c 89 e7             	mov    %r12,%rdi
   42fd1:	e8 aa 03 00 00       	call   43380 <Cell_ref_create_pWo>
   42fd6:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   42fdb:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   42fdf:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   42fe4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   42feb:	00 00 
   42fed:	4c 8d 0d bc 99 fc ff 	lea    -0x36644(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   42ff4:	4c 89 f7             	mov    %r14,%rdi
   42ff7:	48 89 de             	mov    %rbx,%rsi
   42ffa:	4c 89 fa             	mov    %r15,%rdx
   42ffd:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   43002:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   43008:	e8 53 12 fe ff       	call   24260 <ponyint_gc_root_audit>
   4300d:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
   43012:	e8 39 23 fe ff       	call   25350 <nested_fresh>
   43017:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4301b:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   43020:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   43027:	00 00 
   43029:	4c 8d 0d 80 99 fc ff 	lea    -0x36680(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   43030:	4c 89 f7             	mov    %r14,%rdi
   43033:	48 89 de             	mov    %rbx,%rsi
   43036:	4c 89 fa             	mov    %r15,%rdx
   43039:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   4303e:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
   43044:	e8 17 12 fe ff       	call   24260 <ponyint_gc_root_audit>
   43049:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   4304e:	48 8b 40 08          	mov    0x8(%rax),%rax
   43052:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   43057:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4305b:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   43060:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   43067:	00 00 
   43069:	4c 8d 0d 40 99 fc ff 	lea    -0x366c0(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   43070:	4c 89 f7             	mov    %r14,%rdi
   43073:	48 89 de             	mov    %rbx,%rsi
   43076:	4c 89 fa             	mov    %r15,%rdx
   43079:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   4307e:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   43084:	e8 d7 11 fe ff       	call   24260 <ponyint_gc_root_audit>
   43089:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   4308e:	48 83 c0 07          	add    $0x7,%rax
   43092:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   43097:	48 89 41 08          	mov    %rax,0x8(%rcx)
   4309b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4309f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   430a4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   430ab:	00 00 
   430ad:	4c 8d 0d fc 98 fc ff 	lea    -0x36704(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   430b4:	4c 89 f7             	mov    %r14,%rdi
   430b7:	48 89 de             	mov    %rbx,%rsi
   430ba:	4c 89 fa             	mov    %r15,%rdx
   430bd:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   430c2:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   430c8:	e8 93 11 fe ff       	call   24260 <ponyint_gc_root_audit>
   430cd:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   430d2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   430d7:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
   430db:	bf 01 00 00 00       	mov    $0x1,%edi
   430e0:	e8 3b 24 fe ff       	call   25520 <nested_value>
   430e5:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   430e9:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   430ee:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   430f5:	00 00 
   430f7:	4c 8d 0d b2 98 fc ff 	lea    -0x3674e(%rip),%r9        # c9b0 <__NumSizeTable+0x150>
   430fe:	4c 89 f7             	mov    %r14,%rdi
   43101:	48 89 de             	mov    %rbx,%rsi
   43104:	4c 89 fa             	mov    %r15,%rdx
   43107:	b9 18 00 00 00       	mov    $0x18,%ecx
   4310c:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   43112:	e8 49 11 fe ff       	call   24260 <ponyint_gc_root_audit>
   43117:	48 8d 3d b2 51 00 00 	lea    0x51b2(%rip),%rdi        # 482d0 <None_Inst>
   4311e:	e8 1d 0a 00 00       	call   43b40 <None_val_create_o>
   43123:	48 83 c4 58          	add    $0x58,%rsp
   43127:	5b                   	pop    %rbx
   43128:	41 5c                	pop    %r12
   4312a:	41 5d                	pop    %r13
   4312c:	41 5e                	pop    %r14
   4312e:	41 5f                	pop    %r15
   43130:	5d                   	pop    %rbp
   43131:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
