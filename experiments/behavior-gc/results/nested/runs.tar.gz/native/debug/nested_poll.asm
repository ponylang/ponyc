
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000024d60 <nested_poll>:
   24d60:	55                   	push   %rbp
   24d61:	48 89 e5             	mov    %rsp,%rbp
   24d64:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
   24d6b:	b0 00                	mov    $0x0,%al
   24d6d:	e8 be b2 00 00       	call   30030 <pony_ctx>
   24d72:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
   24d76:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   24d7a:	48 8b 40 08          	mov    0x8(%rax),%rax
   24d7e:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
   24d82:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24d89:	25 00 00 00 00 
   24d8e:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   24d95:	31 c0                	xor    %eax,%eax
   24d97:	48 83 79 08 02       	cmpq   $0x2,0x8(%rcx)
   24d9c:	88 45 e7             	mov    %al,-0x19(%rbp)
   24d9f:	75 6b                	jne    24e0c <nested_poll+0xac>
   24da1:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   24da5:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
   24da9:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24db0:	25 00 00 00 00 
   24db5:	48 8b 4d d8          	mov    -0x28(%rbp),%rcx
   24db9:	48 8d 90 10 df fe ff 	lea    -0x120f0(%rax),%rdx
   24dc0:	31 c0                	xor    %eax,%eax
   24dc2:	48 3b 0a             	cmp    (%rdx),%rcx
   24dc5:	88 45 e7             	mov    %al,-0x19(%rbp)
   24dc8:	75 42                	jne    24e0c <nested_poll+0xac>
   24dca:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24dd1:	25 00 00 00 00 
   24dd6:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   24ddd:	31 c0                	xor    %eax,%eax
   24ddf:	80 b9 8c 20 00 00 00 	cmpb   $0x0,0x208c(%rcx)
   24de6:	88 45 e7             	mov    %al,-0x19(%rbp)
   24de9:	75 21                	jne    24e0c <nested_poll+0xac>
   24deb:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24df2:	25 00 00 00 00 
   24df7:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   24dfe:	48 81 78 38 00 04 00 	cmpq   $0x400,0x38(%rax)
   24e05:	00 
   24e06:	0f 94 c0             	sete   %al
   24e09:	88 45 e7             	mov    %al,-0x19(%rbp)
   24e0c:	8a 45 e7             	mov    -0x19(%rbp),%al
   24e0f:	0f b6 f8             	movzbl %al,%edi
   24e12:	83 e7 01             	and    $0x1,%edi
   24e15:	48 8d 35 4e 5f fe ff 	lea    -0x1a0b2(%rip),%rsi        # ad6a <_IO_stdin_used+0x6eea>
   24e1c:	e8 7f f9 ff ff       	call   247a0 <require>
   24e21:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   24e25:	31 c0                	xor    %eax,%eax
   24e27:	48 83 79 20 00       	cmpq   $0x0,0x20(%rcx)
   24e2c:	88 45 d7             	mov    %al,-0x29(%rbp)
   24e2f:	0f 85 81 00 00 00    	jne    24eb6 <nested_poll+0x156>
   24e35:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   24e39:	31 c0                	xor    %eax,%eax
   24e3b:	48 83 79 48 00       	cmpq   $0x0,0x48(%rcx)
   24e40:	88 45 d7             	mov    %al,-0x29(%rbp)
   24e43:	75 71                	jne    24eb6 <nested_poll+0x156>
   24e45:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
   24e49:	48 83 c7 28          	add    $0x28,%rdi
   24e4d:	e8 7e 76 ff ff       	call   1c4d0 <ponyint_actormap_size>
   24e52:	48 89 c1             	mov    %rax,%rcx
   24e55:	31 c0                	xor    %eax,%eax
   24e57:	48 83 f9 00          	cmp    $0x0,%rcx
   24e5b:	88 45 d7             	mov    %al,-0x29(%rbp)
   24e5e:	75 56                	jne    24eb6 <nested_poll+0x156>
   24e60:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24e64:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   24e6b:	48 83 c7 10          	add    $0x10,%rdi
   24e6f:	e8 8c f0 ff ff       	call   23f00 <ponyint_objectmap_size>
   24e74:	48 89 c1             	mov    %rax,%rcx
   24e77:	31 c0                	xor    %eax,%eax
   24e79:	48 83 f9 00          	cmp    $0x0,%rcx
   24e7d:	88 45 d7             	mov    %al,-0x29(%rbp)
   24e80:	75 34                	jne    24eb6 <nested_poll+0x156>
   24e82:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24e86:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   24e8d:	48 83 c7 30          	add    $0x30,%rdi
   24e91:	e8 3a 76 ff ff       	call   1c4d0 <ponyint_actormap_size>
   24e96:	48 89 c1             	mov    %rax,%rcx
   24e99:	31 c0                	xor    %eax,%eax
   24e9b:	48 83 f9 00          	cmp    $0x0,%rcx
   24e9f:	88 45 d7             	mov    %al,-0x29(%rbp)
   24ea2:	75 12                	jne    24eb6 <nested_poll+0x156>
   24ea4:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24ea8:	48 83 c7 40          	add    $0x40,%rdi
   24eac:	e8 8f 14 00 00       	call   26340 <ponyint_heap_has_finalisers>
   24eb1:	34 ff                	xor    $0xff,%al
   24eb3:	88 45 d7             	mov    %al,-0x29(%rbp)
   24eb6:	8a 45 d7             	mov    -0x29(%rbp),%al
   24eb9:	0f b6 f8             	movzbl %al,%edi
   24ebc:	83 e7 01             	and    $0x1,%edi
   24ebf:	48 8d 35 92 5a fe ff 	lea    -0x1a56e(%rip),%rsi        # a958 <_IO_stdin_used+0x6ad8>
   24ec6:	e8 d5 f8 ff ff       	call   247a0 <require>
   24ecb:	e8 a0 fb ff ff       	call   24a70 <check_slots>
   24ed0:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
   24ed7:	00 
   24ed8:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   24edc:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
   24ee0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24ee7:	25 00 00 00 00 
   24eec:	48 89 c1             	mov    %rax,%rcx
   24eef:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
   24ef3:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   24efa:	48 3b 41 08          	cmp    0x8(%rcx),%rax
   24efe:	73 64                	jae    24f64 <nested_poll+0x204>
   24f00:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24f07:	25 00 00 00 00 
   24f0c:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   24f13:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
   24f17:	48 83 7c c8 40 00    	cmpq   $0x0,0x40(%rax,%rcx,8)
   24f1d:	74 32                	je     24f51 <nested_poll+0x1f1>
   24f1f:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   24f23:	89 c1                	mov    %eax,%ecx
   24f25:	b8 01 00 00 00       	mov    $0x1,%eax
   24f2a:	d3 e0                	shl    %cl,%eax
   24f2c:	89 45 c4             	mov    %eax,-0x3c(%rbp)
   24f2f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24f36:	25 00 00 00 00 
   24f3b:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
   24f3e:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   24f45:	0b 88 80 20 00 00    	or     0x2080(%rax),%ecx
   24f4b:	89 88 80 20 00 00    	mov    %ecx,0x2080(%rax)
   24f51:	eb 00                	jmp    24f53 <nested_poll+0x1f3>
   24f53:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   24f57:	48 83 c0 01          	add    $0x1,%rax
   24f5b:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
   24f5f:	e9 74 ff ff ff       	jmp    24ed8 <nested_poll+0x178>
   24f64:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   24f68:	48 8b 80 c0 00 00 00 	mov    0xc0(%rax),%rax
   24f6f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
   24f73:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24f7a:	25 00 00 00 00 
   24f7f:	48 89 c1             	mov    %rax,%rcx
   24f82:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
   24f86:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   24f8d:	48 3b 41 20          	cmp    0x20(%rcx),%rax
   24f91:	0f 94 c0             	sete   %al
   24f94:	0f b6 f8             	movzbl %al,%edi
   24f97:	83 e7 01             	and    $0x1,%edi
   24f9a:	48 8d 35 ce 28 fe ff 	lea    -0x1d732(%rip),%rsi        # 786f <_IO_stdin_used+0x39ef>
   24fa1:	e8 fa f7 ff ff       	call   247a0 <require>
   24fa6:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   24faa:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   24fb1:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
   24fb5:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24fbc:	25 00 00 00 00 
   24fc1:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
   24fc5:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   24fcc:	48 89 48 28          	mov    %rcx,0x28(%rax)
   24fd0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24fd7:	25 00 00 00 00 
   24fdc:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   24fe3:	80 b8 88 20 00 00 00 	cmpb   $0x0,0x2088(%rax)
   24fea:	0f 84 d7 00 00 00    	je     250c7 <nested_poll+0x367>
   24ff0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24ff7:	25 00 00 00 00 
   24ffc:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   25003:	48 8b 40 28          	mov    0x28(%rax),%rax
   25007:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
   2500b:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   25012:	25 00 00 00 00 
   25017:	48 89 c1             	mov    %rax,%rcx
   2501a:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
   2501e:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   25025:	48 3b 41 20          	cmp    0x20(%rcx),%rax
   25029:	0f 86 98 00 00 00    	jbe    250c7 <nested_poll+0x367>
   2502f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   25036:	25 00 00 00 00 
   2503b:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   25042:	83 b8 80 20 00 00 03 	cmpl   $0x3,0x2080(%rax)
   25049:	75 7c                	jne    250c7 <nested_poll+0x367>
   2504b:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   2504f:	48 89 45 88          	mov    %rax,-0x78(%rbp)
   25053:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   25057:	48 89 45 90          	mov    %rax,-0x70(%rbp)
   2505b:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   25062:	25 00 00 00 00 
   25067:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2506e:	48 8b 40 08          	mov    0x8(%rax),%rax
   25072:	48 89 45 98          	mov    %rax,-0x68(%rbp)
   25076:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2507d:	25 00 00 00 00 
   25082:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
   25086:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
   2508a:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
   2508e:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   25095:	48 83 c1 40          	add    $0x40,%rcx
   25099:	4c 8d 05 30 01 00 00 	lea    0x130(%rip),%r8        # 251d0 <check_marks>
   250a0:	e8 0b 2f ff ff       	call   17fb0 <probe_collect_roots>
   250a5:	88 45 a7             	mov    %al,-0x59(%rbp)
   250a8:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   250af:	25 00 00 00 00 
   250b4:	8a 4d a7             	mov    -0x59(%rbp),%cl
   250b7:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   250be:	80 e1 01             	and    $0x1,%cl
   250c1:	88 88 8b 20 00 00    	mov    %cl,0x208b(%rax)
   250c7:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   250cb:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   250d2:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
   250d9:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   250e0:	25 00 00 00 00 
   250e5:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
   250ec:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   250f3:	48 89 48 30          	mov    %rcx,0x30(%rax)
   250f7:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   250fe:	25 00 00 00 00 
   25103:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   2510a:	b0 01                	mov    $0x1,%al
   2510c:	80 b9 8b 20 00 00 00 	cmpb   $0x0,0x208b(%rcx)
   25113:	88 45 87             	mov    %al,-0x79(%rbp)
   25116:	74 75                	je     2518d <nested_poll+0x42d>
   25118:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2511f:	25 00 00 00 00 
   25124:	48 8d 88 10 df fe ff 	lea    -0x120f0(%rax),%rcx
   2512b:	31 c0                	xor    %eax,%eax
   2512d:	83 b9 84 20 00 00 03 	cmpl   $0x3,0x2084(%rcx)
   25134:	88 85 77 ff ff ff    	mov    %al,-0x89(%rbp)
   2513a:	75 48                	jne    25184 <nested_poll+0x424>
   2513c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   25143:	25 00 00 00 00 
   25148:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   2514f:	48 8b 40 30          	mov    0x30(%rax),%rax
   25153:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
   2515a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   25161:	25 00 00 00 00 
   25166:	48 89 c1             	mov    %rax,%rcx
   25169:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
   25170:	48 8d 89 10 df fe ff 	lea    -0x120f0(%rcx),%rcx
   25177:	48 3b 41 18          	cmp    0x18(%rcx),%rax
   2517b:	0f 94 c0             	sete   %al
   2517e:	88 85 77 ff ff ff    	mov    %al,-0x89(%rbp)
   25184:	8a 85 77 ff ff ff    	mov    -0x89(%rbp),%al
   2518a:	88 45 87             	mov    %al,-0x79(%rbp)
   2518d:	8a 45 87             	mov    -0x79(%rbp),%al
   25190:	0f b6 f8             	movzbl %al,%edi
   25193:	83 e7 01             	and    $0x1,%edi
   25196:	48 8d 35 bf 15 fe ff 	lea    -0x1ea41(%rip),%rsi        # 675c <_IO_stdin_used+0x28dc>
   2519d:	e8 fe f5 ff ff       	call   247a0 <require>
   251a2:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   251a9:	25 00 00 00 00 
   251ae:	48 8d 80 10 df fe ff 	lea    -0x120f0(%rax),%rax
   251b5:	c6 80 8c 20 00 00 01 	movb   $0x1,0x208c(%rax)
   251bc:	48 81 c4 a0 00 00 00 	add    $0xa0,%rsp
   251c3:	5d                   	pop    %rbp
   251c4:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
