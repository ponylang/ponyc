
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ae4c0 <Probe_Dispatch>:
  2ae4c0:	50                   	push   %rax
  2ae4c1:	48 89 f7             	mov    %rsi,%rdi
  2ae4c4:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
  2ae4c8:	75 0b                	jne    2ae4d5 <Probe_Dispatch+0x15>
  2ae4ca:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  2ae4ce:	e8 fd 05 00 00       	call   2aead0 <Probe_tag_measure_pWo>
  2ae4d3:	58                   	pop    %rax
  2ae4d4:	c3                   	ret
  2ae4d5:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  2ae4d9:	e8 c2 07 00 00       	call   2aeca0 <Probe_tag_create_pWo>
  2ae4de:	58                   	pop    %rax
  2ae4df:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
