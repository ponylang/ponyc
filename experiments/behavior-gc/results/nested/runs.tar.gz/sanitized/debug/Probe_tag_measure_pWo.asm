
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002aead0 <Probe_tag_measure_pWo>:
  2aead0:	55                   	push   %rbp
  2aead1:	41 57                	push   %r15
  2aead3:	41 56                	push   %r14
  2aead5:	41 55                	push   %r13
  2aead7:	41 54                	push   %r12
  2aead9:	53                   	push   %rbx
  2aeada:	48 83 ec 58          	sub    $0x58,%rsp
  2aeade:	49 89 f4             	mov    %rsi,%r12
  2aeae1:	48 89 fb             	mov    %rdi,%rbx
  2aeae4:	e8 3f 1c fa ff       	call   250728 <pony_ctx>
  2aeae9:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
  2aeaee:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  2aeaf3:	49 89 c6             	mov    %rax,%r14
  2aeaf6:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
  2aeafb:	48 8d 05 d1 9c df ff 	lea    -0x20632f(%rip),%rax        # a87d3 <_ZN11__sanitizerL10kExtraRegsE+0x7f13>
  2aeb02:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  2aeb07:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
  2aeb0c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2aeb11:	48 8d 6c 24 38       	lea    0x38(%rsp),%rbp
  2aeb16:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2aeb1b:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2aeb22:	00 
  2aeb23:	4c 8d 3d 96 c9 e1 ff 	lea    -0x1e366a(%rip),%r15        # cb4c0 <__NumSizeTable+0x20>
  2aeb2a:	4c 89 f7             	mov    %r14,%rdi
  2aeb2d:	48 89 de             	mov    %rbx,%rsi
  2aeb30:	4c 89 fa             	mov    %r15,%rdx
  2aeb33:	b9 11 00 00 00       	mov    $0x11,%ecx
  2aeb38:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2aeb3e:	45 31 c9             	xor    %r9d,%r9d
  2aeb41:	e8 a2 04 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2aeb46:	4c 89 f7             	mov    %r14,%rdi
  2aeb49:	31 f6                	xor    %esi,%esi
  2aeb4b:	e8 78 bf f4 ff       	call   1faac8 <pony_alloc_small>
  2aeb50:	49 89 c5             	mov    %rax,%r13
  2aeb53:	48 8d 05 d6 3e 00 00 	lea    0x3ed6(%rip),%rax        # 2b2a30 <Cell_Desc>
  2aeb5a:	49 89 45 00          	mov    %rax,0x0(%r13)
  2aeb5e:	4c 89 ef             	mov    %r13,%rdi
  2aeb61:	4c 89 e6             	mov    %r12,%rsi
  2aeb64:	e8 57 ff ff ff       	call   2aeac0 <Cell_ref_create_pWo>
  2aeb69:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  2aeb6e:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  2aeb73:	48 8d 05 fe 43 df ff 	lea    -0x20bc02(%rip),%rax        # a2f78 <_ZN11__sanitizerL10kExtraRegsE+0x26b8>
  2aeb7a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  2aeb7f:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
  2aeb84:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2aeb89:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2aeb8e:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2aeb95:	00 
  2aeb96:	4c 89 f7             	mov    %r14,%rdi
  2aeb99:	48 89 de             	mov    %rbx,%rsi
  2aeb9c:	4c 89 fa             	mov    %r15,%rdx
  2aeb9f:	b9 12 00 00 00       	mov    $0x12,%ecx
  2aeba4:	41 b8 0b 00 00 00    	mov    $0xb,%r8d
  2aebaa:	45 31 c9             	xor    %r9d,%r9d
  2aebad:	e8 36 04 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2aebb2:	48 89 df             	mov    %rbx,%rdi
  2aebb5:	e8 26 fa ff ff       	call   2ae5e0 <Probe_ref_middle_o>
  2aebba:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aebbe:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aebc3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aebca:	00 00 
  2aebcc:	4c 8d 0d 1d ca e1 ff 	lea    -0x1e35e3(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2aebd3:	4c 89 f7             	mov    %r14,%rdi
  2aebd6:	48 89 de             	mov    %rbx,%rsi
  2aebd9:	4c 89 fa             	mov    %r15,%rdx
  2aebdc:	b9 13 00 00 00       	mov    $0x13,%ecx
  2aebe1:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
  2aebe7:	e8 fc 03 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2aebec:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  2aebf1:	48 8b 40 08          	mov    0x8(%rax),%rax
  2aebf5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2aebfa:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aebfe:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aec03:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aec0a:	00 00 
  2aec0c:	4c 8d 0d dd c9 e1 ff 	lea    -0x1e3623(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2aec13:	4c 89 f7             	mov    %r14,%rdi
  2aec16:	48 89 de             	mov    %rbx,%rsi
  2aec19:	4c 89 fa             	mov    %r15,%rdx
  2aec1c:	b9 14 00 00 00       	mov    $0x14,%ecx
  2aec21:	41 b8 11 00 00 00    	mov    $0x11,%r8d
  2aec27:	e8 bc 03 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2aec2c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  2aec31:	48 83 c0 05          	add    $0x5,%rax
  2aec35:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  2aec3a:	48 89 41 08          	mov    %rax,0x8(%rcx)
  2aec3e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aec42:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aec47:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aec4e:	00 00 
  2aec50:	4c 8d 0d 99 c9 e1 ff 	lea    -0x1e3667(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2aec57:	4c 89 f7             	mov    %r14,%rdi
  2aec5a:	48 89 de             	mov    %rbx,%rsi
  2aec5d:	4c 89 fa             	mov    %r15,%rdx
  2aec60:	b9 15 00 00 00       	mov    $0x15,%ecx
  2aec65:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2aec6b:	e8 78 03 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2aec70:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  2aec75:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  2aec7a:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  2aec7e:	31 ff                	xor    %edi,%edi
  2aec80:	e8 83 4d f8 ff       	call   233a08 <nested_value>
  2aec85:	48 83 c4 58          	add    $0x58,%rsp
  2aec89:	5b                   	pop    %rbx
  2aec8a:	41 5c                	pop    %r12
  2aec8c:	41 5d                	pop    %r13
  2aec8e:	41 5e                	pop    %r14
  2aec90:	41 5f                	pop    %r15
  2aec92:	5d                   	pop    %rbp
  2aec93:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
