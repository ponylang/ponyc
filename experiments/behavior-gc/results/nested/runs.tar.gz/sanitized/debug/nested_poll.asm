
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000231c18 <nested_poll>:
  231c18:	55                   	push   %rbp
  231c19:	48 89 e5             	mov    %rsp,%rbp
  231c1c:	48 81 ec 60 02 00 00 	sub    $0x260,%rsp
  231c23:	b0 00                	mov    $0x0,%al
  231c25:	e8 fe ea 01 00       	call   250728 <pony_ctx>
  231c2a:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
  231c2e:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  231c32:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
  231c36:	48 83 f9 00          	cmp    $0x0,%rcx
  231c3a:	0f 95 c0             	setne  %al
  231c3d:	48 83 e1 07          	and    $0x7,%rcx
  231c41:	48 83 f9 00          	cmp    $0x0,%rcx
  231c45:	0f 94 c1             	sete   %cl
  231c48:	20 c8                	and    %cl,%al
  231c4a:	a8 01                	test   $0x1,%al
  231c4c:	75 10                	jne    231c5e <nested_poll+0x46>
  231c4e:	48 8b 75 e0          	mov    -0x20(%rbp),%rsi
  231c52:	48 8d 3d 07 9a 09 00 	lea    0x99a07(%rip),%rdi        # 2cb660 <_ZL17kSuppressionTypes+0x13c90>
  231c59:	e8 b2 c3 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231c5e:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
  231c62:	48 83 c1 08          	add    $0x8,%rcx
  231c66:	48 89 4d d8          	mov    %rcx,-0x28(%rbp)
  231c6a:	48 83 f9 00          	cmp    $0x0,%rcx
  231c6e:	0f 95 c0             	setne  %al
  231c71:	48 83 e1 07          	and    $0x7,%rcx
  231c75:	48 83 f9 00          	cmp    $0x0,%rcx
  231c79:	0f 94 c1             	sete   %cl
  231c7c:	20 c8                	and    %cl,%al
  231c7e:	a8 01                	test   $0x1,%al
  231c80:	75 10                	jne    231c92 <nested_poll+0x7a>
  231c82:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
  231c86:	48 8d 3d f3 99 09 00 	lea    0x999f3(%rip),%rdi        # 2cb680 <_ZL17kSuppressionTypes+0x13cb0>
  231c8d:	e8 7e c3 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231c92:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  231c96:	48 c1 e8 03          	shr    $0x3,%rax
  231c9a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231ca1:	74 09                	je     231cac <nested_poll+0x94>
  231ca3:	48 8b 7d d8          	mov    -0x28(%rbp),%rdi
  231ca7:	e8 14 54 f8 ff       	call   1b70c0 <__asan_report_load8>
  231cac:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  231cb0:	48 8b 00             	mov    (%rax),%rax
  231cb3:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
  231cb7:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  231cbe:	25 00 00 00 00 
  231cc3:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  231cca:	48 83 c0 08          	add    $0x8,%rax
  231cce:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
  231cd2:	48 83 e0 07          	and    $0x7,%rax
  231cd6:	48 83 f8 00          	cmp    $0x0,%rax
  231cda:	74 10                	je     231cec <nested_poll+0xd4>
  231cdc:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
  231ce0:	48 8d 3d b9 99 09 00 	lea    0x999b9(%rip),%rdi        # 2cb6a0 <_ZL17kSuppressionTypes+0x13cd0>
  231ce7:	e8 24 c3 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231cec:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
  231cf0:	48 c1 e8 03          	shr    $0x3,%rax
  231cf4:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231cfb:	74 09                	je     231d06 <nested_poll+0xee>
  231cfd:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
  231d01:	e8 ba 53 f8 ff       	call   1b70c0 <__asan_report_load8>
  231d06:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
  231d0a:	31 c0                	xor    %eax,%eax
  231d0c:	48 83 39 02          	cmpq   $0x2,(%rcx)
  231d10:	88 45 cf             	mov    %al,-0x31(%rbp)
  231d13:	0f 85 5b 01 00 00    	jne    231e74 <nested_poll+0x25c>
  231d19:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  231d1d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  231d21:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  231d28:	25 00 00 00 00 
  231d2d:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  231d34:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  231d38:	48 83 e0 07          	and    $0x7,%rax
  231d3c:	48 83 f8 00          	cmp    $0x0,%rax
  231d40:	74 10                	je     231d52 <nested_poll+0x13a>
  231d42:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
  231d46:	48 8d 3d 73 99 09 00 	lea    0x99973(%rip),%rdi        # 2cb6c0 <_ZL17kSuppressionTypes+0x13cf0>
  231d4d:	e8 be c2 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231d52:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
  231d56:	48 c1 e8 03          	shr    $0x3,%rax
  231d5a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231d61:	74 09                	je     231d6c <nested_poll+0x154>
  231d63:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
  231d67:	e8 54 53 f8 ff       	call   1b70c0 <__asan_report_load8>
  231d6c:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
  231d70:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
  231d74:	31 c0                	xor    %eax,%eax
  231d76:	48 3b 0a             	cmp    (%rdx),%rcx
  231d79:	88 45 cf             	mov    %al,-0x31(%rbp)
  231d7c:	0f 85 f2 00 00 00    	jne    231e74 <nested_poll+0x25c>
  231d82:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  231d89:	25 00 00 00 00 
  231d8e:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  231d95:	48 05 8c 20 00 00    	add    $0x208c,%rax
  231d9b:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
  231d9f:	48 83 e0 03          	and    $0x3,%rax
  231da3:	48 83 f8 00          	cmp    $0x0,%rax
  231da7:	74 10                	je     231db9 <nested_poll+0x1a1>
  231da9:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
  231dad:	48 8d 3d 2c 99 09 00 	lea    0x9992c(%rip),%rdi        # 2cb6e0 <_ZL17kSuppressionTypes+0x13d10>
  231db4:	e8 57 c2 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231db9:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  231dbd:	48 c1 e8 03          	shr    $0x3,%rax
  231dc1:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  231dc7:	88 45 af             	mov    %al,-0x51(%rbp)
  231dca:	3c 00                	cmp    $0x0,%al
  231dcc:	74 18                	je     231de6 <nested_poll+0x1ce>
  231dce:	8a 4d af             	mov    -0x51(%rbp),%cl
  231dd1:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  231dd5:	48 83 e0 07          	and    $0x7,%rax
  231dd9:	38 c8                	cmp    %cl,%al
  231ddb:	7c 09                	jl     231de6 <nested_poll+0x1ce>
  231ddd:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
  231de1:	e8 0a 50 f8 ff       	call   1b6df0 <__asan_report_load1>
  231de6:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  231dea:	8a 00                	mov    (%rax),%al
  231dec:	88 45 ae             	mov    %al,-0x52(%rbp)
  231def:	3c 01                	cmp    $0x1,%al
  231df1:	76 14                	jbe    231e07 <nested_poll+0x1ef>
  231df3:	8a 45 ae             	mov    -0x52(%rbp),%al
  231df6:	0f b6 c0             	movzbl %al,%eax
  231df9:	89 c6                	mov    %eax,%esi
  231dfb:	48 8d 3d fe 98 09 00 	lea    0x998fe(%rip),%rdi        # 2cb700 <_ZL17kSuppressionTypes+0x13d30>
  231e02:	e8 09 e7 fb ff       	call   1f0510 <__ubsan_handle_load_invalid_value>
  231e07:	8a 4d ae             	mov    -0x52(%rbp),%cl
  231e0a:	31 c0                	xor    %eax,%eax
  231e0c:	80 f9 00             	cmp    $0x0,%cl
  231e0f:	88 45 cf             	mov    %al,-0x31(%rbp)
  231e12:	75 60                	jne    231e74 <nested_poll+0x25c>
  231e14:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  231e1b:	25 00 00 00 00 
  231e20:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  231e27:	48 83 c0 38          	add    $0x38,%rax
  231e2b:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
  231e2f:	48 83 e0 07          	and    $0x7,%rax
  231e33:	48 83 f8 00          	cmp    $0x0,%rax
  231e37:	74 10                	je     231e49 <nested_poll+0x231>
  231e39:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
  231e3d:	48 8d 3d dc 98 09 00 	lea    0x998dc(%rip),%rdi        # 2cb720 <_ZL17kSuppressionTypes+0x13d50>
  231e44:	e8 c7 c1 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231e49:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  231e4d:	48 c1 e8 03          	shr    $0x3,%rax
  231e51:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231e58:	74 09                	je     231e63 <nested_poll+0x24b>
  231e5a:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
  231e5e:	e8 5d 52 f8 ff       	call   1b70c0 <__asan_report_load8>
  231e63:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  231e67:	48 81 38 00 04 00 00 	cmpq   $0x400,(%rax)
  231e6e:	0f 94 c0             	sete   %al
  231e71:	88 45 cf             	mov    %al,-0x31(%rbp)
  231e74:	8a 45 cf             	mov    -0x31(%rbp),%al
  231e77:	0f b6 f8             	movzbl %al,%edi
  231e7a:	83 e7 01             	and    $0x1,%edi
  231e7d:	48 8d 35 dc a9 e8 ff 	lea    -0x175624(%rip),%rsi        # bc860 <.str.14>
  231e84:	e8 af e7 ff ff       	call   230638 <require>
  231e89:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  231e8d:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
  231e91:	48 83 f9 00          	cmp    $0x0,%rcx
  231e95:	0f 95 c0             	setne  %al
  231e98:	48 83 e1 07          	and    $0x7,%rcx
  231e9c:	48 83 f9 00          	cmp    $0x0,%rcx
  231ea0:	0f 94 c1             	sete   %cl
  231ea3:	20 c8                	and    %cl,%al
  231ea5:	a8 01                	test   $0x1,%al
  231ea7:	75 10                	jne    231eb9 <nested_poll+0x2a1>
  231ea9:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
  231ead:	48 8d 3d 8c 98 09 00 	lea    0x9988c(%rip),%rdi        # 2cb740 <_ZL17kSuppressionTypes+0x13d70>
  231eb4:	e8 57 c1 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231eb9:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
  231ebd:	48 83 c1 20          	add    $0x20,%rcx
  231ec1:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
  231ec5:	48 83 f9 00          	cmp    $0x0,%rcx
  231ec9:	0f 95 c0             	setne  %al
  231ecc:	48 83 e1 07          	and    $0x7,%rcx
  231ed0:	48 83 f9 00          	cmp    $0x0,%rcx
  231ed4:	0f 94 c1             	sete   %cl
  231ed7:	20 c8                	and    %cl,%al
  231ed9:	a8 01                	test   $0x1,%al
  231edb:	75 10                	jne    231eed <nested_poll+0x2d5>
  231edd:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
  231ee1:	48 8d 3d 78 98 09 00 	lea    0x99878(%rip),%rdi        # 2cb760 <_ZL17kSuppressionTypes+0x13d90>
  231ee8:	e8 23 c1 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231eed:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  231ef1:	48 c1 e8 03          	shr    $0x3,%rax
  231ef5:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231efc:	74 09                	je     231f07 <nested_poll+0x2ef>
  231efe:	48 8b 7d 90          	mov    -0x70(%rbp),%rdi
  231f02:	e8 b9 51 f8 ff       	call   1b70c0 <__asan_report_load8>
  231f07:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
  231f0b:	31 c0                	xor    %eax,%eax
  231f0d:	48 83 39 00          	cmpq   $0x0,(%rcx)
  231f11:	88 45 8f             	mov    %al,-0x71(%rbp)
  231f14:	0f 85 6f 02 00 00    	jne    232189 <nested_poll+0x571>
  231f1a:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  231f1e:	48 89 4d 80          	mov    %rcx,-0x80(%rbp)
  231f22:	48 83 f9 00          	cmp    $0x0,%rcx
  231f26:	0f 95 c0             	setne  %al
  231f29:	48 83 e1 07          	and    $0x7,%rcx
  231f2d:	48 83 f9 00          	cmp    $0x0,%rcx
  231f31:	0f 94 c1             	sete   %cl
  231f34:	20 c8                	and    %cl,%al
  231f36:	a8 01                	test   $0x1,%al
  231f38:	75 10                	jne    231f4a <nested_poll+0x332>
  231f3a:	48 8b 75 80          	mov    -0x80(%rbp),%rsi
  231f3e:	48 8d 3d 3b 98 09 00 	lea    0x9983b(%rip),%rdi        # 2cb780 <_ZL17kSuppressionTypes+0x13db0>
  231f45:	e8 c6 c0 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231f4a:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
  231f4e:	48 83 c1 48          	add    $0x48,%rcx
  231f52:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
  231f59:	48 83 f9 00          	cmp    $0x0,%rcx
  231f5d:	0f 95 c0             	setne  %al
  231f60:	48 83 e1 07          	and    $0x7,%rcx
  231f64:	48 83 f9 00          	cmp    $0x0,%rcx
  231f68:	0f 94 c1             	sete   %cl
  231f6b:	20 c8                	and    %cl,%al
  231f6d:	a8 01                	test   $0x1,%al
  231f6f:	75 13                	jne    231f84 <nested_poll+0x36c>
  231f71:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
  231f78:	48 8d 3d 21 98 09 00 	lea    0x99821(%rip),%rdi        # 2cb7a0 <_ZL17kSuppressionTypes+0x13dd0>
  231f7f:	e8 8c c0 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231f84:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  231f8b:	48 c1 e8 03          	shr    $0x3,%rax
  231f8f:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  231f96:	74 0c                	je     231fa4 <nested_poll+0x38c>
  231f98:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
  231f9f:	e8 1c 51 f8 ff       	call   1b70c0 <__asan_report_load8>
  231fa4:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
  231fab:	31 c0                	xor    %eax,%eax
  231fad:	48 83 39 00          	cmpq   $0x0,(%rcx)
  231fb1:	88 45 8f             	mov    %al,-0x71(%rbp)
  231fb4:	0f 85 cf 01 00 00    	jne    232189 <nested_poll+0x571>
  231fba:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  231fbe:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
  231fc5:	48 83 f9 00          	cmp    $0x0,%rcx
  231fc9:	0f 95 c0             	setne  %al
  231fcc:	48 83 e1 07          	and    $0x7,%rcx
  231fd0:	48 83 f9 00          	cmp    $0x0,%rcx
  231fd4:	0f 94 c1             	sete   %cl
  231fd7:	20 c8                	and    %cl,%al
  231fd9:	a8 01                	test   $0x1,%al
  231fdb:	75 13                	jne    231ff0 <nested_poll+0x3d8>
  231fdd:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
  231fe4:	48 8d 3d d5 97 09 00 	lea    0x997d5(%rip),%rdi        # 2cb7c0 <_ZL17kSuppressionTypes+0x13df0>
  231feb:	e8 20 c0 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  231ff0:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
  231ff7:	48 83 c7 28          	add    $0x28,%rdi
  231ffb:	e8 98 63 fd ff       	call   208398 <ponyint_actormap_size>
  232000:	48 89 c1             	mov    %rax,%rcx
  232003:	31 c0                	xor    %eax,%eax
  232005:	48 83 f9 00          	cmp    $0x0,%rcx
  232009:	88 45 8f             	mov    %al,-0x71(%rbp)
  23200c:	0f 85 77 01 00 00    	jne    232189 <nested_poll+0x571>
  232012:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  232016:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
  23201d:	48 83 f9 00          	cmp    $0x0,%rcx
  232021:	0f 95 c0             	setne  %al
  232024:	48 83 e1 3f          	and    $0x3f,%rcx
  232028:	48 83 f9 00          	cmp    $0x0,%rcx
  23202c:	0f 94 c1             	sete   %cl
  23202f:	20 c8                	and    %cl,%al
  232031:	a8 01                	test   $0x1,%al
  232033:	75 13                	jne    232048 <nested_poll+0x430>
  232035:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
  23203c:	48 8d 3d 9d 97 09 00 	lea    0x9979d(%rip),%rdi        # 2cb7e0 <_ZL17kSuppressionTypes+0x13e10>
  232043:	e8 c8 bf fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232048:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
  23204f:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  232056:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
  23205d:	48 83 f9 00          	cmp    $0x0,%rcx
  232061:	0f 95 c0             	setne  %al
  232064:	48 83 e1 07          	and    $0x7,%rcx
  232068:	48 83 f9 00          	cmp    $0x0,%rcx
  23206c:	0f 94 c1             	sete   %cl
  23206f:	20 c8                	and    %cl,%al
  232071:	a8 01                	test   $0x1,%al
  232073:	75 13                	jne    232088 <nested_poll+0x470>
  232075:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
  23207c:	48 8d 3d 7d 97 09 00 	lea    0x9977d(%rip),%rdi        # 2cb800 <_ZL17kSuppressionTypes+0x13e30>
  232083:	e8 88 bf fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232088:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
  23208f:	48 83 c7 10          	add    $0x10,%rdi
  232093:	e8 b0 c0 ff ff       	call   22e148 <ponyint_objectmap_size>
  232098:	48 89 c1             	mov    %rax,%rcx
  23209b:	31 c0                	xor    %eax,%eax
  23209d:	48 83 f9 00          	cmp    $0x0,%rcx
  2320a1:	88 45 8f             	mov    %al,-0x71(%rbp)
  2320a4:	0f 85 df 00 00 00    	jne    232189 <nested_poll+0x571>
  2320aa:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  2320ae:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
  2320b5:	48 83 f9 00          	cmp    $0x0,%rcx
  2320b9:	0f 95 c0             	setne  %al
  2320bc:	48 83 e1 3f          	and    $0x3f,%rcx
  2320c0:	48 83 f9 00          	cmp    $0x0,%rcx
  2320c4:	0f 94 c1             	sete   %cl
  2320c7:	20 c8                	and    %cl,%al
  2320c9:	a8 01                	test   $0x1,%al
  2320cb:	75 13                	jne    2320e0 <nested_poll+0x4c8>
  2320cd:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  2320d4:	48 8d 3d 45 97 09 00 	lea    0x99745(%rip),%rdi        # 2cb820 <_ZL17kSuppressionTypes+0x13e50>
  2320db:	e8 30 bf fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2320e0:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
  2320e7:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  2320ee:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
  2320f5:	48 83 f9 00          	cmp    $0x0,%rcx
  2320f9:	0f 95 c0             	setne  %al
  2320fc:	48 83 e1 07          	and    $0x7,%rcx
  232100:	48 83 f9 00          	cmp    $0x0,%rcx
  232104:	0f 94 c1             	sete   %cl
  232107:	20 c8                	and    %cl,%al
  232109:	a8 01                	test   $0x1,%al
  23210b:	75 13                	jne    232120 <nested_poll+0x508>
  23210d:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
  232114:	48 8d 3d 25 97 09 00 	lea    0x99725(%rip),%rdi        # 2cb840 <_ZL17kSuppressionTypes+0x13e70>
  23211b:	e8 f0 be fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232120:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  232127:	48 83 c7 30          	add    $0x30,%rdi
  23212b:	e8 68 62 fd ff       	call   208398 <ponyint_actormap_size>
  232130:	48 89 c1             	mov    %rax,%rcx
  232133:	31 c0                	xor    %eax,%eax
  232135:	48 83 f9 00          	cmp    $0x0,%rcx
  232139:	88 45 8f             	mov    %al,-0x71(%rbp)
  23213c:	75 4b                	jne    232189 <nested_poll+0x571>
  23213e:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  232142:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
  232149:	48 83 f9 00          	cmp    $0x0,%rcx
  23214d:	0f 95 c0             	setne  %al
  232150:	48 83 e1 3f          	and    $0x3f,%rcx
  232154:	48 83 f9 00          	cmp    $0x0,%rcx
  232158:	0f 94 c1             	sete   %cl
  23215b:	20 c8                	and    %cl,%al
  23215d:	a8 01                	test   $0x1,%al
  23215f:	75 13                	jne    232174 <nested_poll+0x55c>
  232161:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
  232168:	48 8d 3d f1 96 09 00 	lea    0x996f1(%rip),%rdi        # 2cb860 <_ZL17kSuppressionTypes+0x13e90>
  23216f:	e8 9c be fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232174:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
  23217b:	48 83 c7 40          	add    $0x40,%rdi
  23217f:	e8 04 51 00 00       	call   237288 <ponyint_heap_has_finalisers>
  232184:	34 ff                	xor    $0xff,%al
  232186:	88 45 8f             	mov    %al,-0x71(%rbp)
  232189:	8a 45 8f             	mov    -0x71(%rbp),%al
  23218c:	0f b6 f8             	movzbl %al,%edi
  23218f:	83 e7 01             	and    $0x1,%edi
  232192:	48 8d 35 27 a7 e8 ff 	lea    -0x1758d9(%rip),%rsi        # bc8c0 <.str.15>
  232199:	e8 9a e4 ff ff       	call   230638 <require>
  23219e:	e8 35 ef ff ff       	call   2310d8 <check_slots>
  2321a3:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
  2321aa:	00 
  2321ab:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  2321af:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
  2321b6:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2321bd:	25 00 00 00 00 
  2321c2:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2321c9:	48 83 c0 08          	add    $0x8,%rax
  2321cd:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
  2321d4:	48 83 e0 07          	and    $0x7,%rax
  2321d8:	48 83 f8 00          	cmp    $0x0,%rax
  2321dc:	74 13                	je     2321f1 <nested_poll+0x5d9>
  2321de:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  2321e5:	48 8d 3d 94 96 09 00 	lea    0x99694(%rip),%rdi        # 2cb880 <_ZL17kSuppressionTypes+0x13eb0>
  2321ec:	e8 1f be fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2321f1:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  2321f8:	48 c1 e8 03          	shr    $0x3,%rax
  2321fc:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232203:	74 0c                	je     232211 <nested_poll+0x5f9>
  232205:	48 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%rdi
  23220c:	e8 af 4e f8 ff       	call   1b70c0 <__asan_report_load8>
  232211:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
  232218:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
  23221f:	48 3b 01             	cmp    (%rcx),%rax
  232222:	72 05                	jb     232229 <nested_poll+0x611>
  232224:	e9 f8 01 00 00       	jmp    232421 <nested_poll+0x809>
  232229:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232230:	25 00 00 00 00 
  232235:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  23223c:	48 83 c0 40          	add    $0x40,%rax
  232240:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
  232247:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  23224b:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
  232252:	48 83 f8 02          	cmp    $0x2,%rax
  232256:	72 13                	jb     23226b <nested_poll+0x653>
  232258:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
  23225f:	48 8d 3d 3a 96 09 00 	lea    0x9963a(%rip),%rdi        # 2cb8a0 <_ZL17kSuppressionTypes+0x13ed0>
  232266:	e8 f5 d6 fb ff       	call   1ef960 <__ubsan_handle_out_of_bounds>
  23226b:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  232272:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
  232279:	48 8d 14 c1          	lea    (%rcx,%rax,8),%rdx
  23227d:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
  232284:	48 6b f8 08          	imul   $0x8,%rax,%rdi
  232288:	0f 90 c2             	seto   %dl
  23228b:	48 89 ce             	mov    %rcx,%rsi
  23228e:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
  232295:	48 85 c9             	test   %rcx,%rcx
  232298:	0f 95 c0             	setne  %al
  23229b:	48 01 f9             	add    %rdi,%rcx
  23229e:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
  2322a5:	40 0f 95 c7          	setne  %dil
  2322a9:	40 30 f8             	xor    %dil,%al
  2322ac:	34 01                	xor    $0x1,%al
  2322ae:	80 f2 ff             	xor    $0xff,%dl
  2322b1:	48 39 f1             	cmp    %rsi,%rcx
  2322b4:	0f 93 c1             	setae  %cl
  2322b7:	20 d1                	and    %dl,%cl
  2322b9:	20 c8                	and    %cl,%al
  2322bb:	a8 01                	test   $0x1,%al
  2322bd:	75 1a                	jne    2322d9 <nested_poll+0x6c1>
  2322bf:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
  2322c6:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
  2322cd:	48 8d 3d ec 95 09 00 	lea    0x995ec(%rip),%rdi        # 2cb8c0 <_ZL17kSuppressionTypes+0x13ef0>
  2322d4:	e8 a7 f6 fb ff       	call   1f1980 <__ubsan_handle_pointer_overflow>
  2322d9:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
  2322e0:	48 83 f9 00          	cmp    $0x0,%rcx
  2322e4:	0f 95 c0             	setne  %al
  2322e7:	48 83 e1 07          	and    $0x7,%rcx
  2322eb:	48 83 f9 00          	cmp    $0x0,%rcx
  2322ef:	0f 94 c1             	sete   %cl
  2322f2:	20 c8                	and    %cl,%al
  2322f4:	a8 01                	test   $0x1,%al
  2322f6:	75 13                	jne    23230b <nested_poll+0x6f3>
  2322f8:	48 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%rsi
  2322ff:	48 8d 3d ca 95 09 00 	lea    0x995ca(%rip),%rdi        # 2cb8d0 <_ZL17kSuppressionTypes+0x13f00>
  232306:	e8 05 bd fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  23230b:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
  232312:	48 c1 e8 03          	shr    $0x3,%rax
  232316:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  23231d:	74 0c                	je     23232b <nested_poll+0x713>
  23231f:	48 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%rdi
  232326:	e8 95 4d f8 ff       	call   1b70c0 <__asan_report_load8>
  23232b:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
  232332:	48 83 38 00          	cmpq   $0x0,(%rax)
  232336:	0f 84 d2 00 00 00    	je     23240e <nested_poll+0x7f6>
  23233c:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  232340:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  232347:	89 c1                	mov    %eax,%ecx
  232349:	89 8d 0c ff ff ff    	mov    %ecx,-0xf4(%rbp)
  23234f:	48 83 f8 1f          	cmp    $0x1f,%rax
  232353:	76 18                	jbe    23236d <nested_poll+0x755>
  232355:	48 8b 95 00 ff ff ff 	mov    -0x100(%rbp),%rdx
  23235c:	48 8d 3d 8d 95 09 00 	lea    0x9958d(%rip),%rdi        # 2cb8f0 <_ZL17kSuppressionTypes+0x13f20>
  232363:	be 01 00 00 00       	mov    $0x1,%esi
  232368:	e8 83 d0 fb ff       	call   1ef3f0 <__ubsan_handle_shift_out_of_bounds>
  23236d:	8b 8d 0c ff ff ff    	mov    -0xf4(%rbp),%ecx
  232373:	b8 01 00 00 00       	mov    $0x1,%eax
  232378:	d3 e0                	shl    %cl,%eax
  23237a:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%rbp)
  232380:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232387:	25 00 00 00 00 
  23238c:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232393:	48 05 80 20 00 00    	add    $0x2080,%rax
  232399:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
  2323a0:	48 83 e0 07          	and    $0x7,%rax
  2323a4:	48 83 f8 00          	cmp    $0x0,%rax
  2323a8:	74 13                	je     2323bd <nested_poll+0x7a5>
  2323aa:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
  2323b1:	48 8d 3d 58 95 09 00 	lea    0x99558(%rip),%rdi        # 2cb910 <_ZL17kSuppressionTypes+0x13f40>
  2323b8:	e8 53 bc fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2323bd:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  2323c4:	48 c1 e8 03          	shr    $0x3,%rax
  2323c8:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  2323ce:	88 85 f3 fe ff ff    	mov    %al,-0x10d(%rbp)
  2323d4:	3c 00                	cmp    $0x0,%al
  2323d6:	74 25                	je     2323fd <nested_poll+0x7e5>
  2323d8:	8a 8d f3 fe ff ff    	mov    -0x10d(%rbp),%cl
  2323de:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  2323e5:	48 83 e0 07          	and    $0x7,%rax
  2323e9:	48 83 c0 03          	add    $0x3,%rax
  2323ed:	38 c8                	cmp    %cl,%al
  2323ef:	7c 0c                	jl     2323fd <nested_poll+0x7e5>
  2323f1:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
  2323f8:	e8 d3 4b f8 ff       	call   1b6fd0 <__asan_report_load4>
  2323fd:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  232404:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
  23240a:	0b 08                	or     (%rax),%ecx
  23240c:	89 08                	mov    %ecx,(%rax)
  23240e:	eb 00                	jmp    232410 <nested_poll+0x7f8>
  232410:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  232414:	48 83 c0 01          	add    $0x1,%rax
  232418:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
  23241c:	e9 8a fd ff ff       	jmp    2321ab <nested_poll+0x593>
  232421:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  232425:	48 89 8d e8 fe ff ff 	mov    %rcx,-0x118(%rbp)
  23242c:	48 83 f9 00          	cmp    $0x0,%rcx
  232430:	0f 95 c0             	setne  %al
  232433:	48 83 e1 3f          	and    $0x3f,%rcx
  232437:	48 83 f9 00          	cmp    $0x0,%rcx
  23243b:	0f 94 c1             	sete   %cl
  23243e:	20 c8                	and    %cl,%al
  232440:	a8 01                	test   $0x1,%al
  232442:	75 13                	jne    232457 <nested_poll+0x83f>
  232444:	48 8b b5 e8 fe ff ff 	mov    -0x118(%rbp),%rsi
  23244b:	48 8d 3d de 94 09 00 	lea    0x994de(%rip),%rdi        # 2cb930 <_ZL17kSuppressionTypes+0x13f60>
  232452:	e8 b9 bb fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232457:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
  23245e:	48 83 c1 40          	add    $0x40,%rcx
  232462:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
  232469:	48 83 f9 00          	cmp    $0x0,%rcx
  23246d:	0f 95 c0             	setne  %al
  232470:	48 83 e1 3f          	and    $0x3f,%rcx
  232474:	48 83 f9 00          	cmp    $0x0,%rcx
  232478:	0f 94 c1             	sete   %cl
  23247b:	20 c8                	and    %cl,%al
  23247d:	a8 01                	test   $0x1,%al
  23247f:	75 13                	jne    232494 <nested_poll+0x87c>
  232481:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
  232488:	48 8d 3d c1 94 09 00 	lea    0x994c1(%rip),%rdi        # 2cb950 <_ZL17kSuppressionTypes+0x13f80>
  23248f:	e8 7c bb fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232494:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
  23249b:	48 81 c1 80 00 00 00 	add    $0x80,%rcx
  2324a2:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
  2324a9:	48 83 f9 00          	cmp    $0x0,%rcx
  2324ad:	0f 95 c0             	setne  %al
  2324b0:	48 83 e1 3f          	and    $0x3f,%rcx
  2324b4:	48 83 f9 00          	cmp    $0x0,%rcx
  2324b8:	0f 94 c1             	sete   %cl
  2324bb:	20 c8                	and    %cl,%al
  2324bd:	a8 01                	test   $0x1,%al
  2324bf:	75 13                	jne    2324d4 <nested_poll+0x8bc>
  2324c1:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  2324c8:	48 8d 3d a1 94 09 00 	lea    0x994a1(%rip),%rdi        # 2cb970 <_ZL17kSuppressionTypes+0x13fa0>
  2324cf:	e8 3c bb fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2324d4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  2324db:	48 c1 e8 03          	shr    $0x3,%rax
  2324df:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2324e6:	74 0c                	je     2324f4 <nested_poll+0x8dc>
  2324e8:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  2324ef:	e8 cc 4b f8 ff       	call   1b70c0 <__asan_report_load8>
  2324f4:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  2324fb:	48 8b 00             	mov    (%rax),%rax
  2324fe:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
  232505:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23250c:	25 00 00 00 00 
  232511:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232518:	48 83 c0 20          	add    $0x20,%rax
  23251c:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
  232523:	48 83 e0 07          	and    $0x7,%rax
  232527:	48 83 f8 00          	cmp    $0x0,%rax
  23252b:	74 13                	je     232540 <nested_poll+0x928>
  23252d:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
  232534:	48 8d 3d 55 94 09 00 	lea    0x99455(%rip),%rdi        # 2cb990 <_ZL17kSuppressionTypes+0x13fc0>
  23253b:	e8 d0 ba fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232540:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  232547:	48 c1 e8 03          	shr    $0x3,%rax
  23254b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232552:	74 0c                	je     232560 <nested_poll+0x948>
  232554:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
  23255b:	e8 60 4b f8 ff       	call   1b70c0 <__asan_report_load8>
  232560:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
  232567:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
  23256e:	48 3b 01             	cmp    (%rcx),%rax
  232571:	0f 94 c0             	sete   %al
  232574:	0f b6 f8             	movzbl %al,%edi
  232577:	83 e7 01             	and    $0x1,%edi
  23257a:	48 8d 35 7f a3 e8 ff 	lea    -0x175c81(%rip),%rsi        # bc900 <.str.16>
  232581:	e8 b2 e0 ff ff       	call   230638 <require>
  232586:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  23258a:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
  232591:	48 83 f9 00          	cmp    $0x0,%rcx
  232595:	0f 95 c0             	setne  %al
  232598:	48 83 e1 3f          	and    $0x3f,%rcx
  23259c:	48 83 f9 00          	cmp    $0x0,%rcx
  2325a0:	0f 94 c1             	sete   %cl
  2325a3:	20 c8                	and    %cl,%al
  2325a5:	a8 01                	test   $0x1,%al
  2325a7:	75 13                	jne    2325bc <nested_poll+0x9a4>
  2325a9:	48 8b b5 c0 fe ff ff 	mov    -0x140(%rbp),%rsi
  2325b0:	48 8d 3d f9 93 09 00 	lea    0x993f9(%rip),%rdi        # 2cb9b0 <_ZL17kSuppressionTypes+0x13fe0>
  2325b7:	e8 54 ba fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2325bc:	48 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%rcx
  2325c3:	48 83 c1 40          	add    $0x40,%rcx
  2325c7:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
  2325ce:	48 83 f9 00          	cmp    $0x0,%rcx
  2325d2:	0f 95 c0             	setne  %al
  2325d5:	48 83 e1 3f          	and    $0x3f,%rcx
  2325d9:	48 83 f9 00          	cmp    $0x0,%rcx
  2325dd:	0f 94 c1             	sete   %cl
  2325e0:	20 c8                	and    %cl,%al
  2325e2:	a8 01                	test   $0x1,%al
  2325e4:	75 13                	jne    2325f9 <nested_poll+0x9e1>
  2325e6:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
  2325ed:	48 8d 3d dc 93 09 00 	lea    0x993dc(%rip),%rdi        # 2cb9d0 <_ZL17kSuppressionTypes+0x14000>
  2325f4:	e8 17 ba fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2325f9:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
  232600:	48 83 c1 78          	add    $0x78,%rcx
  232604:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
  23260b:	48 83 f9 00          	cmp    $0x0,%rcx
  23260f:	0f 95 c0             	setne  %al
  232612:	48 83 e1 07          	and    $0x7,%rcx
  232616:	48 83 f9 00          	cmp    $0x0,%rcx
  23261a:	0f 94 c1             	sete   %cl
  23261d:	20 c8                	and    %cl,%al
  23261f:	a8 01                	test   $0x1,%al
  232621:	75 13                	jne    232636 <nested_poll+0xa1e>
  232623:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
  23262a:	48 8d 3d bf 93 09 00 	lea    0x993bf(%rip),%rdi        # 2cb9f0 <_ZL17kSuppressionTypes+0x14020>
  232631:	e8 da b9 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232636:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  23263d:	48 c1 e8 03          	shr    $0x3,%rax
  232641:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232648:	74 0c                	je     232656 <nested_poll+0xa3e>
  23264a:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
  232651:	e8 6a 4a f8 ff       	call   1b70c0 <__asan_report_load8>
  232656:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  23265d:	48 8b 00             	mov    (%rax),%rax
  232660:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
  232667:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23266e:	25 00 00 00 00 
  232673:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  23267a:	48 83 c0 28          	add    $0x28,%rax
  23267e:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
  232685:	48 83 e0 07          	and    $0x7,%rax
  232689:	48 83 f8 00          	cmp    $0x0,%rax
  23268d:	74 13                	je     2326a2 <nested_poll+0xa8a>
  23268f:	48 8b b5 a8 fe ff ff 	mov    -0x158(%rbp),%rsi
  232696:	48 8d 3d 73 93 09 00 	lea    0x99373(%rip),%rdi        # 2cba10 <_ZL17kSuppressionTypes+0x14040>
  23269d:	e8 6e b9 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2326a2:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
  2326a9:	48 c1 e8 03          	shr    $0x3,%rax
  2326ad:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2326b4:	74 0c                	je     2326c2 <nested_poll+0xaaa>
  2326b6:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
  2326bd:	e8 ae 4e f8 ff       	call   1b7570 <__asan_report_store8>
  2326c2:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
  2326c9:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
  2326d0:	48 89 08             	mov    %rcx,(%rax)
  2326d3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2326da:	25 00 00 00 00 
  2326df:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2326e6:	48 05 88 20 00 00    	add    $0x2088,%rax
  2326ec:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
  2326f3:	48 83 e0 07          	and    $0x7,%rax
  2326f7:	48 83 f8 00          	cmp    $0x0,%rax
  2326fb:	74 13                	je     232710 <nested_poll+0xaf8>
  2326fd:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  232704:	48 8d 3d 25 93 09 00 	lea    0x99325(%rip),%rdi        # 2cba30 <_ZL17kSuppressionTypes+0x14060>
  23270b:	e8 00 b9 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232710:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  232717:	48 c1 e8 03          	shr    $0x3,%rax
  23271b:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  232721:	88 85 97 fe ff ff    	mov    %al,-0x169(%rbp)
  232727:	3c 00                	cmp    $0x0,%al
  232729:	74 21                	je     23274c <nested_poll+0xb34>
  23272b:	8a 8d 97 fe ff ff    	mov    -0x169(%rbp),%cl
  232731:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  232738:	48 83 e0 07          	and    $0x7,%rax
  23273c:	38 c8                	cmp    %cl,%al
  23273e:	7c 0c                	jl     23274c <nested_poll+0xb34>
  232740:	48 8b bd 98 fe ff ff 	mov    -0x168(%rbp),%rdi
  232747:	e8 a4 46 f8 ff       	call   1b6df0 <__asan_report_load1>
  23274c:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  232753:	8a 00                	mov    (%rax),%al
  232755:	88 85 96 fe ff ff    	mov    %al,-0x16a(%rbp)
  23275b:	3c 01                	cmp    $0x1,%al
  23275d:	76 17                	jbe    232776 <nested_poll+0xb5e>
  23275f:	8a 85 96 fe ff ff    	mov    -0x16a(%rbp),%al
  232765:	0f b6 c0             	movzbl %al,%eax
  232768:	89 c6                	mov    %eax,%esi
  23276a:	48 8d 3d df 92 09 00 	lea    0x992df(%rip),%rdi        # 2cba50 <_ZL17kSuppressionTypes+0x14080>
  232771:	e8 9a dd fb ff       	call   1f0510 <__ubsan_handle_load_invalid_value>
  232776:	8a 85 96 fe ff ff    	mov    -0x16a(%rbp),%al
  23277c:	3c 00                	cmp    $0x0,%al
  23277e:	0f 84 9e 02 00 00    	je     232a22 <nested_poll+0xe0a>
  232784:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23278b:	25 00 00 00 00 
  232790:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232797:	48 83 c0 28          	add    $0x28,%rax
  23279b:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
  2327a2:	48 83 e0 07          	and    $0x7,%rax
  2327a6:	48 83 f8 00          	cmp    $0x0,%rax
  2327aa:	74 13                	je     2327bf <nested_poll+0xba7>
  2327ac:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
  2327b3:	48 8d 3d b6 92 09 00 	lea    0x992b6(%rip),%rdi        # 2cba70 <_ZL17kSuppressionTypes+0x140a0>
  2327ba:	e8 51 b8 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  2327bf:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  2327c6:	48 c1 e8 03          	shr    $0x3,%rax
  2327ca:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2327d1:	74 0c                	je     2327df <nested_poll+0xbc7>
  2327d3:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
  2327da:	e8 e1 48 f8 ff       	call   1b70c0 <__asan_report_load8>
  2327df:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  2327e6:	48 8b 00             	mov    (%rax),%rax
  2327e9:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
  2327f0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2327f7:	25 00 00 00 00 
  2327fc:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232803:	48 83 c0 20          	add    $0x20,%rax
  232807:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
  23280e:	48 83 e0 07          	and    $0x7,%rax
  232812:	48 83 f8 00          	cmp    $0x0,%rax
  232816:	74 13                	je     23282b <nested_poll+0xc13>
  232818:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
  23281f:	48 8d 3d 6a 92 09 00 	lea    0x9926a(%rip),%rdi        # 2cba90 <_ZL17kSuppressionTypes+0x140c0>
  232826:	e8 e5 b7 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  23282b:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
  232832:	48 c1 e8 03          	shr    $0x3,%rax
  232836:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  23283d:	74 0c                	je     23284b <nested_poll+0xc33>
  23283f:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
  232846:	e8 75 48 f8 ff       	call   1b70c0 <__asan_report_load8>
  23284b:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
  232852:	48 8b 8d 80 fe ff ff 	mov    -0x180(%rbp),%rcx
  232859:	48 3b 01             	cmp    (%rcx),%rax
  23285c:	0f 86 c0 01 00 00    	jbe    232a22 <nested_poll+0xe0a>
  232862:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232869:	25 00 00 00 00 
  23286e:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232875:	48 05 80 20 00 00    	add    $0x2080,%rax
  23287b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
  232882:	48 83 e0 07          	and    $0x7,%rax
  232886:	48 83 f8 00          	cmp    $0x0,%rax
  23288a:	74 13                	je     23289f <nested_poll+0xc87>
  23288c:	48 8b b5 70 fe ff ff 	mov    -0x190(%rbp),%rsi
  232893:	48 8d 3d 16 92 09 00 	lea    0x99216(%rip),%rdi        # 2cbab0 <_ZL17kSuppressionTypes+0x140e0>
  23289a:	e8 71 b7 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  23289f:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  2328a6:	48 c1 e8 03          	shr    $0x3,%rax
  2328aa:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  2328b0:	88 85 6f fe ff ff    	mov    %al,-0x191(%rbp)
  2328b6:	3c 00                	cmp    $0x0,%al
  2328b8:	74 25                	je     2328df <nested_poll+0xcc7>
  2328ba:	8a 8d 6f fe ff ff    	mov    -0x191(%rbp),%cl
  2328c0:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  2328c7:	48 83 e0 07          	and    $0x7,%rax
  2328cb:	48 83 c0 03          	add    $0x3,%rax
  2328cf:	38 c8                	cmp    %cl,%al
  2328d1:	7c 0c                	jl     2328df <nested_poll+0xcc7>
  2328d3:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
  2328da:	e8 f1 46 f8 ff       	call   1b6fd0 <__asan_report_load4>
  2328df:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  2328e6:	83 38 03             	cmpl   $0x3,(%rax)
  2328e9:	0f 85 33 01 00 00    	jne    232a22 <nested_poll+0xe0a>
  2328ef:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  2328f3:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
  2328fa:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  2328fe:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
  232905:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23290c:	25 00 00 00 00 
  232911:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232918:	48 83 c0 08          	add    $0x8,%rax
  23291c:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
  232923:	48 83 e0 07          	and    $0x7,%rax
  232927:	48 83 f8 00          	cmp    $0x0,%rax
  23292b:	74 13                	je     232940 <nested_poll+0xd28>
  23292d:	48 8b b5 60 fe ff ff 	mov    -0x1a0(%rbp),%rsi
  232934:	48 8d 3d 95 91 09 00 	lea    0x99195(%rip),%rdi        # 2cbad0 <_ZL17kSuppressionTypes+0x14100>
  23293b:	e8 d0 b6 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232940:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  232947:	48 c1 e8 03          	shr    $0x3,%rax
  23294b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232952:	74 0c                	je     232960 <nested_poll+0xd48>
  232954:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
  23295b:	e8 60 47 f8 ff       	call   1b70c0 <__asan_report_load8>
  232960:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  232967:	48 8b 00             	mov    (%rax),%rax
  23296a:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
  232971:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232978:	25 00 00 00 00 
  23297d:	48 8b bd 50 fe ff ff 	mov    -0x1b0(%rbp),%rdi
  232984:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
  23298b:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
  232992:	48 8d 88 60 df ff ff 	lea    -0x20a0(%rax),%rcx
  232999:	48 83 c1 40          	add    $0x40,%rcx
  23299d:	4c 8d 05 24 05 00 00 	lea    0x524(%rip),%r8        # 232ec8 <check_marks>
  2329a4:	e8 4f 03 fc ff       	call   1f2cf8 <probe_collect_roots>
  2329a9:	88 85 3f fe ff ff    	mov    %al,-0x1c1(%rbp)
  2329af:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2329b6:	25 00 00 00 00 
  2329bb:	8a 8d 3f fe ff ff    	mov    -0x1c1(%rbp),%cl
  2329c1:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2329c8:	48 05 8b 20 00 00    	add    $0x208b,%rax
  2329ce:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
  2329d5:	80 e1 01             	and    $0x1,%cl
  2329d8:	88 8d 4e fe ff ff    	mov    %cl,-0x1b2(%rbp)
  2329de:	48 c1 e8 03          	shr    $0x3,%rax
  2329e2:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  2329e8:	88 85 4f fe ff ff    	mov    %al,-0x1b1(%rbp)
  2329ee:	3c 00                	cmp    $0x0,%al
  2329f0:	74 21                	je     232a13 <nested_poll+0xdfb>
  2329f2:	8a 8d 4f fe ff ff    	mov    -0x1b1(%rbp),%cl
  2329f8:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  2329ff:	48 83 e0 07          	and    $0x7,%rax
  232a03:	38 c8                	cmp    %cl,%al
  232a05:	7c 0c                	jl     232a13 <nested_poll+0xdfb>
  232a07:	48 8b bd 40 fe ff ff 	mov    -0x1c0(%rbp),%rdi
  232a0e:	e8 8d 48 f8 ff       	call   1b72a0 <__asan_report_store1>
  232a13:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  232a1a:	8a 8d 4e fe ff ff    	mov    -0x1b2(%rbp),%cl
  232a20:	88 08                	mov    %cl,(%rax)
  232a22:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  232a26:	48 89 8d 28 fe ff ff 	mov    %rcx,-0x1d8(%rbp)
  232a2d:	48 83 f9 00          	cmp    $0x0,%rcx
  232a31:	0f 95 c0             	setne  %al
  232a34:	48 83 e1 3f          	and    $0x3f,%rcx
  232a38:	48 83 f9 00          	cmp    $0x0,%rcx
  232a3c:	0f 94 c1             	sete   %cl
  232a3f:	20 c8                	and    %cl,%al
  232a41:	a8 01                	test   $0x1,%al
  232a43:	75 13                	jne    232a58 <nested_poll+0xe40>
  232a45:	48 8b b5 28 fe ff ff 	mov    -0x1d8(%rbp),%rsi
  232a4c:	48 8d 3d 9d 90 09 00 	lea    0x9909d(%rip),%rdi        # 2cbaf0 <_ZL17kSuppressionTypes+0x14120>
  232a53:	e8 b8 b5 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232a58:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
  232a5f:	48 83 c1 40          	add    $0x40,%rcx
  232a63:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
  232a6a:	48 83 f9 00          	cmp    $0x0,%rcx
  232a6e:	0f 95 c0             	setne  %al
  232a71:	48 83 e1 3f          	and    $0x3f,%rcx
  232a75:	48 83 f9 00          	cmp    $0x0,%rcx
  232a79:	0f 94 c1             	sete   %cl
  232a7c:	20 c8                	and    %cl,%al
  232a7e:	a8 01                	test   $0x1,%al
  232a80:	75 13                	jne    232a95 <nested_poll+0xe7d>
  232a82:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
  232a89:	48 8d 3d 80 90 09 00 	lea    0x99080(%rip),%rdi        # 2cbb10 <_ZL17kSuppressionTypes+0x14140>
  232a90:	e8 7b b5 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232a95:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
  232a9c:	48 83 c1 78          	add    $0x78,%rcx
  232aa0:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
  232aa7:	48 83 f9 00          	cmp    $0x0,%rcx
  232aab:	0f 95 c0             	setne  %al
  232aae:	48 83 e1 07          	and    $0x7,%rcx
  232ab2:	48 83 f9 00          	cmp    $0x0,%rcx
  232ab6:	0f 94 c1             	sete   %cl
  232ab9:	20 c8                	and    %cl,%al
  232abb:	a8 01                	test   $0x1,%al
  232abd:	75 13                	jne    232ad2 <nested_poll+0xeba>
  232abf:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
  232ac6:	48 8d 3d 63 90 09 00 	lea    0x99063(%rip),%rdi        # 2cbb30 <_ZL17kSuppressionTypes+0x14160>
  232acd:	e8 3e b5 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232ad2:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
  232ad9:	48 c1 e8 03          	shr    $0x3,%rax
  232add:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232ae4:	74 0c                	je     232af2 <nested_poll+0xeda>
  232ae6:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
  232aed:	e8 ce 45 f8 ff       	call   1b70c0 <__asan_report_load8>
  232af2:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
  232af9:	48 8b 00             	mov    (%rax),%rax
  232afc:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
  232b03:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232b0a:	25 00 00 00 00 
  232b0f:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232b16:	48 83 c0 30          	add    $0x30,%rax
  232b1a:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
  232b21:	48 83 e0 07          	and    $0x7,%rax
  232b25:	48 83 f8 00          	cmp    $0x0,%rax
  232b29:	74 13                	je     232b3e <nested_poll+0xf26>
  232b2b:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
  232b32:	48 8d 3d 17 90 09 00 	lea    0x99017(%rip),%rdi        # 2cbb50 <_ZL17kSuppressionTypes+0x14180>
  232b39:	e8 d2 b4 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232b3e:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
  232b45:	48 c1 e8 03          	shr    $0x3,%rax
  232b49:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232b50:	74 0c                	je     232b5e <nested_poll+0xf46>
  232b52:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
  232b59:	e8 12 4a f8 ff       	call   1b7570 <__asan_report_store8>
  232b5e:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
  232b65:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
  232b6c:	48 89 08             	mov    %rcx,(%rax)
  232b6f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232b76:	25 00 00 00 00 
  232b7b:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232b82:	48 05 8b 20 00 00    	add    $0x208b,%rax
  232b88:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
  232b8f:	48 c1 e8 03          	shr    $0x3,%rax
  232b93:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  232b99:	88 85 07 fe ff ff    	mov    %al,-0x1f9(%rbp)
  232b9f:	3c 00                	cmp    $0x0,%al
  232ba1:	74 21                	je     232bc4 <nested_poll+0xfac>
  232ba3:	8a 8d 07 fe ff ff    	mov    -0x1f9(%rbp),%cl
  232ba9:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
  232bb0:	48 83 e0 07          	and    $0x7,%rax
  232bb4:	38 c8                	cmp    %cl,%al
  232bb6:	7c 0c                	jl     232bc4 <nested_poll+0xfac>
  232bb8:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
  232bbf:	e8 2c 42 f8 ff       	call   1b6df0 <__asan_report_load1>
  232bc4:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
  232bcb:	8a 00                	mov    (%rax),%al
  232bcd:	88 85 f7 fd ff ff    	mov    %al,-0x209(%rbp)
  232bd3:	3c 01                	cmp    $0x1,%al
  232bd5:	76 17                	jbe    232bee <nested_poll+0xfd6>
  232bd7:	8a 85 f7 fd ff ff    	mov    -0x209(%rbp),%al
  232bdd:	0f b6 c0             	movzbl %al,%eax
  232be0:	89 c6                	mov    %eax,%esi
  232be2:	48 8d 3d 87 8f 09 00 	lea    0x98f87(%rip),%rdi        # 2cbb70 <_ZL17kSuppressionTypes+0x141a0>
  232be9:	e8 22 d9 fb ff       	call   1f0510 <__ubsan_handle_load_invalid_value>
  232bee:	8a 8d f7 fd ff ff    	mov    -0x209(%rbp),%cl
  232bf4:	b0 01                	mov    $0x1,%al
  232bf6:	80 f9 00             	cmp    $0x0,%cl
  232bf9:	88 85 f6 fd ff ff    	mov    %al,-0x20a(%rbp)
  232bff:	0f 84 0f 02 00 00    	je     232e14 <nested_poll+0x11fc>
  232c05:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232c0c:	25 00 00 00 00 
  232c11:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232c18:	48 05 84 20 00 00    	add    $0x2084,%rax
  232c1e:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
  232c25:	48 83 e0 03          	and    $0x3,%rax
  232c29:	48 83 f8 00          	cmp    $0x0,%rax
  232c2d:	74 13                	je     232c42 <nested_poll+0x102a>
  232c2f:	48 8b b5 e8 fd ff ff 	mov    -0x218(%rbp),%rsi
  232c36:	48 8d 3d 53 8f 09 00 	lea    0x98f53(%rip),%rdi        # 2cbb90 <_ZL17kSuppressionTypes+0x141c0>
  232c3d:	e8 ce b3 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232c42:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
  232c49:	48 c1 e8 03          	shr    $0x3,%rax
  232c4d:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  232c53:	88 85 e7 fd ff ff    	mov    %al,-0x219(%rbp)
  232c59:	3c 00                	cmp    $0x0,%al
  232c5b:	74 25                	je     232c82 <nested_poll+0x106a>
  232c5d:	8a 8d e7 fd ff ff    	mov    -0x219(%rbp),%cl
  232c63:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
  232c6a:	48 83 e0 07          	and    $0x7,%rax
  232c6e:	48 83 c0 03          	add    $0x3,%rax
  232c72:	38 c8                	cmp    %cl,%al
  232c74:	7c 0c                	jl     232c82 <nested_poll+0x106a>
  232c76:	48 8b bd e8 fd ff ff 	mov    -0x218(%rbp),%rdi
  232c7d:	e8 4e 43 f8 ff       	call   1b6fd0 <__asan_report_load4>
  232c82:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
  232c89:	31 c0                	xor    %eax,%eax
  232c8b:	83 39 03             	cmpl   $0x3,(%rcx)
  232c8e:	88 85 e6 fd ff ff    	mov    %al,-0x21a(%rbp)
  232c94:	0f 85 6e 01 00 00    	jne    232e08 <nested_poll+0x11f0>
  232c9a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232ca1:	25 00 00 00 00 
  232ca6:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232cad:	48 83 c0 30          	add    $0x30,%rax
  232cb1:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
  232cb8:	48 83 e0 07          	and    $0x7,%rax
  232cbc:	48 83 f8 00          	cmp    $0x0,%rax
  232cc0:	74 13                	je     232cd5 <nested_poll+0x10bd>
  232cc2:	48 8b b5 d8 fd ff ff 	mov    -0x228(%rbp),%rsi
  232cc9:	48 8d 3d e0 8e 09 00 	lea    0x98ee0(%rip),%rdi        # 2cbbb0 <_ZL17kSuppressionTypes+0x141e0>
  232cd0:	e8 3b b3 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232cd5:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
  232cdc:	48 c1 e8 03          	shr    $0x3,%rax
  232ce0:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232ce7:	74 0c                	je     232cf5 <nested_poll+0x10dd>
  232ce9:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
  232cf0:	e8 cb 43 f8 ff       	call   1b70c0 <__asan_report_load8>
  232cf5:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
  232cfc:	48 8b 00             	mov    (%rax),%rax
  232cff:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
  232d06:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232d0d:	25 00 00 00 00 
  232d12:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232d19:	48 83 c0 10          	add    $0x10,%rax
  232d1d:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
  232d24:	b0 01                	mov    $0x1,%al
  232d26:	a8 01                	test   $0x1,%al
  232d28:	75 11                	jne    232d3b <nested_poll+0x1123>
  232d2a:	48 8d 3d 9f 8e 09 00 	lea    0x98e9f(%rip),%rdi        # 2cbbd0 <_ZL17kSuppressionTypes+0x14200>
  232d31:	be 01 00 00 00       	mov    $0x1,%esi
  232d36:	e8 25 cc fb ff       	call   1ef960 <__ubsan_handle_out_of_bounds>
  232d3b:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
  232d42:	48 85 d2             	test   %rdx,%rdx
  232d45:	0f 95 c0             	setne  %al
  232d48:	48 89 d1             	mov    %rdx,%rcx
  232d4b:	48 83 c1 08          	add    $0x8,%rcx
  232d4f:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
  232d56:	48 89 d6             	mov    %rdx,%rsi
  232d59:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
  232d60:	48 89 ce             	mov    %rcx,%rsi
  232d63:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
  232d6a:	40 0f 95 c6          	setne  %sil
  232d6e:	40 30 f0             	xor    %sil,%al
  232d71:	34 01                	xor    $0x1,%al
  232d73:	48 29 d1             	sub    %rdx,%rcx
  232d76:	0f 93 c1             	setae  %cl
  232d79:	80 e1 ff             	and    $0xff,%cl
  232d7c:	20 c8                	and    %cl,%al
  232d7e:	a8 01                	test   $0x1,%al
  232d80:	75 1a                	jne    232d9c <nested_poll+0x1184>
  232d82:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
  232d89:	48 8b b5 b8 fd ff ff 	mov    -0x248(%rbp),%rsi
  232d90:	48 8d 3d 59 8e 09 00 	lea    0x98e59(%rip),%rdi        # 2cbbf0 <_ZL17kSuppressionTypes+0x14220>
  232d97:	e8 e4 eb fb ff       	call   1f1980 <__ubsan_handle_pointer_overflow>
  232d9c:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
  232da3:	48 83 f9 00          	cmp    $0x0,%rcx
  232da7:	0f 95 c0             	setne  %al
  232daa:	48 83 e1 07          	and    $0x7,%rcx
  232dae:	48 83 f9 00          	cmp    $0x0,%rcx
  232db2:	0f 94 c1             	sete   %cl
  232db5:	20 c8                	and    %cl,%al
  232db7:	a8 01                	test   $0x1,%al
  232db9:	75 13                	jne    232dce <nested_poll+0x11b6>
  232dbb:	48 8b b5 b0 fd ff ff 	mov    -0x250(%rbp),%rsi
  232dc2:	48 8d 3d 37 8e 09 00 	lea    0x98e37(%rip),%rdi        # 2cbc00 <_ZL17kSuppressionTypes+0x14230>
  232dc9:	e8 42 b2 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232dce:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
  232dd5:	48 c1 e8 03          	shr    $0x3,%rax
  232dd9:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  232de0:	74 0c                	je     232dee <nested_poll+0x11d6>
  232de2:	48 8b bd b0 fd ff ff 	mov    -0x250(%rbp),%rdi
  232de9:	e8 d2 42 f8 ff       	call   1b70c0 <__asan_report_load8>
  232dee:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
  232df5:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
  232dfc:	48 3b 01             	cmp    (%rcx),%rax
  232dff:	0f 94 c0             	sete   %al
  232e02:	88 85 e6 fd ff ff    	mov    %al,-0x21a(%rbp)
  232e08:	8a 85 e6 fd ff ff    	mov    -0x21a(%rbp),%al
  232e0e:	88 85 f6 fd ff ff    	mov    %al,-0x20a(%rbp)
  232e14:	8a 85 f6 fd ff ff    	mov    -0x20a(%rbp),%al
  232e1a:	0f b6 f8             	movzbl %al,%edi
  232e1d:	83 e7 01             	and    $0x1,%edi
  232e20:	48 8d 35 19 9b e8 ff 	lea    -0x1764e7(%rip),%rsi        # bc940 <.str.17>
  232e27:	e8 0c d8 ff ff       	call   230638 <require>
  232e2c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  232e33:	25 00 00 00 00 
  232e38:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  232e3f:	48 05 8c 20 00 00    	add    $0x208c,%rax
  232e45:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
  232e4c:	48 83 e0 03          	and    $0x3,%rax
  232e50:	48 83 f8 00          	cmp    $0x0,%rax
  232e54:	74 13                	je     232e69 <nested_poll+0x1251>
  232e56:	48 8b b5 a8 fd ff ff 	mov    -0x258(%rbp),%rsi
  232e5d:	48 8d 3d bc 8d 09 00 	lea    0x98dbc(%rip),%rdi        # 2cbc20 <_ZL17kSuppressionTypes+0x14250>
  232e64:	e8 a7 b1 fb ff       	call   1ee010 <__ubsan_handle_type_mismatch_v1>
  232e69:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  232e70:	48 c1 e8 03          	shr    $0x3,%rax
  232e74:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  232e7a:	88 85 a7 fd ff ff    	mov    %al,-0x259(%rbp)
  232e80:	3c 00                	cmp    $0x0,%al
  232e82:	74 21                	je     232ea5 <nested_poll+0x128d>
  232e84:	8a 8d a7 fd ff ff    	mov    -0x259(%rbp),%cl
  232e8a:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  232e91:	48 83 e0 07          	and    $0x7,%rax
  232e95:	38 c8                	cmp    %cl,%al
  232e97:	7c 0c                	jl     232ea5 <nested_poll+0x128d>
  232e99:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
  232ea0:	e8 fb 43 f8 ff       	call   1b72a0 <__asan_report_store1>
  232ea5:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  232eac:	c6 00 01             	movb   $0x1,(%rax)
  232eaf:	48 81 c4 60 02 00 00 	add    $0x260,%rsp
  232eb6:	5d                   	pop    %rbp
  232eb7:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
