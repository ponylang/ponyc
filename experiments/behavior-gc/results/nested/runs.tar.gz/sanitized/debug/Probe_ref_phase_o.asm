
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ae990 <Probe_ref_phase_o>:
  2ae990:	50                   	push   %rax
  2ae991:	48 89 3c 24          	mov    %rdi,(%rsp)
  2ae995:	e8 46 fb ff ff       	call   2ae4e0 <Probe_ref_allocate_garbage_o>
  2ae99a:	e8 79 32 f8 ff       	call   231c18 <nested_poll>
  2ae99f:	e8 14 47 f8 ff       	call   2330b8 <nested_leave_phase>
  2ae9a4:	48 8d 3d 35 53 00 00 	lea    0x5335(%rip),%rdi        # 2b3ce0 <None_Inst>
  2ae9ab:	e8 d0 08 00 00       	call   2af280 <None_val_create_o>
  2ae9b0:	59                   	pop    %rcx
  2ae9b1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
