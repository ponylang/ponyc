
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ae4e0 <Probe_ref_allocate_garbage_o>:
  2ae4e0:	41 57                	push   %r15
  2ae4e2:	41 56                	push   %r14
  2ae4e4:	41 54                	push   %r12
  2ae4e6:	53                   	push   %rbx
  2ae4e7:	48 83 ec 18          	sub    $0x18,%rsp
  2ae4eb:	49 89 fe             	mov    %rdi,%r14
  2ae4ee:	e8 35 22 fa ff       	call   250728 <pony_ctx>
  2ae4f3:	48 89 c3             	mov    %rax,%rbx
  2ae4f6:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  2ae4fb:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  2ae502:	00 00 
  2ae504:	31 c0                	xor    %eax,%eax
  2ae506:	84 c0                	test   %al,%al
  2ae508:	75 55                	jne    2ae55f <Probe_ref_allocate_garbage_o+0x7f>
  2ae50a:	4c 8d 25 1f 45 00 00 	lea    0x451f(%rip),%r12        # 2b2a30 <Cell_Desc>
  2ae511:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2ae518:	0f 1f 84 00 00 00 00 
  2ae51f:	00 
  2ae520:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  2ae525:	48 89 df             	mov    %rbx,%rdi
  2ae528:	31 f6                	xor    %esi,%esi
  2ae52a:	e8 99 c5 f4 ff       	call   1faac8 <pony_alloc_small>
  2ae52f:	49 89 c7             	mov    %rax,%r15
  2ae532:	4c 89 20             	mov    %r12,(%rax)
  2ae535:	48 89 c7             	mov    %rax,%rdi
  2ae538:	4c 89 f6             	mov    %r14,%rsi
  2ae53b:	e8 80 05 00 00       	call   2aeac0 <Cell_ref_create_pWo>
  2ae540:	4c 89 ff             	mov    %r15,%rdi
  2ae543:	e8 60 2f f8 ff       	call   2314a8 <nested_garbage>
  2ae548:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  2ae54d:	48 ff c0             	inc    %rax
  2ae550:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  2ae555:	48 3d 00 04 00 00    	cmp    $0x400,%rax
  2ae55b:	72 c3                	jb     2ae520 <Probe_ref_allocate_garbage_o+0x40>
  2ae55d:	eb 0c                	jmp    2ae56b <Probe_ref_allocate_garbage_o+0x8b>
  2ae55f:	48 8d 3d 7a 57 00 00 	lea    0x577a(%rip),%rdi        # 2b3ce0 <None_Inst>
  2ae566:	e8 15 0d 00 00       	call   2af280 <None_val_create_o>
  2ae56b:	48 8d 3d 6e 57 00 00 	lea    0x576e(%rip),%rdi        # 2b3ce0 <None_Inst>
  2ae572:	e8 09 0d 00 00       	call   2af280 <None_val_create_o>
  2ae577:	48 83 c4 18          	add    $0x18,%rsp
  2ae57b:	5b                   	pop    %rbx
  2ae57c:	41 5c                	pop    %r12
  2ae57e:	41 5e                	pop    %r14
  2ae580:	41 5f                	pop    %r15
  2ae582:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
