
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ae5e0 <Probe_ref_middle_o>:
  2ae5e0:	55                   	push   %rbp
  2ae5e1:	41 57                	push   %r15
  2ae5e3:	41 56                	push   %r14
  2ae5e5:	41 55                	push   %r13
  2ae5e7:	41 54                	push   %r12
  2ae5e9:	53                   	push   %rbx
  2ae5ea:	48 83 ec 58          	sub    $0x58,%rsp
  2ae5ee:	48 89 fb             	mov    %rdi,%rbx
  2ae5f1:	e8 32 21 fa ff       	call   250728 <pony_ctx>
  2ae5f6:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
  2ae5fb:	49 89 c6             	mov    %rax,%r14
  2ae5fe:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  2ae603:	48 8d 05 c9 a1 df ff 	lea    -0x205e37(%rip),%rax        # a87d3 <_ZN11__sanitizerL10kExtraRegsE+0x7f13>
  2ae60a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  2ae60f:	48 8d 6c 24 30       	lea    0x30(%rsp),%rbp
  2ae614:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  2ae619:	4c 8d 6c 24 40       	lea    0x40(%rsp),%r13
  2ae61e:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  2ae623:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2ae62a:	00 
  2ae62b:	4c 8d 3d 9e cf e1 ff 	lea    -0x1e3062(%rip),%r15        # cb5d0 <__NumSizeTable+0x130>
  2ae632:	4c 89 f7             	mov    %r14,%rdi
  2ae635:	48 89 de             	mov    %rbx,%rsi
  2ae638:	4c 89 fa             	mov    %r15,%rdx
  2ae63b:	b9 18 00 00 00       	mov    $0x18,%ecx
  2ae640:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2ae646:	45 31 c9             	xor    %r9d,%r9d
  2ae649:	e8 9a 09 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae64e:	4c 89 f7             	mov    %r14,%rdi
  2ae651:	31 f6                	xor    %esi,%esi
  2ae653:	e8 70 c4 f4 ff       	call   1faac8 <pony_alloc_small>
  2ae658:	49 89 c4             	mov    %rax,%r12
  2ae65b:	48 8d 05 ce 43 00 00 	lea    0x43ce(%rip),%rax        # 2b2a30 <Cell_Desc>
  2ae662:	49 89 04 24          	mov    %rax,(%r12)
  2ae666:	be 0f 01 00 00       	mov    $0x10f,%esi
  2ae66b:	4c 89 e7             	mov    %r12,%rdi
  2ae66e:	e8 4d 04 00 00       	call   2aeac0 <Cell_ref_create_pWo>
  2ae673:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  2ae678:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  2ae67d:	48 8d 05 f4 48 df ff 	lea    -0x20b70c(%rip),%rax        # a2f78 <_ZN11__sanitizerL10kExtraRegsE+0x26b8>
  2ae684:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  2ae689:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  2ae68e:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  2ae693:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2ae69a:	00 
  2ae69b:	4c 89 f7             	mov    %r14,%rdi
  2ae69e:	48 89 de             	mov    %rbx,%rsi
  2ae6a1:	4c 89 fa             	mov    %r15,%rdx
  2ae6a4:	b9 19 00 00 00       	mov    $0x19,%ecx
  2ae6a9:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
  2ae6af:	45 31 c9             	xor    %r9d,%r9d
  2ae6b2:	e8 31 09 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae6b7:	48 89 df             	mov    %rbx,%rdi
  2ae6ba:	e8 d1 02 00 00       	call   2ae990 <Probe_ref_phase_o>
  2ae6bf:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae6c3:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae6c8:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae6cf:	00 00 
  2ae6d1:	4c 8d 0d 18 cf e1 ff 	lea    -0x1e30e8(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae6d8:	4c 89 f7             	mov    %r14,%rdi
  2ae6db:	48 89 de             	mov    %rbx,%rsi
  2ae6de:	4c 89 fa             	mov    %r15,%rdx
  2ae6e1:	b9 1a 00 00 00       	mov    $0x1a,%ecx
  2ae6e6:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2ae6ec:	e8 f7 08 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae6f1:	4c 89 f7             	mov    %r14,%rdi
  2ae6f4:	31 f6                	xor    %esi,%esi
  2ae6f6:	e8 cd c3 f4 ff       	call   1faac8 <pony_alloc_small>
  2ae6fb:	49 89 c4             	mov    %rax,%r12
  2ae6fe:	48 8d 05 2b 43 00 00 	lea    0x432b(%rip),%rax        # 2b2a30 <Cell_Desc>
  2ae705:	49 89 04 24          	mov    %rax,(%r12)
  2ae709:	be d3 00 00 00       	mov    $0xd3,%esi
  2ae70e:	4c 89 e7             	mov    %r12,%rdi
  2ae711:	e8 aa 03 00 00       	call   2aeac0 <Cell_ref_create_pWo>
  2ae716:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
  2ae71b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae71f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae724:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae72b:	00 00 
  2ae72d:	4c 8d 0d bc ce e1 ff 	lea    -0x1e3144(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae734:	4c 89 f7             	mov    %r14,%rdi
  2ae737:	48 89 de             	mov    %rbx,%rsi
  2ae73a:	4c 89 fa             	mov    %r15,%rdx
  2ae73d:	b9 1b 00 00 00       	mov    $0x1b,%ecx
  2ae742:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2ae748:	e8 9b 08 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae74d:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  2ae752:	e8 31 4c f8 ff       	call   233388 <nested_fresh>
  2ae757:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae75b:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae760:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae767:	00 00 
  2ae769:	4c 8d 0d 80 ce e1 ff 	lea    -0x1e3180(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae770:	4c 89 f7             	mov    %r14,%rdi
  2ae773:	48 89 de             	mov    %rbx,%rsi
  2ae776:	4c 89 fa             	mov    %r15,%rdx
  2ae779:	b9 1c 00 00 00       	mov    $0x1c,%ecx
  2ae77e:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
  2ae784:	e8 5f 08 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae789:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  2ae78e:	48 8b 40 08          	mov    0x8(%rax),%rax
  2ae792:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2ae797:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae79b:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae7a0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae7a7:	00 00 
  2ae7a9:	4c 8d 0d 40 ce e1 ff 	lea    -0x1e31c0(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae7b0:	4c 89 f7             	mov    %r14,%rdi
  2ae7b3:	48 89 de             	mov    %rbx,%rsi
  2ae7b6:	4c 89 fa             	mov    %r15,%rdx
  2ae7b9:	b9 1d 00 00 00       	mov    $0x1d,%ecx
  2ae7be:	41 b8 11 00 00 00    	mov    $0x11,%r8d
  2ae7c4:	e8 1f 08 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae7c9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  2ae7ce:	48 83 c0 07          	add    $0x7,%rax
  2ae7d2:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  2ae7d7:	48 89 41 08          	mov    %rax,0x8(%rcx)
  2ae7db:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae7df:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae7e4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae7eb:	00 00 
  2ae7ed:	4c 8d 0d fc cd e1 ff 	lea    -0x1e3204(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae7f4:	4c 89 f7             	mov    %r14,%rdi
  2ae7f7:	48 89 de             	mov    %rbx,%rsi
  2ae7fa:	4c 89 fa             	mov    %r15,%rdx
  2ae7fd:	b9 1e 00 00 00       	mov    $0x1e,%ecx
  2ae802:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2ae808:	e8 db 07 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae80d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  2ae812:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  2ae817:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  2ae81b:	bf 01 00 00 00       	mov    $0x1,%edi
  2ae820:	e8 e3 51 f8 ff       	call   233a08 <nested_value>
  2ae825:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ae829:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ae82e:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ae835:	00 00 
  2ae837:	4c 8d 0d b2 cd e1 ff 	lea    -0x1e324e(%rip),%r9        # cb5f0 <__NumSizeTable+0x150>
  2ae83e:	4c 89 f7             	mov    %r14,%rdi
  2ae841:	48 89 de             	mov    %rbx,%rsi
  2ae844:	4c 89 fa             	mov    %r15,%rdx
  2ae847:	b9 18 00 00 00       	mov    $0x18,%ecx
  2ae84c:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2ae852:	e8 91 07 f8 ff       	call   22efe8 <ponyint_gc_root_audit>
  2ae857:	48 8d 3d 82 54 00 00 	lea    0x5482(%rip),%rdi        # 2b3ce0 <None_Inst>
  2ae85e:	e8 1d 0a 00 00       	call   2af280 <None_val_create_o>
  2ae863:	48 83 c4 58          	add    $0x58,%rsp
  2ae867:	5b                   	pop    %rbx
  2ae868:	41 5c                	pop    %r12
  2ae86a:	41 5d                	pop    %r13
  2ae86c:	41 5e                	pop    %r14
  2ae86e:	41 5f                	pop    %r15
  2ae870:	5d                   	pop    %rbp
  2ae871:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
