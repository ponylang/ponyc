
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002acb60 <Probe_ref_phase_o>:
  2acb60:	53                   	push   %rbx
  2acb61:	e8 5a fc ff ff       	call   2ac7c0 <Probe_ref_allocate_garbage_o>
  2acb66:	48 89 c3             	mov    %rax,%rbx
  2acb69:	e8 4a 32 f8 ff       	call   22fdb8 <nested_poll>
  2acb6e:	e8 e5 46 f8 ff       	call   231258 <nested_leave_phase>
  2acb73:	48 89 d8             	mov    %rbx,%rax
  2acb76:	5b                   	pop    %rbx
  2acb77:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
