
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ac5e0 <Probe_Dispatch>:
  2ac5e0:	55                   	push   %rbp
  2ac5e1:	41 57                	push   %r15
  2ac5e3:	41 56                	push   %r14
  2ac5e5:	41 55                	push   %r13
  2ac5e7:	41 54                	push   %r12
  2ac5e9:	53                   	push   %rbx
  2ac5ea:	48 83 ec 38          	sub    $0x38,%rsp
  2ac5ee:	48 89 f3             	mov    %rsi,%rbx
  2ac5f1:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
  2ac5f5:	4c 8b 6a 10          	mov    0x10(%rdx),%r13
  2ac5f9:	0f 85 81 01 00 00    	jne    2ac780 <Probe_Dispatch+0x1a0>
  2ac5ff:	e8 c4 22 fa ff       	call   24e8c8 <pony_ctx>
  2ac604:	49 89 c6             	mov    %rax,%r14
  2ac607:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  2ac60c:	48 8d 05 51 b7 df ff 	lea    -0x2048af(%rip),%rax        # a7d64 <_ZN11__sanitizerL10kExtraRegsE+0x7f04>
  2ac613:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  2ac618:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  2ac61d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2ac622:	48 8d 6c 24 28       	lea    0x28(%rsp),%rbp
  2ac627:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2ac62c:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2ac633:	00 
  2ac634:	4c 8d 3d c5 e3 e1 ff 	lea    -0x1e1c3b(%rip),%r15        # caa00 <.str.162+0x20>
  2ac63b:	4c 89 f7             	mov    %r14,%rdi
  2ac63e:	48 89 de             	mov    %rbx,%rsi
  2ac641:	4c 89 fa             	mov    %r15,%rdx
  2ac644:	b9 11 00 00 00       	mov    $0x11,%ecx
  2ac649:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2ac64f:	45 31 c9             	xor    %r9d,%r9d
  2ac652:	e8 31 0b f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac657:	4c 89 f7             	mov    %r14,%rdi
  2ac65a:	31 f6                	xor    %esi,%esi
  2ac65c:	e8 07 c6 f4 ff       	call   1f8c68 <pony_alloc_small>
  2ac661:	49 89 c4             	mov    %rax,%r12
  2ac664:	48 8d 05 25 34 00 00 	lea    0x3425(%rip),%rax        # 2afa90 <Cell_Desc>
  2ac66b:	49 89 04 24          	mov    %rax,(%r12)
  2ac66f:	4d 89 6c 24 08       	mov    %r13,0x8(%r12)
  2ac674:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  2ac679:	48 8d 05 94 5e df ff 	lea    -0x20a16c(%rip),%rax        # a2514 <_ZN11__sanitizerL10kExtraRegsE+0x26b4>
  2ac680:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2ac685:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  2ac68a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2ac68f:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2ac694:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2ac69b:	00 
  2ac69c:	4c 89 f7             	mov    %r14,%rdi
  2ac69f:	48 89 de             	mov    %rbx,%rsi
  2ac6a2:	4c 89 fa             	mov    %r15,%rdx
  2ac6a5:	b9 12 00 00 00       	mov    $0x12,%ecx
  2ac6aa:	41 b8 0b 00 00 00    	mov    $0xb,%r8d
  2ac6b0:	45 31 c9             	xor    %r9d,%r9d
  2ac6b3:	e8 d0 0a f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac6b8:	48 89 df             	mov    %rbx,%rdi
  2ac6bb:	e8 b0 01 00 00       	call   2ac870 <Probe_ref_middle_o>
  2ac6c0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac6c4:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac6c9:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac6d0:	00 00 
  2ac6d2:	4c 8d 2d 17 e4 e1 ff 	lea    -0x1e1be9(%rip),%r13        # caaf0 <.str.162+0x110>
  2ac6d9:	4c 89 f7             	mov    %r14,%rdi
  2ac6dc:	48 89 de             	mov    %rbx,%rsi
  2ac6df:	4c 89 fa             	mov    %r15,%rdx
  2ac6e2:	b9 13 00 00 00       	mov    $0x13,%ecx
  2ac6e7:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
  2ac6ed:	4d 89 e9             	mov    %r13,%r9
  2ac6f0:	e8 93 0a f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac6f5:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
  2ac6fa:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac6fe:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac703:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac70a:	00 00 
  2ac70c:	4c 89 f7             	mov    %r14,%rdi
  2ac70f:	48 89 de             	mov    %rbx,%rsi
  2ac712:	4c 89 fa             	mov    %r15,%rdx
  2ac715:	b9 14 00 00 00       	mov    $0x14,%ecx
  2ac71a:	41 b8 11 00 00 00    	mov    $0x11,%r8d
  2ac720:	4d 89 e9             	mov    %r13,%r9
  2ac723:	e8 60 0a f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac728:	48 8d 45 05          	lea    0x5(%rbp),%rax
  2ac72c:	49 89 44 24 08       	mov    %rax,0x8(%r12)
  2ac731:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac735:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac73a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac741:	00 00 
  2ac743:	4c 89 f7             	mov    %r14,%rdi
  2ac746:	48 89 de             	mov    %rbx,%rsi
  2ac749:	4c 89 fa             	mov    %r15,%rdx
  2ac74c:	b9 15 00 00 00       	mov    $0x15,%ecx
  2ac751:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2ac757:	4d 89 e9             	mov    %r13,%r9
  2ac75a:	e8 29 0a f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac75f:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  2ac764:	31 ff                	xor    %edi,%edi
  2ac766:	4c 89 e6             	mov    %r12,%rsi
  2ac769:	48 89 ea             	mov    %rbp,%rdx
  2ac76c:	e8 37 54 f8 ff       	call   231ba8 <nested_value>
  2ac771:	48 83 c4 38          	add    $0x38,%rsp
  2ac775:	5b                   	pop    %rbx
  2ac776:	41 5c                	pop    %r12
  2ac778:	41 5d                	pop    %r13
  2ac77a:	41 5e                	pop    %r14
  2ac77c:	41 5f                	pop    %r15
  2ac77e:	5d                   	pop    %rbp
  2ac77f:	c3                   	ret
  2ac780:	49 89 fe             	mov    %rdi,%r14
  2ac783:	e8 40 21 fa ff       	call   24e8c8 <pony_ctx>
  2ac788:	bf 01 00 00 00       	mov    $0x1,%edi
  2ac78d:	be 01 00 00 00       	mov    $0x1,%esi
  2ac792:	e8 f1 98 f4 ff       	call   1f6088 <pony_alloc_msg>
  2ac797:	4c 89 68 10          	mov    %r13,0x10(%rax)
  2ac79b:	4c 89 f7             	mov    %r14,%rdi
  2ac79e:	48 89 de             	mov    %rbx,%rsi
  2ac7a1:	48 89 c2             	mov    %rax,%rdx
  2ac7a4:	48 89 c1             	mov    %rax,%rcx
  2ac7a7:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  2ac7ad:	48 83 c4 38          	add    $0x38,%rsp
  2ac7b1:	5b                   	pop    %rbx
  2ac7b2:	41 5c                	pop    %r12
  2ac7b4:	41 5d                	pop    %r13
  2ac7b6:	41 5e                	pop    %r14
  2ac7b8:	41 5f                	pop    %r15
  2ac7ba:	5d                   	pop    %rbp
  2ac7bb:	e9 a8 9a f4 ff       	jmp    1f6268 <pony_sendv>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
