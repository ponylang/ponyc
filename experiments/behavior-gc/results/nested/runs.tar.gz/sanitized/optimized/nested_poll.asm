
measure:     file format elf64-x86-64


Disassembly of section .text:

000000000022fdb8 <nested_poll>:
  22fdb8:	55                   	push   %rbp
  22fdb9:	48 89 e5             	mov    %rsp,%rbp
  22fdbc:	48 81 ec 60 02 00 00 	sub    $0x260,%rsp
  22fdc3:	b0 00                	mov    $0x0,%al
  22fdc5:	e8 fe ea 01 00       	call   24e8c8 <pony_ctx>
  22fdca:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
  22fdce:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22fdd2:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
  22fdd6:	48 83 f9 00          	cmp    $0x0,%rcx
  22fdda:	0f 95 c0             	setne  %al
  22fddd:	48 83 e1 07          	and    $0x7,%rcx
  22fde1:	48 83 f9 00          	cmp    $0x0,%rcx
  22fde5:	0f 94 c1             	sete   %cl
  22fde8:	20 c8                	and    %cl,%al
  22fdea:	a8 01                	test   $0x1,%al
  22fdec:	75 10                	jne    22fdfe <nested_poll+0x46>
  22fdee:	48 8b 75 e0          	mov    -0x20(%rbp),%rsi
  22fdf2:	48 8d 3d 07 7e 09 00 	lea    0x97e07(%rip),%rdi        # 2c7c00 <_ZL17kSuppressionTypes+0x13c90>
  22fdf9:	e8 b2 c3 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22fdfe:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
  22fe02:	48 83 c1 08          	add    $0x8,%rcx
  22fe06:	48 89 4d d8          	mov    %rcx,-0x28(%rbp)
  22fe0a:	48 83 f9 00          	cmp    $0x0,%rcx
  22fe0e:	0f 95 c0             	setne  %al
  22fe11:	48 83 e1 07          	and    $0x7,%rcx
  22fe15:	48 83 f9 00          	cmp    $0x0,%rcx
  22fe19:	0f 94 c1             	sete   %cl
  22fe1c:	20 c8                	and    %cl,%al
  22fe1e:	a8 01                	test   $0x1,%al
  22fe20:	75 10                	jne    22fe32 <nested_poll+0x7a>
  22fe22:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
  22fe26:	48 8d 3d f3 7d 09 00 	lea    0x97df3(%rip),%rdi        # 2c7c20 <_ZL17kSuppressionTypes+0x13cb0>
  22fe2d:	e8 7e c3 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22fe32:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22fe36:	48 c1 e8 03          	shr    $0x3,%rax
  22fe3a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22fe41:	74 09                	je     22fe4c <nested_poll+0x94>
  22fe43:	48 8b 7d d8          	mov    -0x28(%rbp),%rdi
  22fe47:	e8 14 54 f8 ff       	call   1b5260 <__asan_report_load8>
  22fe4c:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22fe50:	48 8b 00             	mov    (%rax),%rax
  22fe53:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
  22fe57:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22fe5e:	25 00 00 00 00 
  22fe63:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  22fe6a:	48 83 c0 08          	add    $0x8,%rax
  22fe6e:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
  22fe72:	48 83 e0 07          	and    $0x7,%rax
  22fe76:	48 83 f8 00          	cmp    $0x0,%rax
  22fe7a:	74 10                	je     22fe8c <nested_poll+0xd4>
  22fe7c:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
  22fe80:	48 8d 3d b9 7d 09 00 	lea    0x97db9(%rip),%rdi        # 2c7c40 <_ZL17kSuppressionTypes+0x13cd0>
  22fe87:	e8 24 c3 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22fe8c:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
  22fe90:	48 c1 e8 03          	shr    $0x3,%rax
  22fe94:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22fe9b:	74 09                	je     22fea6 <nested_poll+0xee>
  22fe9d:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
  22fea1:	e8 ba 53 f8 ff       	call   1b5260 <__asan_report_load8>
  22fea6:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
  22feaa:	31 c0                	xor    %eax,%eax
  22feac:	48 83 39 02          	cmpq   $0x2,(%rcx)
  22feb0:	88 45 cf             	mov    %al,-0x31(%rbp)
  22feb3:	0f 85 5b 01 00 00    	jne    230014 <nested_poll+0x25c>
  22feb9:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  22febd:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  22fec1:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22fec8:	25 00 00 00 00 
  22fecd:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  22fed4:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  22fed8:	48 83 e0 07          	and    $0x7,%rax
  22fedc:	48 83 f8 00          	cmp    $0x0,%rax
  22fee0:	74 10                	je     22fef2 <nested_poll+0x13a>
  22fee2:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
  22fee6:	48 8d 3d 73 7d 09 00 	lea    0x97d73(%rip),%rdi        # 2c7c60 <_ZL17kSuppressionTypes+0x13cf0>
  22feed:	e8 be c2 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22fef2:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
  22fef6:	48 c1 e8 03          	shr    $0x3,%rax
  22fefa:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22ff01:	74 09                	je     22ff0c <nested_poll+0x154>
  22ff03:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
  22ff07:	e8 54 53 f8 ff       	call   1b5260 <__asan_report_load8>
  22ff0c:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
  22ff10:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
  22ff14:	31 c0                	xor    %eax,%eax
  22ff16:	48 3b 0a             	cmp    (%rdx),%rcx
  22ff19:	88 45 cf             	mov    %al,-0x31(%rbp)
  22ff1c:	0f 85 f2 00 00 00    	jne    230014 <nested_poll+0x25c>
  22ff22:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ff29:	25 00 00 00 00 
  22ff2e:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  22ff35:	48 05 8c 20 00 00    	add    $0x208c,%rax
  22ff3b:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
  22ff3f:	48 83 e0 03          	and    $0x3,%rax
  22ff43:	48 83 f8 00          	cmp    $0x0,%rax
  22ff47:	74 10                	je     22ff59 <nested_poll+0x1a1>
  22ff49:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
  22ff4d:	48 8d 3d 2c 7d 09 00 	lea    0x97d2c(%rip),%rdi        # 2c7c80 <_ZL17kSuppressionTypes+0x13d10>
  22ff54:	e8 57 c2 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22ff59:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  22ff5d:	48 c1 e8 03          	shr    $0x3,%rax
  22ff61:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22ff67:	88 45 af             	mov    %al,-0x51(%rbp)
  22ff6a:	3c 00                	cmp    $0x0,%al
  22ff6c:	74 18                	je     22ff86 <nested_poll+0x1ce>
  22ff6e:	8a 4d af             	mov    -0x51(%rbp),%cl
  22ff71:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  22ff75:	48 83 e0 07          	and    $0x7,%rax
  22ff79:	38 c8                	cmp    %cl,%al
  22ff7b:	7c 09                	jl     22ff86 <nested_poll+0x1ce>
  22ff7d:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
  22ff81:	e8 0a 50 f8 ff       	call   1b4f90 <__asan_report_load1>
  22ff86:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
  22ff8a:	8a 00                	mov    (%rax),%al
  22ff8c:	88 45 ae             	mov    %al,-0x52(%rbp)
  22ff8f:	3c 01                	cmp    $0x1,%al
  22ff91:	76 14                	jbe    22ffa7 <nested_poll+0x1ef>
  22ff93:	8a 45 ae             	mov    -0x52(%rbp),%al
  22ff96:	0f b6 c0             	movzbl %al,%eax
  22ff99:	89 c6                	mov    %eax,%esi
  22ff9b:	48 8d 3d fe 7c 09 00 	lea    0x97cfe(%rip),%rdi        # 2c7ca0 <_ZL17kSuppressionTypes+0x13d30>
  22ffa2:	e8 09 e7 fb ff       	call   1ee6b0 <__ubsan_handle_load_invalid_value>
  22ffa7:	8a 4d ae             	mov    -0x52(%rbp),%cl
  22ffaa:	31 c0                	xor    %eax,%eax
  22ffac:	80 f9 00             	cmp    $0x0,%cl
  22ffaf:	88 45 cf             	mov    %al,-0x31(%rbp)
  22ffb2:	75 60                	jne    230014 <nested_poll+0x25c>
  22ffb4:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ffbb:	25 00 00 00 00 
  22ffc0:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  22ffc7:	48 83 c0 38          	add    $0x38,%rax
  22ffcb:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
  22ffcf:	48 83 e0 07          	and    $0x7,%rax
  22ffd3:	48 83 f8 00          	cmp    $0x0,%rax
  22ffd7:	74 10                	je     22ffe9 <nested_poll+0x231>
  22ffd9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
  22ffdd:	48 8d 3d dc 7c 09 00 	lea    0x97cdc(%rip),%rdi        # 2c7cc0 <_ZL17kSuppressionTypes+0x13d50>
  22ffe4:	e8 c7 c1 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  22ffe9:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  22ffed:	48 c1 e8 03          	shr    $0x3,%rax
  22fff1:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22fff8:	74 09                	je     230003 <nested_poll+0x24b>
  22fffa:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
  22fffe:	e8 5d 52 f8 ff       	call   1b5260 <__asan_report_load8>
  230003:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  230007:	48 81 38 00 04 00 00 	cmpq   $0x400,(%rax)
  23000e:	0f 94 c0             	sete   %al
  230011:	88 45 cf             	mov    %al,-0x31(%rbp)
  230014:	8a 45 cf             	mov    -0x31(%rbp),%al
  230017:	0f b6 f8             	movzbl %al,%edi
  23001a:	83 e7 01             	and    $0x1,%edi
  23001d:	48 8d 35 9c bd e8 ff 	lea    -0x174264(%rip),%rsi        # bbdc0 <.str.14>
  230024:	e8 af e7 ff ff       	call   22e7d8 <require>
  230029:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  23002d:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
  230031:	48 83 f9 00          	cmp    $0x0,%rcx
  230035:	0f 95 c0             	setne  %al
  230038:	48 83 e1 07          	and    $0x7,%rcx
  23003c:	48 83 f9 00          	cmp    $0x0,%rcx
  230040:	0f 94 c1             	sete   %cl
  230043:	20 c8                	and    %cl,%al
  230045:	a8 01                	test   $0x1,%al
  230047:	75 10                	jne    230059 <nested_poll+0x2a1>
  230049:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
  23004d:	48 8d 3d 8c 7c 09 00 	lea    0x97c8c(%rip),%rdi        # 2c7ce0 <_ZL17kSuppressionTypes+0x13d70>
  230054:	e8 57 c1 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230059:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
  23005d:	48 83 c1 20          	add    $0x20,%rcx
  230061:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
  230065:	48 83 f9 00          	cmp    $0x0,%rcx
  230069:	0f 95 c0             	setne  %al
  23006c:	48 83 e1 07          	and    $0x7,%rcx
  230070:	48 83 f9 00          	cmp    $0x0,%rcx
  230074:	0f 94 c1             	sete   %cl
  230077:	20 c8                	and    %cl,%al
  230079:	a8 01                	test   $0x1,%al
  23007b:	75 10                	jne    23008d <nested_poll+0x2d5>
  23007d:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
  230081:	48 8d 3d 78 7c 09 00 	lea    0x97c78(%rip),%rdi        # 2c7d00 <_ZL17kSuppressionTypes+0x13d90>
  230088:	e8 23 c1 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  23008d:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  230091:	48 c1 e8 03          	shr    $0x3,%rax
  230095:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  23009c:	74 09                	je     2300a7 <nested_poll+0x2ef>
  23009e:	48 8b 7d 90          	mov    -0x70(%rbp),%rdi
  2300a2:	e8 b9 51 f8 ff       	call   1b5260 <__asan_report_load8>
  2300a7:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
  2300ab:	31 c0                	xor    %eax,%eax
  2300ad:	48 83 39 00          	cmpq   $0x0,(%rcx)
  2300b1:	88 45 8f             	mov    %al,-0x71(%rbp)
  2300b4:	0f 85 6f 02 00 00    	jne    230329 <nested_poll+0x571>
  2300ba:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  2300be:	48 89 4d 80          	mov    %rcx,-0x80(%rbp)
  2300c2:	48 83 f9 00          	cmp    $0x0,%rcx
  2300c6:	0f 95 c0             	setne  %al
  2300c9:	48 83 e1 07          	and    $0x7,%rcx
  2300cd:	48 83 f9 00          	cmp    $0x0,%rcx
  2300d1:	0f 94 c1             	sete   %cl
  2300d4:	20 c8                	and    %cl,%al
  2300d6:	a8 01                	test   $0x1,%al
  2300d8:	75 10                	jne    2300ea <nested_poll+0x332>
  2300da:	48 8b 75 80          	mov    -0x80(%rbp),%rsi
  2300de:	48 8d 3d 3b 7c 09 00 	lea    0x97c3b(%rip),%rdi        # 2c7d20 <_ZL17kSuppressionTypes+0x13db0>
  2300e5:	e8 c6 c0 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2300ea:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
  2300ee:	48 83 c1 48          	add    $0x48,%rcx
  2300f2:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
  2300f9:	48 83 f9 00          	cmp    $0x0,%rcx
  2300fd:	0f 95 c0             	setne  %al
  230100:	48 83 e1 07          	and    $0x7,%rcx
  230104:	48 83 f9 00          	cmp    $0x0,%rcx
  230108:	0f 94 c1             	sete   %cl
  23010b:	20 c8                	and    %cl,%al
  23010d:	a8 01                	test   $0x1,%al
  23010f:	75 13                	jne    230124 <nested_poll+0x36c>
  230111:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
  230118:	48 8d 3d 21 7c 09 00 	lea    0x97c21(%rip),%rdi        # 2c7d40 <_ZL17kSuppressionTypes+0x13dd0>
  23011f:	e8 8c c0 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230124:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  23012b:	48 c1 e8 03          	shr    $0x3,%rax
  23012f:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230136:	74 0c                	je     230144 <nested_poll+0x38c>
  230138:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
  23013f:	e8 1c 51 f8 ff       	call   1b5260 <__asan_report_load8>
  230144:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
  23014b:	31 c0                	xor    %eax,%eax
  23014d:	48 83 39 00          	cmpq   $0x0,(%rcx)
  230151:	88 45 8f             	mov    %al,-0x71(%rbp)
  230154:	0f 85 cf 01 00 00    	jne    230329 <nested_poll+0x571>
  23015a:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  23015e:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
  230165:	48 83 f9 00          	cmp    $0x0,%rcx
  230169:	0f 95 c0             	setne  %al
  23016c:	48 83 e1 07          	and    $0x7,%rcx
  230170:	48 83 f9 00          	cmp    $0x0,%rcx
  230174:	0f 94 c1             	sete   %cl
  230177:	20 c8                	and    %cl,%al
  230179:	a8 01                	test   $0x1,%al
  23017b:	75 13                	jne    230190 <nested_poll+0x3d8>
  23017d:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
  230184:	48 8d 3d d5 7b 09 00 	lea    0x97bd5(%rip),%rdi        # 2c7d60 <_ZL17kSuppressionTypes+0x13df0>
  23018b:	e8 20 c0 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230190:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
  230197:	48 83 c7 28          	add    $0x28,%rdi
  23019b:	e8 98 63 fd ff       	call   206538 <ponyint_actormap_size>
  2301a0:	48 89 c1             	mov    %rax,%rcx
  2301a3:	31 c0                	xor    %eax,%eax
  2301a5:	48 83 f9 00          	cmp    $0x0,%rcx
  2301a9:	88 45 8f             	mov    %al,-0x71(%rbp)
  2301ac:	0f 85 77 01 00 00    	jne    230329 <nested_poll+0x571>
  2301b2:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  2301b6:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
  2301bd:	48 83 f9 00          	cmp    $0x0,%rcx
  2301c1:	0f 95 c0             	setne  %al
  2301c4:	48 83 e1 3f          	and    $0x3f,%rcx
  2301c8:	48 83 f9 00          	cmp    $0x0,%rcx
  2301cc:	0f 94 c1             	sete   %cl
  2301cf:	20 c8                	and    %cl,%al
  2301d1:	a8 01                	test   $0x1,%al
  2301d3:	75 13                	jne    2301e8 <nested_poll+0x430>
  2301d5:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
  2301dc:	48 8d 3d 9d 7b 09 00 	lea    0x97b9d(%rip),%rdi        # 2c7d80 <_ZL17kSuppressionTypes+0x13e10>
  2301e3:	e8 c8 bf fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2301e8:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
  2301ef:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  2301f6:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
  2301fd:	48 83 f9 00          	cmp    $0x0,%rcx
  230201:	0f 95 c0             	setne  %al
  230204:	48 83 e1 07          	and    $0x7,%rcx
  230208:	48 83 f9 00          	cmp    $0x0,%rcx
  23020c:	0f 94 c1             	sete   %cl
  23020f:	20 c8                	and    %cl,%al
  230211:	a8 01                	test   $0x1,%al
  230213:	75 13                	jne    230228 <nested_poll+0x470>
  230215:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
  23021c:	48 8d 3d 7d 7b 09 00 	lea    0x97b7d(%rip),%rdi        # 2c7da0 <_ZL17kSuppressionTypes+0x13e30>
  230223:	e8 88 bf fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230228:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
  23022f:	48 83 c7 10          	add    $0x10,%rdi
  230233:	e8 b0 c0 ff ff       	call   22c2e8 <ponyint_objectmap_size>
  230238:	48 89 c1             	mov    %rax,%rcx
  23023b:	31 c0                	xor    %eax,%eax
  23023d:	48 83 f9 00          	cmp    $0x0,%rcx
  230241:	88 45 8f             	mov    %al,-0x71(%rbp)
  230244:	0f 85 df 00 00 00    	jne    230329 <nested_poll+0x571>
  23024a:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  23024e:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
  230255:	48 83 f9 00          	cmp    $0x0,%rcx
  230259:	0f 95 c0             	setne  %al
  23025c:	48 83 e1 3f          	and    $0x3f,%rcx
  230260:	48 83 f9 00          	cmp    $0x0,%rcx
  230264:	0f 94 c1             	sete   %cl
  230267:	20 c8                	and    %cl,%al
  230269:	a8 01                	test   $0x1,%al
  23026b:	75 13                	jne    230280 <nested_poll+0x4c8>
  23026d:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  230274:	48 8d 3d 45 7b 09 00 	lea    0x97b45(%rip),%rdi        # 2c7dc0 <_ZL17kSuppressionTypes+0x13e50>
  23027b:	e8 30 bf fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230280:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
  230287:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  23028e:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
  230295:	48 83 f9 00          	cmp    $0x0,%rcx
  230299:	0f 95 c0             	setne  %al
  23029c:	48 83 e1 07          	and    $0x7,%rcx
  2302a0:	48 83 f9 00          	cmp    $0x0,%rcx
  2302a4:	0f 94 c1             	sete   %cl
  2302a7:	20 c8                	and    %cl,%al
  2302a9:	a8 01                	test   $0x1,%al
  2302ab:	75 13                	jne    2302c0 <nested_poll+0x508>
  2302ad:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
  2302b4:	48 8d 3d 25 7b 09 00 	lea    0x97b25(%rip),%rdi        # 2c7de0 <_ZL17kSuppressionTypes+0x13e70>
  2302bb:	e8 f0 be fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2302c0:	48 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%rdi
  2302c7:	48 83 c7 30          	add    $0x30,%rdi
  2302cb:	e8 68 62 fd ff       	call   206538 <ponyint_actormap_size>
  2302d0:	48 89 c1             	mov    %rax,%rcx
  2302d3:	31 c0                	xor    %eax,%eax
  2302d5:	48 83 f9 00          	cmp    $0x0,%rcx
  2302d9:	88 45 8f             	mov    %al,-0x71(%rbp)
  2302dc:	75 4b                	jne    230329 <nested_poll+0x571>
  2302de:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  2302e2:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
  2302e9:	48 83 f9 00          	cmp    $0x0,%rcx
  2302ed:	0f 95 c0             	setne  %al
  2302f0:	48 83 e1 3f          	and    $0x3f,%rcx
  2302f4:	48 83 f9 00          	cmp    $0x0,%rcx
  2302f8:	0f 94 c1             	sete   %cl
  2302fb:	20 c8                	and    %cl,%al
  2302fd:	a8 01                	test   $0x1,%al
  2302ff:	75 13                	jne    230314 <nested_poll+0x55c>
  230301:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
  230308:	48 8d 3d f1 7a 09 00 	lea    0x97af1(%rip),%rdi        # 2c7e00 <_ZL17kSuppressionTypes+0x13e90>
  23030f:	e8 9c be fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230314:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
  23031b:	48 83 c7 40          	add    $0x40,%rdi
  23031f:	e8 04 51 00 00       	call   235428 <ponyint_heap_has_finalisers>
  230324:	34 ff                	xor    $0xff,%al
  230326:	88 45 8f             	mov    %al,-0x71(%rbp)
  230329:	8a 45 8f             	mov    -0x71(%rbp),%al
  23032c:	0f b6 f8             	movzbl %al,%edi
  23032f:	83 e7 01             	and    $0x1,%edi
  230332:	48 8d 35 e7 ba e8 ff 	lea    -0x174519(%rip),%rsi        # bbe20 <.str.15>
  230339:	e8 9a e4 ff ff       	call   22e7d8 <require>
  23033e:	e8 35 ef ff ff       	call   22f278 <check_slots>
  230343:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
  23034a:	00 
  23034b:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  23034f:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
  230356:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23035d:	25 00 00 00 00 
  230362:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230369:	48 83 c0 08          	add    $0x8,%rax
  23036d:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
  230374:	48 83 e0 07          	and    $0x7,%rax
  230378:	48 83 f8 00          	cmp    $0x0,%rax
  23037c:	74 13                	je     230391 <nested_poll+0x5d9>
  23037e:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  230385:	48 8d 3d 94 7a 09 00 	lea    0x97a94(%rip),%rdi        # 2c7e20 <_ZL17kSuppressionTypes+0x13eb0>
  23038c:	e8 1f be fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230391:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  230398:	48 c1 e8 03          	shr    $0x3,%rax
  23039c:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2303a3:	74 0c                	je     2303b1 <nested_poll+0x5f9>
  2303a5:	48 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%rdi
  2303ac:	e8 af 4e f8 ff       	call   1b5260 <__asan_report_load8>
  2303b1:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
  2303b8:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
  2303bf:	48 3b 01             	cmp    (%rcx),%rax
  2303c2:	72 05                	jb     2303c9 <nested_poll+0x611>
  2303c4:	e9 f8 01 00 00       	jmp    2305c1 <nested_poll+0x809>
  2303c9:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2303d0:	25 00 00 00 00 
  2303d5:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2303dc:	48 83 c0 40          	add    $0x40,%rax
  2303e0:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
  2303e7:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  2303eb:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
  2303f2:	48 83 f8 02          	cmp    $0x2,%rax
  2303f6:	72 13                	jb     23040b <nested_poll+0x653>
  2303f8:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
  2303ff:	48 8d 3d 3a 7a 09 00 	lea    0x97a3a(%rip),%rdi        # 2c7e40 <_ZL17kSuppressionTypes+0x13ed0>
  230406:	e8 f5 d6 fb ff       	call   1edb00 <__ubsan_handle_out_of_bounds>
  23040b:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  230412:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
  230419:	48 8d 14 c1          	lea    (%rcx,%rax,8),%rdx
  23041d:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
  230424:	48 6b f8 08          	imul   $0x8,%rax,%rdi
  230428:	0f 90 c2             	seto   %dl
  23042b:	48 89 ce             	mov    %rcx,%rsi
  23042e:	48 89 b5 18 ff ff ff 	mov    %rsi,-0xe8(%rbp)
  230435:	48 85 c9             	test   %rcx,%rcx
  230438:	0f 95 c0             	setne  %al
  23043b:	48 01 f9             	add    %rdi,%rcx
  23043e:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
  230445:	40 0f 95 c7          	setne  %dil
  230449:	40 30 f8             	xor    %dil,%al
  23044c:	34 01                	xor    $0x1,%al
  23044e:	80 f2 ff             	xor    $0xff,%dl
  230451:	48 39 f1             	cmp    %rsi,%rcx
  230454:	0f 93 c1             	setae  %cl
  230457:	20 d1                	and    %dl,%cl
  230459:	20 c8                	and    %cl,%al
  23045b:	a8 01                	test   $0x1,%al
  23045d:	75 1a                	jne    230479 <nested_poll+0x6c1>
  23045f:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
  230466:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
  23046d:	48 8d 3d ec 79 09 00 	lea    0x979ec(%rip),%rdi        # 2c7e60 <_ZL17kSuppressionTypes+0x13ef0>
  230474:	e8 a7 f6 fb ff       	call   1efb20 <__ubsan_handle_pointer_overflow>
  230479:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
  230480:	48 83 f9 00          	cmp    $0x0,%rcx
  230484:	0f 95 c0             	setne  %al
  230487:	48 83 e1 07          	and    $0x7,%rcx
  23048b:	48 83 f9 00          	cmp    $0x0,%rcx
  23048f:	0f 94 c1             	sete   %cl
  230492:	20 c8                	and    %cl,%al
  230494:	a8 01                	test   $0x1,%al
  230496:	75 13                	jne    2304ab <nested_poll+0x6f3>
  230498:	48 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%rsi
  23049f:	48 8d 3d ca 79 09 00 	lea    0x979ca(%rip),%rdi        # 2c7e70 <_ZL17kSuppressionTypes+0x13f00>
  2304a6:	e8 05 bd fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2304ab:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
  2304b2:	48 c1 e8 03          	shr    $0x3,%rax
  2304b6:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2304bd:	74 0c                	je     2304cb <nested_poll+0x713>
  2304bf:	48 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%rdi
  2304c6:	e8 95 4d f8 ff       	call   1b5260 <__asan_report_load8>
  2304cb:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
  2304d2:	48 83 38 00          	cmpq   $0x0,(%rax)
  2304d6:	0f 84 d2 00 00 00    	je     2305ae <nested_poll+0x7f6>
  2304dc:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  2304e0:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  2304e7:	89 c1                	mov    %eax,%ecx
  2304e9:	89 8d 0c ff ff ff    	mov    %ecx,-0xf4(%rbp)
  2304ef:	48 83 f8 1f          	cmp    $0x1f,%rax
  2304f3:	76 18                	jbe    23050d <nested_poll+0x755>
  2304f5:	48 8b 95 00 ff ff ff 	mov    -0x100(%rbp),%rdx
  2304fc:	48 8d 3d 8d 79 09 00 	lea    0x9798d(%rip),%rdi        # 2c7e90 <_ZL17kSuppressionTypes+0x13f20>
  230503:	be 01 00 00 00       	mov    $0x1,%esi
  230508:	e8 83 d0 fb ff       	call   1ed590 <__ubsan_handle_shift_out_of_bounds>
  23050d:	8b 8d 0c ff ff ff    	mov    -0xf4(%rbp),%ecx
  230513:	b8 01 00 00 00       	mov    $0x1,%eax
  230518:	d3 e0                	shl    %cl,%eax
  23051a:	89 85 f4 fe ff ff    	mov    %eax,-0x10c(%rbp)
  230520:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230527:	25 00 00 00 00 
  23052c:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230533:	48 05 80 20 00 00    	add    $0x2080,%rax
  230539:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
  230540:	48 83 e0 07          	and    $0x7,%rax
  230544:	48 83 f8 00          	cmp    $0x0,%rax
  230548:	74 13                	je     23055d <nested_poll+0x7a5>
  23054a:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
  230551:	48 8d 3d 58 79 09 00 	lea    0x97958(%rip),%rdi        # 2c7eb0 <_ZL17kSuppressionTypes+0x13f40>
  230558:	e8 53 bc fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  23055d:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  230564:	48 c1 e8 03          	shr    $0x3,%rax
  230568:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  23056e:	88 85 f3 fe ff ff    	mov    %al,-0x10d(%rbp)
  230574:	3c 00                	cmp    $0x0,%al
  230576:	74 25                	je     23059d <nested_poll+0x7e5>
  230578:	8a 8d f3 fe ff ff    	mov    -0x10d(%rbp),%cl
  23057e:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  230585:	48 83 e0 07          	and    $0x7,%rax
  230589:	48 83 c0 03          	add    $0x3,%rax
  23058d:	38 c8                	cmp    %cl,%al
  23058f:	7c 0c                	jl     23059d <nested_poll+0x7e5>
  230591:	48 8b bd f8 fe ff ff 	mov    -0x108(%rbp),%rdi
  230598:	e8 d3 4b f8 ff       	call   1b5170 <__asan_report_load4>
  23059d:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  2305a4:	8b 8d f4 fe ff ff    	mov    -0x10c(%rbp),%ecx
  2305aa:	0b 08                	or     (%rax),%ecx
  2305ac:	89 08                	mov    %ecx,(%rax)
  2305ae:	eb 00                	jmp    2305b0 <nested_poll+0x7f8>
  2305b0:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
  2305b4:	48 83 c0 01          	add    $0x1,%rax
  2305b8:	48 89 45 e8          	mov    %rax,-0x18(%rbp)
  2305bc:	e9 8a fd ff ff       	jmp    23034b <nested_poll+0x593>
  2305c1:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  2305c5:	48 89 8d e8 fe ff ff 	mov    %rcx,-0x118(%rbp)
  2305cc:	48 83 f9 00          	cmp    $0x0,%rcx
  2305d0:	0f 95 c0             	setne  %al
  2305d3:	48 83 e1 3f          	and    $0x3f,%rcx
  2305d7:	48 83 f9 00          	cmp    $0x0,%rcx
  2305db:	0f 94 c1             	sete   %cl
  2305de:	20 c8                	and    %cl,%al
  2305e0:	a8 01                	test   $0x1,%al
  2305e2:	75 13                	jne    2305f7 <nested_poll+0x83f>
  2305e4:	48 8b b5 e8 fe ff ff 	mov    -0x118(%rbp),%rsi
  2305eb:	48 8d 3d de 78 09 00 	lea    0x978de(%rip),%rdi        # 2c7ed0 <_ZL17kSuppressionTypes+0x13f60>
  2305f2:	e8 b9 bb fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2305f7:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
  2305fe:	48 83 c1 40          	add    $0x40,%rcx
  230602:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
  230609:	48 83 f9 00          	cmp    $0x0,%rcx
  23060d:	0f 95 c0             	setne  %al
  230610:	48 83 e1 3f          	and    $0x3f,%rcx
  230614:	48 83 f9 00          	cmp    $0x0,%rcx
  230618:	0f 94 c1             	sete   %cl
  23061b:	20 c8                	and    %cl,%al
  23061d:	a8 01                	test   $0x1,%al
  23061f:	75 13                	jne    230634 <nested_poll+0x87c>
  230621:	48 8b b5 e0 fe ff ff 	mov    -0x120(%rbp),%rsi
  230628:	48 8d 3d c1 78 09 00 	lea    0x978c1(%rip),%rdi        # 2c7ef0 <_ZL17kSuppressionTypes+0x13f80>
  23062f:	e8 7c bb fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230634:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
  23063b:	48 81 c1 80 00 00 00 	add    $0x80,%rcx
  230642:	48 89 8d d8 fe ff ff 	mov    %rcx,-0x128(%rbp)
  230649:	48 83 f9 00          	cmp    $0x0,%rcx
  23064d:	0f 95 c0             	setne  %al
  230650:	48 83 e1 3f          	and    $0x3f,%rcx
  230654:	48 83 f9 00          	cmp    $0x0,%rcx
  230658:	0f 94 c1             	sete   %cl
  23065b:	20 c8                	and    %cl,%al
  23065d:	a8 01                	test   $0x1,%al
  23065f:	75 13                	jne    230674 <nested_poll+0x8bc>
  230661:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  230668:	48 8d 3d a1 78 09 00 	lea    0x978a1(%rip),%rdi        # 2c7f10 <_ZL17kSuppressionTypes+0x13fa0>
  23066f:	e8 3c bb fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230674:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  23067b:	48 c1 e8 03          	shr    $0x3,%rax
  23067f:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230686:	74 0c                	je     230694 <nested_poll+0x8dc>
  230688:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  23068f:	e8 cc 4b f8 ff       	call   1b5260 <__asan_report_load8>
  230694:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  23069b:	48 8b 00             	mov    (%rax),%rax
  23069e:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
  2306a5:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  2306ac:	25 00 00 00 00 
  2306b1:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2306b8:	48 83 c0 20          	add    $0x20,%rax
  2306bc:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
  2306c3:	48 83 e0 07          	and    $0x7,%rax
  2306c7:	48 83 f8 00          	cmp    $0x0,%rax
  2306cb:	74 13                	je     2306e0 <nested_poll+0x928>
  2306cd:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
  2306d4:	48 8d 3d 55 78 09 00 	lea    0x97855(%rip),%rdi        # 2c7f30 <_ZL17kSuppressionTypes+0x13fc0>
  2306db:	e8 d0 ba fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2306e0:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  2306e7:	48 c1 e8 03          	shr    $0x3,%rax
  2306eb:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2306f2:	74 0c                	je     230700 <nested_poll+0x948>
  2306f4:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
  2306fb:	e8 60 4b f8 ff       	call   1b5260 <__asan_report_load8>
  230700:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
  230707:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
  23070e:	48 3b 01             	cmp    (%rcx),%rax
  230711:	0f 94 c0             	sete   %al
  230714:	0f b6 f8             	movzbl %al,%edi
  230717:	83 e7 01             	and    $0x1,%edi
  23071a:	48 8d 35 3f b7 e8 ff 	lea    -0x1748c1(%rip),%rsi        # bbe60 <.str.16>
  230721:	e8 b2 e0 ff ff       	call   22e7d8 <require>
  230726:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  23072a:	48 89 8d c0 fe ff ff 	mov    %rcx,-0x140(%rbp)
  230731:	48 83 f9 00          	cmp    $0x0,%rcx
  230735:	0f 95 c0             	setne  %al
  230738:	48 83 e1 3f          	and    $0x3f,%rcx
  23073c:	48 83 f9 00          	cmp    $0x0,%rcx
  230740:	0f 94 c1             	sete   %cl
  230743:	20 c8                	and    %cl,%al
  230745:	a8 01                	test   $0x1,%al
  230747:	75 13                	jne    23075c <nested_poll+0x9a4>
  230749:	48 8b b5 c0 fe ff ff 	mov    -0x140(%rbp),%rsi
  230750:	48 8d 3d f9 77 09 00 	lea    0x977f9(%rip),%rdi        # 2c7f50 <_ZL17kSuppressionTypes+0x13fe0>
  230757:	e8 54 ba fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  23075c:	48 8b 8d c0 fe ff ff 	mov    -0x140(%rbp),%rcx
  230763:	48 83 c1 40          	add    $0x40,%rcx
  230767:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
  23076e:	48 83 f9 00          	cmp    $0x0,%rcx
  230772:	0f 95 c0             	setne  %al
  230775:	48 83 e1 3f          	and    $0x3f,%rcx
  230779:	48 83 f9 00          	cmp    $0x0,%rcx
  23077d:	0f 94 c1             	sete   %cl
  230780:	20 c8                	and    %cl,%al
  230782:	a8 01                	test   $0x1,%al
  230784:	75 13                	jne    230799 <nested_poll+0x9e1>
  230786:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
  23078d:	48 8d 3d dc 77 09 00 	lea    0x977dc(%rip),%rdi        # 2c7f70 <_ZL17kSuppressionTypes+0x14000>
  230794:	e8 17 ba fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230799:	48 8b 8d b8 fe ff ff 	mov    -0x148(%rbp),%rcx
  2307a0:	48 83 c1 78          	add    $0x78,%rcx
  2307a4:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
  2307ab:	48 83 f9 00          	cmp    $0x0,%rcx
  2307af:	0f 95 c0             	setne  %al
  2307b2:	48 83 e1 07          	and    $0x7,%rcx
  2307b6:	48 83 f9 00          	cmp    $0x0,%rcx
  2307ba:	0f 94 c1             	sete   %cl
  2307bd:	20 c8                	and    %cl,%al
  2307bf:	a8 01                	test   $0x1,%al
  2307c1:	75 13                	jne    2307d6 <nested_poll+0xa1e>
  2307c3:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
  2307ca:	48 8d 3d bf 77 09 00 	lea    0x977bf(%rip),%rdi        # 2c7f90 <_ZL17kSuppressionTypes+0x14020>
  2307d1:	e8 da b9 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2307d6:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  2307dd:	48 c1 e8 03          	shr    $0x3,%rax
  2307e1:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2307e8:	74 0c                	je     2307f6 <nested_poll+0xa3e>
  2307ea:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
  2307f1:	e8 6a 4a f8 ff       	call   1b5260 <__asan_report_load8>
  2307f6:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  2307fd:	48 8b 00             	mov    (%rax),%rax
  230800:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
  230807:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23080e:	25 00 00 00 00 
  230813:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  23081a:	48 83 c0 28          	add    $0x28,%rax
  23081e:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
  230825:	48 83 e0 07          	and    $0x7,%rax
  230829:	48 83 f8 00          	cmp    $0x0,%rax
  23082d:	74 13                	je     230842 <nested_poll+0xa8a>
  23082f:	48 8b b5 a8 fe ff ff 	mov    -0x158(%rbp),%rsi
  230836:	48 8d 3d 73 77 09 00 	lea    0x97773(%rip),%rdi        # 2c7fb0 <_ZL17kSuppressionTypes+0x14040>
  23083d:	e8 6e b9 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230842:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
  230849:	48 c1 e8 03          	shr    $0x3,%rax
  23084d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230854:	74 0c                	je     230862 <nested_poll+0xaaa>
  230856:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
  23085d:	e8 ae 4e f8 ff       	call   1b5710 <__asan_report_store8>
  230862:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
  230869:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
  230870:	48 89 08             	mov    %rcx,(%rax)
  230873:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23087a:	25 00 00 00 00 
  23087f:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230886:	48 05 88 20 00 00    	add    $0x2088,%rax
  23088c:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
  230893:	48 83 e0 07          	and    $0x7,%rax
  230897:	48 83 f8 00          	cmp    $0x0,%rax
  23089b:	74 13                	je     2308b0 <nested_poll+0xaf8>
  23089d:	48 8b b5 98 fe ff ff 	mov    -0x168(%rbp),%rsi
  2308a4:	48 8d 3d 25 77 09 00 	lea    0x97725(%rip),%rdi        # 2c7fd0 <_ZL17kSuppressionTypes+0x14060>
  2308ab:	e8 00 b9 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2308b0:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  2308b7:	48 c1 e8 03          	shr    $0x3,%rax
  2308bb:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  2308c1:	88 85 97 fe ff ff    	mov    %al,-0x169(%rbp)
  2308c7:	3c 00                	cmp    $0x0,%al
  2308c9:	74 21                	je     2308ec <nested_poll+0xb34>
  2308cb:	8a 8d 97 fe ff ff    	mov    -0x169(%rbp),%cl
  2308d1:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  2308d8:	48 83 e0 07          	and    $0x7,%rax
  2308dc:	38 c8                	cmp    %cl,%al
  2308de:	7c 0c                	jl     2308ec <nested_poll+0xb34>
  2308e0:	48 8b bd 98 fe ff ff 	mov    -0x168(%rbp),%rdi
  2308e7:	e8 a4 46 f8 ff       	call   1b4f90 <__asan_report_load1>
  2308ec:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
  2308f3:	8a 00                	mov    (%rax),%al
  2308f5:	88 85 96 fe ff ff    	mov    %al,-0x16a(%rbp)
  2308fb:	3c 01                	cmp    $0x1,%al
  2308fd:	76 17                	jbe    230916 <nested_poll+0xb5e>
  2308ff:	8a 85 96 fe ff ff    	mov    -0x16a(%rbp),%al
  230905:	0f b6 c0             	movzbl %al,%eax
  230908:	89 c6                	mov    %eax,%esi
  23090a:	48 8d 3d df 76 09 00 	lea    0x976df(%rip),%rdi        # 2c7ff0 <_ZL17kSuppressionTypes+0x14080>
  230911:	e8 9a dd fb ff       	call   1ee6b0 <__ubsan_handle_load_invalid_value>
  230916:	8a 85 96 fe ff ff    	mov    -0x16a(%rbp),%al
  23091c:	3c 00                	cmp    $0x0,%al
  23091e:	0f 84 9e 02 00 00    	je     230bc2 <nested_poll+0xe0a>
  230924:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  23092b:	25 00 00 00 00 
  230930:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230937:	48 83 c0 28          	add    $0x28,%rax
  23093b:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
  230942:	48 83 e0 07          	and    $0x7,%rax
  230946:	48 83 f8 00          	cmp    $0x0,%rax
  23094a:	74 13                	je     23095f <nested_poll+0xba7>
  23094c:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
  230953:	48 8d 3d b6 76 09 00 	lea    0x976b6(%rip),%rdi        # 2c8010 <_ZL17kSuppressionTypes+0x140a0>
  23095a:	e8 51 b8 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  23095f:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  230966:	48 c1 e8 03          	shr    $0x3,%rax
  23096a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230971:	74 0c                	je     23097f <nested_poll+0xbc7>
  230973:	48 8b bd 88 fe ff ff 	mov    -0x178(%rbp),%rdi
  23097a:	e8 e1 48 f8 ff       	call   1b5260 <__asan_report_load8>
  23097f:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
  230986:	48 8b 00             	mov    (%rax),%rax
  230989:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
  230990:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230997:	25 00 00 00 00 
  23099c:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  2309a3:	48 83 c0 20          	add    $0x20,%rax
  2309a7:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
  2309ae:	48 83 e0 07          	and    $0x7,%rax
  2309b2:	48 83 f8 00          	cmp    $0x0,%rax
  2309b6:	74 13                	je     2309cb <nested_poll+0xc13>
  2309b8:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
  2309bf:	48 8d 3d 6a 76 09 00 	lea    0x9766a(%rip),%rdi        # 2c8030 <_ZL17kSuppressionTypes+0x140c0>
  2309c6:	e8 e5 b7 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  2309cb:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
  2309d2:	48 c1 e8 03          	shr    $0x3,%rax
  2309d6:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  2309dd:	74 0c                	je     2309eb <nested_poll+0xc33>
  2309df:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
  2309e6:	e8 75 48 f8 ff       	call   1b5260 <__asan_report_load8>
  2309eb:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
  2309f2:	48 8b 8d 80 fe ff ff 	mov    -0x180(%rbp),%rcx
  2309f9:	48 3b 01             	cmp    (%rcx),%rax
  2309fc:	0f 86 c0 01 00 00    	jbe    230bc2 <nested_poll+0xe0a>
  230a02:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230a09:	25 00 00 00 00 
  230a0e:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230a15:	48 05 80 20 00 00    	add    $0x2080,%rax
  230a1b:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
  230a22:	48 83 e0 07          	and    $0x7,%rax
  230a26:	48 83 f8 00          	cmp    $0x0,%rax
  230a2a:	74 13                	je     230a3f <nested_poll+0xc87>
  230a2c:	48 8b b5 70 fe ff ff 	mov    -0x190(%rbp),%rsi
  230a33:	48 8d 3d 16 76 09 00 	lea    0x97616(%rip),%rdi        # 2c8050 <_ZL17kSuppressionTypes+0x140e0>
  230a3a:	e8 71 b7 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230a3f:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  230a46:	48 c1 e8 03          	shr    $0x3,%rax
  230a4a:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  230a50:	88 85 6f fe ff ff    	mov    %al,-0x191(%rbp)
  230a56:	3c 00                	cmp    $0x0,%al
  230a58:	74 25                	je     230a7f <nested_poll+0xcc7>
  230a5a:	8a 8d 6f fe ff ff    	mov    -0x191(%rbp),%cl
  230a60:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  230a67:	48 83 e0 07          	and    $0x7,%rax
  230a6b:	48 83 c0 03          	add    $0x3,%rax
  230a6f:	38 c8                	cmp    %cl,%al
  230a71:	7c 0c                	jl     230a7f <nested_poll+0xcc7>
  230a73:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
  230a7a:	e8 f1 46 f8 ff       	call   1b5170 <__asan_report_load4>
  230a7f:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  230a86:	83 38 03             	cmpl   $0x3,(%rax)
  230a89:	0f 85 33 01 00 00    	jne    230bc2 <nested_poll+0xe0a>
  230a8f:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  230a93:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
  230a9a:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  230a9e:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
  230aa5:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230aac:	25 00 00 00 00 
  230ab1:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230ab8:	48 83 c0 08          	add    $0x8,%rax
  230abc:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
  230ac3:	48 83 e0 07          	and    $0x7,%rax
  230ac7:	48 83 f8 00          	cmp    $0x0,%rax
  230acb:	74 13                	je     230ae0 <nested_poll+0xd28>
  230acd:	48 8b b5 60 fe ff ff 	mov    -0x1a0(%rbp),%rsi
  230ad4:	48 8d 3d 95 75 09 00 	lea    0x97595(%rip),%rdi        # 2c8070 <_ZL17kSuppressionTypes+0x14100>
  230adb:	e8 d0 b6 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230ae0:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  230ae7:	48 c1 e8 03          	shr    $0x3,%rax
  230aeb:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230af2:	74 0c                	je     230b00 <nested_poll+0xd48>
  230af4:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
  230afb:	e8 60 47 f8 ff       	call   1b5260 <__asan_report_load8>
  230b00:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  230b07:	48 8b 00             	mov    (%rax),%rax
  230b0a:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
  230b11:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230b18:	25 00 00 00 00 
  230b1d:	48 8b bd 50 fe ff ff 	mov    -0x1b0(%rbp),%rdi
  230b24:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
  230b2b:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
  230b32:	48 8d 88 60 df ff ff 	lea    -0x20a0(%rax),%rcx
  230b39:	48 83 c1 40          	add    $0x40,%rcx
  230b3d:	4c 8d 05 24 05 00 00 	lea    0x524(%rip),%r8        # 231068 <check_marks>
  230b44:	e8 4f 03 fc ff       	call   1f0e98 <probe_collect_roots>
  230b49:	88 85 3f fe ff ff    	mov    %al,-0x1c1(%rbp)
  230b4f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230b56:	25 00 00 00 00 
  230b5b:	8a 8d 3f fe ff ff    	mov    -0x1c1(%rbp),%cl
  230b61:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230b68:	48 05 8b 20 00 00    	add    $0x208b,%rax
  230b6e:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
  230b75:	80 e1 01             	and    $0x1,%cl
  230b78:	88 8d 4e fe ff ff    	mov    %cl,-0x1b2(%rbp)
  230b7e:	48 c1 e8 03          	shr    $0x3,%rax
  230b82:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  230b88:	88 85 4f fe ff ff    	mov    %al,-0x1b1(%rbp)
  230b8e:	3c 00                	cmp    $0x0,%al
  230b90:	74 21                	je     230bb3 <nested_poll+0xdfb>
  230b92:	8a 8d 4f fe ff ff    	mov    -0x1b1(%rbp),%cl
  230b98:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  230b9f:	48 83 e0 07          	and    $0x7,%rax
  230ba3:	38 c8                	cmp    %cl,%al
  230ba5:	7c 0c                	jl     230bb3 <nested_poll+0xdfb>
  230ba7:	48 8b bd 40 fe ff ff 	mov    -0x1c0(%rbp),%rdi
  230bae:	e8 8d 48 f8 ff       	call   1b5440 <__asan_report_store1>
  230bb3:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  230bba:	8a 8d 4e fe ff ff    	mov    -0x1b2(%rbp),%cl
  230bc0:	88 08                	mov    %cl,(%rax)
  230bc2:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  230bc6:	48 89 8d 28 fe ff ff 	mov    %rcx,-0x1d8(%rbp)
  230bcd:	48 83 f9 00          	cmp    $0x0,%rcx
  230bd1:	0f 95 c0             	setne  %al
  230bd4:	48 83 e1 3f          	and    $0x3f,%rcx
  230bd8:	48 83 f9 00          	cmp    $0x0,%rcx
  230bdc:	0f 94 c1             	sete   %cl
  230bdf:	20 c8                	and    %cl,%al
  230be1:	a8 01                	test   $0x1,%al
  230be3:	75 13                	jne    230bf8 <nested_poll+0xe40>
  230be5:	48 8b b5 28 fe ff ff 	mov    -0x1d8(%rbp),%rsi
  230bec:	48 8d 3d 9d 74 09 00 	lea    0x9749d(%rip),%rdi        # 2c8090 <_ZL17kSuppressionTypes+0x14120>
  230bf3:	e8 b8 b5 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230bf8:	48 8b 8d 28 fe ff ff 	mov    -0x1d8(%rbp),%rcx
  230bff:	48 83 c1 40          	add    $0x40,%rcx
  230c03:	48 89 8d 20 fe ff ff 	mov    %rcx,-0x1e0(%rbp)
  230c0a:	48 83 f9 00          	cmp    $0x0,%rcx
  230c0e:	0f 95 c0             	setne  %al
  230c11:	48 83 e1 3f          	and    $0x3f,%rcx
  230c15:	48 83 f9 00          	cmp    $0x0,%rcx
  230c19:	0f 94 c1             	sete   %cl
  230c1c:	20 c8                	and    %cl,%al
  230c1e:	a8 01                	test   $0x1,%al
  230c20:	75 13                	jne    230c35 <nested_poll+0xe7d>
  230c22:	48 8b b5 20 fe ff ff 	mov    -0x1e0(%rbp),%rsi
  230c29:	48 8d 3d 80 74 09 00 	lea    0x97480(%rip),%rdi        # 2c80b0 <_ZL17kSuppressionTypes+0x14140>
  230c30:	e8 7b b5 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230c35:	48 8b 8d 20 fe ff ff 	mov    -0x1e0(%rbp),%rcx
  230c3c:	48 83 c1 78          	add    $0x78,%rcx
  230c40:	48 89 8d 18 fe ff ff 	mov    %rcx,-0x1e8(%rbp)
  230c47:	48 83 f9 00          	cmp    $0x0,%rcx
  230c4b:	0f 95 c0             	setne  %al
  230c4e:	48 83 e1 07          	and    $0x7,%rcx
  230c52:	48 83 f9 00          	cmp    $0x0,%rcx
  230c56:	0f 94 c1             	sete   %cl
  230c59:	20 c8                	and    %cl,%al
  230c5b:	a8 01                	test   $0x1,%al
  230c5d:	75 13                	jne    230c72 <nested_poll+0xeba>
  230c5f:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
  230c66:	48 8d 3d 63 74 09 00 	lea    0x97463(%rip),%rdi        # 2c80d0 <_ZL17kSuppressionTypes+0x14160>
  230c6d:	e8 3e b5 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230c72:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
  230c79:	48 c1 e8 03          	shr    $0x3,%rax
  230c7d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230c84:	74 0c                	je     230c92 <nested_poll+0xeda>
  230c86:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
  230c8d:	e8 ce 45 f8 ff       	call   1b5260 <__asan_report_load8>
  230c92:	48 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%rax
  230c99:	48 8b 00             	mov    (%rax),%rax
  230c9c:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
  230ca3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230caa:	25 00 00 00 00 
  230caf:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230cb6:	48 83 c0 30          	add    $0x30,%rax
  230cba:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
  230cc1:	48 83 e0 07          	and    $0x7,%rax
  230cc5:	48 83 f8 00          	cmp    $0x0,%rax
  230cc9:	74 13                	je     230cde <nested_poll+0xf26>
  230ccb:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
  230cd2:	48 8d 3d 17 74 09 00 	lea    0x97417(%rip),%rdi        # 2c80f0 <_ZL17kSuppressionTypes+0x14180>
  230cd9:	e8 d2 b4 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230cde:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
  230ce5:	48 c1 e8 03          	shr    $0x3,%rax
  230ce9:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230cf0:	74 0c                	je     230cfe <nested_poll+0xf46>
  230cf2:	48 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%rdi
  230cf9:	e8 12 4a f8 ff       	call   1b5710 <__asan_report_store8>
  230cfe:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
  230d05:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
  230d0c:	48 89 08             	mov    %rcx,(%rax)
  230d0f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230d16:	25 00 00 00 00 
  230d1b:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230d22:	48 05 8b 20 00 00    	add    $0x208b,%rax
  230d28:	48 89 85 f8 fd ff ff 	mov    %rax,-0x208(%rbp)
  230d2f:	48 c1 e8 03          	shr    $0x3,%rax
  230d33:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  230d39:	88 85 07 fe ff ff    	mov    %al,-0x1f9(%rbp)
  230d3f:	3c 00                	cmp    $0x0,%al
  230d41:	74 21                	je     230d64 <nested_poll+0xfac>
  230d43:	8a 8d 07 fe ff ff    	mov    -0x1f9(%rbp),%cl
  230d49:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
  230d50:	48 83 e0 07          	and    $0x7,%rax
  230d54:	38 c8                	cmp    %cl,%al
  230d56:	7c 0c                	jl     230d64 <nested_poll+0xfac>
  230d58:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
  230d5f:	e8 2c 42 f8 ff       	call   1b4f90 <__asan_report_load1>
  230d64:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
  230d6b:	8a 00                	mov    (%rax),%al
  230d6d:	88 85 f7 fd ff ff    	mov    %al,-0x209(%rbp)
  230d73:	3c 01                	cmp    $0x1,%al
  230d75:	76 17                	jbe    230d8e <nested_poll+0xfd6>
  230d77:	8a 85 f7 fd ff ff    	mov    -0x209(%rbp),%al
  230d7d:	0f b6 c0             	movzbl %al,%eax
  230d80:	89 c6                	mov    %eax,%esi
  230d82:	48 8d 3d 87 73 09 00 	lea    0x97387(%rip),%rdi        # 2c8110 <_ZL17kSuppressionTypes+0x141a0>
  230d89:	e8 22 d9 fb ff       	call   1ee6b0 <__ubsan_handle_load_invalid_value>
  230d8e:	8a 8d f7 fd ff ff    	mov    -0x209(%rbp),%cl
  230d94:	b0 01                	mov    $0x1,%al
  230d96:	80 f9 00             	cmp    $0x0,%cl
  230d99:	88 85 f6 fd ff ff    	mov    %al,-0x20a(%rbp)
  230d9f:	0f 84 0f 02 00 00    	je     230fb4 <nested_poll+0x11fc>
  230da5:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230dac:	25 00 00 00 00 
  230db1:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230db8:	48 05 84 20 00 00    	add    $0x2084,%rax
  230dbe:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
  230dc5:	48 83 e0 03          	and    $0x3,%rax
  230dc9:	48 83 f8 00          	cmp    $0x0,%rax
  230dcd:	74 13                	je     230de2 <nested_poll+0x102a>
  230dcf:	48 8b b5 e8 fd ff ff 	mov    -0x218(%rbp),%rsi
  230dd6:	48 8d 3d 53 73 09 00 	lea    0x97353(%rip),%rdi        # 2c8130 <_ZL17kSuppressionTypes+0x141c0>
  230ddd:	e8 ce b3 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230de2:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
  230de9:	48 c1 e8 03          	shr    $0x3,%rax
  230ded:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  230df3:	88 85 e7 fd ff ff    	mov    %al,-0x219(%rbp)
  230df9:	3c 00                	cmp    $0x0,%al
  230dfb:	74 25                	je     230e22 <nested_poll+0x106a>
  230dfd:	8a 8d e7 fd ff ff    	mov    -0x219(%rbp),%cl
  230e03:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
  230e0a:	48 83 e0 07          	and    $0x7,%rax
  230e0e:	48 83 c0 03          	add    $0x3,%rax
  230e12:	38 c8                	cmp    %cl,%al
  230e14:	7c 0c                	jl     230e22 <nested_poll+0x106a>
  230e16:	48 8b bd e8 fd ff ff 	mov    -0x218(%rbp),%rdi
  230e1d:	e8 4e 43 f8 ff       	call   1b5170 <__asan_report_load4>
  230e22:	48 8b 8d e8 fd ff ff 	mov    -0x218(%rbp),%rcx
  230e29:	31 c0                	xor    %eax,%eax
  230e2b:	83 39 03             	cmpl   $0x3,(%rcx)
  230e2e:	88 85 e6 fd ff ff    	mov    %al,-0x21a(%rbp)
  230e34:	0f 85 6e 01 00 00    	jne    230fa8 <nested_poll+0x11f0>
  230e3a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230e41:	25 00 00 00 00 
  230e46:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230e4d:	48 83 c0 30          	add    $0x30,%rax
  230e51:	48 89 85 d8 fd ff ff 	mov    %rax,-0x228(%rbp)
  230e58:	48 83 e0 07          	and    $0x7,%rax
  230e5c:	48 83 f8 00          	cmp    $0x0,%rax
  230e60:	74 13                	je     230e75 <nested_poll+0x10bd>
  230e62:	48 8b b5 d8 fd ff ff 	mov    -0x228(%rbp),%rsi
  230e69:	48 8d 3d e0 72 09 00 	lea    0x972e0(%rip),%rdi        # 2c8150 <_ZL17kSuppressionTypes+0x141e0>
  230e70:	e8 3b b3 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230e75:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
  230e7c:	48 c1 e8 03          	shr    $0x3,%rax
  230e80:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230e87:	74 0c                	je     230e95 <nested_poll+0x10dd>
  230e89:	48 8b bd d8 fd ff ff 	mov    -0x228(%rbp),%rdi
  230e90:	e8 cb 43 f8 ff       	call   1b5260 <__asan_report_load8>
  230e95:	48 8b 85 d8 fd ff ff 	mov    -0x228(%rbp),%rax
  230e9c:	48 8b 00             	mov    (%rax),%rax
  230e9f:	48 89 85 c8 fd ff ff 	mov    %rax,-0x238(%rbp)
  230ea6:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230ead:	25 00 00 00 00 
  230eb2:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230eb9:	48 83 c0 10          	add    $0x10,%rax
  230ebd:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
  230ec4:	b0 01                	mov    $0x1,%al
  230ec6:	a8 01                	test   $0x1,%al
  230ec8:	75 11                	jne    230edb <nested_poll+0x1123>
  230eca:	48 8d 3d 9f 72 09 00 	lea    0x9729f(%rip),%rdi        # 2c8170 <_ZL17kSuppressionTypes+0x14200>
  230ed1:	be 01 00 00 00       	mov    $0x1,%esi
  230ed6:	e8 25 cc fb ff       	call   1edb00 <__ubsan_handle_out_of_bounds>
  230edb:	48 8b 95 d0 fd ff ff 	mov    -0x230(%rbp),%rdx
  230ee2:	48 85 d2             	test   %rdx,%rdx
  230ee5:	0f 95 c0             	setne  %al
  230ee8:	48 89 d1             	mov    %rdx,%rcx
  230eeb:	48 83 c1 08          	add    $0x8,%rcx
  230eef:	48 89 8d b0 fd ff ff 	mov    %rcx,-0x250(%rbp)
  230ef6:	48 89 d6             	mov    %rdx,%rsi
  230ef9:	48 89 b5 b8 fd ff ff 	mov    %rsi,-0x248(%rbp)
  230f00:	48 89 ce             	mov    %rcx,%rsi
  230f03:	48 89 b5 c0 fd ff ff 	mov    %rsi,-0x240(%rbp)
  230f0a:	40 0f 95 c6          	setne  %sil
  230f0e:	40 30 f0             	xor    %sil,%al
  230f11:	34 01                	xor    $0x1,%al
  230f13:	48 29 d1             	sub    %rdx,%rcx
  230f16:	0f 93 c1             	setae  %cl
  230f19:	80 e1 ff             	and    $0xff,%cl
  230f1c:	20 c8                	and    %cl,%al
  230f1e:	a8 01                	test   $0x1,%al
  230f20:	75 1a                	jne    230f3c <nested_poll+0x1184>
  230f22:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
  230f29:	48 8b b5 b8 fd ff ff 	mov    -0x248(%rbp),%rsi
  230f30:	48 8d 3d 59 72 09 00 	lea    0x97259(%rip),%rdi        # 2c8190 <_ZL17kSuppressionTypes+0x14220>
  230f37:	e8 e4 eb fb ff       	call   1efb20 <__ubsan_handle_pointer_overflow>
  230f3c:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
  230f43:	48 83 f9 00          	cmp    $0x0,%rcx
  230f47:	0f 95 c0             	setne  %al
  230f4a:	48 83 e1 07          	and    $0x7,%rcx
  230f4e:	48 83 f9 00          	cmp    $0x0,%rcx
  230f52:	0f 94 c1             	sete   %cl
  230f55:	20 c8                	and    %cl,%al
  230f57:	a8 01                	test   $0x1,%al
  230f59:	75 13                	jne    230f6e <nested_poll+0x11b6>
  230f5b:	48 8b b5 b0 fd ff ff 	mov    -0x250(%rbp),%rsi
  230f62:	48 8d 3d 37 72 09 00 	lea    0x97237(%rip),%rdi        # 2c81a0 <_ZL17kSuppressionTypes+0x14230>
  230f69:	e8 42 b2 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  230f6e:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
  230f75:	48 c1 e8 03          	shr    $0x3,%rax
  230f79:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  230f80:	74 0c                	je     230f8e <nested_poll+0x11d6>
  230f82:	48 8b bd b0 fd ff ff 	mov    -0x250(%rbp),%rdi
  230f89:	e8 d2 42 f8 ff       	call   1b5260 <__asan_report_load8>
  230f8e:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
  230f95:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
  230f9c:	48 3b 01             	cmp    (%rcx),%rax
  230f9f:	0f 94 c0             	sete   %al
  230fa2:	88 85 e6 fd ff ff    	mov    %al,-0x21a(%rbp)
  230fa8:	8a 85 e6 fd ff ff    	mov    -0x21a(%rbp),%al
  230fae:	88 85 f6 fd ff ff    	mov    %al,-0x20a(%rbp)
  230fb4:	8a 85 f6 fd ff ff    	mov    -0x20a(%rbp),%al
  230fba:	0f b6 f8             	movzbl %al,%edi
  230fbd:	83 e7 01             	and    $0x1,%edi
  230fc0:	48 8d 35 d9 ae e8 ff 	lea    -0x175127(%rip),%rsi        # bbea0 <.str.17>
  230fc7:	e8 0c d8 ff ff       	call   22e7d8 <require>
  230fcc:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  230fd3:	25 00 00 00 00 
  230fd8:	48 8d 80 60 df ff ff 	lea    -0x20a0(%rax),%rax
  230fdf:	48 05 8c 20 00 00    	add    $0x208c,%rax
  230fe5:	48 89 85 a8 fd ff ff 	mov    %rax,-0x258(%rbp)
  230fec:	48 83 e0 03          	and    $0x3,%rax
  230ff0:	48 83 f8 00          	cmp    $0x0,%rax
  230ff4:	74 13                	je     231009 <nested_poll+0x1251>
  230ff6:	48 8b b5 a8 fd ff ff 	mov    -0x258(%rbp),%rsi
  230ffd:	48 8d 3d bc 71 09 00 	lea    0x971bc(%rip),%rdi        # 2c81c0 <_ZL17kSuppressionTypes+0x14250>
  231004:	e8 a7 b1 fb ff       	call   1ec1b0 <__ubsan_handle_type_mismatch_v1>
  231009:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  231010:	48 c1 e8 03          	shr    $0x3,%rax
  231014:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  23101a:	88 85 a7 fd ff ff    	mov    %al,-0x259(%rbp)
  231020:	3c 00                	cmp    $0x0,%al
  231022:	74 21                	je     231045 <nested_poll+0x128d>
  231024:	8a 8d a7 fd ff ff    	mov    -0x259(%rbp),%cl
  23102a:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  231031:	48 83 e0 07          	and    $0x7,%rax
  231035:	38 c8                	cmp    %cl,%al
  231037:	7c 0c                	jl     231045 <nested_poll+0x128d>
  231039:	48 8b bd a8 fd ff ff 	mov    -0x258(%rbp),%rdi
  231040:	e8 fb 43 f8 ff       	call   1b5440 <__asan_report_store1>
  231045:	48 8b 85 a8 fd ff ff 	mov    -0x258(%rbp),%rax
  23104c:	c6 00 01             	movb   $0x1,(%rax)
  23104f:	48 81 c4 60 02 00 00 	add    $0x260,%rsp
  231056:	5d                   	pop    %rbp
  231057:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
