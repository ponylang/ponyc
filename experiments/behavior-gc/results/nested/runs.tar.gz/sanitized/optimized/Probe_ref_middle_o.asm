
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ac870 <Probe_ref_middle_o>:
  2ac870:	55                   	push   %rbp
  2ac871:	41 57                	push   %r15
  2ac873:	41 56                	push   %r14
  2ac875:	41 55                	push   %r13
  2ac877:	41 54                	push   %r12
  2ac879:	53                   	push   %rbx
  2ac87a:	48 83 ec 48          	sub    $0x48,%rsp
  2ac87e:	48 89 fb             	mov    %rdi,%rbx
  2ac881:	e8 42 20 fa ff       	call   24e8c8 <pony_ctx>
  2ac886:	49 89 c6             	mov    %rax,%r14
  2ac889:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
  2ac88e:	48 8d 05 cf b4 df ff 	lea    -0x204b31(%rip),%rax        # a7d64 <_ZN11__sanitizerL10kExtraRegsE+0x7f04>
  2ac895:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  2ac89a:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
  2ac89f:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  2ac8a4:	48 8d 6c 24 38       	lea    0x38(%rsp),%rbp
  2ac8a9:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2ac8ae:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2ac8b5:	00 
  2ac8b6:	4c 8d 3d 13 e2 e1 ff 	lea    -0x1e1ded(%rip),%r15        # caad0 <.str.162+0xf0>
  2ac8bd:	4c 89 f7             	mov    %r14,%rdi
  2ac8c0:	48 89 de             	mov    %rbx,%rsi
  2ac8c3:	4c 89 fa             	mov    %r15,%rdx
  2ac8c6:	b9 18 00 00 00       	mov    $0x18,%ecx
  2ac8cb:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2ac8d1:	45 31 c9             	xor    %r9d,%r9d
  2ac8d4:	e8 af 08 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac8d9:	4c 89 f7             	mov    %r14,%rdi
  2ac8dc:	31 f6                	xor    %esi,%esi
  2ac8de:	e8 85 c3 f4 ff       	call   1f8c68 <pony_alloc_small>
  2ac8e3:	49 89 c4             	mov    %rax,%r12
  2ac8e6:	48 8d 05 a3 31 00 00 	lea    0x31a3(%rip),%rax        # 2afa90 <Cell_Desc>
  2ac8ed:	49 89 04 24          	mov    %rax,(%r12)
  2ac8f1:	49 c7 44 24 08 0f 01 	movq   $0x10f,0x8(%r12)
  2ac8f8:	00 00 
  2ac8fa:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
  2ac8ff:	48 8d 05 0e 5c df ff 	lea    -0x20a3f2(%rip),%rax        # a2514 <_ZN11__sanitizerL10kExtraRegsE+0x26b4>
  2ac906:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  2ac90b:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  2ac910:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2ac915:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2ac91c:	00 
  2ac91d:	4c 89 f7             	mov    %r14,%rdi
  2ac920:	48 89 de             	mov    %rbx,%rsi
  2ac923:	4c 89 fa             	mov    %r15,%rdx
  2ac926:	b9 19 00 00 00       	mov    $0x19,%ecx
  2ac92b:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
  2ac931:	45 31 c9             	xor    %r9d,%r9d
  2ac934:	e8 4f 08 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac939:	e8 22 02 00 00       	call   2acb60 <Probe_ref_phase_o>
  2ac93e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2ac943:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac947:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac94c:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac953:	00 00 
  2ac955:	48 8d 2d 94 e1 e1 ff 	lea    -0x1e1e6c(%rip),%rbp        # caaf0 <.str.162+0x110>
  2ac95c:	4c 89 f7             	mov    %r14,%rdi
  2ac95f:	48 89 de             	mov    %rbx,%rsi
  2ac962:	4c 89 fa             	mov    %r15,%rdx
  2ac965:	b9 1a 00 00 00       	mov    $0x1a,%ecx
  2ac96a:	41 b8 0f 00 00 00    	mov    $0xf,%r8d
  2ac970:	49 89 e9             	mov    %rbp,%r9
  2ac973:	e8 10 08 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac978:	4c 89 f7             	mov    %r14,%rdi
  2ac97b:	31 f6                	xor    %esi,%esi
  2ac97d:	e8 e6 c2 f4 ff       	call   1f8c68 <pony_alloc_small>
  2ac982:	49 89 c5             	mov    %rax,%r13
  2ac985:	48 8d 05 04 31 00 00 	lea    0x3104(%rip),%rax        # 2afa90 <Cell_Desc>
  2ac98c:	49 89 45 00          	mov    %rax,0x0(%r13)
  2ac990:	49 c7 45 08 d3 00 00 	movq   $0xd3,0x8(%r13)
  2ac997:	00 
  2ac998:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac99c:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac9a1:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac9a8:	00 00 
  2ac9aa:	4c 89 f7             	mov    %r14,%rdi
  2ac9ad:	48 89 de             	mov    %rbx,%rsi
  2ac9b0:	4c 89 fa             	mov    %r15,%rdx
  2ac9b3:	b9 1b 00 00 00       	mov    $0x1b,%ecx
  2ac9b8:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2ac9be:	49 89 e9             	mov    %rbp,%r9
  2ac9c1:	e8 c2 07 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac9c6:	4c 89 ef             	mov    %r13,%rdi
  2ac9c9:	e8 5a 4b f8 ff       	call   231528 <nested_fresh>
  2ac9ce:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2ac9d2:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2ac9d7:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2ac9de:	00 00 
  2ac9e0:	4c 89 f7             	mov    %r14,%rdi
  2ac9e3:	48 89 de             	mov    %rbx,%rsi
  2ac9e6:	4c 89 fa             	mov    %r15,%rdx
  2ac9e9:	b9 1c 00 00 00       	mov    $0x1c,%ecx
  2ac9ee:	41 b8 0d 00 00 00    	mov    $0xd,%r8d
  2ac9f4:	49 89 e9             	mov    %rbp,%r9
  2ac9f7:	e8 8c 07 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2ac9fc:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
  2aca01:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aca05:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aca0a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aca11:	00 00 
  2aca13:	4c 89 f7             	mov    %r14,%rdi
  2aca16:	48 89 de             	mov    %rbx,%rsi
  2aca19:	4c 89 fa             	mov    %r15,%rdx
  2aca1c:	b9 1d 00 00 00       	mov    $0x1d,%ecx
  2aca21:	41 b8 11 00 00 00    	mov    $0x11,%r8d
  2aca27:	49 89 e9             	mov    %rbp,%r9
  2aca2a:	e8 59 07 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2aca2f:	49 8d 45 07          	lea    0x7(%r13),%rax
  2aca33:	49 89 44 24 08       	mov    %rax,0x8(%r12)
  2aca38:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aca3c:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aca41:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aca48:	00 00 
  2aca4a:	4c 89 f7             	mov    %r14,%rdi
  2aca4d:	48 89 de             	mov    %rbx,%rsi
  2aca50:	4c 89 fa             	mov    %r15,%rdx
  2aca53:	b9 1e 00 00 00       	mov    $0x1e,%ecx
  2aca58:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2aca5e:	49 89 e9             	mov    %rbp,%r9
  2aca61:	e8 22 07 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2aca66:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  2aca6b:	bf 01 00 00 00       	mov    $0x1,%edi
  2aca70:	4c 89 e6             	mov    %r12,%rsi
  2aca73:	4c 89 ea             	mov    %r13,%rdx
  2aca76:	e8 2d 51 f8 ff       	call   231ba8 <nested_value>
  2aca7b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aca7f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aca84:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aca8b:	00 00 
  2aca8d:	4c 89 f7             	mov    %r14,%rdi
  2aca90:	48 89 de             	mov    %rbx,%rsi
  2aca93:	4c 89 fa             	mov    %r15,%rdx
  2aca96:	b9 18 00 00 00       	mov    $0x18,%ecx
  2aca9b:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2acaa1:	49 89 e9             	mov    %rbp,%r9
  2acaa4:	e8 df 06 f8 ff       	call   22d188 <ponyint_gc_root_audit>
  2acaa9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  2acaae:	48 83 c4 48          	add    $0x48,%rsp
  2acab2:	5b                   	pop    %rbx
  2acab3:	41 5c                	pop    %r12
  2acab5:	41 5d                	pop    %r13
  2acab7:	41 5e                	pop    %r14
  2acab9:	41 5f                	pop    %r15
  2acabb:	5d                   	pop    %rbp
  2acabc:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
