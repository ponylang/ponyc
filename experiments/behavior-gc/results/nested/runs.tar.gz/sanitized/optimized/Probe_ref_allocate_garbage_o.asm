
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002ac7c0 <Probe_ref_allocate_garbage_o>:
  2ac7c0:	41 57                	push   %r15
  2ac7c2:	41 56                	push   %r14
  2ac7c4:	53                   	push   %rbx
  2ac7c5:	45 31 f6             	xor    %r14d,%r14d
  2ac7c8:	e8 fb 20 fa ff       	call   24e8c8 <pony_ctx>
  2ac7cd:	48 89 c3             	mov    %rax,%rbx
  2ac7d0:	4c 8d 3d b9 32 00 00 	lea    0x32b9(%rip),%r15        # 2afa90 <Cell_Desc>
  2ac7d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  2ac7de:	00 00 
  2ac7e0:	48 89 df             	mov    %rbx,%rdi
  2ac7e3:	31 f6                	xor    %esi,%esi
  2ac7e5:	e8 7e c4 f4 ff       	call   1f8c68 <pony_alloc_small>
  2ac7ea:	4c 89 38             	mov    %r15,(%rax)
  2ac7ed:	4c 89 70 08          	mov    %r14,0x8(%rax)
  2ac7f1:	48 89 c7             	mov    %rax,%rdi
  2ac7f4:	e8 4f 2e f8 ff       	call   22f648 <nested_garbage>
  2ac7f9:	49 ff c6             	inc    %r14
  2ac7fc:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
  2ac803:	75 db                	jne    2ac7e0 <Probe_ref_allocate_garbage_o+0x20>
  2ac805:	48 8d 05 74 3a 00 00 	lea    0x3a74(%rip),%rax        # 2b0280 <None_Inst>
  2ac80c:	5b                   	pop    %rbx
  2ac80d:	41 5e                	pop    %r14
  2ac80f:	41 5f                	pop    %r15
  2ac811:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
