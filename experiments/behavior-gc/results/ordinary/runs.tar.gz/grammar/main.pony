use "peg"
use @pony_exitcode[None](code: I32)
use @puts[I32](s: Pointer[U8] tag)

actor Main
  new create(env: Env) =>
    @pony_exitcode(1)
    let large = try env.args(1)? == "large" else false end
    Worker(large)

actor Worker

  var _round: USize = 0
  var _expected: USize = 0
  var _ok: Bool = true

  var _first: (Parser val | None) = None

  new create(large: Bool) =>
    if large then run_large() else run_small() end

  be run_small() =>
    start_small()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_small() => _expected = 8

  be run_large() =>
    start_large()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_large() => _expected = 64

  fun ref batch() =>
    let grammar = Source.from_string("DIGIT19 <- '1'..'9'\nDIGIT <- '0'..'9'\nDIGITS <- DIGIT+\nINT <- '-' DIGIT19 DIGITS / '-' DIGIT / DIGIT19 DIGITS / DIGIT\nFRAC <- '.' DIGITS\nEXP <- ('e' / 'E') ('-' / '+')? DIGITS\nNUMBER <- INT FRAC? EXP?\n\nHEX <- DIGIT / 'a'..'f' / 'A'..'F'\nCHAR <-\n  \"\\\\\\\"\" / \"\\\\\\\\\" / \"\\\\/\" / \"\\\\b\" / \"\\\\f\" / \"\\\\n\" / \"\\\\r\" / \"\\\\t\" /\n  \"\\\\u\" HEX HEX HEX HEX / !\"\\\"\" !\"\\\\\" .\nSTRING <- \"\\\"\" CHAR* \"\\\"\"\nBOOL <- \"true\" / \"false\"\n\nvalue <- \"null\" / BOOL / NUMBER / STRING / object / array\npair <- STRING -':' value\n\nobject <- -'{' (pair % ',') -'}'\narray <- -'[' (value % ',') -']'\n\nwhitespace <- (' ' / '\\t' / '\\r' / '\\n')+\nlinecomment <- \"//\" (!'\\r' !'\\n' .)*\nnestedcomment <- \"/*\" ((!\"/*\" !\"*/\" .) / nestedcomment)* \"*/\"\n\nstart <- value\nhidden <- (whitespace / linecomment / nestedcomment)+\n")
    match recover val PegCompiler(grammar) end
    | let p: Parser val =>
      verify(p)
      if _round == 0 then _first = p end
    else _ok = false end
    match _first
    | let p: Parser val => verify(p)
    else _ok = false end
    _round = _round + 1

  fun ref verify(p: Parser val) =>
    let src = Source.from_string("{\n  \"firstName\": \"Rack\",\n  \"lastName\": \"Jackon\",\n  \"gender\": \"man\",\n  \"age\": 24,\n  \"address\": {\n    \"streetAddress\": \"126\",\n    \"city\": \"San Jone\",\n    \"state\": \"CA\",\n    \"postalCode\": \"394221\"\n  },\n  \"phoneNumbers\": [\n    {\n      \"type\": \"home\",\n      \"number\": \"7383627627\"\n    }\n  ]\n}\n")
    match recover val p.parse(src) end
    | (let offset: USize, let tree: ASTChild) =>
      let text: String = recover Printer(tree) end
      _ok = _ok and (offset == src.content.size()) and (text == "(object\n  (pair\n    (STRING \"firstName\")\n    (STRING \"Rack\")\n  )\n  (pair\n    (STRING \"lastName\")\n    (STRING \"Jackon\")\n  )\n  (pair\n    (STRING \"gender\")\n    (STRING \"man\")\n  )\n  (pair\n    (STRING \"age\")\n    (NUMBER 24)\n  )\n  (pair\n    (STRING \"address\")\n    (object\n      (pair\n        (STRING \"streetAddress\")\n        (STRING \"126\")\n      )\n      (pair\n        (STRING \"city\")\n        (STRING \"San Jone\")\n      )\n      (pair\n        (STRING \"state\")\n        (STRING \"CA\")\n      )\n      (pair\n        (STRING \"postalCode\")\n        (STRING \"394221\")\n      )\n    )\n  )\n  (pair\n    (STRING \"phoneNumbers\")\n    (array\n      (object\n        (pair\n          (STRING \"type\")\n          (STRING \"home\")\n        )\n        (pair\n          (STRING \"number\")\n          (STRING \"7383627627\")\n        )\n      )\n    )\n  )\n)\n")
    else _ok = false end

  fun ref finish() =>
    if _ok and (_round == _expected) then
      @puts("verified".cstring())
      @pony_exitcode(0)
    end
