
use @pony_exitcode[None](code: I32)
use @puts[I32](s: Pointer[U8] tag)

class Binding
  let factor: USize = 2

class FunctionDef
  let symbol: USize
  let parameter: Binding
  new create(i: USize, b: Binding) => (symbol, parameter) = (i, b)

class Instr
  let opcode: USize
  let operand: USize
  new create(op: USize, value: USize) => (opcode, operand) = (op, value)

actor Main
  new create(env: Env) =>
    @pony_exitcode(1)
    let large = try env.args(1)? == "large" else false end
    Worker(large)

actor Worker

  var _round: USize = 0
  var _expected: USize = 0
  var _ok: Bool = true

  let _shared: Binding = Binding
  let _source: Array[FunctionDef] = Array[FunctionDef]
  var _checksum: USize = 0

  new create(large: Bool) =>
    if large then run_large() else run_small() end

  be run_small() =>
    start_small()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_small() => _expected = 8

  be run_large() =>
    start_large()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_large() => _expected = 64

  fun ref batch() =>
    if _source.size() == 0 then
      var i: USize = 0
      while i < 512 do
        _source.push(FunctionDef(i, _shared))
        i = i + 1
      end
    end
    let code = Array[Instr]
    var index: USize = 0
    for def in _source.values() do
      _ok = _ok and (def.symbol == index) and (def.parameter is _shared)
      code.push(Instr(0, def.parameter.factor))
      code.push(Instr(1, def.symbol))
      index = index + 1
    end
    try
      var i: USize = 0
      while i < 512 do
        let mul = code(i * 2)?
        let add = code((i * 2) + 1)?
        let value = (3 * mul.operand) + add.operand
        _ok = _ok and (mul.opcode == 0) and (add.opcode == 1) and (value == (6 + i))
        _checksum = _checksum + value
        i = i + 1
      end
    else _ok = false end
    _round = _round + 1

  fun ref finish() =>
    if (_checksum == (_expected * ((512 * 6) + ((511 * 512) / 2)))) and _ok and (_round == _expected) then
      @puts("verified".cstring())
      @pony_exitcode(0)
    end
