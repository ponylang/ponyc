use @printf[I32](fmt: Pointer[U8] tag, ...)
use @pony_exitcode[None](code: I32)

actor Main
  new create(env: Env) =>
    @pony_exitcode(1)
    Worker

actor Worker
  var _round: USize = 0
  var _x: U64 = 7
  new create() => tick()

  be tick() =>
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    finish()

  fun ref step() =>
    _x = (_x * 6364136223846793005) + 1442695040888963407

  fun ref finish() =>
    _round = _round + 1
    if _round < 16384 then
      tick()
    else
      @printf("%llu\n".cstring(), _x)
      @pony_exitcode(0)
    end
