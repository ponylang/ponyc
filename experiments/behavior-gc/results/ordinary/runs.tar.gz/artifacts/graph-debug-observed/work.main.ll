; ModuleID = 'graph'
source_filename = "graph"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%Instr_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%t2_USize_val_Binding_ref_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [31 x ptr] }
%Main_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%FunctionDef_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%Binding_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%Worker_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [7 x ptr] }
%t2_USize_val_USize_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [31 x ptr] }
%USize_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [35 x ptr] }
%None = type { ptr }
%String_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [12 x ptr] }
%String = type { ptr, i64, i64, ptr }
%Env_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%Array_Instr_ref_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [12 x ptr] }
%Array_FunctionDef_ref_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [12 x ptr] }
%t2_USize_val_Binding_ref_Box = type { ptr, %t2_USize_val_Binding_ref }
%t2_USize_val_Binding_ref = type { i64, ptr }
%__message = type { i32, i32 }
%FunctionDef = type { ptr, i64, ptr }
%Worker = type { ptr, [296 x i8], i64, i64, i8, ptr, ptr, i64 }
%t2_USize_val_USize_val = type { i64, i64 }
%Instr = type { ptr, i64, i64 }
%__Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [0 x ptr] }
%__object = type { ptr }
%USize_Box = type { ptr, i64 }
%Env = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%Binding = type { ptr, i64 }
%Array_Instr_ref = type { ptr, i64, i64, ptr }
%Array_FunctionDef_ref = type { ptr, i64, i64, ptr }
%t2_USize_val_USize_val_Box = type { ptr, %t2_USize_val_USize_val }

@Instr_Desc = constant %Instr_Desc { i32 21, i32 24, i32 0, i32 8, ptr null, ptr @10, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Instr_Traits, ptr null, [1 x ptr] [ptr @Instr_ref_create_pZpZo] }
@t2_USize_val_Binding_ref_Desc = constant %t2_USize_val_Binding_ref_Desc { i32 2, i32 24, i32 2, i32 8, ptr null, ptr @11, ptr null, ptr @t2_USize_val_Binding_ref_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @t2_USize_val_Binding_ref_Traits, ptr @t2_USize_val_Binding_ref_Fields, [31 x ptr] [ptr @t2_USize_val_Binding_ref_box___is_, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @t2_USize_val_Binding_ref_box___digestof_] }
@Main_Desc = constant %Main_Desc { i32 1, i32 304, i32 0, i32 0, ptr null, ptr @12, ptr @Main_GetBehaviourName, ptr null, ptr @Main_Dispatch, ptr null, i32 -1, i1 true, ptr @Main_Traits, ptr null, [2 x ptr] [ptr @Main_runtime_override_defaults_oo, ptr @Main_tag_create_ioo__send] }
@0 = private unnamed_addr constant [15 x i8] c"Main.*UNKNOWN*\00"
@FunctionDef_Desc = constant %FunctionDef_Desc { i32 13, i32 24, i32 0, i32 8, ptr null, ptr @13, ptr null, ptr @FunctionDef_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @FunctionDef_Traits, ptr null, [1 x ptr] [ptr @FunctionDef_ref_create_pZmoo] }
@Binding_Desc = constant %Binding_Desc { i32 11, i32 16, i32 0, i32 8, ptr null, ptr @14, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Binding_Traits, ptr null, [1 x ptr] [ptr @Binding_iso_create_o] }
@Worker_Desc = constant %Worker_Desc { i32 17, i32 352, i32 0, i32 304, ptr null, ptr @15, ptr @Worker_GetBehaviourName, ptr @Worker_Trace, ptr @Worker_Dispatch, ptr null, i32 -1, i1 true, ptr @Worker_Traits, ptr null, [7 x ptr] [ptr @Worker_ref_finish_o, ptr @Worker_ref_start_large_o, ptr @Worker_tag_run_small_o__send, ptr @Worker_tag_create_pbo__send, ptr @Worker_tag_run_large_o__send, ptr @Worker_ref_batch_o, ptr @Worker_ref_start_small_o] }
@1 = private unnamed_addr constant [17 x i8] c"Worker.*UNKNOWN*\00"
@t2_USize_val_USize_val_Desc = constant %t2_USize_val_USize_val_Desc { i32 6, i32 24, i32 2, i32 8, ptr null, ptr @16, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @t2_USize_val_USize_val_Traits, ptr @t2_USize_val_USize_val_Fields, [31 x ptr] [ptr @t2_USize_val_USize_val_box___is_, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @t2_USize_val_USize_val_box___digestof_] }
@__NumSizeTable = constant [7 x i32] [i32 8, i32 1, i32 1, i32 4, i32 8, i32 4, i32 8], align 4
@USize_Desc = external global %USize_Desc
@None_Inst = external global %None
@String_Desc = external global %String_Desc
@2 = private unnamed_addr constant [6 x i8] c"large\00"
@3 = private unnamed_addr constant %String { ptr @String_Desc, i64 5, i64 6, ptr @2 }
@Env_Desc = external global %Env_Desc
@4 = private unnamed_addr constant [12 x i8] c"Main.create\00"
@5 = private unnamed_addr constant [17 x i8] c"Worker.run_large\00"
@6 = private unnamed_addr constant [17 x i8] c"Worker.run_small\00"
@Array_Instr_ref_Desc = external global %Array_Instr_ref_Desc
@7 = private unnamed_addr constant [9 x i8] c"verified\00"
@8 = private unnamed_addr constant %String { ptr @String_Desc, i64 8, i64 9, ptr @7 }
@Array_FunctionDef_ref_Desc = external global %Array_FunctionDef_ref_Desc
@9 = private unnamed_addr constant [14 x i8] c"Worker.create\00"
@10 = private unnamed_addr constant [6 x i8] c"Instr\00"
@Instr_Traits = constant [1 x i64] zeroinitializer
@11 = private unnamed_addr constant [25 x i8] c"t2_USize_val_Binding_ref\00"
@t2_USize_val_Binding_ref_Traits = constant [1 x i64] zeroinitializer
@t2_USize_val_Binding_ref_Fields = constant [2 x { i32, ptr }] [{ i32, ptr } { i32 0, ptr @USize_Desc }, { i32, ptr } { i32 8, ptr @Binding_Desc }]
@12 = private unnamed_addr constant [5 x i8] c"Main\00"
@Main_Traits = constant [1 x i64] zeroinitializer
@13 = private unnamed_addr constant [12 x i8] c"FunctionDef\00"
@FunctionDef_Traits = constant [1 x i64] zeroinitializer
@14 = private unnamed_addr constant [8 x i8] c"Binding\00"
@Binding_Traits = constant [1 x i64] zeroinitializer
@15 = private unnamed_addr constant [7 x i8] c"Worker\00"
@Worker_Traits = constant [1 x i64] zeroinitializer
@16 = private unnamed_addr constant [23 x i8] c"t2_USize_val_USize_val\00"
@t2_USize_val_USize_val_Traits = constant [1 x i64] zeroinitializer
@t2_USize_val_USize_val_Fields = constant [2 x { i32, ptr }] [{ i32, ptr } { i32 0, ptr @USize_Desc }, { i32, ptr } { i32 8, ptr @USize_Desc }]
@17 = private unnamed_addr constant [31 x i8] c"Error: couldn't start runtime!\00"

; Function Attrs: nounwind memory(none)
declare ptr @pony_ctx() #0

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(304) ptr @pony_create(ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_destroy(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv_single(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_alloc(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(32) ptr @pony_alloc_small(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(1024) ptr @pony_alloc_large(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_realloc(ptr, ptr, i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable_or_null(32) ptr @pony_alloc_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(32) ptr @pony_alloc_small_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(1024) ptr @pony_alloc_large_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 ptr @pony_alloc_msg(i32, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_trace(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceknown(ptr, ptr readonly, ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceunknown(ptr, ptr readonly, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_send(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_recv(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_send_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_recv_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i32 @pony_init(i32, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_become(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i1 @pony_start(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: read)
declare i32 @pony_get_exitcode() #2

declare void @pony_coverage_init(i32)

declare void @pony_coverage_write(ptr)

; Function Attrs: noreturn
declare void @abort() #3

; Function Attrs: nounwind memory(argmem: read)
declare i32 @memcmp(ptr readonly, ptr readonly, i64) #2

declare i32 @puts(ptr)

define fastcc i64 @U32_box_usize_Z(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = zext i32 %0 to i64
  ret i64 %1
}

define fastcc i64 @U32_val_usize_Z(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = zext i32 %0 to i64
  ret i64 %1
}

define fastcc i64 @U64_box_usize_Z(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @U64_val_usize_Z(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @USize_box_u64_W(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @USize_val_u64_W(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define { i32, i32, i32, i32 } @internal.x86.cpuid(i32 %0) unnamed_addr #4 {
entry:
  %1 = call { i32, i32, i32, i32 } asm "cpuid", "={ax},={bx},={cx},={dx},{ax}"(i32 %0)
  ret { i32, i32, i32, i32 } %1
}

; Function Attrs: nounwind
declare { i64, i32 } @llvm.x86.rdtscp() #5

define i64 @internal.x86.rdtscp(ptr %0) unnamed_addr #4 {
entry:
  %1 = call { i64, i32 } @llvm.x86.rdtscp()
  %2 = extractvalue { i64, i32 } %1, 1
  store i32 %2, ptr %0, align 4
  %3 = extractvalue { i64, i32 } %1, 0
  ret i64 %3
}

define void @t2_USize_val_Binding_ref_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw %t2_USize_val_Binding_ref_Box, ptr %1, i32 0, i32 1
  %3 = getelementptr inbounds nuw %t2_USize_val_Binding_ref, ptr %2, i32 0, i32 0
  %4 = load i64, ptr %3, align 8
  %5 = getelementptr inbounds nuw %t2_USize_val_Binding_ref, ptr %2, i32 0, i32 1
  %6 = load ptr, ptr %5, align 8
  call void @pony_traceknown(ptr %0, ptr %6, ptr @Binding_Desc, i32 0)
  ret void
}

define void @Main_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw %__message, ptr %2, i32 0, i32 1
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 1, label %handler
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  %4 = getelementptr inbounds nuw { i32, i32, ptr, ptr }, ptr %2, i32 0, i32 3
  %5 = load ptr, ptr %4, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %5, ptr @Env_Desc, i32 1)
  call void @pony_recv_done(ptr %0)
  call fastcc void @Main_tag_create_ioo(ptr %1, ptr %5)
  ret void
}

define ptr @Main_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 1, label %handler
  ]

default:                                          ; preds = %entry
  ret ptr @0

handler:                                          ; preds = %entry
  ret ptr @4
}

define void @FunctionDef_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw %FunctionDef, ptr %1, i32 0, i32 1
  %3 = load i64, ptr %2, align 8
  %4 = getelementptr inbounds nuw %FunctionDef, ptr %1, i32 0, i32 2
  %5 = load ptr, ptr %4, align 8
  call void @pony_traceknown(ptr %0, ptr %5, ptr @Binding_Desc, i32 0)
  ret void
}

define void @Worker_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw %__message, ptr %2, i32 0, i32 1
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 4, label %handler
    i32 2, label %handler1
    i32 3, label %handler2
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  call fastcc void @Worker_tag_run_large_o(ptr %1)
  ret void

handler1:                                         ; preds = %entry
  call fastcc void @Worker_tag_run_small_o(ptr %1)
  ret void

handler2:                                         ; preds = %entry
  %4 = getelementptr inbounds nuw { i32, i32, ptr, i8 }, ptr %2, i32 0, i32 3
  %5 = load i8, ptr %4, align 1
  %6 = trunc i8 %5 to i1
  call fastcc void @Worker_tag_create_pbo(ptr %1, i1 %6)
  ret void
}

define ptr @Worker_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 4, label %handler
    i32 2, label %handler1
    i32 3, label %handler2
  ]

default:                                          ; preds = %entry
  ret ptr @1

handler:                                          ; preds = %entry
  ret ptr @5

handler1:                                         ; preds = %entry
  ret ptr @6

handler2:                                         ; preds = %entry
  ret ptr @9
}

define void @Worker_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 2
  %3 = load i64, ptr %2, align 8
  %4 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 3
  %5 = load i64, ptr %4, align 8
  %6 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 4
  %7 = load i8, ptr %6, align 1
  %8 = trunc i8 %7 to i1
  %9 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 5
  %10 = load ptr, ptr %9, align 8
  call void @pony_traceknown(ptr %0, ptr %10, ptr @Binding_Desc, i32 0)
  %11 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 6
  %12 = load ptr, ptr %11, align 8
  call void @pony_traceknown(ptr %0, ptr %12, ptr @Array_FunctionDef_ref_Desc, i32 0)
  %13 = getelementptr inbounds nuw %Worker, ptr %1, i32 0, i32 7
  %14 = load i64, ptr %13, align 8
  ret void
}

define fastcc void @Instr_ref_create_pZpZo(ptr %this, i64 %op, i64 %value) unnamed_addr #4 !dbg !5 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !17, !DIExpression(), !19)
  %op2 = alloca i64, align 8
  store i64 %op, ptr %op2, align 8
    #dbg_declare(ptr %op2, !20, !DIExpression(), !21)
  %value3 = alloca i64, align 8
  store i64 %value, ptr %value3, align 8
    #dbg_declare(ptr %value3, !22, !DIExpression(), !23)
  %0 = insertvalue %t2_USize_val_USize_val undef, i64 %op, 0
  %1 = insertvalue %t2_USize_val_USize_val %0, i64 %value, 1
  %2 = getelementptr inbounds nuw %Instr, ptr %this, i32 0, i32 1, !dbg !24
  %3 = load i64, ptr %2, align 8, !dbg !24
  %4 = insertvalue %t2_USize_val_USize_val undef, i64 %3, 0, !dbg !24
  %5 = getelementptr inbounds nuw %Instr, ptr %this, i32 0, i32 2, !dbg !24
  %6 = load i64, ptr %5, align 8, !dbg !24
  %7 = insertvalue %t2_USize_val_USize_val %4, i64 %6, 1, !dbg !24
  %8 = extractvalue %t2_USize_val_USize_val %1, 0, !dbg !24
  %9 = getelementptr inbounds nuw %Instr, ptr %this, i32 0, i32 1, !dbg !24
  %10 = load i64, ptr %9, align 8, !dbg !24
  store i64 %8, ptr %9, align 8, !dbg !24
  %11 = extractvalue %t2_USize_val_USize_val %1, 1, !dbg !24
  %12 = getelementptr inbounds nuw %Instr, ptr %this, i32 0, i32 2, !dbg !24
  %13 = load i64, ptr %12, align 8, !dbg !24
  store i64 %11, ptr %12, align 8, !dbg !24
  ret void, !dbg !24
}

define fastcc noalias align 32 dereferenceable(24) ptr @Instr_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %2 = getelementptr inbounds nuw %Instr, ptr %1, i32 0, i32 0
  store volatile ptr @Instr_Desc, ptr %2, align 8
  ret ptr %1
}

define fastcc i64 @t2_USize_val_Binding_ref_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw %t2_USize_val_Binding_ref_Box, ptr %0, i32 0, i32 1
  %2 = load %t2_USize_val_Binding_ref, ptr %1, align 8
  %3 = extractvalue %t2_USize_val_Binding_ref %2, 0
  %4 = xor i64 0, %3
  %5 = extractvalue %t2_USize_val_Binding_ref %2, 1
  %6 = ptrtoint ptr %5 to i64
  %7 = xor i64 %4, %6
  ret i64 %7
}

define fastcc i1 @t2_USize_val_Binding_ref_box___is_(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw %t2_USize_val_Binding_ref_Box, ptr %0, i32 0, i32 1
  %4 = load %t2_USize_val_Binding_ref, ptr %3, align 8
  %5 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 3
  %6 = load i32, ptr %5, align 4
  %7 = zext i32 %6 to i64
  %8 = getelementptr inbounds i8, ptr %1, i64 %7
  %9 = extractvalue %t2_USize_val_Binding_ref %4, 0
  %10 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 13
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds [0 x { i32, ptr }], ptr %11, i32 0, i32 0
  %13 = load { i32, ptr }, ptr %12, align 8
  %14 = extractvalue { i32, ptr } %13, 0
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %8, i64 %15
  %17 = extractvalue { i32, ptr } %13, 1
  %18 = icmp eq ptr %17, null
  br i1 %18, label %is_tuple_null_desc, label %is_tuple_nonnull_desc

is_tuple_null_desc:                               ; preds = %entry
  %19 = load ptr, ptr %16, align 8
  %20 = ptrtoint ptr %19 to i64
  %21 = lshr i64 %20, 63
  %22 = trunc i64 %21 to i1
  br i1 %22, label %is_post, label %rib_heap

rib_heap:                                         ; preds = %is_tuple_null_desc
  %23 = getelementptr inbounds nuw %__object, ptr %19, i32 0, i32 0
  %24 = load ptr, ptr %23, align 8
  %25 = icmp eq ptr %24, @USize_Desc
  br i1 %25, label %is_value, label %is_post

is_value:                                         ; preds = %rib_heap
  %26 = getelementptr inbounds nuw %USize_Box, ptr %19, i32 0, i32 1
  %27 = load i64, ptr %26, align 8
  %28 = icmp eq i64 %9, %27
  br label %is_post

is_post:                                          ; preds = %is_value, %rib_heap, %is_tuple_null_desc
  %29 = phi i1 [ %28, %is_value ], [ false, %is_tuple_null_desc ], [ false, %rib_heap ]
  br label %is_tuple_merge_desc

is_tuple_nonnull_desc:                            ; preds = %entry
  %30 = getelementptr inbounds nuw %__Desc, ptr %17, i32 0, i32 0
  %31 = load i32, ptr %30, align 4
  %32 = and i32 %31, 3
  switch i32 %32, label %is_tuple_nonbox [
    i32 0, label %is_tuple_num
    i32 2, label %is_tuple_tuple
  ]

is_tuple_num:                                     ; preds = %is_tuple_nonnull_desc
  %33 = icmp eq ptr @USize_Desc, %17
  br i1 %33, label %is_tuple_bothnum, label %is_tuple_post1

is_tuple_bothnum:                                 ; preds = %is_tuple_num
  %34 = load i64, ptr %16, align 8
  %35 = icmp eq i64 %9, %34
  br label %is_tuple_post1

is_tuple_tuple:                                   ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_nonbox:                                  ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_post1:                                   ; preds = %is_tuple_nonbox, %is_tuple_tuple, %is_tuple_bothnum, %is_tuple_num
  %36 = phi i1 [ false, %is_tuple_num ], [ %35, %is_tuple_bothnum ], [ false, %is_tuple_tuple ], [ false, %is_tuple_nonbox ]
  br label %is_tuple_merge_desc

is_tuple_merge_desc:                              ; preds = %is_tuple_post1, %is_post
  %37 = phi i1 [ %29, %is_post ], [ %36, %is_tuple_post1 ]
  br i1 %37, label %is_tuple_next, label %is_tuple_post

is_tuple_next:                                    ; preds = %is_tuple_merge_desc
  %38 = extractvalue %t2_USize_val_Binding_ref %4, 1
  %39 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 13
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds [0 x { i32, ptr }], ptr %40, i32 0, i32 1
  %42 = load { i32, ptr }, ptr %41, align 8
  %43 = extractvalue { i32, ptr } %42, 0
  %44 = zext i32 %43 to i64
  %45 = getelementptr inbounds i8, ptr %8, i64 %44
  %46 = extractvalue { i32, ptr } %42, 1
  %47 = icmp eq ptr %46, null
  br i1 %47, label %is_tuple_null_desc2, label %is_tuple_nonnull_desc3

is_tuple_null_desc2:                              ; preds = %is_tuple_next
  %48 = load ptr, ptr %45, align 8
  %49 = icmp eq ptr %38, %48
  br label %is_tuple_merge_desc4

is_tuple_nonnull_desc3:                           ; preds = %is_tuple_next
  %50 = getelementptr inbounds nuw %__Desc, ptr %46, i32 0, i32 0
  %51 = load i32, ptr %50, align 4
  %52 = and i32 %51, 3
  switch i32 %52, label %is_tuple_nonbox7 [
    i32 0, label %is_tuple_num5
    i32 2, label %is_tuple_tuple6
  ]

is_tuple_num5:                                    ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post8

is_tuple_tuple6:                                  ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post8

is_tuple_nonbox7:                                 ; preds = %is_tuple_nonnull_desc3
  %53 = load ptr, ptr %45, align 8
  %54 = icmp eq ptr %38, %53
  br label %is_tuple_post8

is_tuple_post8:                                   ; preds = %is_tuple_nonbox7, %is_tuple_tuple6, %is_tuple_num5
  %55 = phi i1 [ false, %is_tuple_num5 ], [ false, %is_tuple_tuple6 ], [ %54, %is_tuple_nonbox7 ]
  br label %is_tuple_merge_desc4

is_tuple_merge_desc4:                             ; preds = %is_tuple_post8, %is_tuple_null_desc2
  %56 = phi i1 [ %49, %is_tuple_null_desc2 ], [ %55, %is_tuple_post8 ]
  br i1 %56, label %is_tuple_next9, label %is_tuple_post

is_tuple_next9:                                   ; preds = %is_tuple_merge_desc4
  br label %is_tuple_post

is_tuple_post:                                    ; preds = %is_tuple_next9, %is_tuple_merge_desc4, %is_tuple_merge_desc
  %57 = phi i1 [ false, %is_tuple_merge_desc ], [ false, %is_tuple_merge_desc4 ], [ true, %is_tuple_next9 ]
  ret i1 %57
}

define fastcc ptr @Main_tag_create_ioo__send(ptr %0, ptr dereferenceable(64) %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  %4 = getelementptr inbounds nuw { i32, i32, ptr, ptr }, ptr %3, i32 0, i32 3
  store ptr %1, ptr %4, align 8
  call void @pony_gc_send(ptr %2, ptr %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %2, ptr %1, ptr @Env_Desc, i32 1)
  call void @pony_send_done(ptr %2), !pony.msgsend !4
  call void @pony_sendv_single(ptr %2, ptr %0, ptr %3, ptr %3, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Main_tag_create_ioo(ptr %this, ptr dereferenceable(64) %env) unnamed_addr #4 !dbg !25 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %large = alloca i8, align 1
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !64, !DIExpression(), !68)
  %env2 = alloca ptr, align 8
  store ptr %env, ptr %env2, align 8
    #dbg_declare(ptr %env2, !69, !DIExpression(), !70)
  call void @pony_exitcode(i32 1), !dbg !71
  %1 = getelementptr inbounds nuw %Env, ptr %env, i32 0, i32 5
  %2 = load ptr, ptr %1, align 8
  %3 = call fastcc { ptr, i1 } @Array_String_val_val_apply_Zo_p(ptr %2, i64 1), !dbg !72
  %4 = extractvalue { ptr, i1 } %3, 1, !dbg !72
    #dbg_declare(ptr %large, !66, !DIExpression(), !74)
  br i1 %4, label %call_error, label %call_continue, !dbg !72

call_error:                                       ; preds = %entry
  br label %try_else, !dbg !72

call_continue:                                    ; preds = %entry
  %5 = extractvalue { ptr, i1 } %3, 0, !dbg !72
  %6 = call fastcc i1 @String_val_eq_ob(ptr %5, ptr @3), !dbg !75
  %7 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !76, !pony.newcall !4
  br label %try_post

try_else:                                         ; preds = %call_error
  %8 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !78, !pony.newcall !4
  br label %try_post

try_post:                                         ; preds = %try_else, %call_continue
  %9 = phi i1 [ %6, %call_continue ], [ false, %try_else ]
  call void @llvm.lifetime.start.p0(ptr %large)
  %10 = load i8, ptr %large, align 1
  %11 = trunc i8 %10 to i1
  %12 = zext i1 %9 to i8
  store i8 %12, ptr %large, align 1
  %13 = load i8, ptr %large, align 1
  %14 = trunc i8 %13 to i1
  %15 = call ptr @pony_create(ptr %0, ptr @Worker_Desc, i1 true)
  %16 = zext i1 %14 to i8, !dbg !80
  %17 = call ptr @pony_alloc_msg(i32 0, i32 3), !dbg !80, !pony.msgsend !4
  %18 = getelementptr inbounds nuw { i32, i32, ptr, i8 }, ptr %17, i32 0, i32 3, !dbg !80
  store i8 %16, ptr %18, align 1, !dbg !80
  call void @pony_sendv_single(ptr %0, ptr %15, ptr %17, ptr %17, i1 true), !dbg !80, !pony.msgsend !4
  call void @llvm.lifetime.end.p0(ptr %large)
  ret void
}

define void @Main_runtime_override_defaults_oo(ptr dereferenceable(112) %rto) #4 !dbg !81 !pony.abi !4 {
entry:
  %rto1 = alloca ptr, align 8
  store ptr %rto, ptr %rto1, align 8
    #dbg_declare(ptr %rto1, !120, !DIExpression(), !122)
  %0 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !122, !pony.newcall !4
  ret void, !dbg !122
}

define fastcc noalias align 32 dereferenceable(304) ptr @Main_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr @Main_Desc, i1 false)
  ret ptr %1
}

define fastcc void @FunctionDef_ref_create_pZmoo(ptr %this, i64 %i, ptr dereferenceable(16) %b) unnamed_addr #4 !dbg !123 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !137, !DIExpression(), !139)
  %i2 = alloca i64, align 8
  store i64 %i, ptr %i2, align 8
    #dbg_declare(ptr %i2, !140, !DIExpression(), !141)
  %b3 = alloca ptr, align 8
  store ptr %b, ptr %b3, align 8
    #dbg_declare(ptr %b3, !142, !DIExpression(), !143)
  %0 = insertvalue %t2_USize_val_Binding_ref undef, i64 %i, 0
  %1 = insertvalue %t2_USize_val_Binding_ref %0, ptr %b, 1
  %2 = getelementptr inbounds nuw %FunctionDef, ptr %this, i32 0, i32 1, !dbg !144
  %3 = load i64, ptr %2, align 8, !dbg !144
  %4 = insertvalue %t2_USize_val_Binding_ref undef, i64 %3, 0, !dbg !144
  %5 = getelementptr inbounds nuw %FunctionDef, ptr %this, i32 0, i32 2, !dbg !144
  %6 = load ptr, ptr %5, align 8, !dbg !144
  %7 = insertvalue %t2_USize_val_Binding_ref %4, ptr %6, 1, !dbg !144
  %8 = extractvalue %t2_USize_val_Binding_ref %1, 0, !dbg !144
  %9 = getelementptr inbounds nuw %FunctionDef, ptr %this, i32 0, i32 1, !dbg !144
  %10 = load i64, ptr %9, align 8, !dbg !144
  store i64 %8, ptr %9, align 8, !dbg !144
  %11 = extractvalue %t2_USize_val_Binding_ref %1, 1, !dbg !144
  %12 = getelementptr inbounds nuw %FunctionDef, ptr %this, i32 0, i32 2, !dbg !144
  %13 = load ptr, ptr %12, align 8, !dbg !144
  store ptr %11, ptr %12, align 8, !dbg !144
  ret void, !dbg !144
}

define fastcc noalias align 32 dereferenceable(24) ptr @FunctionDef_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %2 = getelementptr inbounds nuw %FunctionDef, ptr %1, i32 0, i32 0
  store volatile ptr @FunctionDef_Desc, ptr %2, align 8
  ret ptr %1
}

define fastcc void @Binding_iso_create_o(ptr %this) unnamed_addr #4 !dbg !145 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !150, !DIExpression(), !152)
  %0 = getelementptr inbounds nuw %Binding, ptr %this, i32 0, i32 1, !dbg !153
  %1 = load i64, ptr %0, align 8, !dbg !153
  store i64 2, ptr %0, align 8, !dbg !153
  ret void, !dbg !152
}

define fastcc noalias align 32 dereferenceable(16) ptr @Binding_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %2 = getelementptr inbounds nuw %Binding, ptr %1, i32 0, i32 0
  store volatile ptr @Binding_Desc, ptr %2, align 8
  ret ptr %1
}

define fastcc ptr @Worker_tag_run_large_o__send(ptr dereferenceable(352) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 4), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_run_large_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !154 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !174, !DIExpression(), !176)
  %1 = call fastcc ptr @Worker_ref_start_large_o(ptr %this), !dbg !177
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 53)
  %2 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !178
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 54)
  %3 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !179
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 55)
  %4 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !180
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 56)
  %5 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !181
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 57)
  %6 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !182
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 58)
  %7 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !183
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 59)
  %8 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !184
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 60)
  %9 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !185
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 61)
  %10 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !186
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 62)
  %11 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !187
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 63)
  %12 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !188
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 64)
  %13 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !189
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 65)
  %14 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !190
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 66)
  %15 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !191
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 67)
  %16 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !192
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 68)
  %17 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !193
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 69)
  %18 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !194
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 70)
  %19 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !195
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 71)
  %20 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !196
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 72)
  %21 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !197
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 73)
  %22 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !198
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 74)
  %23 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !199
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 75)
  %24 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !200
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 76)
  %25 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !201
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 77)
  %26 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !202
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 78)
  %27 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !203
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 79)
  %28 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !204
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 80)
  %29 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !205
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 81)
  %30 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !206
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 82)
  %31 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !207
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 83)
  %32 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !208
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 84)
  %33 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !209
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 85)
  %34 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !210
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 86)
  %35 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !211
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 87)
  %36 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !212
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 88)
  %37 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !213
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 89)
  %38 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !214
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 90)
  %39 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !215
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 91)
  %40 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !216
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 92)
  %41 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !217
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 93)
  %42 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !218
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 94)
  %43 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !219
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 95)
  %44 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !220
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 96)
  %45 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !221
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 97)
  %46 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !222
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 98)
  %47 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !223
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 99)
  %48 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !224
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 100)
  %49 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !225
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 101)
  %50 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !226
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 102)
  %51 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !227
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 103)
  %52 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !228
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 104)
  %53 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !229
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 105)
  %54 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !230
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 106)
  %55 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !231
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 107)
  %56 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !232
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 108)
  %57 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !233
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 109)
  %58 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !234
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 110)
  %59 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !235
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 111)
  %60 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !236
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 112)
  %61 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !237
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 113)
  %62 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !238
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 114)
  %63 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !239
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 115)
  %64 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !240
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 116)
  %65 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !241
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 117)
  %66 = call fastcc ptr @Worker_ref_finish_o(ptr %this), !dbg !242
  ret void
}

define fastcc ptr @Worker_tag_run_small_o__send(ptr dereferenceable(352) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 2), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_run_small_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !243 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !246, !DIExpression(), !247)
  %1 = call fastcc ptr @Worker_ref_start_small_o(ptr %this), !dbg !248
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 39)
  %2 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !249
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 40)
  %3 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !250
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 41)
  %4 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !251
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 42)
  %5 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !252
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 43)
  %6 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !253
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 44)
  %7 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !254
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 45)
  %8 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !255
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 46)
  %9 = call fastcc ptr @Worker_ref_batch_o(ptr %this), !dbg !256
  call void @ponyint_ordinary_poll(ptr %0, ptr %this, i32 47)
  %10 = call fastcc ptr @Worker_ref_finish_o(ptr %this), !dbg !257
  ret void
}

define fastcc ptr @Worker_ref_batch_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !258 !pony.abi !4 {
entry:
  %value = alloca i64, align 8
  %add = alloca ptr, align 8
  %mul = alloca ptr, align 8
  %i11 = alloca i64, align 8
  %def = alloca ptr, align 8
  %"$1$0" = alloca ptr, align 8
  %index = alloca i64, align 8
  %code = alloca ptr, align 8
  %0 = call ptr @pony_ctx()
  %i = alloca i64, align 8
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !261, !DIExpression(), !289)
  %1 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 6, !dbg !290
  %2 = load ptr, ptr %1, align 8, !dbg !290
  %3 = call fastcc i64 @Array_FunctionDef_ref_ref_size_Z(ptr %2), !dbg !291
  %4 = icmp eq i64 %3, 0
    #dbg_declare(ptr %i, !262, !DIExpression(), !292)
    #dbg_declare(ptr %code, !265, !DIExpression(), !293)
    #dbg_declare(ptr %index, !272, !DIExpression(), !294)
    #dbg_declare(ptr %"$1$0", !273, !DIExpression(), !295)
    #dbg_declare(ptr %def, !279, !DIExpression(), !296)
    #dbg_declare(ptr %i11, !282, !DIExpression(), !297)
    #dbg_declare(ptr %mul, !284, !DIExpression(), !298)
    #dbg_declare(ptr %add, !287, !DIExpression(), !299)
    #dbg_declare(ptr %value, !288, !DIExpression(), !300)
  br i1 %4, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  call void @llvm.lifetime.start.p0(ptr %i)
  %5 = load i64, ptr %i, align 8
  store i64 0, ptr %i, align 8
  br label %while_init

while_init:                                       ; preds = %if_then
  %6 = load i64, ptr %i, align 8, !dbg !301
  %7 = icmp ult i64 %6, 512, !dbg !301
  br i1 %7, label %while_body, label %while_else

while_body:                                       ; preds = %while_body, %while_init
  %8 = load i64, ptr %i, align 8
  %9 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 5
  %10 = load ptr, ptr %9, align 8
  %11 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %12 = getelementptr inbounds nuw %FunctionDef, ptr %11, i32 0, i32 0
  store volatile ptr @FunctionDef_Desc, ptr %12, align 8
  call fastcc void @FunctionDef_ref_create_pZmoo(ptr %11, i64 %8, ptr %10), !dbg !303, !pony.newcall !4
  %13 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 6
  %14 = load ptr, ptr %13, align 8
  %15 = call fastcc ptr @Array_FunctionDef_ref_ref_push_oo(ptr %14, ptr %11), !dbg !305
  %16 = load i64, ptr %i, align 8, !dbg !306
  %17 = add i64 %16, 1, !dbg !306
  %18 = load i64, ptr %i, align 8, !dbg !307
  store i64 %17, ptr %i, align 8, !dbg !307
  %19 = load i64, ptr %i, align 8, !dbg !301
  %20 = icmp ult i64 %19, 512, !dbg !301
  br i1 %20, label %while_body, label %while_post

while_else:                                       ; preds = %while_init
  %21 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !308, !pony.newcall !4
  br label %while_post

while_post:                                       ; preds = %while_else, %while_body
  call void @llvm.lifetime.end.p0(ptr %i)
  br label %if_post

if_else:                                          ; preds = %entry
  %22 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !310, !pony.newcall !4
  br label %if_post

if_post:                                          ; preds = %if_else, %while_post
  %23 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %24 = getelementptr inbounds nuw %Array_Instr_ref, ptr %23, i32 0, i32 0
  store volatile ptr @Array_Instr_ref_Desc, ptr %24, align 8
  call fastcc void @Array_Instr_ref_ref_create_pZo(ptr %23, i64 0), !dbg !312, !pony.newcall !4
  call void @llvm.lifetime.start.p0(ptr %code)
  %25 = load ptr, ptr %code, align 8
  store ptr %23, ptr %code, align 8
  call void @llvm.lifetime.start.p0(ptr %index)
  %26 = load i64, ptr %index, align 8
  store i64 0, ptr %index, align 8
  %27 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 6
  %28 = load ptr, ptr %27, align 8
  %29 = call fastcc ptr @Array_FunctionDef_ref_ref_values_o(ptr %28), !dbg !313
  call void @llvm.lifetime.start.p0(ptr %"$1$0")
  %30 = load ptr, ptr %"$1$0", align 8
  store ptr %29, ptr %"$1$0", align 8
  br label %while_init2

while_init2:                                      ; preds = %if_post
  %31 = load ptr, ptr %"$1$0", align 8
  %32 = call fastcc i1 @ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref_ref_has_next_b(ptr %31), !dbg !314
  br i1 %32, label %while_body3, label %while_else4

while_body3:                                      ; preds = %sc_post8, %while_init2
  %33 = load ptr, ptr %"$1$0", align 8
  %34 = call fastcc { ptr, i1 } @ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref_ref_next_o_p(ptr %33), !dbg !315
  %35 = extractvalue { ptr, i1 } %34, 1, !dbg !315
  br i1 %35, label %call_error, label %call_continue, !dbg !315

call_error:                                       ; preds = %while_body3
  br label %try_else, !dbg !315

call_continue:                                    ; preds = %while_body3
  %36 = extractvalue { ptr, i1 } %34, 0, !dbg !315
  %37 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !317, !pony.newcall !4
  br label %try_post

try_else:                                         ; preds = %call_error
  %38 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !319, !pony.newcall !4
  br label %while_else4, !dbg !322

try_post:                                         ; preds = %call_continue
  %39 = phi ptr [ %36, %call_continue ]
  call void @llvm.lifetime.start.p0(ptr %def)
  %40 = load ptr, ptr %def, align 8
  store ptr %39, ptr %def, align 8
  br label %sc_left, !dbg !323

sc_left:                                          ; preds = %try_post
  br label %sc_left6, !dbg !324

sc_left6:                                         ; preds = %sc_left
  %41 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !324
  %42 = load i8, ptr %41, align 1, !dbg !324
  %43 = trunc i8 %42 to i1, !dbg !324
  br i1 %43, label %sc_right, label %sc_post, !dbg !324

sc_right:                                         ; preds = %sc_left6
  %44 = load ptr, ptr %def, align 8, !dbg !325
  %45 = getelementptr inbounds nuw %FunctionDef, ptr %44, i32 0, i32 1, !dbg !325
  %46 = load i64, ptr %45, align 8, !dbg !325
  %47 = load i64, ptr %index, align 8, !dbg !325
  %48 = icmp eq i64 %46, %47, !dbg !325
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left6
  %49 = phi i1 [ %43, %sc_left6 ], [ %48, %sc_right ]
  br i1 %49, label %sc_right7, label %sc_post8

sc_right7:                                        ; preds = %sc_post
  %50 = load ptr, ptr %def, align 8
  %51 = getelementptr inbounds nuw %FunctionDef, ptr %50, i32 0, i32 2
  %52 = load ptr, ptr %51, align 8
  %53 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 5
  %54 = load ptr, ptr %53, align 8
  %55 = icmp eq ptr %52, %54, !dbg !326
  br label %sc_post8

sc_post8:                                         ; preds = %sc_right7, %sc_post
  %56 = phi i1 [ %49, %sc_post ], [ %55, %sc_right7 ]
  %57 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !327
  %58 = load i8, ptr %57, align 1, !dbg !327
  %59 = zext i1 %56 to i8, !dbg !327
  store i8 %59, ptr %57, align 1, !dbg !327
  %60 = trunc i8 %58 to i1, !dbg !327
  %61 = load ptr, ptr %def, align 8
  %62 = getelementptr inbounds nuw %FunctionDef, ptr %61, i32 0, i32 2
  %63 = load ptr, ptr %62, align 8
  %64 = getelementptr inbounds nuw %Binding, ptr %63, i32 0, i32 1
  %65 = load i64, ptr %64, align 8
  %66 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %67 = getelementptr inbounds nuw %Instr, ptr %66, i32 0, i32 0
  store volatile ptr @Instr_Desc, ptr %67, align 8
  call fastcc void @Instr_ref_create_pZpZo(ptr %66, i64 0, i64 %65), !dbg !328, !pony.newcall !4
  %68 = load ptr, ptr %code, align 8
  %69 = call fastcc ptr @Array_Instr_ref_ref_push_oo(ptr %68, ptr %66), !dbg !329
  %70 = load ptr, ptr %def, align 8
  %71 = getelementptr inbounds nuw %FunctionDef, ptr %70, i32 0, i32 1
  %72 = load i64, ptr %71, align 8
  %73 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %74 = getelementptr inbounds nuw %Instr, ptr %73, i32 0, i32 0
  store volatile ptr @Instr_Desc, ptr %74, align 8
  call fastcc void @Instr_ref_create_pZpZo(ptr %73, i64 1, i64 %72), !dbg !330, !pony.newcall !4
  %75 = load ptr, ptr %code, align 8
  %76 = call fastcc ptr @Array_Instr_ref_ref_push_oo(ptr %75, ptr %73), !dbg !331
  %77 = load i64, ptr %index, align 8, !dbg !332
  %78 = add i64 %77, 1, !dbg !332
  %79 = load i64, ptr %index, align 8, !dbg !333
  store i64 %78, ptr %index, align 8, !dbg !333
  call void @llvm.lifetime.end.p0(ptr %def)
  %80 = load ptr, ptr %"$1$0", align 8
  %81 = call fastcc i1 @ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref_ref_has_next_b(ptr %80), !dbg !314
  br i1 %81, label %while_body3, label %while_post5

while_else4:                                      ; preds = %try_else, %while_init2
  %82 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !334, !pony.newcall !4
  br label %while_post5

while_post5:                                      ; preds = %while_else4, %sc_post8
  call void @llvm.lifetime.start.p0(ptr %i11)
  %83 = load i64, ptr %i11, align 8
  store i64 0, ptr %i11, align 8
  br label %while_init12

while_init12:                                     ; preds = %while_post5
  %84 = load i64, ptr %i11, align 8, !dbg !336
  %85 = icmp ult i64 %84, 512, !dbg !336
  br i1 %85, label %while_body13, label %while_else14

while_body13:                                     ; preds = %sc_post28, %while_init12
  %86 = load i64, ptr %i11, align 8, !dbg !337
  %87 = mul i64 %86, 2, !dbg !337
  %88 = load ptr, ptr %code, align 8
  %89 = call fastcc { ptr, i1 } @Array_Instr_ref_ref_apply_Zo_p(ptr %88, i64 %87), !dbg !338
  %90 = extractvalue { ptr, i1 } %89, 1, !dbg !338
  br i1 %90, label %call_error16, label %call_continue17, !dbg !338

call_error16:                                     ; preds = %while_body13
  br label %try_else9, !dbg !338

call_continue17:                                  ; preds = %while_body13
  %91 = extractvalue { ptr, i1 } %89, 0, !dbg !338
  call void @llvm.lifetime.start.p0(ptr %mul)
  %92 = load ptr, ptr %mul, align 8
  store ptr %91, ptr %mul, align 8
  %93 = load i64, ptr %i11, align 8, !dbg !339
  %94 = mul i64 %93, 2, !dbg !339
  %95 = add i64 %94, 1
  %96 = load ptr, ptr %code, align 8
  %97 = call fastcc { ptr, i1 } @Array_Instr_ref_ref_apply_Zo_p(ptr %96, i64 %95), !dbg !340
  %98 = extractvalue { ptr, i1 } %97, 1, !dbg !340
  br i1 %98, label %call_error18, label %call_continue19, !dbg !340

call_error18:                                     ; preds = %call_continue17
  br label %try_else9, !dbg !340

call_continue19:                                  ; preds = %call_continue17
  %99 = extractvalue { ptr, i1 } %97, 0, !dbg !340
  call void @llvm.lifetime.start.p0(ptr %add)
  %100 = load ptr, ptr %add, align 8
  store ptr %99, ptr %add, align 8
  %101 = load ptr, ptr %mul, align 8, !dbg !341
  %102 = getelementptr inbounds nuw %Instr, ptr %101, i32 0, i32 2, !dbg !341
  %103 = load i64, ptr %102, align 8, !dbg !341
  %104 = mul i64 3, %103, !dbg !341
  %105 = load ptr, ptr %add, align 8
  %106 = getelementptr inbounds nuw %Instr, ptr %105, i32 0, i32 2
  %107 = load i64, ptr %106, align 8
  %108 = add i64 %104, %107
  call void @llvm.lifetime.start.p0(ptr %value)
  %109 = load i64, ptr %value, align 8
  store i64 %108, ptr %value, align 8
  br label %sc_left20, !dbg !342

sc_left20:                                        ; preds = %call_continue19
  br label %sc_left21, !dbg !343

sc_left21:                                        ; preds = %sc_left20
  br label %sc_left22, !dbg !344

sc_left22:                                        ; preds = %sc_left21
  %110 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !344
  %111 = load i8, ptr %110, align 1, !dbg !344
  %112 = trunc i8 %111 to i1, !dbg !344
  br i1 %112, label %sc_right23, label %sc_post24, !dbg !344

sc_right23:                                       ; preds = %sc_left22
  %113 = load ptr, ptr %mul, align 8, !dbg !345
  %114 = getelementptr inbounds nuw %Instr, ptr %113, i32 0, i32 1, !dbg !345
  %115 = load i64, ptr %114, align 8, !dbg !345
  %116 = icmp eq i64 %115, 0, !dbg !345
  br label %sc_post24

sc_post24:                                        ; preds = %sc_right23, %sc_left22
  %117 = phi i1 [ %112, %sc_left22 ], [ %116, %sc_right23 ]
  br i1 %117, label %sc_right25, label %sc_post26

sc_right25:                                       ; preds = %sc_post24
  %118 = load ptr, ptr %add, align 8, !dbg !346
  %119 = getelementptr inbounds nuw %Instr, ptr %118, i32 0, i32 1, !dbg !346
  %120 = load i64, ptr %119, align 8, !dbg !346
  %121 = icmp eq i64 %120, 1, !dbg !346
  br label %sc_post26

sc_post26:                                        ; preds = %sc_right25, %sc_post24
  %122 = phi i1 [ %117, %sc_post24 ], [ %121, %sc_right25 ]
  br i1 %122, label %sc_right27, label %sc_post28

sc_right27:                                       ; preds = %sc_post26
  %123 = load i64, ptr %value, align 8, !dbg !347
  %124 = load i64, ptr %i11, align 8, !dbg !348
  %125 = add i64 6, %124, !dbg !348
  %126 = icmp eq i64 %123, %125
  br label %sc_post28

sc_post28:                                        ; preds = %sc_right27, %sc_post26
  %127 = phi i1 [ %122, %sc_post26 ], [ %126, %sc_right27 ]
  %128 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !349
  %129 = load i8, ptr %128, align 1, !dbg !349
  %130 = zext i1 %127 to i8, !dbg !349
  store i8 %130, ptr %128, align 1, !dbg !349
  %131 = trunc i8 %129 to i1, !dbg !349
  %132 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 7, !dbg !350
  %133 = load i64, ptr %132, align 8, !dbg !350
  %134 = load i64, ptr %value, align 8, !dbg !350
  %135 = add i64 %133, %134, !dbg !350
  %136 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 7, !dbg !351
  %137 = load i64, ptr %136, align 8, !dbg !351
  store i64 %135, ptr %136, align 8, !dbg !351
  %138 = load i64, ptr %i11, align 8, !dbg !352
  %139 = add i64 %138, 1, !dbg !352
  %140 = load i64, ptr %i11, align 8, !dbg !353
  store i64 %139, ptr %i11, align 8, !dbg !353
  call void @llvm.lifetime.end.p0(ptr %mul)
  call void @llvm.lifetime.end.p0(ptr %value)
  call void @llvm.lifetime.end.p0(ptr %add)
  %141 = load i64, ptr %i11, align 8, !dbg !336
  %142 = icmp ult i64 %141, 512, !dbg !336
  br i1 %142, label %while_body13, label %while_post15

while_else14:                                     ; preds = %while_init12
  %143 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !354, !pony.newcall !4
  br label %while_post15

while_post15:                                     ; preds = %while_else14, %sc_post28
  call void @llvm.lifetime.end.p0(ptr %i11)
  %144 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !356, !pony.newcall !4
  br label %try_post10

try_else9:                                        ; preds = %call_error18, %call_error16
  %145 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !358
  %146 = load i8, ptr %145, align 1, !dbg !358
  store i8 0, ptr %145, align 1, !dbg !358
  %147 = trunc i8 %146 to i1, !dbg !358
  %148 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !360, !pony.newcall !4
  br label %try_post10

try_post10:                                       ; preds = %try_else9, %while_post15
  %149 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 2, !dbg !362
  %150 = load i64, ptr %149, align 8, !dbg !362
  %151 = add i64 %150, 1, !dbg !362
  %152 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 2, !dbg !363
  %153 = load i64, ptr %152, align 8, !dbg !363
  store i64 %151, ptr %152, align 8, !dbg !363
  %154 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !364, !pony.newcall !4
  call void @llvm.lifetime.end.p0(ptr %code)
  call void @llvm.lifetime.end.p0(ptr %index)
  call void @llvm.lifetime.end.p0(ptr %"$1$0")
  ret ptr %154, !dbg !364
}

define fastcc ptr @Worker_ref_start_small_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !365 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !368, !DIExpression(), !369)
  %0 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 3, !dbg !370
  %1 = load i64, ptr %0, align 8, !dbg !370
  store i64 8, ptr %0, align 8, !dbg !370
  %2 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !371, !pony.newcall !4
  ret ptr %2, !dbg !371
}

define fastcc ptr @Worker_ref_finish_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !372 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !375, !DIExpression(), !376)
  br label %sc_left, !dbg !377

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !379

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 7, !dbg !380
  %1 = load i64, ptr %0, align 8, !dbg !380
  %2 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 3, !dbg !381
  %3 = load i64, ptr %2, align 8, !dbg !381
  br i1 true, label %div_nonzero, label %div_post

div_nonzero:                                      ; preds = %sc_left2
  br label %div_post

div_post:                                         ; preds = %div_nonzero, %sc_left2
  %4 = phi i64 [ 0, %sc_left2 ], [ 130816, %div_nonzero ]
  %5 = add i64 3072, %4
  %6 = mul i64 %3, %5
  %7 = icmp eq i64 %1, %6
  br i1 %7, label %sc_right, label %sc_post

sc_right:                                         ; preds = %div_post
  %8 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4
  %9 = load i8, ptr %8, align 1
  %10 = trunc i8 %9 to i1
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %div_post
  %11 = phi i1 [ %7, %div_post ], [ %10, %sc_right ]
  br i1 %11, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %12 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 2, !dbg !382
  %13 = load i64, ptr %12, align 8, !dbg !382
  %14 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 3, !dbg !382
  %15 = load i64, ptr %14, align 8, !dbg !382
  %16 = icmp eq i64 %13, %15, !dbg !382
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %17 = phi i1 [ %11, %sc_post ], [ %16, %sc_right3 ]
  br i1 %17, label %if_then, label %if_else

if_then:                                          ; preds = %sc_post4
  %18 = call fastcc ptr @String_val_cstring_o(ptr @8), !dbg !383
  %19 = call i32 @puts(ptr %18), !dbg !385
  call void @pony_exitcode(i32 0), !dbg !386
  br label %if_post

if_else:                                          ; preds = %sc_post4
  %20 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !387, !pony.newcall !4
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %21 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !389, !pony.newcall !4
  ret ptr %21, !dbg !389
}

define fastcc ptr @Worker_tag_create_pbo__send(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = zext i1 %1 to i8
  %4 = call ptr @pony_alloc_msg(i32 0, i32 3), !pony.msgsend !4
  %5 = getelementptr inbounds nuw { i32, i32, ptr, i8 }, ptr %4, i32 0, i32 3
  store i8 %3, ptr %5, align 1
  call void @pony_sendv_single(ptr %2, ptr %0, ptr %4, ptr %4, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Worker_tag_create_pbo(ptr %this, i1 %large) unnamed_addr #4 !dbg !390 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !395, !DIExpression(), !396)
  %large2 = alloca i8, align 1
  %1 = zext i1 %large to i8
  store i8 %1, ptr %large2, align 1
    #dbg_declare(ptr %large2, !397, !DIExpression(), !398)
  %2 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 2, !dbg !399
  %3 = load i64, ptr %2, align 8, !dbg !399
  store i64 0, ptr %2, align 8, !dbg !399
  %4 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 3, !dbg !400
  %5 = load i64, ptr %4, align 8, !dbg !400
  store i64 0, ptr %4, align 8, !dbg !400
  %6 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 4, !dbg !401
  %7 = load i8, ptr %6, align 1, !dbg !401
  store i8 1, ptr %6, align 1, !dbg !401
  %8 = trunc i8 %7 to i1, !dbg !401
  %9 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %10 = getelementptr inbounds nuw %Binding, ptr %9, i32 0, i32 0
  store volatile ptr @Binding_Desc, ptr %10, align 8
  call fastcc void @Binding_iso_create_o(ptr %9), !dbg !402, !pony.newcall !4
  %11 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 5, !dbg !403
  %12 = load ptr, ptr %11, align 8, !dbg !403
  store ptr %9, ptr %11, align 8, !dbg !403
  %13 = call ptr @pony_alloc_small(ptr %0, i32 0)
  %14 = getelementptr inbounds nuw %Array_FunctionDef_ref, ptr %13, i32 0, i32 0
  store volatile ptr @Array_FunctionDef_ref_Desc, ptr %14, align 8
  call fastcc void @Array_FunctionDef_ref_ref_create_pZo(ptr %13, i64 0), !dbg !404, !pony.newcall !4
  %15 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 6, !dbg !405
  %16 = load ptr, ptr %15, align 8, !dbg !405
  store ptr %13, ptr %15, align 8, !dbg !405
  %17 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 7, !dbg !406
  %18 = load i64, ptr %17, align 8, !dbg !406
  store i64 0, ptr %17, align 8, !dbg !406
  br i1 %large, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %19 = call ptr @pony_alloc_msg(i32 0, i32 4), !dbg !407, !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr %this, ptr %19, ptr %19, i1 true), !dbg !407, !pony.msgsend !4
  br label %if_post

if_else:                                          ; preds = %entry
  %20 = call ptr @pony_alloc_msg(i32 0, i32 2), !dbg !410, !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr %this, ptr %20, ptr %20, i1 true), !dbg !410, !pony.msgsend !4
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret void
}

define fastcc ptr @Worker_ref_start_large_o(ptr dereferenceable(352) %this) unnamed_addr #4 !dbg !412 !pony.abi !4 {
entry:
  %this1 = alloca ptr, align 8
  store ptr %this, ptr %this1, align 8
    #dbg_declare(ptr %this1, !415, !DIExpression(), !416)
  %0 = getelementptr inbounds nuw %Worker, ptr %this, i32 0, i32 3, !dbg !417
  %1 = load i64, ptr %0, align 8, !dbg !417
  store i64 64, ptr %0, align 8, !dbg !417
  %2 = call fastcc ptr @None_val_create_o(ptr @None_Inst), !dbg !418, !pony.newcall !4
  ret ptr %2, !dbg !418
}

define fastcc noalias align 32 dereferenceable(352) ptr @Worker_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr @Worker_Desc, i1 false)
  ret ptr %1
}

define fastcc i64 @t2_USize_val_USize_val_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw %t2_USize_val_USize_val_Box, ptr %0, i32 0, i32 1
  %2 = load %t2_USize_val_USize_val, ptr %1, align 8
  %3 = extractvalue %t2_USize_val_USize_val %2, 0
  %4 = xor i64 0, %3
  %5 = extractvalue %t2_USize_val_USize_val %2, 1
  %6 = xor i64 %4, %5
  ret i64 %6
}

define fastcc i1 @t2_USize_val_USize_val_box___is_(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw %t2_USize_val_USize_val_Box, ptr %0, i32 0, i32 1
  %4 = load %t2_USize_val_USize_val, ptr %3, align 8
  %5 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 3
  %6 = load i32, ptr %5, align 4
  %7 = zext i32 %6 to i64
  %8 = getelementptr inbounds i8, ptr %1, i64 %7
  %9 = extractvalue %t2_USize_val_USize_val %4, 0
  %10 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 13
  %11 = load ptr, ptr %10, align 8
  %12 = getelementptr inbounds [0 x { i32, ptr }], ptr %11, i32 0, i32 0
  %13 = load { i32, ptr }, ptr %12, align 8
  %14 = extractvalue { i32, ptr } %13, 0
  %15 = zext i32 %14 to i64
  %16 = getelementptr inbounds i8, ptr %8, i64 %15
  %17 = extractvalue { i32, ptr } %13, 1
  %18 = icmp eq ptr %17, null
  br i1 %18, label %is_tuple_null_desc, label %is_tuple_nonnull_desc

is_tuple_null_desc:                               ; preds = %entry
  %19 = load ptr, ptr %16, align 8
  %20 = ptrtoint ptr %19 to i64
  %21 = lshr i64 %20, 63
  %22 = trunc i64 %21 to i1
  br i1 %22, label %is_post, label %rib_heap

rib_heap:                                         ; preds = %is_tuple_null_desc
  %23 = getelementptr inbounds nuw %__object, ptr %19, i32 0, i32 0
  %24 = load ptr, ptr %23, align 8
  %25 = icmp eq ptr %24, @USize_Desc
  br i1 %25, label %is_value, label %is_post

is_value:                                         ; preds = %rib_heap
  %26 = getelementptr inbounds nuw %USize_Box, ptr %19, i32 0, i32 1
  %27 = load i64, ptr %26, align 8
  %28 = icmp eq i64 %9, %27
  br label %is_post

is_post:                                          ; preds = %is_value, %rib_heap, %is_tuple_null_desc
  %29 = phi i1 [ %28, %is_value ], [ false, %is_tuple_null_desc ], [ false, %rib_heap ]
  br label %is_tuple_merge_desc

is_tuple_nonnull_desc:                            ; preds = %entry
  %30 = getelementptr inbounds nuw %__Desc, ptr %17, i32 0, i32 0
  %31 = load i32, ptr %30, align 4
  %32 = and i32 %31, 3
  switch i32 %32, label %is_tuple_nonbox [
    i32 0, label %is_tuple_num
    i32 2, label %is_tuple_tuple
  ]

is_tuple_num:                                     ; preds = %is_tuple_nonnull_desc
  %33 = icmp eq ptr @USize_Desc, %17
  br i1 %33, label %is_tuple_bothnum, label %is_tuple_post1

is_tuple_bothnum:                                 ; preds = %is_tuple_num
  %34 = load i64, ptr %16, align 8
  %35 = icmp eq i64 %9, %34
  br label %is_tuple_post1

is_tuple_tuple:                                   ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_nonbox:                                  ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_post1:                                   ; preds = %is_tuple_nonbox, %is_tuple_tuple, %is_tuple_bothnum, %is_tuple_num
  %36 = phi i1 [ false, %is_tuple_num ], [ %35, %is_tuple_bothnum ], [ false, %is_tuple_tuple ], [ false, %is_tuple_nonbox ]
  br label %is_tuple_merge_desc

is_tuple_merge_desc:                              ; preds = %is_tuple_post1, %is_post
  %37 = phi i1 [ %29, %is_post ], [ %36, %is_tuple_post1 ]
  br i1 %37, label %is_tuple_next, label %is_tuple_post

is_tuple_next:                                    ; preds = %is_tuple_merge_desc
  %38 = extractvalue %t2_USize_val_USize_val %4, 1
  %39 = getelementptr inbounds nuw %__Desc, ptr %2, i32 0, i32 13
  %40 = load ptr, ptr %39, align 8
  %41 = getelementptr inbounds [0 x { i32, ptr }], ptr %40, i32 0, i32 1
  %42 = load { i32, ptr }, ptr %41, align 8
  %43 = extractvalue { i32, ptr } %42, 0
  %44 = zext i32 %43 to i64
  %45 = getelementptr inbounds i8, ptr %8, i64 %44
  %46 = extractvalue { i32, ptr } %42, 1
  %47 = icmp eq ptr %46, null
  br i1 %47, label %is_tuple_null_desc2, label %is_tuple_nonnull_desc3

is_tuple_null_desc2:                              ; preds = %is_tuple_next
  %48 = load ptr, ptr %45, align 8
  %49 = ptrtoint ptr %48 to i64
  %50 = lshr i64 %49, 63
  %51 = trunc i64 %50 to i1
  br i1 %51, label %is_post6, label %rib_heap5

rib_heap5:                                        ; preds = %is_tuple_null_desc2
  %52 = getelementptr inbounds nuw %__object, ptr %48, i32 0, i32 0
  %53 = load ptr, ptr %52, align 8
  %54 = icmp eq ptr %53, @USize_Desc
  br i1 %54, label %is_value7, label %is_post6

is_value7:                                        ; preds = %rib_heap5
  %55 = getelementptr inbounds nuw %USize_Box, ptr %48, i32 0, i32 1
  %56 = load i64, ptr %55, align 8
  %57 = icmp eq i64 %38, %56
  br label %is_post6

is_post6:                                         ; preds = %is_value7, %rib_heap5, %is_tuple_null_desc2
  %58 = phi i1 [ %57, %is_value7 ], [ false, %is_tuple_null_desc2 ], [ false, %rib_heap5 ]
  br label %is_tuple_merge_desc4

is_tuple_nonnull_desc3:                           ; preds = %is_tuple_next
  %59 = getelementptr inbounds nuw %__Desc, ptr %46, i32 0, i32 0
  %60 = load i32, ptr %59, align 4
  %61 = and i32 %60, 3
  switch i32 %61, label %is_tuple_nonbox11 [
    i32 0, label %is_tuple_num8
    i32 2, label %is_tuple_tuple10
  ]

is_tuple_num8:                                    ; preds = %is_tuple_nonnull_desc3
  %62 = icmp eq ptr @USize_Desc, %46
  br i1 %62, label %is_tuple_bothnum9, label %is_tuple_post12

is_tuple_bothnum9:                                ; preds = %is_tuple_num8
  %63 = load i64, ptr %45, align 8
  %64 = icmp eq i64 %38, %63
  br label %is_tuple_post12

is_tuple_tuple10:                                 ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post12

is_tuple_nonbox11:                                ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post12

is_tuple_post12:                                  ; preds = %is_tuple_nonbox11, %is_tuple_tuple10, %is_tuple_bothnum9, %is_tuple_num8
  %65 = phi i1 [ false, %is_tuple_num8 ], [ %64, %is_tuple_bothnum9 ], [ false, %is_tuple_tuple10 ], [ false, %is_tuple_nonbox11 ]
  br label %is_tuple_merge_desc4

is_tuple_merge_desc4:                             ; preds = %is_tuple_post12, %is_post6
  %66 = phi i1 [ %58, %is_post6 ], [ %65, %is_tuple_post12 ]
  br i1 %66, label %is_tuple_next13, label %is_tuple_post

is_tuple_next13:                                  ; preds = %is_tuple_merge_desc4
  br label %is_tuple_post

is_tuple_post:                                    ; preds = %is_tuple_next13, %is_tuple_merge_desc4, %is_tuple_merge_desc
  %67 = phi i1 [ false, %is_tuple_merge_desc ], [ false, %is_tuple_merge_desc4 ], [ true, %is_tuple_next13 ]
  ret i1 %67
}

declare void @pony_exitcode(i32)

declare { ptr, i1 } @Array_String_val_val_apply_Zo_p(ptr dereferenceable(32), i64)

declare i1 @String_val_eq_ob(ptr dereferenceable(32), ptr dereferenceable(32))

declare ptr @None_val_create_o(ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

declare void @ponyint_ordinary_poll(ptr, ptr, i32)

declare i64 @Array_FunctionDef_ref_ref_size_Z(ptr dereferenceable(32))

declare ptr @Array_FunctionDef_ref_ref_push_oo(ptr dereferenceable(32), ptr dereferenceable(24))

declare void @Array_Instr_ref_ref_create_pZo(ptr, i64)

declare ptr @Array_FunctionDef_ref_ref_values_o(ptr dereferenceable(32))

declare i1 @ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref_ref_has_next_b(ptr dereferenceable(24))

declare { ptr, i1 } @ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref_ref_next_o_p(ptr dereferenceable(24))

declare ptr @Array_Instr_ref_ref_push_oo(ptr dereferenceable(32), ptr dereferenceable(24))

declare { ptr, i1 } @Array_Instr_ref_ref_apply_Zo_p(ptr dereferenceable(32), i64)

declare ptr @String_val_cstring_o(ptr dereferenceable(32))

declare void @Array_FunctionDef_ref_ref_create_pZo(ptr, i64)

define i32 @main(i32 %argc, ptr %argv, ptr %envp) #4 {
entry:
  %0 = alloca { i8 }, align 8
  %argc1 = call i32 @pony_init(i32 %argc, ptr %argv)
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_create(ptr %1, ptr @Main_Desc, i1 false)
  call void @ponyint_become(ptr %1, ptr %2)
  %3 = call ptr @pony_alloc_small(ptr %1, i32 1)
  %4 = getelementptr inbounds nuw %Env, ptr %3, i32 0, i32 0
  store volatile ptr @Env_Desc, ptr %4, align 8
  call fastcc void @Env_ref__create_pIioioo(ptr %3, i32 %argc1, ptr %argv, ptr %envp)
  %5 = call ptr @pony_alloc_msg(i32 0, i32 1)
  %6 = getelementptr inbounds nuw { i32, i32, ptr, ptr }, ptr %5, i32 0, i32 3
  store ptr %3, ptr %6, align 8
  call void @pony_gc_send(ptr %1, ptr null)
  call void @pony_traceknown(ptr %1, ptr %3, ptr @Env_Desc, i32 1)
  call void @pony_send_done(ptr %1)
  call void @pony_sendv_single(ptr %1, ptr %2, ptr %5, ptr %5, i1 true)
  call void @ponyint_become(ptr %1, ptr null)
  %7 = getelementptr inbounds nuw { i8 }, ptr %0, i32 0, i32 0
  store i8 1, ptr %7, align 1
  %8 = call i1 @pony_start(ptr null, ptr %0)
  br i1 %8, label %post, label %start_fail

start_fail:                                       ; preds = %entry
  %9 = call i32 @puts(ptr @17)
  br label %post

post:                                             ; preds = %start_fail, %entry
  call void @ponyint_become(ptr %1, ptr null)
  %10 = call i32 @pony_get_exitcode()
  %11 = select i1 %8, i32 %10, i32 -1
  ret i32 %11
}

declare void @Env_ref__create_pIioioo(ptr, i32, ptr, ptr)

attributes #0 = { nounwind memory(none) }
attributes #1 = { nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { nounwind memory(argmem: read) }
attributes #3 = { noreturn }
attributes #4 = { "target-cpu"="arrowlake" "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,-avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,-avx512vpopcntdq,+cmov,-avx512vp2intersect,+avxvnniint8,-avx512cd,+movbe,-ccmp,-amx-int8,-kl,-avx512bmm,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,-avx512vl,-uintr,-cf,-jmpabs,+clflushopt,-raoint,+cmpccxadd,+bmi,-amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,-avx512f,-amx-bf16,-avx512bf16,-avx512vnni,-push2pop2,+cx8,-avx512bw,+sse3,-pku,-nf,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,-wbnoinvd,-enqcmd,+avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,+avxifma,+f16c,-avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,-avx512vbmi2,-prefetchi,+rdpid,-amx-movrs,-fma4,-avx512vbmi,+shstk,+vaes,+waitpkg,-sgx,+fxsr,-avx512dq,-sse4a,+cx16,+sse2,+64bit,+64bit-mode" }
attributes #5 = { nounwind }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }

!llvm.module.flags = !{!0, !1}
!llvm.dbg.cu = !{!2}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus, file: !3, producer: "ponyc-0.78.2-3276ae583", isOptimized: false, flags: "-d --pic -p <home>/code/ponylang/peg -o <experiment>/ordinary/artifacts/graph-debug-observed -b work <experiment>/ordinary/graph -r ir ", runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false)
!3 = !DIFile(filename: "graph", directory: "<experiment>/ordinary/graph")
!4 = !{}
!5 = distinct !DISubprogram(name: "create", linkageName: "Instr_ref_create_pZpZo", scope: !6, file: !6, line: 16, type: !7, scopeLine: 16, spFlags: DISPFlagDefinition, unit: !2, declaration: !15, retainedNodes: !16)
!6 = !DIFile(filename: "<experiment>/ordinary/graph/main.pony", directory: "")
!7 = !DISubroutineType(types: !8)
!8 = !{!9, !9, !13, !13}
!9 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !10, size: 64, align: 64, dwarfAddressSpace: 0)
!10 = !DICompositeType(tag: DW_TAG_structure_type, name: "Instr", file: !6, line: 129, size: 192, align: 64, elements: !11, identifier: "Instr")
!11 = !{!12, !14}
!12 = !DIDerivedType(tag: DW_TAG_member, name: "opcode", file: !6, line: 14, baseType: !13, size: 64, align: 64, offset: 64)
!13 = !DIBasicType(name: "USize", size: 64, encoding: DW_ATE_unsigned)
!14 = !DIDerivedType(tag: DW_TAG_member, name: "operand", file: !6, line: 15, baseType: !13, size: 64, align: 64, offset: 128)
!15 = !DISubprogram(name: "create", linkageName: "Instr_ref_create_pZpZo", scope: !10, file: !6, line: 16, type: !7, scopeLine: 16, spFlags: 0)
!16 = !{!17}
!17 = !DILocalVariable(name: "this", arg: 1, scope: !5, file: !6, line: 16, type: !18, flags: DIFlagArtificial)
!18 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !10, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!19 = !DILocation(line: 16, column: 3, scope: !5)
!20 = !DILocalVariable(name: "op", arg: 2, scope: !5, file: !6, line: 16, type: !13)
!21 = !DILocation(line: 16, column: 14, scope: !5)
!22 = !DILocalVariable(name: "value", arg: 3, scope: !5, file: !6, line: 16, type: !13)
!23 = !DILocation(line: 16, column: 25, scope: !5)
!24 = !DILocation(line: 16, column: 60, scope: !5)
!25 = distinct !DISubprogram(name: "create", linkageName: "Main_tag_create_ioo", scope: !6, file: !6, line: 19, type: !26, scopeLine: 19, spFlags: DISPFlagDefinition, unit: !2, declaration: !62, retainedNodes: !63)
!26 = !DISubroutineType(types: !27)
!27 = !{!28, !28, !30}
!28 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64, align: 64, dwarfAddressSpace: 0)
!29 = !DICompositeType(tag: DW_TAG_structure_type, name: "Main", file: !6, line: 18, size: 2432, align: 64, elements: !4, identifier: "Main")
!30 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64, align: 64, dwarfAddressSpace: 0)
!31 = !DICompositeType(tag: DW_TAG_structure_type, name: "Env", file: !32, line: 19, size: 512, align: 64, elements: !33, identifier: "Env")
!32 = !DIFile(filename: "<checkout>/packages/builtin/env.pony", directory: "")
!33 = !{!34, !38, !42, !46, !47, !58, !59}
!34 = !DIDerivedType(tag: DW_TAG_member, name: "root", file: !32, line: 9, baseType: !35, size: 64, align: 64, offset: 64)
!35 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 64, align: 64, dwarfAddressSpace: 0)
!36 = !DICompositeType(tag: DW_TAG_structure_type, name: "AmbientAuth", file: !37, line: 9, size: 64, align: 64, elements: !4, identifier: "AmbientAuth")
!37 = !DIFile(filename: "<checkout>/packages/builtin/ambient_auth.pony", directory: "")
!38 = !DIDerivedType(tag: DW_TAG_member, name: "input", file: !32, line: 14, baseType: !39, size: 64, align: 64, offset: 128)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64, align: 64, dwarfAddressSpace: 0)
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputStream", file: !41, line: 14, elements: !4, identifier: "InputStream")
!41 = !DIFile(filename: "<checkout>/packages/builtin/stdin.pony", directory: "")
!42 = !DIDerivedType(tag: DW_TAG_member, name: "out", file: !32, line: 19, baseType: !43, size: 64, align: 64, offset: 192)
!43 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64, align: 64, dwarfAddressSpace: 0)
!44 = !DICompositeType(tag: DW_TAG_structure_type, name: "OutStream", file: !45, line: 19, elements: !4, identifier: "OutStream")
!45 = !DIFile(filename: "<checkout>/packages/builtin/std_stream.pony", directory: "")
!46 = !DIDerivedType(tag: DW_TAG_member, name: "err", file: !32, line: 22, baseType: !43, size: 64, align: 64, offset: 256)
!47 = !DIDerivedType(tag: DW_TAG_member, name: "args", file: !32, line: 25, baseType: !48, size: 64, align: 64, offset: 320)
!48 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !49, size: 64, align: 64, dwarfAddressSpace: 0)
!49 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_String_val", file: !50, line: 25, size: 256, align: 64, elements: !51, identifier: "Array_String_val")
!50 = !DIFile(filename: "<checkout>/packages/builtin/array.pony", directory: "")
!51 = !{!52, !53, !54}
!52 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !50, line: 89, baseType: !13, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!53 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !50, line: 90, baseType: !13, size: 64, align: 64, offset: 128, flags: DIFlagPrivate)
!54 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !50, line: 91, baseType: !55, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!55 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !56, size: 64, align: 64, dwarfAddressSpace: 0)
!56 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_String_val", file: !57, line: 91, elements: !4, identifier: "Pointer_String_val")
!57 = !DIFile(filename: "<checkout>/packages/builtin/pointer.pony", directory: "")
!58 = !DIDerivedType(tag: DW_TAG_member, name: "vars", file: !32, line: 28, baseType: !48, size: 64, align: 64, offset: 384)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "exitcode", file: !32, line: 31, baseType: !60, size: 64, align: 64, offset: 448)
!60 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !61, size: 64, align: 64, dwarfAddressSpace: 0)
!61 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$6", file: !32, line: 31, elements: !4, identifier: "$0$6")
!62 = !DISubprogram(name: "create", linkageName: "Main_tag_create_ioo", scope: !29, file: !6, line: 19, type: !26, scopeLine: 19, spFlags: 0)
!63 = !{!64, !66}
!64 = !DILocalVariable(name: "this", arg: 1, scope: !25, file: !6, line: 19, type: !65, flags: DIFlagArtificial)
!65 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !29, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!66 = !DILocalVariable(name: "large", scope: !25, file: !6, line: 21, type: !67, align: 8)
!67 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean)
!68 = !DILocation(line: 19, column: 3, scope: !25)
!69 = !DILocalVariable(name: "env", arg: 2, scope: !25, file: !6, line: 19, type: !30)
!70 = !DILocation(line: 19, column: 14, scope: !25)
!71 = !DILocation(line: 20, column: 5, scope: !25)
!72 = !DILocation(line: 21, column: 29, scope: !73)
!73 = distinct !DILexicalBlock(scope: !25, file: !6, line: 21, column: 21)
!74 = !DILocation(line: 21, column: 5, scope: !25)
!75 = !DILocation(line: 21, column: 34, scope: !73)
!76 = !DILocation(line: 21, column: 50, scope: !77)
!77 = distinct !DILexicalBlock(scope: !25, file: !6, line: 21, column: 50)
!78 = !DILocation(line: 21, column: 50, scope: !79)
!79 = distinct !DILexicalBlock(scope: !25, file: !6, line: 21, column: 50)
!80 = !DILocation(line: 22, column: 11, scope: !25)
!81 = distinct !DISubprogram(name: "runtime_override_defaults", linkageName: "Main_runtime_override_defaults_oo", scope: !6, file: !6, line: 18, type: !82, scopeLine: 18, spFlags: DISPFlagDefinition, unit: !2, declaration: !118, retainedNodes: !119)
!82 = !DISubroutineType(types: !83)
!83 = !{!84, !87}
!84 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !85, size: 64, align: 64, dwarfAddressSpace: 0)
!85 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", file: !86, line: 21, size: 64, align: 64, elements: !4, identifier: "None")
!86 = !DIFile(filename: "<checkout>/packages/builtin/none.pony", directory: "")
!87 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !88, size: 64, align: 64, dwarfAddressSpace: 0)
!88 = !DICompositeType(tag: DW_TAG_structure_type, name: "RuntimeOptions", file: !89, line: 18, size: 896, align: 64, elements: !90, identifier: "RuntimeOptions")
!89 = !DIFile(filename: "<checkout>/packages/builtin/runtime_options.pony", directory: "")
!90 = !{!91, !93, !94, !95, !96, !97, !98, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !112, !113, !114, !115, !116, !117}
!91 = !DIDerivedType(tag: DW_TAG_member, name: "ponymaxthreads", file: !89, line: 37, baseType: !92, size: 32, align: 32)
!92 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned)
!93 = !DIDerivedType(tag: DW_TAG_member, name: "ponyminthreads", file: !89, line: 44, baseType: !92, size: 32, align: 32, offset: 32)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoscale", file: !89, line: 53, baseType: !67, size: 8, align: 8, offset: 64)
!95 = !DIDerivedType(tag: DW_TAG_member, name: "ponysuspendthreshold", file: !89, line: 60, baseType: !92, size: 32, align: 32, offset: 96)
!96 = !DIDerivedType(tag: DW_TAG_member, name: "ponycdinterval", file: !89, line: 67, baseType: !92, size: 32, align: 32, offset: 128)
!97 = !DIDerivedType(tag: DW_TAG_member, name: "ponygcinitial", file: !89, line: 73, baseType: !13, size: 64, align: 64, offset: 192)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "ponygcfactor", file: !89, line: 79, baseType: !99, size: 64, align: 64, offset: 256)
!99 = !DIBasicType(name: "F64", size: 64, encoding: DW_ATE_float)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoyield", file: !89, line: 85, baseType: !67, size: 8, align: 8, offset: 320)
!101 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoblock", file: !89, line: 90, baseType: !67, size: 8, align: 8, offset: 328)
!102 = !DIDerivedType(tag: DW_TAG_member, name: "ponypin", file: !89, line: 95, baseType: !67, size: 8, align: 8, offset: 336)
!103 = !DIDerivedType(tag: DW_TAG_member, name: "ponypinasio", file: !89, line: 101, baseType: !67, size: 8, align: 8, offset: 344)
!104 = !DIDerivedType(tag: DW_TAG_member, name: "ponypinpinnedactorthread", file: !89, line: 107, baseType: !67, size: 8, align: 8, offset: 352)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "ponyprintstatsinterval", file: !89, line: 113, baseType: !92, size: 32, align: 32, offset: 384)
!106 = !DIDerivedType(tag: DW_TAG_member, name: "ponyversion", file: !89, line: 119, baseType: !67, size: 8, align: 8, offset: 416)
!107 = !DIDerivedType(tag: DW_TAG_member, name: "ponyhelp", file: !89, line: 124, baseType: !67, size: 8, align: 8, offset: 424)
!108 = !DIDerivedType(tag: DW_TAG_member, name: "ponymemoryprofile", file: !89, line: 129, baseType: !92, size: 32, align: 32, offset: 448)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingformat", file: !89, line: 146, baseType: !110, size: 64, align: 64, offset: 512)
!110 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !111, size: 64, align: 64, dwarfAddressSpace: 0)
!111 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_U8_val", file: !57, line: 52, elements: !4, identifier: "Pointer_U8_val")
!112 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingoutput", file: !89, line: 151, baseType: !110, size: 64, align: 64, offset: 576)
!113 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingcategories", file: !89, line: 156, baseType: !110, size: 64, align: 64, offset: 640)
!114 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingmode", file: !89, line: 163, baseType: !110, size: 64, align: 64, offset: 704)
!115 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingflightrecorderbuffer", file: !89, line: 169, baseType: !13, size: 64, align: 64, offset: 768)
!116 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingflightrecorderhandletermint", file: !89, line: 175, baseType: !67, size: 8, align: 8, offset: 832)
!117 = !DIDerivedType(tag: DW_TAG_member, name: "ponypintracingthread", file: !89, line: 181, baseType: !67, size: 8, align: 8, offset: 840)
!118 = !DISubprogram(name: "runtime_override_defaults", linkageName: "Main_runtime_override_defaults_oo", scope: !29, file: !6, line: 18, type: !82, scopeLine: 18, spFlags: 0)
!119 = !{!120}
!120 = !DILocalVariable(name: "rto", arg: 1, scope: !81, file: !6, line: 18, type: !121, flags: DIFlagArtificial)
!121 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !88, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!122 = !DILocation(line: 18, column: 1, scope: !81)
!123 = distinct !DISubprogram(name: "create", linkageName: "FunctionDef_ref_create_pZmoo", scope: !6, file: !6, line: 11, type: !124, scopeLine: 11, spFlags: DISPFlagDefinition, unit: !2, declaration: !135, retainedNodes: !136)
!124 = !DISubroutineType(types: !125)
!125 = !{!126, !126, !13, !131}
!126 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !127, size: 64, align: 64, dwarfAddressSpace: 0)
!127 = !DICompositeType(tag: DW_TAG_structure_type, name: "FunctionDef", file: !6, line: 31, size: 192, align: 64, elements: !128, identifier: "FunctionDef")
!128 = !{!129, !130}
!129 = !DIDerivedType(tag: DW_TAG_member, name: "symbol", file: !6, line: 9, baseType: !13, size: 64, align: 64, offset: 64)
!130 = !DIDerivedType(tag: DW_TAG_member, name: "parameter", file: !6, line: 10, baseType: !131, size: 64, align: 64, offset: 128)
!131 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !132, size: 64, align: 64, dwarfAddressSpace: 0)
!132 = !DICompositeType(tag: DW_TAG_structure_type, name: "Binding", file: !6, line: 30, size: 128, align: 64, elements: !133, identifier: "Binding")
!133 = !{!134}
!134 = !DIDerivedType(tag: DW_TAG_member, name: "factor", file: !6, line: 6, baseType: !13, size: 64, align: 64, offset: 64)
!135 = !DISubprogram(name: "create", linkageName: "FunctionDef_ref_create_pZmoo", scope: !127, file: !6, line: 11, type: !124, scopeLine: 11, spFlags: 0)
!136 = !{!137}
!137 = !DILocalVariable(name: "this", arg: 1, scope: !123, file: !6, line: 11, type: !138, flags: DIFlagArtificial)
!138 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !127, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!139 = !DILocation(line: 11, column: 3, scope: !123)
!140 = !DILocalVariable(name: "i", arg: 2, scope: !123, file: !6, line: 11, type: !13)
!141 = !DILocation(line: 11, column: 14, scope: !123)
!142 = !DILocalVariable(name: "b", arg: 3, scope: !123, file: !6, line: 11, type: !131)
!143 = !DILocation(line: 11, column: 24, scope: !123)
!144 = !DILocation(line: 11, column: 59, scope: !123)
!145 = distinct !DISubprogram(name: "create", linkageName: "Binding_iso_create_o", scope: !6, file: !6, line: 5, type: !146, scopeLine: 5, spFlags: DISPFlagDefinition, unit: !2, declaration: !148, retainedNodes: !149)
!146 = !DISubroutineType(types: !147)
!147 = !{!131, !131}
!148 = !DISubprogram(name: "create", linkageName: "Binding_iso_create_o", scope: !132, file: !6, line: 5, type: !146, scopeLine: 5, spFlags: 0)
!149 = !{!150}
!150 = !DILocalVariable(name: "this", arg: 1, scope: !145, file: !6, line: 5, type: !151, flags: DIFlagArtificial)
!151 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !132, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!152 = !DILocation(line: 5, column: 1, scope: !145)
!153 = !DILocation(line: 6, column: 3, scope: !145)
!154 = distinct !DISubprogram(name: "run_large", linkageName: "Worker_tag_run_large_o", scope: !6, file: !6, line: 51, type: !155, scopeLine: 51, spFlags: DISPFlagDefinition, unit: !2, declaration: !172, retainedNodes: !173)
!155 = !DISubroutineType(types: !156)
!156 = !{!84, !157}
!157 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !158, size: 64, align: 64, dwarfAddressSpace: 0)
!158 = !DICompositeType(tag: DW_TAG_structure_type, name: "Worker", file: !6, line: 22, size: 2816, align: 64, elements: !159, identifier: "Worker")
!159 = !{!160, !161, !162, !163, !164, !171}
!160 = !DIDerivedType(tag: DW_TAG_member, name: "_round", file: !6, line: 26, baseType: !13, size: 64, align: 64, offset: 2432, flags: DIFlagPrivate)
!161 = !DIDerivedType(tag: DW_TAG_member, name: "_expected", file: !6, line: 27, baseType: !13, size: 64, align: 64, offset: 2496, flags: DIFlagPrivate)
!162 = !DIDerivedType(tag: DW_TAG_member, name: "_ok", file: !6, line: 28, baseType: !67, size: 8, align: 8, offset: 2560, flags: DIFlagPrivate)
!163 = !DIDerivedType(tag: DW_TAG_member, name: "_shared", file: !6, line: 30, baseType: !131, size: 64, align: 64, offset: 2624, flags: DIFlagPrivate)
!164 = !DIDerivedType(tag: DW_TAG_member, name: "_source", file: !6, line: 31, baseType: !165, size: 64, align: 64, offset: 2688, flags: DIFlagPrivate)
!165 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !166, size: 64, align: 64, dwarfAddressSpace: 0)
!166 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_FunctionDef_ref", file: !50, line: 31, size: 256, align: 64, elements: !167, identifier: "Array_FunctionDef_ref")
!167 = !{!52, !53, !168}
!168 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !50, line: 91, baseType: !169, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!169 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !170, size: 64, align: 64, dwarfAddressSpace: 0)
!170 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_FunctionDef_ref", file: !57, line: 91, elements: !4, identifier: "Pointer_FunctionDef_ref")
!171 = !DIDerivedType(tag: DW_TAG_member, name: "_checksum", file: !6, line: 32, baseType: !13, size: 64, align: 64, offset: 2752, flags: DIFlagPrivate)
!172 = !DISubprogram(name: "run_large", linkageName: "Worker_tag_run_large_o", scope: !158, file: !6, line: 51, type: !155, scopeLine: 51, spFlags: 0)
!173 = !{!174}
!174 = !DILocalVariable(name: "this", arg: 1, scope: !154, file: !6, line: 51, type: !175, flags: DIFlagArtificial)
!175 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !158, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!176 = !DILocation(line: 51, column: 3, scope: !154)
!177 = !DILocation(line: 52, column: 16, scope: !154)
!178 = !DILocation(line: 53, column: 10, scope: !154)
!179 = !DILocation(line: 54, column: 10, scope: !154)
!180 = !DILocation(line: 55, column: 10, scope: !154)
!181 = !DILocation(line: 56, column: 10, scope: !154)
!182 = !DILocation(line: 57, column: 10, scope: !154)
!183 = !DILocation(line: 58, column: 10, scope: !154)
!184 = !DILocation(line: 59, column: 10, scope: !154)
!185 = !DILocation(line: 60, column: 10, scope: !154)
!186 = !DILocation(line: 61, column: 10, scope: !154)
!187 = !DILocation(line: 62, column: 10, scope: !154)
!188 = !DILocation(line: 63, column: 10, scope: !154)
!189 = !DILocation(line: 64, column: 10, scope: !154)
!190 = !DILocation(line: 65, column: 10, scope: !154)
!191 = !DILocation(line: 66, column: 10, scope: !154)
!192 = !DILocation(line: 67, column: 10, scope: !154)
!193 = !DILocation(line: 68, column: 10, scope: !154)
!194 = !DILocation(line: 69, column: 10, scope: !154)
!195 = !DILocation(line: 70, column: 10, scope: !154)
!196 = !DILocation(line: 71, column: 10, scope: !154)
!197 = !DILocation(line: 72, column: 10, scope: !154)
!198 = !DILocation(line: 73, column: 10, scope: !154)
!199 = !DILocation(line: 74, column: 10, scope: !154)
!200 = !DILocation(line: 75, column: 10, scope: !154)
!201 = !DILocation(line: 76, column: 10, scope: !154)
!202 = !DILocation(line: 77, column: 10, scope: !154)
!203 = !DILocation(line: 78, column: 10, scope: !154)
!204 = !DILocation(line: 79, column: 10, scope: !154)
!205 = !DILocation(line: 80, column: 10, scope: !154)
!206 = !DILocation(line: 81, column: 10, scope: !154)
!207 = !DILocation(line: 82, column: 10, scope: !154)
!208 = !DILocation(line: 83, column: 10, scope: !154)
!209 = !DILocation(line: 84, column: 10, scope: !154)
!210 = !DILocation(line: 85, column: 10, scope: !154)
!211 = !DILocation(line: 86, column: 10, scope: !154)
!212 = !DILocation(line: 87, column: 10, scope: !154)
!213 = !DILocation(line: 88, column: 10, scope: !154)
!214 = !DILocation(line: 89, column: 10, scope: !154)
!215 = !DILocation(line: 90, column: 10, scope: !154)
!216 = !DILocation(line: 91, column: 10, scope: !154)
!217 = !DILocation(line: 92, column: 10, scope: !154)
!218 = !DILocation(line: 93, column: 10, scope: !154)
!219 = !DILocation(line: 94, column: 10, scope: !154)
!220 = !DILocation(line: 95, column: 10, scope: !154)
!221 = !DILocation(line: 96, column: 10, scope: !154)
!222 = !DILocation(line: 97, column: 10, scope: !154)
!223 = !DILocation(line: 98, column: 10, scope: !154)
!224 = !DILocation(line: 99, column: 10, scope: !154)
!225 = !DILocation(line: 100, column: 10, scope: !154)
!226 = !DILocation(line: 101, column: 10, scope: !154)
!227 = !DILocation(line: 102, column: 10, scope: !154)
!228 = !DILocation(line: 103, column: 10, scope: !154)
!229 = !DILocation(line: 104, column: 10, scope: !154)
!230 = !DILocation(line: 105, column: 10, scope: !154)
!231 = !DILocation(line: 106, column: 10, scope: !154)
!232 = !DILocation(line: 107, column: 10, scope: !154)
!233 = !DILocation(line: 108, column: 10, scope: !154)
!234 = !DILocation(line: 109, column: 10, scope: !154)
!235 = !DILocation(line: 110, column: 10, scope: !154)
!236 = !DILocation(line: 111, column: 10, scope: !154)
!237 = !DILocation(line: 112, column: 10, scope: !154)
!238 = !DILocation(line: 113, column: 10, scope: !154)
!239 = !DILocation(line: 114, column: 10, scope: !154)
!240 = !DILocation(line: 115, column: 10, scope: !154)
!241 = !DILocation(line: 116, column: 10, scope: !154)
!242 = !DILocation(line: 117, column: 11, scope: !154)
!243 = distinct !DISubprogram(name: "run_small", linkageName: "Worker_tag_run_small_o", scope: !6, file: !6, line: 37, type: !155, scopeLine: 37, spFlags: DISPFlagDefinition, unit: !2, declaration: !244, retainedNodes: !245)
!244 = !DISubprogram(name: "run_small", linkageName: "Worker_tag_run_small_o", scope: !158, file: !6, line: 37, type: !155, scopeLine: 37, spFlags: 0)
!245 = !{!246}
!246 = !DILocalVariable(name: "this", arg: 1, scope: !243, file: !6, line: 37, type: !175, flags: DIFlagArtificial)
!247 = !DILocation(line: 37, column: 3, scope: !243)
!248 = !DILocation(line: 38, column: 16, scope: !243)
!249 = !DILocation(line: 39, column: 10, scope: !243)
!250 = !DILocation(line: 40, column: 10, scope: !243)
!251 = !DILocation(line: 41, column: 10, scope: !243)
!252 = !DILocation(line: 42, column: 10, scope: !243)
!253 = !DILocation(line: 43, column: 10, scope: !243)
!254 = !DILocation(line: 44, column: 10, scope: !243)
!255 = !DILocation(line: 45, column: 10, scope: !243)
!256 = !DILocation(line: 46, column: 10, scope: !243)
!257 = !DILocation(line: 47, column: 11, scope: !243)
!258 = distinct !DISubprogram(name: "batch", linkageName: "Worker_ref_batch_o", scope: !6, file: !6, line: 121, type: !155, scopeLine: 121, spFlags: DISPFlagDefinition, unit: !2, declaration: !259, retainedNodes: !260)
!259 = !DISubprogram(name: "batch", linkageName: "Worker_ref_batch_o", scope: !158, file: !6, line: 121, type: !155, scopeLine: 121, spFlags: 0)
!260 = !{!261, !262, !265, !272, !273, !279, !282, !284, !287, !288}
!261 = !DILocalVariable(name: "this", arg: 1, scope: !258, file: !6, line: 121, type: !175, flags: DIFlagArtificial)
!262 = !DILocalVariable(name: "i", scope: !263, file: !6, line: 123, type: !13, align: 64)
!263 = distinct !DILexicalBlock(scope: !264, file: !6, line: 123, column: 7)
!264 = distinct !DILexicalBlock(scope: !258, file: !6, line: 122, column: 5)
!265 = !DILocalVariable(name: "code", scope: !258, file: !6, line: 129, type: !266, align: 64)
!266 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !267, size: 64, align: 64, dwarfAddressSpace: 0)
!267 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_Instr_ref", file: !50, line: 93, size: 256, align: 64, elements: !268, identifier: "Array_Instr_ref")
!268 = !{!52, !53, !269}
!269 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !50, line: 91, baseType: !270, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!270 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !271, size: 64, align: 64, dwarfAddressSpace: 0)
!271 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_Instr_ref", file: !57, line: 91, elements: !4, identifier: "Pointer_Instr_ref")
!272 = !DILocalVariable(name: "index", scope: !258, file: !6, line: 130, type: !13, align: 64)
!273 = !DILocalVariable(name: "$1$0", scope: !258, file: !6, line: 131, type: !274, align: 64)
!274 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !275, size: 64, align: 64, dwarfAddressSpace: 0)
!275 = !DICompositeType(tag: DW_TAG_structure_type, name: "ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref", file: !50, line: 977, size: 192, align: 64, elements: !276, identifier: "ArrayValues_FunctionDef_ref_Array_FunctionDef_ref_ref")
!276 = !{!277, !278}
!277 = !DIDerivedType(tag: DW_TAG_member, name: "_array", file: !50, line: 1012, baseType: !165, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!278 = !DIDerivedType(tag: DW_TAG_member, name: "_i", file: !50, line: 1013, baseType: !13, size: 64, align: 64, offset: 128, flags: DIFlagPrivate)
!279 = !DILocalVariable(name: "def", scope: !280, file: !6, line: 131, type: !126, align: 64)
!280 = distinct !DILexicalBlock(scope: !281, file: !6, line: 131, column: 5)
!281 = distinct !DILexicalBlock(scope: !258, file: !6, line: 131, column: 5)
!282 = !DILocalVariable(name: "i", scope: !283, file: !6, line: 138, type: !13, align: 64)
!283 = distinct !DILexicalBlock(scope: !258, file: !6, line: 138, column: 7)
!284 = !DILocalVariable(name: "mul", scope: !285, file: !6, line: 140, type: !9, align: 64)
!285 = distinct !DILexicalBlock(scope: !286, file: !6, line: 140, column: 9)
!286 = distinct !DILexicalBlock(scope: !283, file: !6, line: 139, column: 7)
!287 = !DILocalVariable(name: "add", scope: !285, file: !6, line: 141, type: !9, align: 64)
!288 = !DILocalVariable(name: "value", scope: !285, file: !6, line: 142, type: !13, align: 64)
!289 = !DILocation(line: 121, column: 3, scope: !258)
!290 = !DILocation(line: 122, column: 23, scope: !264)
!291 = !DILocation(line: 122, column: 20, scope: !264)
!292 = !DILocation(line: 123, column: 7, scope: !263)
!293 = !DILocation(line: 129, column: 5, scope: !258)
!294 = !DILocation(line: 130, column: 5, scope: !258)
!295 = !DILocation(line: 131, column: 5, scope: !258)
!296 = !DILocation(line: 131, column: 9, scope: !280)
!297 = !DILocation(line: 138, column: 7, scope: !283)
!298 = !DILocation(line: 140, column: 9, scope: !285)
!299 = !DILocation(line: 141, column: 9, scope: !285)
!300 = !DILocation(line: 142, column: 9, scope: !285)
!301 = !DILocation(line: 124, column: 15, scope: !302)
!302 = distinct !DILexicalBlock(scope: !263, file: !6, line: 124, column: 7)
!303 = !DILocation(line: 125, column: 33, scope: !304)
!304 = distinct !DILexicalBlock(scope: !302, file: !6, line: 125, column: 9)
!305 = !DILocation(line: 125, column: 21, scope: !304)
!306 = !DILocation(line: 126, column: 15, scope: !304)
!307 = !DILocation(line: 126, column: 11, scope: !304)
!308 = !DILocation(line: 126, column: 17, scope: !309)
!309 = distinct !DILexicalBlock(scope: !302, file: !6, line: 126, column: 17)
!310 = !DILocation(line: 127, column: 7, scope: !311)
!311 = distinct !DILexicalBlock(scope: !264, file: !6, line: 127, column: 7)
!312 = !DILocation(line: 129, column: 21, scope: !258)
!313 = !DILocation(line: 131, column: 30, scope: !258)
!314 = !DILocation(line: 131, column: 16, scope: !281)
!315 = !DILocation(line: 131, column: 16, scope: !316)
!316 = distinct !DILexicalBlock(scope: !280, file: !6, line: 131, column: 16)
!317 = !DILocation(line: 131, column: 16, scope: !318)
!318 = distinct !DILexicalBlock(scope: !280, file: !6, line: 131, column: 16)
!319 = !DILocation(line: 131, column: 16, scope: !320)
!320 = distinct !DILexicalBlock(scope: !321, file: !6, line: 131, column: 16)
!321 = distinct !DILexicalBlock(scope: !280, file: !6, line: 131, column: 16)
!322 = !DILocation(line: 131, column: 16, scope: !321)
!323 = !DILocation(line: 132, column: 43, scope: !280)
!324 = !DILocation(line: 132, column: 17, scope: !280)
!325 = !DILocation(line: 132, column: 33, scope: !280)
!326 = !DILocation(line: 132, column: 62, scope: !280)
!327 = !DILocation(line: 132, column: 11, scope: !280)
!328 = !DILocation(line: 133, column: 22, scope: !280)
!329 = !DILocation(line: 133, column: 16, scope: !280)
!330 = !DILocation(line: 134, column: 22, scope: !280)
!331 = !DILocation(line: 134, column: 16, scope: !280)
!332 = !DILocation(line: 135, column: 21, scope: !280)
!333 = !DILocation(line: 135, column: 13, scope: !280)
!334 = !DILocation(line: 135, column: 23, scope: !335)
!335 = distinct !DILexicalBlock(scope: !281, file: !6, line: 135, column: 23)
!336 = !DILocation(line: 139, column: 15, scope: !286)
!337 = !DILocation(line: 140, column: 26, scope: !285)
!338 = !DILocation(line: 140, column: 23, scope: !285)
!339 = !DILocation(line: 141, column: 27, scope: !285)
!340 = !DILocation(line: 141, column: 23, scope: !285)
!341 = !DILocation(line: 142, column: 24, scope: !285)
!342 = !DILocation(line: 143, column: 63, scope: !285)
!343 = !DILocation(line: 143, column: 41, scope: !285)
!344 = !DILocation(line: 143, column: 19, scope: !285)
!345 = !DILocation(line: 143, column: 35, scope: !285)
!346 = !DILocation(line: 143, column: 57, scope: !285)
!347 = !DILocation(line: 143, column: 74, scope: !285)
!348 = !DILocation(line: 143, column: 80, scope: !285)
!349 = !DILocation(line: 143, column: 13, scope: !285)
!350 = !DILocation(line: 144, column: 31, scope: !285)
!351 = !DILocation(line: 144, column: 19, scope: !285)
!352 = !DILocation(line: 145, column: 15, scope: !285)
!353 = !DILocation(line: 145, column: 11, scope: !285)
!354 = !DILocation(line: 145, column: 17, scope: !355)
!355 = distinct !DILexicalBlock(scope: !286, file: !6, line: 145, column: 17)
!356 = !DILocation(line: 147, column: 16, scope: !357)
!357 = distinct !DILexicalBlock(scope: !258, file: !6, line: 147, column: 16)
!358 = !DILocation(line: 147, column: 14, scope: !359)
!359 = distinct !DILexicalBlock(scope: !258, file: !6, line: 147, column: 10)
!360 = !DILocation(line: 147, column: 16, scope: !361)
!361 = distinct !DILexicalBlock(scope: !258, file: !6, line: 147, column: 16)
!362 = !DILocation(line: 148, column: 21, scope: !258)
!363 = !DILocation(line: 148, column: 12, scope: !258)
!364 = !DILocation(line: 122, column: 5, scope: !258)
!365 = distinct !DISubprogram(name: "start_small", linkageName: "Worker_ref_start_small_o", scope: !6, file: !6, line: 49, type: !155, scopeLine: 49, spFlags: DISPFlagDefinition, unit: !2, declaration: !366, retainedNodes: !367)
!366 = !DISubprogram(name: "start_small", linkageName: "Worker_ref_start_small_o", scope: !158, file: !6, line: 49, type: !155, scopeLine: 49, spFlags: 0)
!367 = !{!368}
!368 = !DILocalVariable(name: "this", arg: 1, scope: !365, file: !6, line: 49, type: !175, flags: DIFlagArtificial)
!369 = !DILocation(line: 49, column: 3, scope: !365)
!370 = !DILocation(line: 49, column: 38, scope: !365)
!371 = !DILocation(line: 49, column: 28, scope: !365)
!372 = distinct !DISubprogram(name: "finish", linkageName: "Worker_ref_finish_o", scope: !6, file: !6, line: 150, type: !155, scopeLine: 150, spFlags: DISPFlagDefinition, unit: !2, declaration: !373, retainedNodes: !374)
!373 = !DISubprogram(name: "finish", linkageName: "Worker_ref_finish_o", scope: !158, file: !6, line: 150, type: !155, scopeLine: 150, spFlags: 0)
!374 = !{!375}
!375 = !DILocalVariable(name: "this", arg: 1, scope: !372, file: !6, line: 150, type: !175, flags: DIFlagArtificial)
!376 = !DILocation(line: 150, column: 3, scope: !372)
!377 = !DILocation(line: 151, column: 77, scope: !378)
!378 = distinct !DILexicalBlock(scope: !372, file: !6, line: 151, column: 5)
!379 = !DILocation(line: 151, column: 69, scope: !378)
!380 = !DILocation(line: 151, column: 19, scope: !378)
!381 = !DILocation(line: 151, column: 33, scope: !378)
!382 = !DILocation(line: 151, column: 89, scope: !378)
!383 = !DILocation(line: 152, column: 31, scope: !384)
!384 = distinct !DILexicalBlock(scope: !378, file: !6, line: 152, column: 7)
!385 = !DILocation(line: 152, column: 7, scope: !384)
!386 = !DILocation(line: 153, column: 7, scope: !384)
!387 = !DILocation(line: 153, column: 23, scope: !388)
!388 = distinct !DILexicalBlock(scope: !378, file: !6, line: 153, column: 23)
!389 = !DILocation(line: 151, column: 5, scope: !372)
!390 = distinct !DISubprogram(name: "create", linkageName: "Worker_tag_create_pbo", scope: !6, file: !6, line: 34, type: !391, scopeLine: 34, spFlags: DISPFlagDefinition, unit: !2, declaration: !393, retainedNodes: !394)
!391 = !DISubroutineType(types: !392)
!392 = !{!157, !157, !67}
!393 = !DISubprogram(name: "create", linkageName: "Worker_tag_create_pbo", scope: !158, file: !6, line: 34, type: !391, scopeLine: 34, spFlags: 0)
!394 = !{!395}
!395 = !DILocalVariable(name: "this", arg: 1, scope: !390, file: !6, line: 34, type: !175, flags: DIFlagArtificial)
!396 = !DILocation(line: 34, column: 3, scope: !390)
!397 = !DILocalVariable(name: "large", arg: 2, scope: !390, file: !6, line: 34, type: !67)
!398 = !DILocation(line: 34, column: 14, scope: !390)
!399 = !DILocation(line: 26, column: 3, scope: !390)
!400 = !DILocation(line: 27, column: 3, scope: !390)
!401 = !DILocation(line: 28, column: 3, scope: !390)
!402 = !DILocation(line: 30, column: 26, scope: !390)
!403 = !DILocation(line: 30, column: 3, scope: !390)
!404 = !DILocation(line: 31, column: 42, scope: !390)
!405 = !DILocation(line: 31, column: 3, scope: !390)
!406 = !DILocation(line: 32, column: 3, scope: !390)
!407 = !DILocation(line: 35, column: 28, scope: !408)
!408 = distinct !DILexicalBlock(scope: !409, file: !6, line: 35, column: 19)
!409 = distinct !DILexicalBlock(scope: !390, file: !6, line: 35, column: 5)
!410 = !DILocation(line: 35, column: 45, scope: !411)
!411 = distinct !DILexicalBlock(scope: !409, file: !6, line: 35, column: 36)
!412 = distinct !DISubprogram(name: "start_large", linkageName: "Worker_ref_start_large_o", scope: !6, file: !6, line: 119, type: !155, scopeLine: 119, spFlags: DISPFlagDefinition, unit: !2, declaration: !413, retainedNodes: !414)
!413 = !DISubprogram(name: "start_large", linkageName: "Worker_ref_start_large_o", scope: !158, file: !6, line: 119, type: !155, scopeLine: 119, spFlags: 0)
!414 = !{!415}
!415 = !DILocalVariable(name: "this", arg: 1, scope: !412, file: !6, line: 119, type: !175, flags: DIFlagArtificial)
!416 = !DILocation(line: 119, column: 3, scope: !412)
!417 = !DILocation(line: 119, column: 38, scope: !412)
!418 = !DILocation(line: 119, column: 28, scope: !412)
