use "time"
use @printf[I32](fmt: Pointer[U8] tag, ...)
use @pony_exitcode[None](code: I32)

actor Main
  new create(env: Env) =>
    @pony_exitcode(1)
    Worker

actor Worker
  var _start: U64 = 0
  var _elapsed: U64 = 0
  var _round: USize = 0
  var _x: U64 = 7
  new create() => tick()

  be tick() =>
    begin_interval()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    step()
    finish()

  fun ref begin_interval() => _start = Time.nanos()

  fun ref step() =>
    _x = (_x * 6364136223846793005) + 1442695040888963407

  fun ref finish() =>
    _elapsed = _elapsed + (Time.nanos() - _start)
    _round = _round + 1
    if _round < 16384 then
      tick()
    else
      @printf("%llu %llu\n".cstring(), _x, _elapsed)
      @pony_exitcode(0)
    end
