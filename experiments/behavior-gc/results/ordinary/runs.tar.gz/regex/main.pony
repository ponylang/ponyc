use "iregex"
use @pony_exitcode[None](code: I32)
use @puts[I32](s: Pointer[U8] tag)

actor Main
  new create(env: Env) =>
    @pony_exitcode(1)
    let large = try env.args(1)? == "large" else false end
    Worker(large)

actor Worker

  var _round: USize = 0
  var _expected: USize = 0
  var _ok: Bool = true

  var _first: (IRegexp | None) = None

  new create(large: Bool) =>
    if large then run_large() else run_small() end

  be run_small() =>
    start_small()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_small() => _expected = 8

  be run_large() =>
    start_large()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    batch()
    finish()

  fun ref start_large() => _expected = 64

  fun ref batch() =>
    var i: USize = 0
    while i < 32 do
      let even = ((i % 2) == 0)
      let pattern = if even then "(ab|cd)[0-9]{2}" else "x+y" end
      match IRegexpCompiler.parse(pattern)
      | let r: IRegexp =>
        if even then
          _ok = _ok and r.is_match("ab42") and r.is_match("cd00")
            and (not r.is_match("ab4")) and (not r.is_match("xab42"))
            and (not r.is_match("cd0z")) and r.search("xab42!")
        else
          _ok = _ok and r.is_match("xxxy") and (not r.is_match("ab42"))
            and (not r.is_match("y"))
        end
        if (_round == 0) and (i == 0) then _first = r end
      else _ok = false end
      i = i + 1
    end
    match _first
    | let r: IRegexp => _ok = _ok and r.is_match("ab17") and (not r.is_match("xxxy"))
    else _ok = false end
    _round = _round + 1

  fun ref finish() =>
    if _ok and (_round == _expected) then
      @puts("verified".cstring())
      @pony_exitcode(0)
    end
