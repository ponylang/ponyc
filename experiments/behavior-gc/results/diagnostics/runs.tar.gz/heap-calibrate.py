import subprocess, shlex
from pathlib import Path

repo = Path.cwd()
out = Path.home() / 'tmp/ponyc-6490/heap-calibration'
out.mkdir(exist_ok=True)
build = repo / 'build/build_debug'
flags_path = build / 'src/libponyrt/CMakeFiles/libponyrt.dir/flags.make'
testdir = build / 'test/libponyrt'
flags = [flag for row in flags_path.read_text().splitlines() if row.startswith('C_') for flag in shlex.split(row.partition(' = ')[2])]
link = shlex.split((testdir / 'CMakeFiles/libponyrt.tests.dir/link.txt').read_text())
link = [x for x in link if x not in ('-Xlinker', '--dependency-file=CMakeFiles/libponyrt.tests.dir/link.d')]
link[link.index('-o')+1] = str(out / 'probe')
for name,source,old,new,test in [
    ('free','mem/heap.c','c = heap->small_free[i]','c = NULL','Heap.PendingFinalisers'),
    ('full','mem/heap.c','c = heap->small_full[i]','c = NULL','Heap.PendingFinalisers'),
    ('large','mem/heap.c','c = heap->large','c = NULL','Heap.PendingFinalisers'),
    ('empty','mem/heap.c','return false;\n}\n\nstatic void set_large_chunk_finaliser','return true;\n}\n\nstatic void set_large_chunk_finaliser','Heap.PendingFinalisers'),
    ('mismatch','gc/root_audit.c','(ctx->current == receiver)','(ctx->current != NULL)','RootAudit.RefusesOtherActor')
]:
    path = repo / 'src/libponyrt' / source
    contents = path.read_text()
    assert contents.count(old) == 1, (name,contents.count(old))
    src = out / path.name
    src.write_text(contents.replace(old,new))
    obj = out / 'mutant.o'
    subprocess.run(['clang',*flags,'-I'+str(path.parent),'-c',src,'-o',obj],check=True)
    cmd = link[:]
    cmd.insert(cmd.index('../../src/libponyrt/libponyrt.a'),str(obj))
    subprocess.run(cmd,cwd=testdir,check=True)
    run = subprocess.run([out / 'probe','--gtest_filter='+test],capture_output=True,text=True,timeout=15)
    (out / (name+'.log')).write_text(run.stdout + run.stderr)
    assert run.returncode == 1 and '[  FAILED  ] '+test in run.stdout,(name,run)
    print(name, [s for s in run.stdout.splitlines() if 'Failure' in s])
