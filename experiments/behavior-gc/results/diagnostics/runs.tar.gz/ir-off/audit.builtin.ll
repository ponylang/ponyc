; ModuleID = 'gc-root-audit.builtin'
source_filename = "gc-root-audit.builtin"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%U32_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%Pointer_AsioEvent_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [21 x ptr] }
%"$0$16_Desc" = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%Pointer_Pointer_U8_val_ref_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [21 x ptr] }
%AmbientAuth_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%StdStream_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%Pointer_String_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [20 x ptr] }
%String_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Array_String_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Bool_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%F64_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%Stdin_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [5 x ptr] }
%I32_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%U64_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%USize_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [31 x ptr] }
%RuntimeOptions_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [0 x ptr] }
%Array_U8_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Env_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%None_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%AsioEvent_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%U8_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%Pointer_U8_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [25 x ptr] }
%"$0$16" = type { ptr }
%AmbientAuth = type { ptr }
%None = type { ptr }
%AsioEvent = type { ptr }

@U32_Desc = constant %U32_Desc { i32 20, i32 16, i32 0, i32 8, ptr null, ptr @7, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U32_Traits, ptr null, [28 x ptr] [ptr @U32_box_usize_Z_Unbox, ptr @U32_box_shl_II_Unbox, ptr @U32_val_usize_Z_Unbox, ptr @U32_val_ne_Ib_Unbox, ptr @U32_box_eq_Ib_Unbox, ptr @U32_val_op_and_II_Unbox, ptr @U32_val_shl_II_Unbox, ptr @U32_val_eq_Ib_Unbox, ptr @U32_box_ne_Ib_Unbox, ptr @U32_box_op_and_II_Unbox, ptr @U32_val_create_pII_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U32_box___digestof_] }
@Pointer_AsioEvent_val_Desc = constant %Pointer_AsioEvent_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @8, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_AsioEvent_val_Traits, ptr null, [21 x ptr] [ptr null, ptr @Pointer_AsioEvent_val_ref_create_o, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b] }
@"$0$16_Desc" = constant %"$0$16_Desc" { i32 25, i32 8, i32 0, i32 0, ptr @"$0$16_Inst", ptr @9, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @"$0$16_Traits", ptr null, [9 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @"$0$16_val_create_o"] }
@Pointer_Pointer_U8_val_ref_Desc = constant %Pointer_Pointer_U8_val_ref_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @10, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_Pointer_U8_val_ref_Traits, ptr null, [21 x ptr] [ptr @Pointer_Pointer_U8_val_ref_val__apply_Zo, ptr @Pointer_Pointer_U8_val_ref_ref__apply_Zo, ptr @Pointer_Pointer_U8_val_ref_box__apply_Zo, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b] }
@AmbientAuth_Desc = constant %AmbientAuth_Desc { i32 3, i32 8, i32 0, i32 0, ptr @AmbientAuth_Inst, ptr @11, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @AmbientAuth_Traits, ptr null, [1 x ptr] [ptr @AmbientAuth_val__create_o] }
@StdStream_Desc = constant %StdStream_Desc { i32 27, i32 312, i32 0, i32 304, ptr null, ptr @12, ptr @StdStream_GetBehaviourName, ptr @StdStream_Trace, ptr @StdStream_Dispatch, ptr null, i32 -1, i1 true, ptr @StdStream_Traits, ptr null, [2 x ptr] [ptr @StdStream_tag__err_o__send, ptr @StdStream_tag__out_o__send] }
@0 = private unnamed_addr constant [20 x i8] c"StdStream.*UNKNOWN*\00"
@Pointer_String_val_Desc = constant %Pointer_String_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @13, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_String_val_Traits, ptr null, [20 x ptr] [ptr @Pointer_String_val_ref__alloc_pZo, ptr @Pointer_String_val_ref_create_o, ptr @Pointer_String_val_tag__min_alloc_Z, ptr @Pointer_String_val_ref__update_Zoo, ptr null, ptr null, ptr null, ptr @Pointer_String_val_tag__min_alloc_Z, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_String_val_ref__realloc_ZZo, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_String_val_tag__min_alloc_Z, ptr @Pointer_String_val_tag__min_alloc_Z] }
@String_Desc = constant %String_Desc { i32 5, i32 32, i32 0, i32 8, ptr null, ptr @14, ptr null, ptr @String_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @String_Traits, ptr null, [10 x ptr] [ptr @String_box_cstring_o, ptr @String_val_cstring_o, ptr @String_val_is_null_terminated_b, ptr @String_ref__set_ZCC, ptr @String_ref_is_null_terminated_b, ptr @String_ref_copy_cstring_moo, ptr @String_ref_cstring_o, ptr @String_box_is_null_terminated_b, ptr null, ptr @String_ref_create_pZo] }
@Array_String_val_Desc = constant %Array_String_val_Desc { i32 7, i32 32, i32 0, i32 8, ptr null, ptr @15, ptr null, ptr @Array_String_val_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Array_String_val_Traits, ptr null, [10 x ptr] [ptr @Array_String_val_ref_push_oo, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Array_String_val_ref_reserve_Zo, ptr null, ptr null, ptr @Array_String_val_ref_create_pZo] }
@Bool_Desc = constant %Bool_Desc { i32 8, i32 16, i32 0, i32 8, ptr null, ptr @16, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Bool_Traits, ptr null, [28 x ptr] [ptr @Bool_val_op_and_bb_Unbox, ptr @Bool_box_op_not_b_Unbox, ptr @Bool_box_op_and_bb_Unbox, ptr @Bool_val_op_not_b_Unbox, ptr @Bool_val_create_pbb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Bool_box___digestof_] }
@F64_Desc = constant %F64_Desc { i32 24, i32 16, i32 0, i32 8, ptr null, ptr @17, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @F64_Traits, ptr null, [28 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @F64_box___digestof_] }
@Stdin_Desc = constant %Stdin_Desc { i32 31, i32 336, i32 0, i32 304, ptr null, ptr @18, ptr @Stdin_GetBehaviourName, ptr @Stdin_Trace, ptr @Stdin_Dispatch, ptr null, i32 1, i1 true, ptr @Stdin_Traits, ptr null, [5 x ptr] [ptr @Stdin_tag__create_pbo__send, ptr @Stdin_tag__event_notify_topIpIo__send, ptr @Stdin_ref__read_b, ptr @Stdin_ref__close_event_o, ptr @Stdin_tag__read_again_o__send] }
@1 = private unnamed_addr constant [16 x i8] c"Stdin.*UNKNOWN*\00"
@I32_Desc = constant %I32_Desc { i32 12, i32 16, i32 0, i32 8, ptr null, ptr @19, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @I32_Traits, ptr null, [28 x ptr] [ptr @I32_val_create_pii_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @I32_box___digestof_] }
@U64_Desc = constant %U64_Desc { i32 16, i32 16, i32 0, i32 8, ptr null, ptr @20, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U64_Traits, ptr null, [28 x ptr] [ptr @U64_box_usize_Z_Unbox, ptr @U64_val_create_pWW_Unbox, ptr @U64_val_usize_Z_Unbox, ptr @U64_box_eq_Wb_Unbox, ptr @U64_val_eq_Wb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U64_box___digestof_] }
@USize_Desc = constant %USize_Desc { i32 0, i32 16, i32 0, i32 8, ptr null, ptr @21, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @USize_Traits, ptr null, [31 x ptr] [ptr @USize_box_u64_W_Unbox, ptr @USize_val_create_pZZ_Unbox, ptr @USize_val_add_ZZ_Unbox, ptr @USize_val_u64_W_Unbox, ptr @USize_val_ne_Zb_Unbox, ptr @USize_box_neg_Z_Unbox, ptr @USize_val_max_value_Z_Unbox, ptr @USize_val_next_pow2_Z_Unbox, ptr @USize_val_neg_Z_Unbox, ptr @USize_box_min_ZZ_Unbox, ptr @USize_box_eq_Zb_Unbox, ptr @USize_box_shl_ZZ_Unbox, ptr @USize_val_gt_Zb_Unbox, ptr @USize_box_sub_ZZ_Unbox, ptr @USize_box_clz_Z_Unbox, ptr @USize_box_add_ZZ_Unbox, ptr @USize_val_min_ZZ_Unbox, ptr @USize_box_bitwidth_Z_Unbox, ptr @USize_box_ne_Zb_Unbox, ptr @USize_box_next_pow2_Z_Unbox, ptr @USize_val_sub_ZZ_Unbox, ptr @USize_box_max_ZZ_Unbox, ptr @USize_val_max_ZZ_Unbox, ptr @USize_val_eq_Zb_Unbox, ptr @USize_val_shl_ZZ_Unbox, ptr @USize_box_lt_Zb_Unbox, ptr @USize_val_lt_Zb_Unbox, ptr @USize_box___digestof_, ptr @USize_val_clz_Z_Unbox, ptr @USize_val_bitwidth_Z_Unbox, ptr @USize_box_gt_Zb_Unbox] }
@RuntimeOptions_Desc = constant %RuntimeOptions_Desc { i32 -1, i32 112, i32 0, i32 0, ptr null, ptr @22, ptr null, ptr @RuntimeOptions_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @RuntimeOptions_Traits, ptr null, [0 x ptr] zeroinitializer }
@Array_U8_val_Desc = constant %Array_U8_val_Desc { i32 33, i32 32, i32 0, i32 8, ptr null, ptr @23, ptr null, ptr @Array_U8_val_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Array_U8_val_Traits, ptr null, [10 x ptr] [ptr @Array_U8_val_ref_cpointer_Zo, ptr @Array_U8_val_box_size_Z, ptr @Array_U8_val_val_cpointer_Zo, ptr @Array_U8_val_ref_truncate_Zo, ptr @Array_U8_val_ref_undefined_U8_val_Zo, ptr @Array_U8_val_ref_size_Z, ptr @Array_U8_val_ref_reserve_Zo, ptr @Array_U8_val_val_size_Z, ptr @Array_U8_val_box_cpointer_Zo, ptr @Array_U8_val_ref_create_pZo] }
@Env_Desc = constant %Env_Desc { i32 9, i32 64, i32 0, i32 8, ptr null, ptr @24, ptr null, ptr @Env_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Env_Traits, ptr null, [9 x ptr] [ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_ref__create_pIioioo, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_tag__strings_from_pointers_oZo] }
@None_Desc = constant %None_Desc { i32 13, i32 8, i32 0, i32 0, ptr @None_Inst, ptr @25, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @None_Traits, ptr null, [9 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @None_val_create_o] }
@AsioEvent_Desc = constant %AsioEvent_Desc { i32 29, i32 8, i32 0, i32 0, ptr @AsioEvent_Inst, ptr @26, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @AsioEvent_Traits, ptr null, [9 x ptr] [ptr @AsioEvent_val_disposable_Ib, ptr @AsioEvent_val_none_o, ptr @AsioEvent_box_none_o, ptr @AsioEvent_box_disposable_Ib, ptr @AsioEvent_box_readable_Ib, ptr @AsioEvent_val_errored_Ib, ptr @AsioEvent_val_readable_Ib, ptr @AsioEvent_box_errored_Ib, ptr @AsioEvent_val_create_o] }
@U8_Desc = constant %U8_Desc { i32 4, i32 16, i32 0, i32 8, ptr null, ptr @27, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U8_Traits, ptr null, [28 x ptr] [ptr @U8_box_ne_Cb_Unbox, ptr @U8_val_create_pCC_Unbox, ptr @U8_val_eq_Cb_Unbox, ptr @U8_val_ne_Cb_Unbox, ptr @U8_box_eq_Cb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U8_box___digestof_] }
@Pointer_U8_val_Desc = constant %Pointer_U8_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @28, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_U8_val_Traits, ptr null, [25 x ptr] [ptr @Pointer_U8_val_ref__alloc_pZo, ptr @Pointer_U8_val_ref_create_o, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_box__apply_ZC, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_box__copy_to_oZo, ptr @Pointer_U8_val_ref__apply_ZC, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_box__offset_Zo, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_ref__realloc_ZZo, ptr @Pointer_U8_val_ref__copy_to_oZo, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_val__apply_ZC, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_ref__update_ZCC, ptr @Pointer_U8_val_val__offset_Zo, ptr @Pointer_U8_val_ref__offset_Zo, ptr @Pointer_U8_val_val__copy_to_oZo] }
@"$0$16_Inst" = constant %"$0$16" { ptr @"$0$16_Desc" }
@AmbientAuth_Inst = constant %AmbientAuth { ptr @AmbientAuth_Desc }
@None_Inst = constant %None { ptr @None_Desc }
@AsioEvent_Inst = constant %AsioEvent { ptr @AsioEvent_Desc }
@2 = private unnamed_addr constant [15 x i8] c"StdStream._err\00"
@3 = private unnamed_addr constant [15 x i8] c"StdStream._out\00"
@4 = private unnamed_addr constant [14 x i8] c"Stdin._create\00"
@5 = private unnamed_addr constant [18 x i8] c"Stdin._read_again\00"
@6 = private unnamed_addr constant [20 x i8] c"Stdin._event_notify\00"
@7 = private unnamed_addr constant [4 x i8] c"U32\00"
@U32_Traits = constant [1 x i64] zeroinitializer
@8 = private unnamed_addr constant [22 x i8] c"Pointer_AsioEvent_val\00"
@Pointer_AsioEvent_val_Traits = constant [1 x i64] zeroinitializer
@9 = private unnamed_addr constant [6 x i8] c"$0$16\00"
@"$0$16_Traits" = constant [1 x i64] [i64 4]
@10 = private unnamed_addr constant [27 x i8] c"Pointer_Pointer_U8_val_ref\00"
@Pointer_Pointer_U8_val_ref_Traits = constant [1 x i64] zeroinitializer
@11 = private unnamed_addr constant [12 x i8] c"AmbientAuth\00"
@AmbientAuth_Traits = constant [1 x i64] zeroinitializer
@12 = private unnamed_addr constant [10 x i8] c"StdStream\00"
@StdStream_Traits = constant [1 x i64] [i64 2]
@13 = private unnamed_addr constant [19 x i8] c"Pointer_String_val\00"
@Pointer_String_val_Traits = constant [1 x i64] zeroinitializer
@14 = private unnamed_addr constant [7 x i8] c"String\00"
@String_Traits = constant [1 x i64] zeroinitializer
@15 = private unnamed_addr constant [17 x i8] c"Array_String_val\00"
@Array_String_val_Traits = constant [1 x i64] zeroinitializer
@16 = private unnamed_addr constant [5 x i8] c"Bool\00"
@Bool_Traits = constant [1 x i64] zeroinitializer
@17 = private unnamed_addr constant [4 x i8] c"F64\00"
@F64_Traits = constant [1 x i64] zeroinitializer
@18 = private unnamed_addr constant [6 x i8] c"Stdin\00"
@Stdin_Traits = constant [1 x i64] [i64 1]
@19 = private unnamed_addr constant [4 x i8] c"I32\00"
@I32_Traits = constant [1 x i64] zeroinitializer
@20 = private unnamed_addr constant [4 x i8] c"U64\00"
@U64_Traits = constant [1 x i64] zeroinitializer
@21 = private unnamed_addr constant [6 x i8] c"USize\00"
@USize_Traits = constant [1 x i64] zeroinitializer
@22 = private unnamed_addr constant [15 x i8] c"RuntimeOptions\00"
@RuntimeOptions_Traits = constant [1 x i64] zeroinitializer
@23 = private unnamed_addr constant [13 x i8] c"Array_U8_val\00"
@Array_U8_val_Traits = constant [1 x i64] zeroinitializer
@24 = private unnamed_addr constant [4 x i8] c"Env\00"
@Env_Traits = constant [1 x i64] zeroinitializer
@25 = private unnamed_addr constant [5 x i8] c"None\00"
@None_Traits = constant [1 x i64] [i64 24]
@26 = private unnamed_addr constant [10 x i8] c"AsioEvent\00"
@AsioEvent_Traits = constant [1 x i64] zeroinitializer
@27 = private unnamed_addr constant [3 x i8] c"U8\00"
@U8_Traits = constant [1 x i64] zeroinitializer
@28 = private unnamed_addr constant [15 x i8] c"Pointer_U8_val\00"
@Pointer_U8_val_Traits = constant [1 x i64] zeroinitializer

; Function Attrs: nounwind memory(none)
declare ptr @pony_ctx() #0

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(304) ptr @pony_create(ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_destroy(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv_single(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_alloc(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(32) ptr @pony_alloc_small(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(1024) ptr @pony_alloc_large(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_realloc(ptr, ptr, i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable_or_null(32) ptr @pony_alloc_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(32) ptr @pony_alloc_small_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(1024) ptr @pony_alloc_large_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 ptr @pony_alloc_msg(i32, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_trace(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceknown(ptr, ptr readonly, ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceunknown(ptr, ptr readonly, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_send(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_recv(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_send_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_recv_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i32 @pony_init(i32, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_become(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i1 @pony_start(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: read)
declare i32 @pony_get_exitcode() #2

declare void @pony_coverage_init(i32)

declare void @pony_coverage_write(ptr)

; Function Attrs: noreturn
declare void @abort() #3

; Function Attrs: nounwind memory(argmem: read)
declare i32 @memcmp(ptr readonly, ptr readonly, i64) #2

declare i32 @puts(ptr)

define void @StdStream_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 0, label %handler
    i32 1, label %handler1
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
    #dbg_value(ptr %1, !5, !DIExpression(), !20)
  %4 = call ptr @pony_os_stderr(), !dbg !21
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !22
  store ptr %4, ptr %5, align 8, !dbg !22
  ret void

handler1:                                         ; preds = %entry
    #dbg_value(ptr %1, !23, !DIExpression(), !27)
  %6 = call ptr @pony_os_stdout(), !dbg !28
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !29
  store ptr %6, ptr %7, align 8, !dbg !29
  ret void
}

define ptr @StdStream_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 0, label %handler
    i32 1, label %handler1
  ]

default:                                          ; preds = %entry
  ret ptr @0

handler:                                          ; preds = %entry
  ret ptr @2

handler1:                                         ; preds = %entry
  ret ptr @3
}

define void @StdStream_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 304
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @String_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @Array_String_val_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %3 = load ptr, ptr %2, align 8
  call void @pony_trace(ptr %0, ptr %3)
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %5 = load i64, ptr %4, align 8
  br label %cond

cond:                                             ; preds = %body, %entry
  %6 = phi i64 [ 0, %entry ], [ %10, %body ]
  %7 = icmp ult i64 %6, %5
  br i1 %7, label %body, label %post

body:                                             ; preds = %cond
  %8 = getelementptr inbounds [8 x i8], ptr %3, i64 %6
  %9 = load ptr, ptr %8, align 8
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @String_Desc, i32 1)
  %10 = add i64 %6, 1
  br label %cond

post:                                             ; preds = %cond
  ret void
}

define void @Stdin_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 0, label %handler
    i32 4, label %handler1
    i32 1, label %handler2
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load i8, ptr %4, align 1
  %6 = trunc i8 %5 to i1
    #dbg_value(ptr %1, !30, !DIExpression(), !51)
    #dbg_value(i1 %6, !52, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !51)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !63)
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !65
  store ptr @None_Inst, ptr %7, align 8, !dbg !65
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 312, !dbg !66
  store i64 32, ptr %8, align 8, !dbg !66
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !77)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !85)
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 320, !dbg !87
  store ptr null, ptr %9, align 8, !dbg !87
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 328, !dbg !88
  %11 = zext i1 %6 to i8, !dbg !88
  store i8 %11, ptr %10, align 1, !dbg !88
  ret void

handler1:                                         ; preds = %entry
    #dbg_value(ptr %1, !89, !DIExpression(), !95)
  %12 = call fastcc i1 @Stdin_ref__read_b(ptr nonnull dereferenceable(336) %1), !dbg !96
  ret void

handler2:                                         ; preds = %entry
  %13 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %14 = load ptr, ptr %13, align 8
  %15 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %16 = load i32, ptr %15, align 4
  %17 = getelementptr inbounds nuw i8, ptr %2, i64 28
  %18 = load i32, ptr %17, align 4
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %14, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  call void @pony_recv_done(ptr %0)
  call fastcc void @Stdin_tag__event_notify_topIpIo(ptr %1, ptr %14, i32 %16, i32 %18)
  ret void
}

define ptr @Stdin_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 0, label %handler
    i32 4, label %handler1
    i32 1, label %handler2
  ]

default:                                          ; preds = %entry
  ret ptr @1

handler:                                          ; preds = %entry
  ret ptr @4

handler1:                                         ; preds = %entry
  ret ptr @5

handler2:                                         ; preds = %entry
  ret ptr @6
}

define void @Stdin_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 304
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceunknown(ptr %0, ptr %3, i32 0)
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 320
  %5 = load ptr, ptr %4, align 8
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  ret void
}

define void @RuntimeOptions_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 64
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 72
  %5 = load ptr, ptr %4, align 8
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 80
  %7 = load ptr, ptr %6, align 8
  call void @pony_traceknown(ptr %0, ptr %7, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 88
  %9 = load ptr, ptr %8, align 8
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @Array_U8_val_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %3 = load ptr, ptr %2, align 8
  call void @pony_trace(ptr %0, ptr %3)
  ret void
}

define void @Env_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceunknown(ptr %0, ptr %3, i32 2)
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 24
  %5 = load ptr, ptr %4, align 8
  call void @pony_traceunknown(ptr %0, ptr %5, i32 2)
  %6 = getelementptr inbounds nuw i8, ptr %1, i64 32
  %7 = load ptr, ptr %6, align 8
  call void @pony_traceunknown(ptr %0, ptr %7, i32 2)
  %8 = getelementptr inbounds nuw i8, ptr %1, i64 40
  %9 = load ptr, ptr %8, align 8
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @Array_String_val_Desc, i32 1)
  %10 = getelementptr inbounds nuw i8, ptr %1, i64 48
  %11 = load ptr, ptr %10, align 8
  call void @pony_traceknown(ptr %0, ptr %11, ptr nonnull @Array_String_val_Desc, i32 1)
  %12 = getelementptr inbounds nuw i8, ptr %1, i64 56
  %13 = load ptr, ptr %12, align 8
  call void @pony_traceunknown(ptr %0, ptr %13, i32 1)
  ret void
}

define fastcc i64 @U32_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i32 [ %3, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = zext i32 %6 to i64
  ret i64 %7
}

define fastcc i32 @U32_val_op_and_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !97 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !104, !DIExpression(), !106)
    #dbg_value(i32 %y, !107, !DIExpression(), !106)
  %0 = and i32 %this, %y, !dbg !108
  ret i32 %0, !dbg !108
}

define fastcc i32 @U32_box_op_and_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !109 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !112, !DIExpression(), !113)
    #dbg_value(i32 %y, !114, !DIExpression(), !113)
  %0 = and i32 %this, %y, !dbg !115
  ret i32 %0, !dbg !115
}

define fastcc i32 @U32_val_shl_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !116 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !119, !DIExpression(), !120)
    #dbg_value(i32 %y, !121, !DIExpression(), !120)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !122
  %1 = shl i32 %this, %0, !dbg !122
  ret i32 %1, !dbg !122
}

define fastcc i32 @U32_box_shl_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !123 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !126, !DIExpression(), !127)
    #dbg_value(i32 %y, !128, !DIExpression(), !127)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !129
  %1 = shl i32 %this, %0, !dbg !129
  ret i32 %1, !dbg !129
}

define fastcc i1 @U32_val_ne_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !130 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !135, !DIExpression(), !136)
    #dbg_value(i32 %y, !137, !DIExpression(), !136)
  %0 = icmp ne i32 %this, %y, !dbg !138
  ret i1 %0, !dbg !138
}

define fastcc i1 @U32_box_ne_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !139 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !142, !DIExpression(), !143)
    #dbg_value(i32 %y, !144, !DIExpression(), !143)
  %0 = icmp ne i32 %this, %y, !dbg !145
  ret i1 %0, !dbg !145
}

define fastcc i1 @U32_box_eq_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !146 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !149, !DIExpression(), !150)
    #dbg_value(i32 %y, !151, !DIExpression(), !150)
  %0 = icmp eq i32 %this, %y, !dbg !152
  ret i1 %0, !dbg !152
}

define fastcc i1 @U32_val_eq_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !153 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !156, !DIExpression(), !157)
    #dbg_value(i32 %y, !158, !DIExpression(), !157)
  %0 = icmp eq i32 %this, %y, !dbg !159
  ret i1 %0, !dbg !159
}

define fastcc i32 @U32_val_create_pII(i32 %this, i32 %value) unnamed_addr #4 !dbg !160 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !163, !DIExpression(), !164)
    #dbg_value(i32 %value, !165, !DIExpression(), !164)
  ret i32 %value, !dbg !166
}

define fastcc ptr @Pointer_AsioEvent_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define fastcc i1 @Pointer_AsioEvent_val_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

define fastcc ptr @"$0$16_val_create_o"(ptr %this) unnamed_addr #4 !dbg !167 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !175, !DIExpression(), !177)
  ret ptr %this, !dbg !178
}

define fastcc ptr @"$0$16_Alloc"() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @"$0$16_Inst"
}

define fastcc ptr @Pointer_Pointer_U8_val_ref_box__apply_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [8 x i8], ptr %0, i64 %1
  %3 = load ptr, ptr %2, align 8
  ret ptr %3
}

define fastcc ptr @Pointer_Pointer_U8_val_ref_ref__apply_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [8 x i8], ptr %0, i64 %1
  %3 = load ptr, ptr %2, align 8
  ret ptr %3
}

define fastcc ptr @Pointer_Pointer_U8_val_ref_val__apply_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [8 x i8], ptr %0, i64 %1
  %3 = load ptr, ptr %2, align 8
  ret ptr %3
}

define fastcc i1 @Pointer_Pointer_U8_val_ref_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

define fastcc ptr @AmbientAuth_val__create_o(ptr %this) unnamed_addr #4 !dbg !179 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !187, !DIExpression(), !189)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !190)
  ret ptr %this, !dbg !192
}

define fastcc ptr @AmbientAuth_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @AmbientAuth_Inst
}

define fastcc ptr @StdStream_tag__err_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @StdStream_tag__err_o(ptr %this) unnamed_addr #4 !dbg !6 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !5, !DIExpression(), !20)
  %0 = call ptr @pony_os_stderr(), !dbg !21
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !22
  store ptr %0, ptr %1, align 8, !dbg !22
  ret void
}

define fastcc ptr @StdStream_tag__out_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @StdStream_tag__out_o(ptr %this) unnamed_addr #4 !dbg !24 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !23, !DIExpression(), !27)
  %0 = call ptr @pony_os_stdout(), !dbg !28
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !29
  store ptr %0, ptr %1, align 8, !dbg !29
  ret void
}

define fastcc noalias align 32 dereferenceable(312) ptr @StdStream_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  ret ptr %1
}

define fastcc ptr @Pointer_String_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define fastcc noalias align 32 dereferenceable_or_null(8) ptr @Pointer_String_val_ref__alloc_pZo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = shl i64 %1, 3
  %4 = call ptr @pony_alloc(ptr %2, i64 %3)
  ret ptr %4
}

define fastcc noalias align 32 dereferenceable_or_null(8) ptr @Pointer_String_val_ref__realloc_ZZo(ptr %0, i64 %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = call ptr @pony_ctx()
  %4 = shl i64 %1, 3
  %5 = shl i64 %2, 3
  %6 = call ptr @pony_realloc(ptr %3, ptr %0, i64 %4, i64 %5)
  ret ptr %6
}

define fastcc ptr @Pointer_String_val_ref__update_Zoo(ptr %0, i64 %1, ptr dereferenceable(32) %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds [8 x i8], ptr %0, i64 %1
  %4 = load ptr, ptr %3, align 8
  store ptr %2, ptr %3, align 8
  ret ptr %4
}

define fastcc i64 @Pointer_String_val_tag__min_alloc_Z(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 4
}

define fastcc i1 @String_ref_is_null_terminated_b(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !193 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !205, !DIExpression(), !207)
  br label %sc_left, !dbg !208

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !209

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !210
  %1 = load i64, ptr %0, align 8, !dbg !210
  %.not = icmp eq i64 %1, 0, !dbg !210
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !211
  %3 = load i64, ptr %2, align 8, !dbg !211
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !211
  %5 = load i64, ptr %4, align 8, !dbg !211
  %6 = icmp ne i64 %3, %5, !dbg !211
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !212
  %9 = load i64, ptr %8, align 8, !dbg !212
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !212
  %11 = load ptr, ptr %10, align 8, !dbg !212
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !213
  %13 = load i8, ptr %12, align 1, !dbg !213
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !208
}

define fastcc i1 @String_box_is_null_terminated_b(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !214 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !217, !DIExpression(), !218)
  br label %sc_left, !dbg !219

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !220

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !221
  %1 = load i64, ptr %0, align 8, !dbg !221
  %.not = icmp eq i64 %1, 0, !dbg !221
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !222
  %3 = load i64, ptr %2, align 8, !dbg !222
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !222
  %5 = load i64, ptr %4, align 8, !dbg !222
  %6 = icmp ne i64 %3, %5, !dbg !222
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !223
  %9 = load i64, ptr %8, align 8, !dbg !223
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !223
  %11 = load ptr, ptr %10, align 8, !dbg !223
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !224
  %13 = load i8, ptr %12, align 1, !dbg !224
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !219
}

define fastcc i1 @String_val_is_null_terminated_b(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !225 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !228, !DIExpression(), !229)
  br label %sc_left, !dbg !230

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !231

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !232
  %1 = load i64, ptr %0, align 8, !dbg !232
  %.not = icmp eq i64 %1, 0, !dbg !232
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !233
  %3 = load i64, ptr %2, align 8, !dbg !233
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !233
  %5 = load i64, ptr %4, align 8, !dbg !233
  %6 = icmp ne i64 %3, %5, !dbg !233
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !234
  %9 = load i64, ptr %8, align 8, !dbg !234
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !234
  %11 = load ptr, ptr %10, align 8, !dbg !234
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !235
  %13 = load i8, ptr %12, align 1, !dbg !235
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !230
}

define fastcc ptr @String_box_cstring_o(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !236 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !241, !DIExpression(), !243)
    #dbg_value(ptr %this, !217, !DIExpression(), !244)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !247
  %1 = load i64, ptr %0, align 8, !dbg !247
  %.not.i = icmp eq i64 %1, 0, !dbg !247
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !248
  %3 = load i64, ptr %2, align 8, !dbg !248
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !248
  %5 = load i64, ptr %4, align 8, !dbg !248
  %6 = icmp ne i64 %3, %5, !dbg !248
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_box_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !249
  %9 = load i64, ptr %8, align 8, !dbg !249
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !249
  %11 = load ptr, ptr %10, align 8, !dbg !249
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !250
  %13 = load i8, ptr %12, align 1, !dbg !250
  %14 = icmp eq i8 %13, 0
  br label %String_box_is_null_terminated_b.exit

String_box_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_box_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %17 = load ptr, ptr %16, align 8
  ret ptr %17, !dbg !251

if_else:                                          ; preds = %String_box_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !253)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !256
  %19 = load i64, ptr %18, align 8, !dbg !256
  %20 = add i64 %19, 1, !dbg !256
  %21 = call ptr @pony_ctx(), !dbg !257
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i64 %20), !dbg !257
    #dbg_value(ptr %22, !242, !DIExpression(), !243)
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %26 = load ptr, ptr %25, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %22, ptr align 1 %26, i64 %24, i1 false), !dbg !258
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = getelementptr inbounds i8, ptr %22, i64 %28, !dbg !259
  %30 = load i8, ptr %29, align 1, !dbg !259
  store i8 0, ptr %29, align 1, !dbg !259
  ret ptr %22, !dbg !260
}

define fastcc ptr @String_val_cstring_o(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !261 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !264, !DIExpression(), !266)
    #dbg_value(ptr %this, !228, !DIExpression(), !267)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !270
  %1 = load i64, ptr %0, align 8, !dbg !270
  %.not.i = icmp eq i64 %1, 0, !dbg !270
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !271
  %3 = load i64, ptr %2, align 8, !dbg !271
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !271
  %5 = load i64, ptr %4, align 8, !dbg !271
  %6 = icmp ne i64 %3, %5, !dbg !271
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_val_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !272
  %9 = load i64, ptr %8, align 8, !dbg !272
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !272
  %11 = load ptr, ptr %10, align 8, !dbg !272
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !273
  %13 = load i8, ptr %12, align 1, !dbg !273
  %14 = icmp eq i8 %13, 0
  br label %String_val_is_null_terminated_b.exit

String_val_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_val_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %17 = load ptr, ptr %16, align 8
  ret ptr %17, !dbg !274

if_else:                                          ; preds = %String_val_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !276)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !279
  %19 = load i64, ptr %18, align 8, !dbg !279
  %20 = add i64 %19, 1, !dbg !279
  %21 = call ptr @pony_ctx(), !dbg !280
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i64 %20), !dbg !280
    #dbg_value(ptr %22, !265, !DIExpression(), !266)
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %26 = load ptr, ptr %25, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %22, ptr align 1 %26, i64 %24, i1 false), !dbg !281
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = getelementptr inbounds i8, ptr %22, i64 %28, !dbg !282
  %30 = load i8, ptr %29, align 1, !dbg !282
  store i8 0, ptr %29, align 1, !dbg !282
  ret ptr %22, !dbg !283
}

define fastcc ptr @String_ref_cstring_o(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !284 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !287, !DIExpression(), !289)
    #dbg_value(ptr %this, !205, !DIExpression(), !290)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !293
  %1 = load i64, ptr %0, align 8, !dbg !293
  %.not.i = icmp eq i64 %1, 0, !dbg !293
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !294
  %3 = load i64, ptr %2, align 8, !dbg !294
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !294
  %5 = load i64, ptr %4, align 8, !dbg !294
  %6 = icmp ne i64 %3, %5, !dbg !294
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_ref_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !295
  %9 = load i64, ptr %8, align 8, !dbg !295
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !295
  %11 = load ptr, ptr %10, align 8, !dbg !295
  %12 = getelementptr inbounds i8, ptr %11, i64 %9, !dbg !296
  %13 = load i8, ptr %12, align 1, !dbg !296
  %14 = icmp eq i8 %13, 0
  br label %String_ref_is_null_terminated_b.exit

String_ref_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_ref_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %17 = load ptr, ptr %16, align 8
  ret ptr %17, !dbg !297

if_else:                                          ; preds = %String_ref_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !299)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !302
  %19 = load i64, ptr %18, align 8, !dbg !302
  %20 = add i64 %19, 1, !dbg !302
  %21 = call ptr @pony_ctx(), !dbg !303
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i64 %20), !dbg !303
    #dbg_value(ptr %22, !288, !DIExpression(), !289)
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %26 = load ptr, ptr %25, align 8
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %22, ptr align 1 %26, i64 %24, i1 false), !dbg !304
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %28 = load i64, ptr %27, align 8
  %29 = getelementptr inbounds i8, ptr %22, i64 %28, !dbg !305
  %30 = load i8, ptr %29, align 1, !dbg !305
  store i8 0, ptr %29, align 1, !dbg !305
  ret ptr %22, !dbg !306
}

define fastcc i8 @String_ref__set_ZCC(ptr dereferenceable(32) %this, i64 %i, i8 %value) unnamed_addr #4 !dbg !307 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !313, !DIExpression(), !314)
    #dbg_value(i64 %i, !315, !DIExpression(), !314)
    #dbg_value(i8 %value, !316, !DIExpression(), !314)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 %i, !dbg !317
  %3 = load i8, ptr %2, align 1, !dbg !317
  store i8 %value, ptr %2, align 1, !dbg !317
  ret i8 %3, !dbg !317
}

define fastcc void @String_ref_create_pZo(ptr %this, i64 %len) unnamed_addr #4 !dbg !318 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !323, !DIExpression(), !324)
    #dbg_value(i64 %len, !325, !DIExpression(), !324)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !326
  store i64 0, ptr %0, align 8, !dbg !326
    #dbg_value(i64 0, !327, !DIExpression(), !334)
  %1 = add i64 -1, -1
    #dbg_value(i64 %len, !336, !DIExpression(), !342)
    #dbg_value(i64 %1, !344, !DIExpression(), !342)
  %2 = icmp ult i64 %len, %1, !dbg !345
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %3 = phi i64 [ %len, %if_then.i ], [ %1, %if_else.i ]
  %4 = add i64 %3, 1
    #dbg_value(i64 %4, !347, !DIExpression(), !351)
    #dbg_value(i64 32, !353, !DIExpression(), !351)
  %5 = icmp ugt i64 %4, 32, !dbg !354
  br i1 %5, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_min_ZZ.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_min_ZZ.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %6 = phi i64 [ %4, %if_then.i4 ], [ 32, %if_else.i3 ]
  %7 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !356
  store i64 %6, ptr %7, align 8, !dbg !356
  %8 = call ptr @pony_ctx(), !dbg !357
  %9 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %8, i64 %6), !dbg !357
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !358
  store ptr %9, ptr %10, align 8, !dbg !358
    #dbg_value(ptr %this, !313, !DIExpression(), !359)
    #dbg_value(i64 0, !315, !DIExpression(), !359)
    #dbg_value(i8 0, !316, !DIExpression(), !359)
  %11 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %12 = load ptr, ptr %11, align 8
  %13 = load i8, ptr %12, align 1, !dbg !361
  store i8 0, ptr %12, align 1, !dbg !361
  ret void, !dbg !362
}

define fastcc void @String_ref_copy_cstring_moo(ptr %this, ptr %str) unnamed_addr #4 !dbg !363 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !368, !DIExpression(), !372)
    #dbg_value(ptr %str, !373, !DIExpression(), !372)
  %0 = icmp eq ptr %str, null, !dbg !374
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !375
  store i64 0, ptr %1, align 8, !dbg !375
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !377
  store i64 32, ptr %2, align 8, !dbg !377
  %3 = call ptr @pony_ctx(), !dbg !378
  %4 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %3, i64 32), !dbg !378
  %5 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !379
  store ptr %4, ptr %5, align 8, !dbg !379
    #dbg_value(ptr %this, !313, !DIExpression(), !380)
    #dbg_value(i64 0, !315, !DIExpression(), !380)
    #dbg_value(i8 0, !316, !DIExpression(), !380)
  %6 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %7 = load ptr, ptr %6, align 8
  %8 = load i8, ptr %7, align 1, !dbg !382
  store i8 0, ptr %7, align 1, !dbg !382
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i64 0, !369, !DIExpression(), !383)
  br label %while_init

while_init:                                       ; preds = %if_else
  %9 = load i8, ptr %str, align 1, !dbg !384
  %.not = icmp eq i8 %9, 0
  br i1 %.not, label %while_else, label %while_body

while_body:                                       ; preds = %while_body, %while_init
  %i.0 = phi i64 [ 0, %while_init ], [ %10, %while_body ]
    #dbg_value(i64 %i.0, !369, !DIExpression(), !383)
  %10 = add i64 %i.0, 1, !dbg !386
    #dbg_value(i64 %10, !369, !DIExpression(), !383)
  %11 = getelementptr inbounds i8, ptr %str, i64 %10, !dbg !384
  %12 = load i8, ptr %11, align 1, !dbg !384
  %.not10 = icmp eq i8 %12, 0
  br i1 %.not10, label %while_post, label %while_body

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !388)
  br label %while_post

while_post:                                       ; preds = %while_else, %while_body
  %i.1 = phi i64 [ %10, %while_body ], [ 0, %while_else ]
    #dbg_value(i64 %i.1, !369, !DIExpression(), !383)
  %13 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !391
  store i64 %i.1, ptr %13, align 8, !dbg !391
  %14 = add i64 %i.1, 1, !dbg !392
    #dbg_value(i64 %14, !347, !DIExpression(), !393)
    #dbg_value(i64 32, !353, !DIExpression(), !393)
  %15 = icmp ugt i64 %14, 32, !dbg !395
  br i1 %15, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %while_post
  br label %USize_val_max_ZZ.exit

if_else.i:                                        ; preds = %while_post
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %16 = phi i64 [ %14, %if_then.i ], [ 32, %if_else.i ]
  %17 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !396
  store i64 %16, ptr %17, align 8, !dbg !396
  %18 = call ptr @pony_ctx(), !dbg !397
  %19 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %18, i64 %16), !dbg !397
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !398
  store ptr %19, ptr %20, align 8, !dbg !398
  %21 = add i64 %i.1, 1, !dbg !399
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %19, ptr align 1 %str, i64 %21, i1 false), !dbg !400
  br label %if_post

if_post:                                          ; preds = %USize_val_max_ZZ.exit, %if_then
  ret void, !dbg !401
}

define fastcc noalias align 32 dereferenceable(32) ptr @String_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @String_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc ptr @Array_String_val_ref_push_oo(ptr dereferenceable(32) %this, ptr dereferenceable(32) %value) unnamed_addr #4 !dbg !402 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !416, !DIExpression(), !418)
    #dbg_value(ptr %value, !419, !DIExpression(), !418)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !420
  %1 = load i64, ptr %0, align 8, !dbg !420
  %2 = add i64 %1, 1, !dbg !420
    #dbg_value(ptr %this, !421, !DIExpression(), !427)
    #dbg_value(i64 %2, !429, !DIExpression(), !427)
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !430
  %4 = load i64, ptr %3, align 8, !dbg !430
  %5 = icmp ult i64 %4, %2, !dbg !430
  br i1 %5, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  %6 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %7 = load ptr, ptr %6, align 8
    #dbg_value(i64 %2, !432, !DIExpression(), !437)
    #dbg_value(i64 %1, !440, !DIExpression(), !444)
  %8 = call fastcc i64 @USize_val_u64_W(i64 %1), !dbg !446
  %9 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %8, i1 false), !dbg !449
  %10 = call fastcc i64 @U64_val_usize_Z(i64 %9), !dbg !450
    #dbg_value(i64 %10, !436, !DIExpression(), !437)
  %11 = icmp eq i64 %10, 0, !dbg !451
  br i1 %11, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %if_then.i
  br label %USize_val_next_pow2_Z.exit.i

if_else.i.i:                                      ; preds = %if_then.i
    #dbg_value(i64 %2, !453, !DIExpression(), !457)
  %12 = sub i64 64, %10
  %13 = call i64 @llvm.umin.i64(i64 %12, i64 63)
  br label %USize_val_next_pow2_Z.exit.i

USize_val_next_pow2_Z.exit.i:                     ; preds = %if_else.i.i, %if_then.i.i
  %14 = phi i64 [ 0, %if_then.i.i ], [ %13, %if_else.i.i ]
  %15 = shl nuw i64 1, %14
    #dbg_value(i64 %15, !347, !DIExpression(), !460)
    #dbg_value(i64 %2, !353, !DIExpression(), !460)
  %16 = icmp ugt i64 %15, %2, !dbg !462
  br i1 %16, label %if_then.i4.i, label %if_else.i3.i

if_then.i4.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

if_else.i3.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

USize_val_max_ZZ.exit.i:                          ; preds = %if_else.i3.i, %if_then.i4.i
  %17 = phi i64 [ %15, %if_then.i4.i ], [ %2, %if_else.i3.i ]
    #dbg_value(i64 %17, !347, !DIExpression(), !463)
    #dbg_value(i64 8, !353, !DIExpression(), !463)
  %18 = icmp ugt i64 %17, 8, !dbg !465
  br i1 %18, label %if_then.i6.i, label %if_else.i5.i

if_then.i6.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

if_else.i5.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

USize_val_max_ZZ.exit7.i:                         ; preds = %if_else.i5.i, %if_then.i6.i
  %19 = phi i64 [ %17, %if_then.i6.i ], [ 8, %if_else.i5.i ]
    #dbg_value(i64 %19, !347, !DIExpression(), !466)
    #dbg_value(i64 4, !353, !DIExpression(), !466)
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !468
  store i64 %19, ptr %20, align 8, !dbg !468
  %21 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %24 = load ptr, ptr %23, align 8
  %25 = call ptr @pony_ctx(), !dbg !469
  %26 = shl i64 %19, 3, !dbg !469
  %27 = shl i64 %22, 3, !dbg !469
  %28 = call noalias align 32 dereferenceable_or_null(8) ptr @pony_realloc(ptr %25, ptr %24, i64 %26, i64 %27), !dbg !469
  %29 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !470
  store ptr %28, ptr %29, align 8, !dbg !470
  br label %Array_String_val_ref_reserve_Zo.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !471)
  br label %Array_String_val_ref_reserve_Zo.exit

Array_String_val_ref_reserve_Zo.exit:             ; preds = %USize_val_max_ZZ.exit7.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !474)
  %30 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %33 = load ptr, ptr %32, align 8
  %34 = getelementptr inbounds [8 x i8], ptr %33, i64 %31, !dbg !476
  %35 = load ptr, ptr %34, align 8, !dbg !476
  store ptr %value, ptr %34, align 8, !dbg !476
  %36 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !477
  %37 = load i64, ptr %36, align 8, !dbg !477
  %38 = add i64 %37, 1, !dbg !477
  %39 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !478
  store i64 %38, ptr %39, align 8, !dbg !478
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !479)
  ret ptr @None_Inst, !dbg !481
}

define fastcc ptr @Array_String_val_ref_reserve_Zo(ptr dereferenceable(32) %this, i64 %len) unnamed_addr #4 !dbg !422 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !421, !DIExpression(), !482)
    #dbg_value(i64 %len, !429, !DIExpression(), !482)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !483
  %1 = load i64, ptr %0, align 8, !dbg !483
  %2 = icmp ult i64 %1, %len, !dbg !483
  br i1 %2, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %4 = load ptr, ptr %3, align 8
    #dbg_value(i64 %len, !432, !DIExpression(), !484)
  %5 = add i64 %len, -1, !dbg !486
    #dbg_value(i64 %5, !440, !DIExpression(), !487)
  %6 = call fastcc i64 @USize_val_u64_W(i64 %5), !dbg !489
  %7 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %6, i1 false), !dbg !490
  %8 = call fastcc i64 @U64_val_usize_Z(i64 %7), !dbg !491
    #dbg_value(i64 %8, !436, !DIExpression(), !484)
  %9 = icmp eq i64 %8, 0, !dbg !492
  br i1 %9, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i64 %len, !453, !DIExpression(), !493)
  %10 = sub i64 64, %8
  %11 = call i64 @llvm.umin.i64(i64 %10, i64 63)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %12 = phi i64 [ 0, %if_then.i ], [ %11, %if_else.i ]
  %13 = shl nuw i64 1, %12
    #dbg_value(i64 %13, !347, !DIExpression(), !495)
    #dbg_value(i64 %len, !353, !DIExpression(), !495)
  %14 = icmp ugt i64 %13, %len, !dbg !497
  br i1 %14, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %15 = phi i64 [ %13, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i64 %15, !347, !DIExpression(), !498)
    #dbg_value(i64 8, !353, !DIExpression(), !498)
  %16 = icmp ugt i64 %15, 8, !dbg !500
  br i1 %16, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %17 = phi i64 [ %15, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i64 %17, !347, !DIExpression(), !501)
    #dbg_value(i64 4, !353, !DIExpression(), !501)
  %18 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !503
  store i64 %17, ptr %18, align 8, !dbg !503
  %19 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %20 = load i64, ptr %19, align 8
  %21 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %22 = load ptr, ptr %21, align 8
  %23 = call ptr @pony_ctx(), !dbg !504
  %24 = shl i64 %17, 3, !dbg !504
  %25 = shl i64 %20, 3, !dbg !504
  %26 = call noalias align 32 dereferenceable_or_null(8) ptr @pony_realloc(ptr %23, ptr %22, i64 %24, i64 %25), !dbg !504
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !505
  store ptr %26, ptr %27, align 8, !dbg !505
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !506)
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit7
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !508)
  ret ptr @None_Inst, !dbg !510
}

define fastcc void @Array_String_val_ref_create_pZo(ptr %this, i64 %len) unnamed_addr #4 !dbg !511 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !516, !DIExpression(), !517)
    #dbg_value(i64 %len, !518, !DIExpression(), !517)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !519
  store i64 0, ptr %0, align 8, !dbg !519
  %.not = icmp eq i64 %len, 0, !dbg !520
  br i1 %.not, label %if_else, label %if_then

if_then:                                          ; preds = %entry
    #dbg_value(i64 %len, !432, !DIExpression(), !522)
  %1 = add i64 %len, -1, !dbg !525
    #dbg_value(i64 %1, !440, !DIExpression(), !526)
  %2 = call fastcc i64 @USize_val_u64_W(i64 %1), !dbg !528
  %3 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %2, i1 false), !dbg !529
  %4 = call fastcc i64 @U64_val_usize_Z(i64 %3), !dbg !530
    #dbg_value(i64 %4, !436, !DIExpression(), !522)
  %5 = icmp eq i64 %4, 0, !dbg !531
  br i1 %5, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i64 %len, !453, !DIExpression(), !532)
  %6 = sub i64 64, %4
  %7 = call i64 @llvm.umin.i64(i64 %6, i64 63)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %8 = phi i64 [ 0, %if_then.i ], [ %7, %if_else.i ]
  %9 = shl nuw i64 1, %8
    #dbg_value(i64 %9, !347, !DIExpression(), !534)
    #dbg_value(i64 %len, !353, !DIExpression(), !534)
  %10 = icmp ugt i64 %9, %len, !dbg !536
  br i1 %10, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %11 = phi i64 [ %9, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i64 %11, !347, !DIExpression(), !537)
    #dbg_value(i64 8, !353, !DIExpression(), !537)
  %12 = icmp ugt i64 %11, 8, !dbg !539
  br i1 %12, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %13 = phi i64 [ %11, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i64 %13, !347, !DIExpression(), !540)
    #dbg_value(i64 4, !353, !DIExpression(), !540)
  %14 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !542
  store i64 %13, ptr %14, align 8, !dbg !542
  %15 = call ptr @pony_ctx(), !dbg !543
  %16 = shl i64 %13, 3, !dbg !543
  %17 = call noalias align 32 dereferenceable_or_null(8) ptr @pony_alloc(ptr %15, i64 %16), !dbg !543
  %18 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !544
  store ptr %17, ptr %18, align 8, !dbg !544
  br label %if_post

if_else:                                          ; preds = %entry
  %19 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !545
  store i64 0, ptr %19, align 8, !dbg !545
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !547
  store ptr null, ptr %20, align 8, !dbg !547
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit7
  ret void, !dbg !548
}

define fastcc noalias align 32 dereferenceable(32) ptr @Array_String_val_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_String_val_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc i64 @Bool_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %4 = load i8, ptr %3, align 1
  %5 = zext i8 %4 to i64
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i64 [ %2, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = and i64 %6, 1
  ret i64 %7
}

define fastcc i1 @Bool_box_op_not_b(i1 %this) unnamed_addr #4 !dbg !549 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !555, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !557)
  %0 = xor i1 %this, true, !dbg !558
  ret i1 %0, !dbg !558
}

define fastcc i1 @Bool_val_op_not_b(i1 %this) unnamed_addr #4 !dbg !559 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !562, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !563)
  %0 = xor i1 %this, true, !dbg !564
  ret i1 %0, !dbg !564
}

define fastcc i1 @Bool_val_create_pbb(i1 %this, i1 %from) unnamed_addr #4 !dbg !565 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !570, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !571)
    #dbg_value(i1 %from, !572, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !571)
  ret i1 %from, !dbg !573
}

define fastcc i1 @Bool_box_op_and_bb(i1 %this, i1 %y) unnamed_addr #4 !dbg !574 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !577, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !578)
    #dbg_value(i1 %y, !579, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !578)
  br label %sc_left, !dbg !580

sc_left:                                          ; preds = %entry
  br i1 %this, label %sc_right, label %sc_post, !dbg !580

sc_right:                                         ; preds = %sc_left
  br label %sc_post, !dbg !580

sc_post:                                          ; preds = %sc_right, %sc_left
  %0 = phi i1 [ false, %sc_left ], [ %y, %sc_right ], !dbg !580
  ret i1 %0, !dbg !580
}

define fastcc i1 @Bool_val_op_and_bb(i1 %this, i1 %y) unnamed_addr #4 !dbg !581 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !584, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !585)
    #dbg_value(i1 %y, !586, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !585)
  br label %sc_left, !dbg !587

sc_left:                                          ; preds = %entry
  br i1 %this, label %sc_right, label %sc_post, !dbg !587

sc_right:                                         ; preds = %sc_left
  br label %sc_post, !dbg !587

sc_post:                                          ; preds = %sc_right, %sc_left
  %0 = phi i1 [ false, %sc_left ], [ %y, %sc_right ], !dbg !587
  ret i1 %0, !dbg !587
}

define fastcc i64 @F64_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  ret i64 %2
}

define fastcc ptr @Stdin_tag__create_pbo__send(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = zext i1 %1 to i8
  %4 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store i8 %3, ptr %5, align 1
  call void @pony_sendv_single(ptr %2, ptr %0, ptr %4, ptr %4, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Stdin_tag__create_pbo(ptr %this, i1 %use_event) unnamed_addr #4 !dbg !31 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !30, !DIExpression(), !51)
    #dbg_value(i1 %use_event, !52, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !51)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !63)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !65
  store ptr @None_Inst, ptr %0, align 8, !dbg !65
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 312, !dbg !66
  store i64 32, ptr %1, align 8, !dbg !66
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !77)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !85)
  %2 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !87
  store ptr null, ptr %2, align 8, !dbg !87
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 328, !dbg !88
  %4 = zext i1 %use_event to i8, !dbg !88
  store i8 %4, ptr %3, align 1, !dbg !88
  ret void
}

define fastcc i1 @Stdin_ref__read_b(ptr dereferenceable(336) %this) unnamed_addr #4 !dbg !588 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !593, !DIExpression(), !611)
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304
  %2 = load ptr, ptr %1, align 8
  br label %case_pattern

case_pattern:                                     ; preds = %entry
  %3 = load ptr, ptr %2, align 8
  %4 = icmp slt ptr %2, null
  br i1 %4, label %ptf_tagged, label %ptf_heap

ptf_tagged:                                       ; preds = %case_pattern
  br label %ptf_merge

ptf_heap:                                         ; preds = %case_pattern
  br label %ptf_merge

ptf_merge:                                        ; preds = %ptf_heap, %ptf_tagged
  %5 = getelementptr inbounds nuw i8, ptr %3, i64 72
  %6 = load ptr, ptr %5, align 8
  %7 = load i64, ptr %6, align 8
  %8 = and i64 %7, 32
  %.not = icmp ne i64 %8, 0
  br i1 %.not, label %pattern_continue, label %match_else

pattern_continue:                                 ; preds = %ptf_merge
    #dbg_value(ptr %2, !594, !DIExpression(), !612)
  br label %match_post

match_else:                                       ; preds = %ptf_merge
  br label %try_else, !dbg !613

match_post:                                       ; preds = %pattern_continue
    #dbg_value(ptr %2, !600, !DIExpression(), !616)
    #dbg_value(i64 0, !601, !DIExpression(), !616)
  br label %while_init

while_init:                                       ; preds = %match_post
  br i1 true, label %while_body, label %while_else

while_body:                                       ; preds = %if_post15, %while_init
  %sum.0 = phi i64 [ 0, %while_init ], [ %86, %if_post15 ]
    #dbg_value(i64 poison, !610, !DIExpression(), !617)
    #dbg_value(i64 %sum.0, !601, !DIExpression(), !616)
    #dbg_value(i64 poison, !602, !DIExpression(), !617)
    #dbg_value(ptr poison, !605, !DIExpression(), !617)
  %9 = getelementptr inbounds nuw i8, ptr %this, i64 312
  %10 = load i64, ptr %9, align 8
    #dbg_value(i64 %10, !602, !DIExpression(), !617)
  %11 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_U8_val_Desc, ptr %11, align 8
    #dbg_value(ptr %11, !618, !DIExpression(), !625)
    #dbg_value(i64 0, !628, !DIExpression(), !625)
  %12 = getelementptr inbounds nuw i8, ptr %11, i64 8, !dbg !629
  store i64 0, ptr %12, align 8, !dbg !629
  %13 = getelementptr inbounds nuw i8, ptr %11, i64 16, !dbg !630
  store i64 0, ptr %13, align 8, !dbg !630
  %14 = getelementptr inbounds nuw i8, ptr %11, i64 24, !dbg !633
  store ptr null, ptr %14, align 8, !dbg !633
    #dbg_value(ptr %11, !634, !DIExpression(), !640)
    #dbg_value(i64 %10, !642, !DIExpression(), !640)
    #dbg_value(ptr %11, !643, !DIExpression(), !647)
    #dbg_value(i64 %10, !649, !DIExpression(), !647)
  %15 = getelementptr inbounds nuw i8, ptr %11, i64 16, !dbg !650
  %16 = load i64, ptr %15, align 8, !dbg !650
  %17 = icmp ult i64 %16, %10, !dbg !650
  br i1 %17, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %while_body
  %18 = getelementptr inbounds nuw i8, ptr %11, i64 24
  %19 = load ptr, ptr %18, align 8
    #dbg_value(i64 %10, !432, !DIExpression(), !652)
  %20 = add i64 %10, -1, !dbg !655
    #dbg_value(i64 %20, !440, !DIExpression(), !656)
  %21 = call fastcc i64 @USize_val_u64_W(i64 %20), !dbg !658
  %22 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %21, i1 false), !dbg !659
  %23 = call fastcc i64 @U64_val_usize_Z(i64 %22), !dbg !660
    #dbg_value(i64 %23, !436, !DIExpression(), !652)
  %24 = icmp eq i64 %23, 0, !dbg !661
  br i1 %24, label %if_then.i.i.i, label %if_else.i.i.i

if_then.i.i.i:                                    ; preds = %if_then.i.i
  br label %USize_val_next_pow2_Z.exit.i.i

if_else.i.i.i:                                    ; preds = %if_then.i.i
    #dbg_value(i64 %10, !453, !DIExpression(), !662)
  %25 = sub i64 64, %23
  %26 = call i64 @llvm.umin.i64(i64 %25, i64 63)
  br label %USize_val_next_pow2_Z.exit.i.i

USize_val_next_pow2_Z.exit.i.i:                   ; preds = %if_else.i.i.i, %if_then.i.i.i
  %27 = phi i64 [ 0, %if_then.i.i.i ], [ %26, %if_else.i.i.i ]
  %28 = shl nuw i64 1, %27
    #dbg_value(i64 %28, !347, !DIExpression(), !664)
    #dbg_value(i64 %10, !353, !DIExpression(), !664)
  %29 = icmp ugt i64 %28, %10, !dbg !666
  br i1 %29, label %if_then.i4.i.i, label %if_else.i3.i.i

if_then.i4.i.i:                                   ; preds = %USize_val_next_pow2_Z.exit.i.i
  br label %USize_val_max_ZZ.exit.i.i

if_else.i3.i.i:                                   ; preds = %USize_val_next_pow2_Z.exit.i.i
  br label %USize_val_max_ZZ.exit.i.i

USize_val_max_ZZ.exit.i.i:                        ; preds = %if_else.i3.i.i, %if_then.i4.i.i
  %30 = phi i64 [ %28, %if_then.i4.i.i ], [ %10, %if_else.i3.i.i ]
    #dbg_value(i64 %30, !347, !DIExpression(), !667)
    #dbg_value(i64 8, !353, !DIExpression(), !667)
  %31 = icmp ugt i64 %30, 8, !dbg !669
  br i1 %31, label %if_then.i6.i.i, label %if_else.i5.i.i

if_then.i6.i.i:                                   ; preds = %USize_val_max_ZZ.exit.i.i
  br label %USize_val_max_ZZ.exit7.i.i

if_else.i5.i.i:                                   ; preds = %USize_val_max_ZZ.exit.i.i
  br label %USize_val_max_ZZ.exit7.i.i

USize_val_max_ZZ.exit7.i.i:                       ; preds = %if_else.i5.i.i, %if_then.i6.i.i
  %32 = phi i64 [ %30, %if_then.i6.i.i ], [ 8, %if_else.i5.i.i ]
    #dbg_value(i64 %32, !347, !DIExpression(), !670)
    #dbg_value(i64 32, !353, !DIExpression(), !670)
  %33 = icmp ugt i64 %32, 32, !dbg !672
  br i1 %33, label %if_then.i9.i.i, label %if_else.i8.i.i

if_then.i9.i.i:                                   ; preds = %USize_val_max_ZZ.exit7.i.i
  br label %USize_val_max_ZZ.exit10.i.i

if_else.i8.i.i:                                   ; preds = %USize_val_max_ZZ.exit7.i.i
  br label %USize_val_max_ZZ.exit10.i.i

USize_val_max_ZZ.exit10.i.i:                      ; preds = %if_else.i8.i.i, %if_then.i9.i.i
  %34 = phi i64 [ %32, %if_then.i9.i.i ], [ 32, %if_else.i8.i.i ]
  %35 = getelementptr inbounds nuw i8, ptr %11, i64 16, !dbg !673
  store i64 %34, ptr %35, align 8, !dbg !673
  %36 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %37 = load i64, ptr %36, align 8
  %38 = getelementptr inbounds nuw i8, ptr %11, i64 24
  %39 = load ptr, ptr %38, align 8
  %40 = call ptr @pony_ctx(), !dbg !674
  %41 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %40, ptr %39, i64 %34, i64 %37), !dbg !674
  %42 = getelementptr inbounds nuw i8, ptr %11, i64 24, !dbg !675
  store ptr %41, ptr %42, align 8, !dbg !675
  br label %Array_U8_val_ref_undefined_U8_val_Zo.exit

if_else.i.i:                                      ; preds = %while_body
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !676)
  br label %Array_U8_val_ref_undefined_U8_val_Zo.exit

Array_U8_val_ref_undefined_U8_val_Zo.exit:        ; preds = %USize_val_max_ZZ.exit10.i.i, %if_else.i.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !679)
  %43 = getelementptr inbounds nuw i8, ptr %11, i64 8, !dbg !681
  store i64 %10, ptr %43, align 8, !dbg !681
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !682)
    #dbg_value(ptr %11, !605, !DIExpression(), !617)
    #dbg_value(ptr %11, !684, !DIExpression(), !690)
    #dbg_value(i64 0, !692, !DIExpression(), !690)
  %44 = getelementptr inbounds nuw i8, ptr %11, i64 24
  %45 = load ptr, ptr %44, align 8
    #dbg_value(ptr %11, !693, !DIExpression(), !699)
  %46 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %47 = load i64, ptr %46, align 8
  %48 = call i64 @pony_os_stdin_read(ptr %45, i64 %47), !dbg !701
    #dbg_value(i64 %48, !610, !DIExpression(), !617)
  br label %case_pattern2

case_pattern2:                                    ; preds = %Array_U8_val_ref_undefined_U8_val_Zo.exit
  %49 = icmp eq i64 %48, -1
  br i1 %49, label %pattern_continue6, label %case_pattern5

pattern_continue6:                                ; preds = %case_pattern2
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !702)
  ret i1 true, !dbg !707

case_pattern5:                                    ; preds = %case_pattern2
  %50 = icmp eq i64 %48, 0
  br i1 %50, label %pattern_continue8, label %case_pattern7

pattern_continue8:                                ; preds = %case_pattern5
    #dbg_value(ptr %this, !708, !DIExpression(), !712)
  %51 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !715
  %52 = load ptr, ptr %51, align 8, !dbg !715
  %53 = icmp eq ptr %52, null, !dbg !717
  br i1 %53, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %pattern_continue8
  %54 = getelementptr inbounds nuw i8, ptr %this, i64 320
  %55 = load ptr, ptr %54, align 8
  call void @pony_asio_event_unsubscribe(ptr %55), !dbg !718
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !720)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !722)
  %56 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !724
  store ptr null, ptr %56, align 8, !dbg !724
  br label %Stdin_ref__close_event_o.exit

if_else.i:                                        ; preds = %pattern_continue8
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !725)
  br label %Stdin_ref__close_event_o.exit

Stdin_ref__close_event_o.exit:                    ; preds = %if_then.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !728)
  %57 = load ptr, ptr %2, align 8
  %58 = getelementptr inbounds nuw i8, ptr %57, i64 104
  %59 = load ptr, ptr %58, align 8
  %60 = call fastcc ptr %59(ptr nonnull %2), !dbg !730
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !731)
  %61 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !733
  store ptr @None_Inst, ptr %61, align 8, !dbg !733
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !734)
  ret i1 false, !dbg !737

case_pattern7:                                    ; preds = %case_pattern5
  %62 = icmp eq i64 %48, -2
  br i1 %62, label %pattern_continue9, label %match_else4

pattern_continue9:                                ; preds = %case_pattern7
    #dbg_value(ptr %this, !708, !DIExpression(), !738)
  %63 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !741
  %64 = load ptr, ptr %63, align 8, !dbg !741
  %65 = icmp eq ptr %64, null, !dbg !742
  br i1 %65, label %if_else.i36, label %if_then.i35

if_then.i35:                                      ; preds = %pattern_continue9
  %66 = getelementptr inbounds nuw i8, ptr %this, i64 320
  %67 = load ptr, ptr %66, align 8
  call void @pony_asio_event_unsubscribe(ptr %67), !dbg !743
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !744)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !746)
  %68 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !748
  store ptr null, ptr %68, align 8, !dbg !748
  br label %Stdin_ref__close_event_o.exit37

if_else.i36:                                      ; preds = %pattern_continue9
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !749)
  br label %Stdin_ref__close_event_o.exit37

Stdin_ref__close_event_o.exit37:                  ; preds = %if_then.i35, %if_else.i36
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !751)
  %69 = load ptr, ptr %2, align 8
  %70 = getelementptr inbounds nuw i8, ptr %69, i64 96
  %71 = load ptr, ptr %70, align 8
  %72 = call fastcc ptr %71(ptr nonnull %2), !dbg !753
  %73 = load ptr, ptr %2, align 8
  %74 = getelementptr inbounds nuw i8, ptr %73, i64 104
  %75 = load ptr, ptr %74, align 8
  %76 = call fastcc ptr %75(ptr nonnull %2), !dbg !754
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !755)
  %77 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !757
  store ptr @None_Inst, ptr %77, align 8, !dbg !757
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !758)
  ret i1 false, !dbg !761

match_else4:                                      ; preds = %case_pattern7
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !762)
  br label %match_post3

match_post3:                                      ; preds = %match_else4
    #dbg_value(ptr %11, !766, !DIExpression(), !770)
    #dbg_value(i64 %48, !772, !DIExpression(), !770)
  %78 = getelementptr inbounds nuw i8, ptr %11, i64 8
  %79 = load i64, ptr %78, align 8
    #dbg_value(i64 %79, !336, !DIExpression(), !773)
    #dbg_value(i64 %48, !344, !DIExpression(), !773)
  %80 = icmp ult i64 %79, %48, !dbg !775
  br i1 %80, label %if_then.i.i39, label %if_else.i.i38

if_then.i.i39:                                    ; preds = %match_post3
  br label %Array_U8_val_ref_truncate_Zo.exit

if_else.i.i38:                                    ; preds = %match_post3
  br label %Array_U8_val_ref_truncate_Zo.exit

Array_U8_val_ref_truncate_Zo.exit:                ; preds = %if_then.i.i39, %if_else.i.i38
  %81 = phi i64 [ %79, %if_then.i.i39 ], [ %48, %if_else.i.i38 ]
  %82 = getelementptr inbounds nuw i8, ptr %11, i64 8, !dbg !776
  store i64 %81, ptr %82, align 8, !dbg !776
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !777)
  %83 = load ptr, ptr %2, align 8
  %VTABLE12 = getelementptr inbounds nuw i8, ptr %83, i64 88
  %84 = load ptr, ptr %VTABLE12, align 8
  %85 = call fastcc ptr %84(ptr nonnull %2, ptr nonnull %11), !dbg !779
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %Array_U8_val_ref_truncate_Zo.exit
  unreachable

if_else:                                          ; preds = %Array_U8_val_ref_truncate_Zo.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !780)
  br label %if_post

if_post:                                          ; preds = %if_else
  %86 = add i64 %sum.0, %48, !dbg !784
    #dbg_value(i64 %86, !601, !DIExpression(), !616)
  %87 = icmp ugt i64 %86, 4096
  br i1 %87, label %if_then13, label %if_else14

if_then13:                                        ; preds = %if_post
  %88 = getelementptr inbounds nuw i8, ptr %this, i64 328
  %89 = load i8, ptr %88, align 1
  %90 = trunc i8 %89 to i1
  br i1 %90, label %if_then16, label %if_else17

if_then16:                                        ; preds = %if_then13
  %91 = call ptr @pony_alloc_msg(i32 0, i32 4), !dbg !785, !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr nonnull %this, ptr %91, ptr %91, i1 true), !dbg !785, !pony.msgsend !4
  br label %if_post18

if_else17:                                        ; preds = %if_then13
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !790)
  br label %if_post18

if_post18:                                        ; preds = %if_else17, %if_then16
  br label %while_else, !dbg !793

if_else14:                                        ; preds = %if_post
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !794)
  br label %if_post15

if_post15:                                        ; preds = %if_else14
  br i1 true, label %while_body, label %while_post

while_else:                                       ; preds = %if_post18, %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !797)
  br label %while_post

while_post:                                       ; preds = %while_else, %if_post15
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !800)
  br label %try_post

try_else:                                         ; preds = %match_else
    #dbg_value(ptr %this, !708, !DIExpression(), !803)
  %92 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !806
  %93 = load ptr, ptr %92, align 8, !dbg !806
  %94 = icmp eq ptr %93, null, !dbg !807
  br i1 %94, label %if_else.i41, label %if_then.i40

if_then.i40:                                      ; preds = %try_else
  %95 = getelementptr inbounds nuw i8, ptr %this, i64 320
  %96 = load ptr, ptr %95, align 8
  call void @pony_asio_event_unsubscribe(ptr %96), !dbg !808
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !809)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !811)
  %97 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !813
  store ptr null, ptr %97, align 8, !dbg !813
  br label %Stdin_ref__close_event_o.exit42

if_else.i41:                                      ; preds = %try_else
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !814)
  br label %Stdin_ref__close_event_o.exit42

Stdin_ref__close_event_o.exit42:                  ; preds = %if_then.i40, %if_else.i41
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !816)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !818)
  br label %try_post

try_post:                                         ; preds = %Stdin_ref__close_event_o.exit42, %while_post
  ret i1 %.not, !dbg !821
}

define fastcc ptr @Stdin_tag__read_again_o__send(ptr dereferenceable(336) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 4), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Stdin_tag__read_again_o(ptr dereferenceable(336) %this) unnamed_addr #4 !dbg !90 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !89, !DIExpression(), !95)
  %0 = call fastcc i1 @Stdin_ref__read_b(ptr nonnull %this), !dbg !96
  ret void
}

define fastcc ptr @Stdin_ref__close_event_o(ptr dereferenceable(336) %this) unnamed_addr #4 !dbg !709 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !708, !DIExpression(), !822)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !823
  %1 = load ptr, ptr %0, align 8, !dbg !823
  %2 = icmp eq ptr %1, null, !dbg !824
  br i1 %2, label %if_else, label %if_then

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 320
  %4 = load ptr, ptr %3, align 8
  call void @pony_asio_event_unsubscribe(ptr %4), !dbg !825
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !826)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !828)
  %5 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !830
  store ptr null, ptr %5, align 8, !dbg !830
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !831)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !833)
  ret ptr @None_Inst, !dbg !835
}

define fastcc ptr @Stdin_tag__event_notify_topIpIo__send(ptr dereferenceable(336) %0, ptr %1, i32 %2, i32 %3) unnamed_addr #4 !pony.abi !4 {
entry:
  %4 = call ptr @pony_ctx()
  %5 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 16
  store ptr %1, ptr %6, align 8
  %7 = getelementptr inbounds nuw i8, ptr %5, i64 24
  store i32 %2, ptr %7, align 4
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 28
  store i32 %3, ptr %8, align 4
  call void @pony_gc_send(ptr %4, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %4, ptr %1, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  call void @pony_send_done(ptr %4), !pony.msgsend !4
  call void @pony_sendv(ptr %4, ptr nonnull %0, ptr %5, ptr %5, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Stdin_tag__event_notify_topIpIo(ptr dereferenceable(336) %this, ptr %event, i32 %flags, i32 %arg) unnamed_addr #4 !dbg !836 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !841, !DIExpression(), !850)
    #dbg_value(ptr %event, !851, !DIExpression(), !850)
    #dbg_value(i32 %flags, !852, !DIExpression(), !850)
    #dbg_value(i32 %arg, !853, !DIExpression(), !850)
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !854)
    #dbg_value(ptr @AsioEvent_Inst, !856, !DIExpression(), !862)
    #dbg_value(i32 %flags, !864, !DIExpression(), !862)
  %0 = icmp eq i32 %flags, 0, !dbg !865
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  call void @pony_asio_event_destroy(ptr %event), !dbg !866
  br label %if_post

if_else:                                          ; preds = %entry
  br label %sc_left, !dbg !868

sc_left:                                          ; preds = %if_else
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !868
  %2 = load ptr, ptr %1, align 8, !dbg !868
  %3 = icmp eq ptr %2, %event, !dbg !869
  br i1 %3, label %sc_right, label %sc_post

sc_right:                                         ; preds = %sc_left
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !870)
    #dbg_value(ptr @AsioEvent_Inst, !872, !DIExpression(), !876)
    #dbg_value(i32 %flags, !878, !DIExpression(), !876)
  %4 = and i32 %flags, 16
  %5 = icmp ne i32 %4, 0
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left
  %6 = phi i1 [ false, %sc_left ], [ %5, %sc_right ]
  br i1 %6, label %if_then5, label %if_else6

if_then5:                                         ; preds = %sc_post
    #dbg_value(ptr %this, !708, !DIExpression(), !879)
  %7 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !881
  %8 = load ptr, ptr %7, align 8, !dbg !881
  %9 = icmp eq ptr %8, null, !dbg !882
  br i1 %9, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %if_then5
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 320
  %11 = load ptr, ptr %10, align 8
  call void @pony_asio_event_unsubscribe(ptr %11), !dbg !883
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !884)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !886)
  %12 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !888
  store ptr null, ptr %12, align 8, !dbg !888
  br label %Stdin_ref__close_event_o.exit

if_else.i:                                        ; preds = %if_then5
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !889)
  br label %Stdin_ref__close_event_o.exit

Stdin_ref__close_event_o.exit:                    ; preds = %if_then.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !891)
  %13 = getelementptr inbounds nuw i8, ptr %this, i64 304
  %14 = load ptr, ptr %13, align 8
  br label %case_pattern

case_pattern:                                     ; preds = %Stdin_ref__close_event_o.exit
  %15 = load ptr, ptr %14, align 8
  %16 = icmp slt ptr %14, null
  br i1 %16, label %ptf_tagged, label %ptf_heap

ptf_tagged:                                       ; preds = %case_pattern
  br label %ptf_merge

ptf_heap:                                         ; preds = %case_pattern
  br label %ptf_merge

ptf_merge:                                        ; preds = %ptf_heap, %ptf_tagged
  %17 = getelementptr inbounds nuw i8, ptr %15, i64 72
  %18 = load ptr, ptr %17, align 8
  %19 = load i64, ptr %18, align 8
  %20 = and i64 %19, 32
  %.not = icmp eq i64 %20, 0
  br i1 %.not, label %match_else, label %pattern_continue

pattern_continue:                                 ; preds = %ptf_merge
    #dbg_value(ptr %14, !842, !DIExpression(), !893)
  br label %match_post

match_else:                                       ; preds = %ptf_merge
  br label %try_else, !dbg !894

match_post:                                       ; preds = %pattern_continue
    #dbg_value(ptr %14, !849, !DIExpression(), !897)
  %21 = load ptr, ptr %14, align 8
  %22 = getelementptr inbounds nuw i8, ptr %21, i64 96
  %23 = load ptr, ptr %22, align 8
  %24 = call fastcc ptr %23(ptr nonnull %14), !dbg !898
  %25 = load ptr, ptr %14, align 8
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 104
  %27 = load ptr, ptr %26, align 8
  %28 = call fastcc ptr %27(ptr nonnull %14), !dbg !899
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !900)
  br label %try_post

try_else:                                         ; preds = %match_else
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !903)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !906)
  br label %try_post

try_post:                                         ; preds = %try_else, %match_post
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !909)
  %29 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !911
  store ptr @None_Inst, ptr %29, align 8, !dbg !911
  br label %if_post7

if_else6:                                         ; preds = %sc_post
  br label %sc_left9, !dbg !912

sc_left9:                                         ; preds = %if_else6
  %30 = getelementptr inbounds nuw i8, ptr %this, i64 320, !dbg !912
  %31 = load ptr, ptr %30, align 8, !dbg !912
  %32 = icmp eq ptr %31, %event, !dbg !914
  br i1 %32, label %sc_right10, label %sc_post11

sc_right10:                                       ; preds = %sc_left9
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !915)
    #dbg_value(ptr @AsioEvent_Inst, !917, !DIExpression(), !921)
    #dbg_value(i32 %flags, !923, !DIExpression(), !921)
  %33 = trunc i32 %flags to i1
  br label %sc_post11

sc_post11:                                        ; preds = %sc_right10, %sc_left9
  %34 = phi i1 [ false, %sc_left9 ], [ %33, %sc_right10 ]
  br i1 %34, label %if_then12, label %if_else13

if_then12:                                        ; preds = %sc_post11
  %35 = call fastcc i1 @Stdin_ref__read_b(ptr nonnull %this), !dbg !924
  br label %if_post14

if_else13:                                        ; preds = %sc_post11
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !926)
  br label %if_post14

if_post14:                                        ; preds = %if_else13, %if_then12
  br label %if_post7

if_post7:                                         ; preds = %if_post14, %try_post
  br label %if_post

if_post:                                          ; preds = %if_post7, %if_then
  ret void
}

define fastcc noalias align 32 dereferenceable(336) ptr @Stdin_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Stdin_Desc, i1 false)
  ret ptr %1
}

define fastcc i64 @I32_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i32 [ %3, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = zext i32 %6 to i64
  ret i64 %7
}

define fastcc i32 @I32_val_create_pii(i32 %this, i32 %value) unnamed_addr #4 !dbg !929 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !936, !DIExpression(), !938)
    #dbg_value(i32 %value, !939, !DIExpression(), !938)
  ret i32 %value, !dbg !940
}

define fastcc i64 @U64_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  ret i64 %2
}

define fastcc i1 @U64_val_eq_Wb(i64 %this, i64 %y) unnamed_addr #4 !dbg !941 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !947, !DIExpression(), !949)
    #dbg_value(i64 %y, !950, !DIExpression(), !949)
  %0 = icmp eq i64 %this, %y, !dbg !951
  ret i1 %0, !dbg !951
}

define fastcc i1 @U64_box_eq_Wb(i64 %this, i64 %y) unnamed_addr #4 !dbg !952 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !955, !DIExpression(), !956)
    #dbg_value(i64 %y, !957, !DIExpression(), !956)
  %0 = icmp eq i64 %this, %y, !dbg !958
  ret i1 %0, !dbg !958
}

define fastcc i64 @U64_val_create_pWW(i64 %this, i64 %value) unnamed_addr #4 !dbg !959 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !964, !DIExpression(), !965)
    #dbg_value(i64 %value, !966, !DIExpression(), !965)
  ret i64 %value, !dbg !967
}

define fastcc i64 @USize_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  ret i64 %2
}

define fastcc i64 @USize_val_bitwidth_Z(i64 %this) unnamed_addr #4 !dbg !454 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !453, !DIExpression(), !968)
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i64 64, !dbg !969
}

define fastcc i64 @USize_box_bitwidth_Z(i64 %this) unnamed_addr #4 !dbg !970 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !973, !DIExpression(), !974)
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i64 64, !dbg !975
}

define fastcc i64 @USize_box_sub_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !976 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !979, !DIExpression(), !980)
    #dbg_value(i64 %y, !981, !DIExpression(), !980)
  %0 = sub i64 %this, %y, !dbg !982
  ret i64 %0, !dbg !982
}

define fastcc i64 @USize_val_sub_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !983 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !986, !DIExpression(), !987)
    #dbg_value(i64 %y, !988, !DIExpression(), !987)
  %0 = sub i64 %this, %y, !dbg !989
  ret i64 %0, !dbg !989
}

define fastcc i64 @USize_val_shl_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !990 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !993, !DIExpression(), !994)
    #dbg_value(i64 %y, !995, !DIExpression(), !994)
  %0 = call i64 @llvm.umin.i64(i64 %y, i64 63), !dbg !996
  %1 = shl i64 %this, %0, !dbg !996
  ret i64 %1, !dbg !996
}

define fastcc i64 @USize_box_shl_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !997 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1000, !DIExpression(), !1001)
    #dbg_value(i64 %y, !1002, !DIExpression(), !1001)
  %0 = call i64 @llvm.umin.i64(i64 %y, i64 63), !dbg !1003
  %1 = shl i64 %this, %0, !dbg !1003
  ret i64 %1, !dbg !1003
}

define fastcc i1 @USize_val_ne_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1004 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1009, !DIExpression(), !1010)
    #dbg_value(i64 %y, !1011, !DIExpression(), !1010)
  %0 = icmp ne i64 %this, %y, !dbg !1012
  ret i1 %0, !dbg !1012
}

define fastcc i1 @USize_box_ne_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1013 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1016, !DIExpression(), !1017)
    #dbg_value(i64 %y, !1018, !DIExpression(), !1017)
  %0 = icmp ne i64 %this, %y, !dbg !1019
  ret i1 %0, !dbg !1019
}

define fastcc i64 @USize_val_max_value_Z(i64 %this) unnamed_addr #4 !dbg !328 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !327, !DIExpression(), !1020)
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i64 -1, !dbg !1021
}

define fastcc i64 @USize_val_add_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !1022 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1025, !DIExpression(), !1026)
    #dbg_value(i64 %y, !1027, !DIExpression(), !1026)
  %0 = add i64 %this, %y, !dbg !1028
  ret i64 %0, !dbg !1028
}

define fastcc i64 @USize_box_add_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !1029 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1032, !DIExpression(), !1033)
    #dbg_value(i64 %y, !1034, !DIExpression(), !1033)
  %0 = add i64 %this, %y, !dbg !1035
  ret i64 %0, !dbg !1035
}

define fastcc i64 @USize_val_next_pow2_Z(i64 %this) unnamed_addr #4 !dbg !433 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !432, !DIExpression(), !1036)
  %0 = add i64 %this, -1, !dbg !1037
    #dbg_value(i64 %0, !440, !DIExpression(), !1038)
  %1 = call fastcc i64 @USize_val_u64_W(i64 %0), !dbg !1040
  %2 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %1, i1 false), !dbg !1041
  %3 = call fastcc i64 @U64_val_usize_Z(i64 %2), !dbg !1042
    #dbg_value(i64 %3, !436, !DIExpression(), !1036)
  %4 = icmp eq i64 %3, 0, !dbg !1043
  br i1 %4, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i64 %this, !453, !DIExpression(), !1044)
  %5 = sub i64 64, %3
  %6 = call i64 @llvm.umin.i64(i64 %5, i64 63)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %7 = phi i64 [ 0, %if_then ], [ %6, %if_else ]
  %8 = shl nuw i64 1, %7
  ret i64 %8, !dbg !1046
}

define fastcc i64 @USize_box_next_pow2_Z(i64 %this) unnamed_addr #4 !dbg !1047 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1050, !DIExpression(), !1052)
  %0 = add i64 %this, -1, !dbg !1053
    #dbg_value(i64 %0, !440, !DIExpression(), !1054)
  %1 = call fastcc i64 @USize_val_u64_W(i64 %0), !dbg !1056
  %2 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %1, i1 false), !dbg !1057
  %3 = call fastcc i64 @U64_val_usize_Z(i64 %2), !dbg !1058
    #dbg_value(i64 %3, !1051, !DIExpression(), !1052)
  %4 = icmp eq i64 %3, 0, !dbg !1059
  br i1 %4, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i64 %this, !453, !DIExpression(), !1061)
  %5 = sub i64 64, %3
  %6 = call i64 @llvm.umin.i64(i64 %5, i64 63)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %7 = phi i64 [ 0, %if_then ], [ %6, %if_else ]
  %8 = shl nuw i64 1, %7
  ret i64 %8, !dbg !1064
}

define fastcc i1 @USize_box_eq_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1065 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1068, !DIExpression(), !1069)
    #dbg_value(i64 %y, !1070, !DIExpression(), !1069)
  %0 = icmp eq i64 %this, %y, !dbg !1071
  ret i1 %0, !dbg !1071
}

define fastcc i1 @USize_val_eq_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1072 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1075, !DIExpression(), !1076)
    #dbg_value(i64 %y, !1077, !DIExpression(), !1076)
  %0 = icmp eq i64 %this, %y, !dbg !1078
  ret i1 %0, !dbg !1078
}

define fastcc i64 @USize_box_clz_Z(i64 %this) unnamed_addr #4 !dbg !1079 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1082, !DIExpression(), !1083)
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  %0 = call fastcc i64 @USize_val_u64_W(i64 %this), !dbg !1084
  %1 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %0, i1 false), !dbg !1087
  %2 = call fastcc i64 @U64_val_usize_Z(i64 %1), !dbg !1088
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %3 = phi i64 [ poison, %if_then ], [ %2, %if_else ]
  ret i64 %3, !dbg !1089
}

define fastcc i64 @USize_val_clz_Z(i64 %this) unnamed_addr #4 !dbg !441 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !440, !DIExpression(), !1090)
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  %0 = call fastcc i64 @USize_val_u64_W(i64 %this), !dbg !1091
  %1 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %0, i1 false), !dbg !1092
  %2 = call fastcc i64 @U64_val_usize_Z(i64 %1), !dbg !1093
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %3 = phi i64 [ poison, %if_then ], [ %2, %if_else ]
  ret i64 %3, !dbg !1094
}

define fastcc i64 @USize_val_max_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !348 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !347, !DIExpression(), !1095)
    #dbg_value(i64 %y, !353, !DIExpression(), !1095)
  %0 = icmp ugt i64 %this, %y, !dbg !1096
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i64 [ %this, %if_then ], [ %y, %if_else ]
  ret i64 %1, !dbg !1097
}

define fastcc i64 @USize_box_max_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !1098 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1101, !DIExpression(), !1102)
    #dbg_value(i64 %y, !1103, !DIExpression(), !1102)
  %0 = icmp ugt i64 %this, %y, !dbg !1104
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i64 [ %this, %if_then ], [ %y, %if_else ]
  ret i64 %1, !dbg !1106
}

define fastcc i64 @USize_val_neg_Z(i64 %this) unnamed_addr #4 !dbg !1107 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1110, !DIExpression(), !1111)
  %0 = sub i64 0, %this, !dbg !1112
  ret i64 %0, !dbg !1112
}

define fastcc i64 @USize_box_neg_Z(i64 %this) unnamed_addr #4 !dbg !1113 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1116, !DIExpression(), !1117)
  %0 = sub i64 0, %this, !dbg !1118
  ret i64 %0, !dbg !1118
}

define fastcc i64 @USize_val_min_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !337 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !336, !DIExpression(), !1119)
    #dbg_value(i64 %y, !344, !DIExpression(), !1119)
  %0 = icmp ult i64 %this, %y, !dbg !1120
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i64 [ %this, %if_then ], [ %y, %if_else ]
  ret i64 %1, !dbg !1121
}

define fastcc i64 @USize_box_min_ZZ(i64 %this, i64 %y) unnamed_addr #4 !dbg !1122 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1125, !DIExpression(), !1126)
    #dbg_value(i64 %y, !1127, !DIExpression(), !1126)
  %0 = icmp ult i64 %this, %y, !dbg !1128
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i64 [ %this, %if_then ], [ %y, %if_else ]
  ret i64 %1, !dbg !1130
}

define fastcc i64 @USize_val_create_pZZ(i64 %this, i64 %value) unnamed_addr #4 !dbg !1131 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1134, !DIExpression(), !1135)
    #dbg_value(i64 %value, !1136, !DIExpression(), !1135)
  ret i64 %value, !dbg !1137
}

define fastcc i1 @USize_val_lt_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1138 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1141, !DIExpression(), !1142)
    #dbg_value(i64 %y, !1143, !DIExpression(), !1142)
  %0 = icmp ult i64 %this, %y, !dbg !1144
  ret i1 %0, !dbg !1144
}

define fastcc i1 @USize_box_lt_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1145 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1148, !DIExpression(), !1149)
    #dbg_value(i64 %y, !1150, !DIExpression(), !1149)
  %0 = icmp ult i64 %this, %y, !dbg !1151
  ret i1 %0, !dbg !1151
}

define fastcc i1 @USize_val_gt_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1152 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1155, !DIExpression(), !1156)
    #dbg_value(i64 %y, !1157, !DIExpression(), !1156)
  %0 = icmp ugt i64 %this, %y, !dbg !1158
  ret i1 %0, !dbg !1158
}

define fastcc i1 @USize_box_gt_Zb(i64 %this, i64 %y) unnamed_addr #4 !dbg !1159 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !1162, !DIExpression(), !1163)
    #dbg_value(i64 %y, !1164, !DIExpression(), !1163)
  %0 = icmp ugt i64 %this, %y, !dbg !1165
  ret i1 %0, !dbg !1165
}

define fastcc noalias align 32 dereferenceable(112) ptr @RuntimeOptions_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 2)
  ret ptr %1
}

define fastcc i64 @Array_U8_val_ref_size_Z(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !694 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !693, !DIExpression(), !1166)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %1 = load i64, ptr %0, align 8
  ret i64 %1, !dbg !1167
}

define fastcc i64 @Array_U8_val_val_size_Z(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !1168 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1171, !DIExpression(), !1172)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %1 = load i64, ptr %0, align 8
  ret i64 %1, !dbg !1173
}

define fastcc i64 @Array_U8_val_box_size_Z(ptr dereferenceable(32) %this) unnamed_addr #4 !dbg !1174 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1177, !DIExpression(), !1178)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %1 = load i64, ptr %0, align 8
  ret i64 %1, !dbg !1179
}

define fastcc ptr @Array_U8_val_ref_reserve_Zo(ptr dereferenceable(32) %this, i64 %len) unnamed_addr #4 !dbg !644 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !643, !DIExpression(), !1180)
    #dbg_value(i64 %len, !649, !DIExpression(), !1180)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1181
  %1 = load i64, ptr %0, align 8, !dbg !1181
  %2 = icmp ult i64 %1, %len, !dbg !1181
  br i1 %2, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %4 = load ptr, ptr %3, align 8
    #dbg_value(i64 %len, !432, !DIExpression(), !1182)
  %5 = add i64 %len, -1, !dbg !1184
    #dbg_value(i64 %5, !440, !DIExpression(), !1185)
  %6 = call fastcc i64 @USize_val_u64_W(i64 %5), !dbg !1187
  %7 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %6, i1 false), !dbg !1188
  %8 = call fastcc i64 @U64_val_usize_Z(i64 %7), !dbg !1189
    #dbg_value(i64 %8, !436, !DIExpression(), !1182)
  %9 = icmp eq i64 %8, 0, !dbg !1190
  br i1 %9, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i64 %len, !453, !DIExpression(), !1191)
  %10 = sub i64 64, %8
  %11 = call i64 @llvm.umin.i64(i64 %10, i64 63)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %12 = phi i64 [ 0, %if_then.i ], [ %11, %if_else.i ]
  %13 = shl nuw i64 1, %12
    #dbg_value(i64 %13, !347, !DIExpression(), !1193)
    #dbg_value(i64 %len, !353, !DIExpression(), !1193)
  %14 = icmp ugt i64 %13, %len, !dbg !1195
  br i1 %14, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %15 = phi i64 [ %13, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i64 %15, !347, !DIExpression(), !1196)
    #dbg_value(i64 8, !353, !DIExpression(), !1196)
  %16 = icmp ugt i64 %15, 8, !dbg !1198
  br i1 %16, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %17 = phi i64 [ %15, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i64 %17, !347, !DIExpression(), !1199)
    #dbg_value(i64 32, !353, !DIExpression(), !1199)
  %18 = icmp ugt i64 %17, 32, !dbg !1201
  br i1 %18, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %19 = phi i64 [ %17, %if_then.i9 ], [ 32, %if_else.i8 ]
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1202
  store i64 %19, ptr %20, align 8, !dbg !1202
  %21 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %24 = load ptr, ptr %23, align 8
  %25 = call ptr @pony_ctx(), !dbg !1203
  %26 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %25, ptr %24, i64 %19, i64 %22), !dbg !1203
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !1204
  store ptr %26, ptr %27, align 8, !dbg !1204
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1205)
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1207)
  ret ptr @None_Inst, !dbg !1209
}

define fastcc ptr @Array_U8_val_box_cpointer_Zo(ptr dereferenceable(32) %this, i64 %offset) unnamed_addr #4 !dbg !1210 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1213, !DIExpression(), !1214)
    #dbg_value(i64 %offset, !1215, !DIExpression(), !1214)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 %offset, !dbg !1216
  ret ptr %2, !dbg !1216
}

define fastcc ptr @Array_U8_val_val_cpointer_Zo(ptr dereferenceable(32) %this, i64 %offset) unnamed_addr #4 !dbg !1217 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1220, !DIExpression(), !1221)
    #dbg_value(i64 %offset, !1222, !DIExpression(), !1221)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 %offset, !dbg !1223
  ret ptr %2, !dbg !1223
}

define fastcc ptr @Array_U8_val_ref_cpointer_Zo(ptr dereferenceable(32) %this, i64 %offset) unnamed_addr #4 !dbg !685 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !684, !DIExpression(), !1224)
    #dbg_value(i64 %offset, !692, !DIExpression(), !1224)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %1 = load ptr, ptr %0, align 8
  %2 = getelementptr inbounds i8, ptr %1, i64 %offset, !dbg !1225
  ret ptr %2, !dbg !1225
}

define fastcc ptr @Array_U8_val_ref_undefined_U8_val_Zo(ptr dereferenceable(32) %this, i64 %len) unnamed_addr #4 !dbg !635 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !634, !DIExpression(), !1226)
    #dbg_value(i64 %len, !642, !DIExpression(), !1226)
    #dbg_value(ptr %this, !643, !DIExpression(), !1227)
    #dbg_value(i64 %len, !649, !DIExpression(), !1227)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1229
  %1 = load i64, ptr %0, align 8, !dbg !1229
  %2 = icmp ult i64 %1, %len, !dbg !1229
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %4 = load ptr, ptr %3, align 8
    #dbg_value(i64 %len, !432, !DIExpression(), !1230)
  %5 = add i64 %len, -1, !dbg !1232
    #dbg_value(i64 %5, !440, !DIExpression(), !1233)
  %6 = call fastcc i64 @USize_val_u64_W(i64 %5), !dbg !1235
  %7 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %6, i1 false), !dbg !1236
  %8 = call fastcc i64 @U64_val_usize_Z(i64 %7), !dbg !1237
    #dbg_value(i64 %8, !436, !DIExpression(), !1230)
  %9 = icmp eq i64 %8, 0, !dbg !1238
  br i1 %9, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %if_then.i
  br label %USize_val_next_pow2_Z.exit.i

if_else.i.i:                                      ; preds = %if_then.i
    #dbg_value(i64 %len, !453, !DIExpression(), !1239)
  %10 = sub i64 64, %8
  %11 = call i64 @llvm.umin.i64(i64 %10, i64 63)
  br label %USize_val_next_pow2_Z.exit.i

USize_val_next_pow2_Z.exit.i:                     ; preds = %if_else.i.i, %if_then.i.i
  %12 = phi i64 [ 0, %if_then.i.i ], [ %11, %if_else.i.i ]
  %13 = shl nuw i64 1, %12
    #dbg_value(i64 %13, !347, !DIExpression(), !1241)
    #dbg_value(i64 %len, !353, !DIExpression(), !1241)
  %14 = icmp ugt i64 %13, %len, !dbg !1243
  br i1 %14, label %if_then.i4.i, label %if_else.i3.i

if_then.i4.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

if_else.i3.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

USize_val_max_ZZ.exit.i:                          ; preds = %if_else.i3.i, %if_then.i4.i
  %15 = phi i64 [ %13, %if_then.i4.i ], [ %len, %if_else.i3.i ]
    #dbg_value(i64 %15, !347, !DIExpression(), !1244)
    #dbg_value(i64 8, !353, !DIExpression(), !1244)
  %16 = icmp ugt i64 %15, 8, !dbg !1246
  br i1 %16, label %if_then.i6.i, label %if_else.i5.i

if_then.i6.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

if_else.i5.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

USize_val_max_ZZ.exit7.i:                         ; preds = %if_else.i5.i, %if_then.i6.i
  %17 = phi i64 [ %15, %if_then.i6.i ], [ 8, %if_else.i5.i ]
    #dbg_value(i64 %17, !347, !DIExpression(), !1247)
    #dbg_value(i64 32, !353, !DIExpression(), !1247)
  %18 = icmp ugt i64 %17, 32, !dbg !1249
  br i1 %18, label %if_then.i9.i, label %if_else.i8.i

if_then.i9.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

if_else.i8.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

USize_val_max_ZZ.exit10.i:                        ; preds = %if_else.i8.i, %if_then.i9.i
  %19 = phi i64 [ %17, %if_then.i9.i ], [ 32, %if_else.i8.i ]
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1250
  store i64 %19, ptr %20, align 8, !dbg !1250
  %21 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %22 = load i64, ptr %21, align 8
  %23 = getelementptr inbounds nuw i8, ptr %this, i64 24
  %24 = load ptr, ptr %23, align 8
  %25 = call ptr @pony_ctx(), !dbg !1251
  %26 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %25, ptr %24, i64 %19, i64 %22), !dbg !1251
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !1252
  store ptr %26, ptr %27, align 8, !dbg !1252
  br label %Array_U8_val_ref_reserve_Zo.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1253)
  br label %Array_U8_val_ref_reserve_Zo.exit

Array_U8_val_ref_reserve_Zo.exit:                 ; preds = %USize_val_max_ZZ.exit10.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1255)
  %28 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !1257
  store i64 %len, ptr %28, align 8, !dbg !1257
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1258)
  ret ptr @None_Inst, !dbg !1260
}

define fastcc void @Array_U8_val_ref_create_pZo(ptr %this, i64 %len) unnamed_addr #4 !dbg !619 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !618, !DIExpression(), !1261)
    #dbg_value(i64 %len, !628, !DIExpression(), !1261)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !1262
  store i64 0, ptr %0, align 8, !dbg !1262
  %.not = icmp eq i64 %len, 0, !dbg !1263
  br i1 %.not, label %if_else, label %if_then

if_then:                                          ; preds = %entry
    #dbg_value(i64 %len, !432, !DIExpression(), !1264)
  %1 = add i64 %len, -1, !dbg !1267
    #dbg_value(i64 %1, !440, !DIExpression(), !1268)
  %2 = call fastcc i64 @USize_val_u64_W(i64 %1), !dbg !1270
  %3 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %2, i1 false), !dbg !1271
  %4 = call fastcc i64 @U64_val_usize_Z(i64 %3), !dbg !1272
    #dbg_value(i64 %4, !436, !DIExpression(), !1264)
  %5 = icmp eq i64 %4, 0, !dbg !1273
  br i1 %5, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i64 %len, !453, !DIExpression(), !1274)
  %6 = sub i64 64, %4
  %7 = call i64 @llvm.umin.i64(i64 %6, i64 63)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %8 = phi i64 [ 0, %if_then.i ], [ %7, %if_else.i ]
  %9 = shl nuw i64 1, %8
    #dbg_value(i64 %9, !347, !DIExpression(), !1276)
    #dbg_value(i64 %len, !353, !DIExpression(), !1276)
  %10 = icmp ugt i64 %9, %len, !dbg !1278
  br i1 %10, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %11 = phi i64 [ %9, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i64 %11, !347, !DIExpression(), !1279)
    #dbg_value(i64 8, !353, !DIExpression(), !1279)
  %12 = icmp ugt i64 %11, 8, !dbg !1281
  br i1 %12, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %13 = phi i64 [ %11, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i64 %13, !347, !DIExpression(), !1282)
    #dbg_value(i64 32, !353, !DIExpression(), !1282)
  %14 = icmp ugt i64 %13, 32, !dbg !1284
  br i1 %14, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %15 = phi i64 [ %13, %if_then.i9 ], [ 32, %if_else.i8 ]
  %16 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1285
  store i64 %15, ptr %16, align 8, !dbg !1285
  %17 = call ptr @pony_ctx(), !dbg !1286
  %18 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %17, i64 %15), !dbg !1286
  %19 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !1287
  store ptr %18, ptr %19, align 8, !dbg !1287
  br label %if_post

if_else:                                          ; preds = %entry
  %20 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1288
  store i64 0, ptr %20, align 8, !dbg !1288
  %21 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !1289
  store ptr null, ptr %21, align 8, !dbg !1289
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
  ret void, !dbg !1290
}

define fastcc ptr @Array_U8_val_ref_truncate_Zo(ptr dereferenceable(32) %this, i64 %len) unnamed_addr #4 !dbg !767 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !766, !DIExpression(), !1291)
    #dbg_value(i64 %len, !772, !DIExpression(), !1291)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %1 = load i64, ptr %0, align 8
    #dbg_value(i64 %1, !336, !DIExpression(), !1292)
    #dbg_value(i64 %len, !344, !DIExpression(), !1292)
  %2 = icmp ult i64 %1, %len, !dbg !1294
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %3 = phi i64 [ %1, %if_then.i ], [ %len, %if_else.i ]
  %4 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !1295
  store i64 %3, ptr %4, align 8, !dbg !1295
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1296)
  ret ptr @None_Inst, !dbg !1298
}

define fastcc noalias align 32 dereferenceable(32) ptr @Array_U8_val_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_U8_val_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc void @Env_ref__create_pIioioo(ptr %this, i32 %argc, ptr %argv, ptr %envp) unnamed_addr #4 !dbg !1299 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !1322, !DIExpression(), !1324)
    #dbg_value(i32 %argc, !1325, !DIExpression(), !1324)
    #dbg_value(ptr %argv, !1326, !DIExpression(), !1324)
    #dbg_value(ptr %envp, !1327, !DIExpression(), !1324)
    #dbg_value(ptr @AmbientAuth_Inst, !187, !DIExpression(), !1328)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1330)
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !1332
  store ptr @AmbientAuth_Inst, ptr %1, align 8, !dbg !1332
  call void @pony_os_stdout_setup(), !dbg !1333
  %2 = call i1 @pony_os_stdin_setup(), !dbg !1334
  %3 = call ptr @pony_create(ptr %0, ptr nonnull @Stdin_Desc, i1 false)
  %4 = zext i1 %2 to i8, !dbg !1335
  %5 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !1335, !pony.msgsend !4
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 16, !dbg !1335
  store i8 %4, ptr %6, align 1, !dbg !1335
  call void @pony_sendv_single(ptr %0, ptr nonnull %3, ptr %5, ptr %5, i1 true), !dbg !1335, !pony.msgsend !4
  %7 = getelementptr inbounds nuw i8, ptr %this, i64 16, !dbg !1336
  store ptr %3, ptr %7, align 8, !dbg !1336
  %8 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  %9 = call ptr @pony_alloc_msg(i32 0, i32 1), !dbg !1337, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %8, ptr %9, ptr %9, i1 true), !dbg !1337, !pony.msgsend !4
  %10 = getelementptr inbounds nuw i8, ptr %this, i64 24, !dbg !1338
  store ptr %8, ptr %10, align 8, !dbg !1338
  %11 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  %12 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !1339, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %11, ptr %12, ptr %12, i1 true), !dbg !1339, !pony.msgsend !4
  %13 = getelementptr inbounds nuw i8, ptr %this, i64 32, !dbg !1340
  store ptr %11, ptr %13, align 8, !dbg !1340
  %14 = call fastcc i64 @U32_val_usize_Z(i32 %argc), !dbg !1341
  %15 = call fastcc ptr @Env_tag__strings_from_pointers_oZo(ptr %this, ptr %argv, i64 %14), !dbg !1342
  %16 = getelementptr inbounds nuw i8, ptr %this, i64 40, !dbg !1343
  store ptr %15, ptr %16, align 8, !dbg !1343
    #dbg_value(ptr %this, !1344, !DIExpression(), !1353)
    #dbg_value(ptr %envp, !1355, !DIExpression(), !1353)
  %17 = icmp eq ptr %envp, null, !dbg !1356
  br i1 %17, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %Env_tag__count_strings_oZ.exit, !dbg !1358

if_else.i:                                        ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1360)
    #dbg_value(i64 0, !1350, !DIExpression(), !1353)
  %18 = load ptr, ptr %envp, align 8, !dbg !1363
    #dbg_value(ptr %18, !1351, !DIExpression(), !1364)
  %19 = icmp eq ptr %18, null, !dbg !1365
  br i1 %19, label %while_else.i, label %while_body.i

while_body.i:                                     ; preds = %while_body.i, %if_else.i
  %i.0.i = phi i64 [ 0, %if_else.i ], [ %20, %while_body.i ]
    #dbg_value(ptr poison, !1351, !DIExpression(), !1364)
    #dbg_value(i64 %i.0.i, !1350, !DIExpression(), !1353)
  %20 = add i64 %i.0.i, 1, !dbg !1366
    #dbg_value(i64 %20, !1350, !DIExpression(), !1353)
  %21 = getelementptr inbounds [8 x i8], ptr %envp, i64 %20, !dbg !1363
  %22 = load ptr, ptr %21, align 8, !dbg !1363
    #dbg_value(ptr %22, !1351, !DIExpression(), !1364)
  %23 = icmp eq ptr %22, null, !dbg !1365
  br i1 %23, label %while_post.i, label %while_body.i

while_else.i:                                     ; preds = %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1368)
  br label %while_post.i

while_post.i:                                     ; preds = %while_else.i, %while_body.i
  %i.1.i = phi i64 [ %20, %while_body.i ], [ 0, %while_else.i ]
    #dbg_value(i64 %i.1.i, !1350, !DIExpression(), !1353)
  br label %Env_tag__count_strings_oZ.exit, !dbg !1371

Env_tag__count_strings_oZ.exit:                   ; preds = %while_post.i, %if_then.i
  %24 = phi i64 [ 0, %if_then.i ], [ %i.1.i, %while_post.i ]
  %25 = call fastcc ptr @Env_tag__strings_from_pointers_oZo(ptr nonnull %this, ptr %envp, i64 %24), !dbg !1372
  %26 = getelementptr inbounds nuw i8, ptr %this, i64 48, !dbg !1373
  store ptr %25, ptr %26, align 8, !dbg !1373
    #dbg_value(ptr @"$0$16_Inst", !175, !DIExpression(), !1374)
  %27 = getelementptr inbounds nuw i8, ptr %this, i64 56, !dbg !1376
  store ptr @"$0$16_Inst", ptr %27, align 8, !dbg !1376
  ret void, !dbg !1376
}

define fastcc i64 @Env_tag__count_strings_oZ(ptr dereferenceable(64) %this, ptr %data) unnamed_addr #4 !dbg !1345 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1344, !DIExpression(), !1377)
    #dbg_value(ptr %data, !1355, !DIExpression(), !1377)
  %0 = icmp eq ptr %data, null, !dbg !1378
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  ret i64 0, !dbg !1379

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1380)
  br label %if_post

if_post:                                          ; preds = %if_else
    #dbg_value(i64 0, !1350, !DIExpression(), !1377)
  br label %while_init

while_init:                                       ; preds = %if_post
  %1 = load ptr, ptr %data, align 8, !dbg !1382
    #dbg_value(ptr %1, !1351, !DIExpression(), !1383)
  %2 = icmp eq ptr %1, null, !dbg !1384
  br i1 %2, label %while_else, label %while_body

while_body:                                       ; preds = %while_body, %while_init
  %i.0 = phi i64 [ 0, %while_init ], [ %3, %while_body ]
    #dbg_value(ptr poison, !1351, !DIExpression(), !1383)
    #dbg_value(i64 %i.0, !1350, !DIExpression(), !1377)
  %3 = add i64 %i.0, 1, !dbg !1385
    #dbg_value(i64 %3, !1350, !DIExpression(), !1377)
  %4 = getelementptr inbounds [8 x i8], ptr %data, i64 %3, !dbg !1382
  %5 = load ptr, ptr %4, align 8, !dbg !1382
    #dbg_value(ptr %5, !1351, !DIExpression(), !1383)
  %6 = icmp eq ptr %5, null, !dbg !1384
  br i1 %6, label %while_post, label %while_body

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1386)
  br label %while_post

while_post:                                       ; preds = %while_else, %while_body
  %i.1 = phi i64 [ %3, %while_body ], [ 0, %while_else ]
    #dbg_value(i64 %i.1, !1350, !DIExpression(), !1377)
  ret i64 %i.1, !dbg !1388
}

define fastcc ptr @Env_tag__strings_from_pointers_oZo(ptr dereferenceable(64) %this, ptr %data, i64 %len) unnamed_addr #4 !dbg !1389 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !1394, !DIExpression(), !1400)
    #dbg_value(ptr %data, !1401, !DIExpression(), !1400)
    #dbg_value(i64 %len, !1402, !DIExpression(), !1400)
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_String_val_Desc, ptr %1, align 8
    #dbg_value(ptr %1, !516, !DIExpression(), !1403)
    #dbg_value(i64 %len, !518, !DIExpression(), !1403)
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 8, !dbg !1406
  store i64 0, ptr %2, align 8, !dbg !1406
  %.not.i = icmp eq i64 %len, 0, !dbg !1407
  br i1 %.not.i, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %entry
    #dbg_value(i64 %len, !432, !DIExpression(), !1408)
  %3 = add i64 %len, -1, !dbg !1410
    #dbg_value(i64 %3, !440, !DIExpression(), !1411)
  %4 = call fastcc i64 @USize_val_u64_W(i64 %3), !dbg !1413
  %5 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %4, i1 false), !dbg !1414
  %6 = call fastcc i64 @U64_val_usize_Z(i64 %5), !dbg !1415
    #dbg_value(i64 %6, !436, !DIExpression(), !1408)
  %7 = icmp eq i64 %6, 0, !dbg !1416
  br i1 %7, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %if_then.i
  br label %USize_val_next_pow2_Z.exit.i

if_else.i.i:                                      ; preds = %if_then.i
    #dbg_value(i64 %len, !453, !DIExpression(), !1417)
  %8 = sub i64 64, %6
  %9 = call i64 @llvm.umin.i64(i64 %8, i64 63)
  br label %USize_val_next_pow2_Z.exit.i

USize_val_next_pow2_Z.exit.i:                     ; preds = %if_else.i.i, %if_then.i.i
  %10 = phi i64 [ 0, %if_then.i.i ], [ %9, %if_else.i.i ]
  %11 = shl nuw i64 1, %10
    #dbg_value(i64 %11, !347, !DIExpression(), !1419)
    #dbg_value(i64 %len, !353, !DIExpression(), !1419)
  %12 = icmp ugt i64 %11, %len, !dbg !1421
  br i1 %12, label %if_then.i4.i, label %if_else.i3.i

if_then.i4.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

if_else.i3.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

USize_val_max_ZZ.exit.i:                          ; preds = %if_else.i3.i, %if_then.i4.i
  %13 = phi i64 [ %11, %if_then.i4.i ], [ %len, %if_else.i3.i ]
    #dbg_value(i64 %13, !347, !DIExpression(), !1422)
    #dbg_value(i64 8, !353, !DIExpression(), !1422)
  %14 = icmp ugt i64 %13, 8, !dbg !1424
  br i1 %14, label %if_then.i6.i, label %if_else.i5.i

if_then.i6.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

if_else.i5.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

USize_val_max_ZZ.exit7.i:                         ; preds = %if_else.i5.i, %if_then.i6.i
  %15 = phi i64 [ %13, %if_then.i6.i ], [ 8, %if_else.i5.i ]
    #dbg_value(i64 %15, !347, !DIExpression(), !1425)
    #dbg_value(i64 4, !353, !DIExpression(), !1425)
  %16 = getelementptr inbounds nuw i8, ptr %1, i64 16, !dbg !1427
  store i64 %15, ptr %16, align 8, !dbg !1427
  %17 = call ptr @pony_ctx(), !dbg !1428
  %18 = shl i64 %15, 3, !dbg !1428
  %19 = call noalias align 32 dereferenceable_or_null(8) ptr @pony_alloc(ptr %17, i64 %18), !dbg !1428
  %20 = getelementptr inbounds nuw i8, ptr %1, i64 24, !dbg !1429
  store ptr %19, ptr %20, align 8, !dbg !1429
  br label %Array_String_val_ref_create_pZo.exit

if_else.i:                                        ; preds = %entry
  %21 = getelementptr inbounds nuw i8, ptr %1, i64 16, !dbg !1430
  store i64 0, ptr %21, align 8, !dbg !1430
  %22 = getelementptr inbounds nuw i8, ptr %1, i64 24, !dbg !1431
  store ptr null, ptr %22, align 8, !dbg !1431
  br label %Array_String_val_ref_create_pZo.exit

Array_String_val_ref_create_pZo.exit:             ; preds = %USize_val_max_ZZ.exit7.i, %if_else.i
    #dbg_value(ptr %1, !1395, !DIExpression(), !1400)
    #dbg_value(i64 0, !1396, !DIExpression(), !1400)
  br label %while_init

while_init:                                       ; preds = %Array_String_val_ref_create_pZo.exit
  %.not = icmp eq i64 %len, 0, !dbg !1432
  br i1 %.not, label %while_else, label %while_body

while_body:                                       ; preds = %String_ref_copy_cstring_moo.exit, %while_init
  %i.0 = phi i64 [ 0, %while_init ], [ %23, %String_ref_copy_cstring_moo.exit ]
    #dbg_value(ptr poison, !1397, !DIExpression(), !1433)
    #dbg_value(i64 %i.0, !1396, !DIExpression(), !1400)
  %23 = add i64 %i.0, 1, !dbg !1434
    #dbg_value(i64 %23, !1396, !DIExpression(), !1400)
  %24 = getelementptr inbounds [8 x i8], ptr %data, i64 %i.0, !dbg !1435
  %25 = load ptr, ptr %24, align 8, !dbg !1435
    #dbg_value(ptr %25, !1397, !DIExpression(), !1433)
  %26 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @String_Desc, ptr %26, align 8
    #dbg_value(ptr %26, !368, !DIExpression(), !1436)
    #dbg_value(ptr %25, !373, !DIExpression(), !1436)
  %27 = icmp eq ptr %25, null, !dbg !1439
  br i1 %27, label %if_then.i17, label %if_else.i12

if_then.i17:                                      ; preds = %while_body
  %28 = getelementptr inbounds nuw i8, ptr %26, i64 8, !dbg !1440
  store i64 0, ptr %28, align 8, !dbg !1440
  %29 = getelementptr inbounds nuw i8, ptr %26, i64 16, !dbg !1441
  store i64 32, ptr %29, align 8, !dbg !1441
  %30 = call ptr @pony_ctx(), !dbg !1442
  %31 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %30, i64 32), !dbg !1442
  %32 = getelementptr inbounds nuw i8, ptr %26, i64 24, !dbg !1443
  store ptr %31, ptr %32, align 8, !dbg !1443
    #dbg_value(ptr %26, !313, !DIExpression(), !1444)
    #dbg_value(i64 0, !315, !DIExpression(), !1444)
    #dbg_value(i8 0, !316, !DIExpression(), !1444)
  %33 = getelementptr inbounds nuw i8, ptr %26, i64 24
  %34 = load ptr, ptr %33, align 8
  %35 = load i8, ptr %34, align 1, !dbg !1446
  store i8 0, ptr %34, align 1, !dbg !1446
  br label %String_ref_copy_cstring_moo.exit

if_else.i12:                                      ; preds = %while_body
    #dbg_value(i64 0, !369, !DIExpression(), !1447)
  %36 = load i8, ptr %25, align 1, !dbg !1448
  %.not.i13 = icmp eq i8 %36, 0
  br i1 %.not.i13, label %while_else.i, label %while_body.i

while_body.i:                                     ; preds = %while_body.i, %if_else.i12
  %i.0.i = phi i64 [ 0, %if_else.i12 ], [ %37, %while_body.i ]
    #dbg_value(i64 %i.0.i, !369, !DIExpression(), !1447)
  %37 = add i64 %i.0.i, 1, !dbg !1449
    #dbg_value(i64 %37, !369, !DIExpression(), !1447)
  %38 = getelementptr inbounds i8, ptr %25, i64 %37, !dbg !1448
  %39 = load i8, ptr %38, align 1, !dbg !1448
  %.not10.i = icmp eq i8 %39, 0
  br i1 %.not10.i, label %while_post.i, label %while_body.i

while_else.i:                                     ; preds = %if_else.i12
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1450)
  br label %while_post.i

while_post.i:                                     ; preds = %while_else.i, %while_body.i
  %i.1.i = phi i64 [ %37, %while_body.i ], [ 0, %while_else.i ]
    #dbg_value(i64 %i.1.i, !369, !DIExpression(), !1447)
  %40 = getelementptr inbounds nuw i8, ptr %26, i64 8, !dbg !1452
  store i64 %i.1.i, ptr %40, align 8, !dbg !1452
  %41 = add i64 %i.1.i, 1, !dbg !1453
    #dbg_value(i64 %41, !347, !DIExpression(), !1454)
    #dbg_value(i64 32, !353, !DIExpression(), !1454)
  %42 = icmp ugt i64 %41, 32, !dbg !1456
  br i1 %42, label %if_then.i.i16, label %if_else.i.i14

if_then.i.i16:                                    ; preds = %while_post.i
  br label %USize_val_max_ZZ.exit.i15

if_else.i.i14:                                    ; preds = %while_post.i
  br label %USize_val_max_ZZ.exit.i15

USize_val_max_ZZ.exit.i15:                        ; preds = %if_else.i.i14, %if_then.i.i16
  %43 = phi i64 [ %41, %if_then.i.i16 ], [ 32, %if_else.i.i14 ]
  %44 = getelementptr inbounds nuw i8, ptr %26, i64 16, !dbg !1457
  store i64 %43, ptr %44, align 8, !dbg !1457
  %45 = call ptr @pony_ctx(), !dbg !1458
  %46 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %45, i64 %43), !dbg !1458
  %47 = getelementptr inbounds nuw i8, ptr %26, i64 24, !dbg !1459
  store ptr %46, ptr %47, align 8, !dbg !1459
  %48 = add i64 %i.1.i, 1, !dbg !1460
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %46, ptr align 1 %25, i64 %48, i1 false), !dbg !1461
  br label %String_ref_copy_cstring_moo.exit

String_ref_copy_cstring_moo.exit:                 ; preds = %if_then.i17, %USize_val_max_ZZ.exit.i15
  %49 = call fastcc ptr @Array_String_val_ref_push_oo(ptr nonnull %1, ptr nonnull %26), !dbg !1462
  %50 = icmp ult i64 %23, %len, !dbg !1432
  br i1 %50, label %while_body, label %while_post

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1463)
  br label %while_post

while_post:                                       ; preds = %while_else, %String_ref_copy_cstring_moo.exit
  ret ptr %1, !dbg !1466
}

define fastcc noalias align 32 dereferenceable(64) ptr @Env_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 1)
  store volatile ptr @Env_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc ptr @None_val_create_o(ptr %this) unnamed_addr #4 !dbg !54 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !53, !DIExpression(), !1467)
  ret ptr %this, !dbg !1468
}

define fastcc ptr @None_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @None_Inst
}

define fastcc i1 @AsioEvent_val_readable_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !918 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !917, !DIExpression(), !1469)
    #dbg_value(i32 %flags, !923, !DIExpression(), !1469)
  %0 = trunc i32 %flags to i1
  ret i1 %0, !dbg !1470
}

define fastcc i1 @AsioEvent_box_readable_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !1471 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1474, !DIExpression(), !1475)
    #dbg_value(i32 %flags, !1476, !DIExpression(), !1475)
  %0 = trunc i32 %flags to i1
  ret i1 %0, !dbg !1477
}

define fastcc i1 @AsioEvent_box_errored_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !1478 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1481, !DIExpression(), !1482)
    #dbg_value(i32 %flags, !1483, !DIExpression(), !1482)
  %0 = and i32 %flags, 16
  %1 = icmp ne i32 %0, 0
  ret i1 %1, !dbg !1484
}

define fastcc i1 @AsioEvent_val_errored_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !873 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !872, !DIExpression(), !1485)
    #dbg_value(i32 %flags, !878, !DIExpression(), !1485)
  %0 = and i32 %flags, 16
  %1 = icmp ne i32 %0, 0
  ret i1 %1, !dbg !1486
}

define fastcc i1 @AsioEvent_box_disposable_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !1487 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1490, !DIExpression(), !1491)
    #dbg_value(i32 %flags, !1492, !DIExpression(), !1491)
  %0 = icmp eq i32 %flags, 0, !dbg !1493
  ret i1 %0, !dbg !1493
}

define fastcc i1 @AsioEvent_val_disposable_Ib(ptr dereferenceable(8) %this, i32 %flags) unnamed_addr #4 !dbg !857 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !856, !DIExpression(), !1494)
    #dbg_value(i32 %flags, !864, !DIExpression(), !1494)
  %0 = icmp eq i32 %flags, 0, !dbg !1495
  ret i1 %0, !dbg !1495
}

define fastcc ptr @AsioEvent_box_none_o(ptr dereferenceable(8) %this) unnamed_addr #4 !dbg !1496 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1499, !DIExpression(), !1500)
  ret ptr null, !dbg !1501
}

define fastcc ptr @AsioEvent_val_none_o(ptr dereferenceable(8) %this) unnamed_addr #4 !dbg !80 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !79, !DIExpression(), !1502)
  ret ptr null, !dbg !1503
}

define fastcc ptr @AsioEvent_val_create_o(ptr %this) unnamed_addr #4 !dbg !68 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !67, !DIExpression(), !1504)
  ret ptr %this, !dbg !1505
}

define fastcc ptr @AsioEvent_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @AsioEvent_Inst
}

define fastcc i64 @U8_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i8
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i8, ptr %4, align 1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i8 [ %3, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = zext i8 %6 to i64
  ret i64 %7
}

define fastcc i1 @U8_val_eq_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1506 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1511, !DIExpression(), !1513)
    #dbg_value(i8 %y, !1514, !DIExpression(), !1513)
  %0 = icmp eq i8 %this, %y, !dbg !1515
  ret i1 %0, !dbg !1515
}

define fastcc i1 @U8_box_eq_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1516 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1519, !DIExpression(), !1520)
    #dbg_value(i8 %y, !1521, !DIExpression(), !1520)
  %0 = icmp eq i8 %this, %y, !dbg !1522
  ret i1 %0, !dbg !1522
}

define fastcc i8 @U8_val_create_pCC(i8 %this, i8 %value) unnamed_addr #4 !dbg !1523 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1528, !DIExpression(), !1529)
    #dbg_value(i8 %value, !1530, !DIExpression(), !1529)
  ret i8 %value, !dbg !1531
}

define fastcc i1 @U8_val_ne_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1532 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1535, !DIExpression(), !1536)
    #dbg_value(i8 %y, !1537, !DIExpression(), !1536)
  %0 = icmp ne i8 %this, %y, !dbg !1538
  ret i1 %0, !dbg !1538
}

define fastcc i1 @U8_box_ne_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1539 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1542, !DIExpression(), !1543)
    #dbg_value(i8 %y, !1544, !DIExpression(), !1543)
  %0 = icmp ne i8 %this, %y, !dbg !1545
  ret i1 %0, !dbg !1545
}

define fastcc ptr @Pointer_U8_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define fastcc noalias align 32 dereferenceable_or_null(1) ptr @Pointer_U8_val_ref__alloc_pZo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc(ptr %2, i64 %1)
  ret ptr %3
}

define fastcc noalias align 32 dereferenceable_or_null(1) ptr @Pointer_U8_val_ref__realloc_ZZo(ptr %0, i64 %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = call ptr @pony_ctx()
  %4 = call ptr @pony_realloc(ptr %3, ptr %0, i64 %1, i64 %2)
  ret ptr %4
}

define fastcc ptr @Pointer_U8_val_tag__unsafe_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr %0
}

define fastcc i8 @Pointer_U8_val_box__apply_ZC(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define fastcc i8 @Pointer_U8_val_ref__apply_ZC(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define fastcc i8 @Pointer_U8_val_val__apply_ZC(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define fastcc i8 @Pointer_U8_val_ref__update_ZCC(ptr %0, i64 %1, i8 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds i8, ptr %0, i64 %1
  %4 = load i8, ptr %3, align 1
  store i8 %2, ptr %3, align 1
  ret i8 %4
}

define fastcc ptr @Pointer_U8_val_box__offset_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  ret ptr %2
}

define fastcc ptr @Pointer_U8_val_ref__offset_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  ret ptr %2
}

define fastcc ptr @Pointer_U8_val_val__offset_Zo(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i64 %1
  ret ptr %2
}

define fastcc i64 @Pointer_U8_val_tag__min_alloc_Z(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 32
}

define fastcc ptr @Pointer_U8_val_box__copy_to_oZo(ptr %0, ptr %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 %0, i64 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

define fastcc ptr @Pointer_U8_val_ref__copy_to_oZo(ptr %0, ptr %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 %0, i64 %2, i1 false)
  ret ptr %0
}

define fastcc ptr @Pointer_U8_val_val__copy_to_oZo(ptr %0, ptr %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i64(ptr align 1 %1, ptr align 1 %0, i64 %2, i1 false)
  ret ptr %0
}

define fastcc i1 @Pointer_U8_val_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

declare ptr @pony_os_stderr()

declare ptr @pony_os_stdout()

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #5

declare i64 @pony_os_stdin_read(ptr, i64)

declare void @pony_asio_event_unsubscribe(ptr)

declare void @pony_asio_event_destroy(ptr)

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctlz.i64(i64, i1 immarg) #6

declare i64 @USize_val_u64_W(i64)

declare i64 @U64_val_usize_Z(i64)

declare void @pony_os_stdout_setup()

declare i1 @pony_os_stdin_setup()

declare i64 @U32_val_usize_Z(i32)

define fastcc i32 @U32_val_op_and_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !104, !DIExpression(), !106)
    #dbg_value(i32 %1, !107, !DIExpression(), !106)
  %8 = and i32 %7, %1, !dbg !108
  ret i32 %8
}

define fastcc i32 @U32_box_op_and_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !112, !DIExpression(), !113)
    #dbg_value(i32 %1, !114, !DIExpression(), !113)
  %8 = and i32 %7, %1, !dbg !115
  ret i32 %8
}

define fastcc i32 @U32_val_shl_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !119, !DIExpression(), !120)
    #dbg_value(i32 %1, !121, !DIExpression(), !120)
  %8 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !122
  %9 = shl i32 %7, %8, !dbg !122
  ret i32 %9
}

define fastcc i32 @U32_box_shl_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !126, !DIExpression(), !127)
    #dbg_value(i32 %1, !128, !DIExpression(), !127)
  %8 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !129
  %9 = shl i32 %7, %8, !dbg !129
  ret i32 %9
}

declare i64 @U32_box_usize_Z(i32)

define fastcc i64 @U32_box_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i32 [ %3, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = call fastcc i64 @U32_box_usize_Z(i32 %6)
  ret i64 %7
}

define fastcc i64 @U32_val_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i32, ptr %4, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %6 = phi i32 [ %3, %unbox_tagged ], [ %5, %unbox_heap ]
  %7 = call fastcc i64 @U32_val_usize_Z(i32 %6)
  ret i64 %7
}

define fastcc i1 @U32_val_ne_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !135, !DIExpression(), !136)
    #dbg_value(i32 %1, !137, !DIExpression(), !136)
  %8 = icmp ne i32 %7, %1, !dbg !138
  ret i1 %8
}

define fastcc i1 @U32_box_ne_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !142, !DIExpression(), !143)
    #dbg_value(i32 %1, !144, !DIExpression(), !143)
  %8 = icmp ne i32 %7, %1, !dbg !145
  ret i1 %8
}

define fastcc i1 @U32_box_eq_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !149, !DIExpression(), !150)
    #dbg_value(i32 %1, !151, !DIExpression(), !150)
  %8 = icmp eq i32 %7, %1, !dbg !152
  ret i1 %8
}

define fastcc i1 @U32_val_eq_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i32
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i32, ptr %5, align 4
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i32 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i32 %7, !156, !DIExpression(), !157)
    #dbg_value(i32 %1, !158, !DIExpression(), !157)
  %8 = icmp eq i32 %7, %1, !dbg !159
  ret i1 %8
}

define fastcc i32 @U32_val_create_pII_Unbox(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = icmp slt ptr %0, null
  br i1 %3, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
    #dbg_value(i32 %1, !163, !DIExpression(), !164)
    #dbg_value(i32 %2, !165, !DIExpression(), !164)
  ret i32 %2
}

define fastcc i1 @Bool_box_op_not_b_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i1
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i8, ptr %4, align 1
  %6 = trunc i8 %5 to i1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i1 [ %3, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i1 %7, !555, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !557)
  %8 = xor i1 %7, true, !dbg !558
  ret i1 %8
}

define fastcc i1 @Bool_val_op_not_b_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp slt ptr %0, null
  br i1 %1, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %2 = ptrtoint ptr %0 to i64
  %3 = trunc i64 %2 to i1
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %5 = load i8, ptr %4, align 1
  %6 = trunc i8 %5 to i1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i1 [ %3, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i1 %7, !562, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !563)
  %8 = xor i1 %7, true, !dbg !564
  ret i1 %8
}

define fastcc i1 @Bool_val_create_pbb_Unbox(ptr %0, i1 %1, i1 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = icmp slt ptr %0, null
  br i1 %3, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
    #dbg_value(i1 %1, !570, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !571)
    #dbg_value(i1 %2, !572, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !571)
  ret i1 %2
}

define fastcc i1 @Bool_box_op_and_bb_Unbox(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i1
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  %7 = trunc i8 %6 to i1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %8 = phi i1 [ %4, %unbox_tagged ], [ %7, %unbox_heap ]
    #dbg_value(i1 %8, !577, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !578)
    #dbg_value(i1 %1, !579, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !578)
  br i1 %8, label %sc_right.i, label %Bool_box_op_and_bb.exit, !dbg !580

sc_right.i:                                       ; preds = %unbox_merge
  br label %Bool_box_op_and_bb.exit, !dbg !580

Bool_box_op_and_bb.exit:                          ; preds = %unbox_merge, %sc_right.i
  %9 = phi i1 [ false, %unbox_merge ], [ %1, %sc_right.i ], !dbg !580
  ret i1 %9
}

define fastcc i1 @Bool_val_op_and_bb_Unbox(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i1
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  %7 = trunc i8 %6 to i1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %8 = phi i1 [ %4, %unbox_tagged ], [ %7, %unbox_heap ]
    #dbg_value(i1 %8, !584, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !585)
    #dbg_value(i1 %1, !586, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !585)
  br i1 %8, label %sc_right.i, label %Bool_val_op_and_bb.exit, !dbg !587

sc_right.i:                                       ; preds = %unbox_merge
  br label %Bool_val_op_and_bb.exit, !dbg !587

Bool_val_op_and_bb.exit:                          ; preds = %unbox_merge, %sc_right.i
  %9 = phi i1 [ false, %unbox_merge ], [ %1, %sc_right.i ], !dbg !587
  ret i1 %9
}

define fastcc i32 @I32_val_create_pii_Unbox(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = icmp slt ptr %0, null
  br i1 %3, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
    #dbg_value(i32 %1, !936, !DIExpression(), !938)
    #dbg_value(i32 %2, !939, !DIExpression(), !938)
  ret i32 %2
}

define fastcc i1 @U64_val_eq_Wb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !947, !DIExpression(), !949)
    #dbg_value(i64 %1, !950, !DIExpression(), !949)
  %4 = icmp eq i64 %3, %1, !dbg !951
  ret i1 %4
}

define fastcc i1 @U64_box_eq_Wb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !955, !DIExpression(), !956)
    #dbg_value(i64 %1, !957, !DIExpression(), !956)
  %4 = icmp eq i64 %3, %1, !dbg !958
  ret i1 %4
}

define fastcc i64 @U64_val_create_pWW_Unbox(ptr %0, i64 %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i64 %1, !964, !DIExpression(), !965)
    #dbg_value(i64 %2, !966, !DIExpression(), !965)
  ret i64 %2
}

declare i64 @U64_box_usize_Z(i64)

define fastcc i64 @U64_box_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = call fastcc i64 @U64_box_usize_Z(i64 %2)
  ret i64 %3
}

define fastcc i64 @U64_val_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = call fastcc i64 @U64_val_usize_Z(i64 %2)
  ret i64 %3
}

define fastcc i64 @USize_val_u64_W_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = call fastcc i64 @USize_val_u64_W(i64 %2)
  ret i64 %3
}

declare i64 @USize_box_u64_W(i64)

define fastcc i64 @USize_box_u64_W_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
  %3 = call fastcc i64 @USize_box_u64_W(i64 %2)
  ret i64 %3
}

define fastcc i64 @USize_val_bitwidth_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !453, !DIExpression(), !968)
  ret i64 64
}

define fastcc i64 @USize_box_bitwidth_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !973, !DIExpression(), !974)
  ret i64 64
}

define fastcc i64 @USize_box_sub_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !979, !DIExpression(), !980)
    #dbg_value(i64 %1, !981, !DIExpression(), !980)
  %4 = sub i64 %3, %1, !dbg !982
  ret i64 %4
}

define fastcc i64 @USize_val_sub_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !986, !DIExpression(), !987)
    #dbg_value(i64 %1, !988, !DIExpression(), !987)
  %4 = sub i64 %3, %1, !dbg !989
  ret i64 %4
}

define fastcc i64 @USize_val_shl_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !993, !DIExpression(), !994)
    #dbg_value(i64 %1, !995, !DIExpression(), !994)
  %4 = call i64 @llvm.umin.i64(i64 %1, i64 63), !dbg !996
  %5 = shl i64 %3, %4, !dbg !996
  ret i64 %5
}

define fastcc i64 @USize_box_shl_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1000, !DIExpression(), !1001)
    #dbg_value(i64 %1, !1002, !DIExpression(), !1001)
  %4 = call i64 @llvm.umin.i64(i64 %1, i64 63), !dbg !1003
  %5 = shl i64 %3, %4, !dbg !1003
  ret i64 %5
}

define fastcc i1 @USize_val_ne_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1009, !DIExpression(), !1010)
    #dbg_value(i64 %1, !1011, !DIExpression(), !1010)
  %4 = icmp ne i64 %3, %1, !dbg !1012
  ret i1 %4
}

define fastcc i1 @USize_box_ne_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1016, !DIExpression(), !1017)
    #dbg_value(i64 %1, !1018, !DIExpression(), !1017)
  %4 = icmp ne i64 %3, %1, !dbg !1019
  ret i1 %4
}

define fastcc i64 @USize_val_max_value_Z_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i64 %1, !327, !DIExpression(), !1020)
  ret i64 -1
}

define fastcc i64 @USize_val_add_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1025, !DIExpression(), !1026)
    #dbg_value(i64 %1, !1027, !DIExpression(), !1026)
  %4 = add i64 %3, %1, !dbg !1028
  ret i64 %4
}

define fastcc i64 @USize_box_add_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1032, !DIExpression(), !1033)
    #dbg_value(i64 %1, !1034, !DIExpression(), !1033)
  %4 = add i64 %3, %1, !dbg !1035
  ret i64 %4
}

define fastcc i64 @USize_val_next_pow2_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !432, !DIExpression(), !1036)
  %3 = add i64 %2, -1, !dbg !1037
    #dbg_value(i64 %3, !440, !DIExpression(), !1038)
  %4 = call fastcc i64 @USize_val_u64_W(i64 %3), !dbg !1040
  %5 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %4, i1 false), !dbg !1041
  %6 = call fastcc i64 @U64_val_usize_Z(i64 %5), !dbg !1042
    #dbg_value(i64 %6, !436, !DIExpression(), !1036)
  %7 = icmp eq i64 %6, 0, !dbg !1043
  br i1 %7, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(i64 %2, !453, !DIExpression(), !1044)
  %8 = sub i64 64, %6
  %9 = call i64 @llvm.umin.i64(i64 %8, i64 63)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %10 = phi i64 [ 0, %if_then.i ], [ %9, %if_else.i ]
  %11 = shl nuw i64 1, %10
  ret i64 %11
}

define fastcc i64 @USize_box_next_pow2_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !1050, !DIExpression(), !1052)
  %3 = add i64 %2, -1, !dbg !1053
    #dbg_value(i64 %3, !440, !DIExpression(), !1054)
  %4 = call fastcc i64 @USize_val_u64_W(i64 %3), !dbg !1056
  %5 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %4, i1 false), !dbg !1057
  %6 = call fastcc i64 @U64_val_usize_Z(i64 %5), !dbg !1058
    #dbg_value(i64 %6, !1051, !DIExpression(), !1052)
  %7 = icmp eq i64 %6, 0, !dbg !1059
  br i1 %7, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_next_pow2_Z.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(i64 %2, !453, !DIExpression(), !1061)
  %8 = sub i64 64, %6
  %9 = call i64 @llvm.umin.i64(i64 %8, i64 63)
  br label %USize_box_next_pow2_Z.exit

USize_box_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %10 = phi i64 [ 0, %if_then.i ], [ %9, %if_else.i ]
  %11 = shl nuw i64 1, %10
  ret i64 %11
}

define fastcc i1 @USize_box_eq_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1068, !DIExpression(), !1069)
    #dbg_value(i64 %1, !1070, !DIExpression(), !1069)
  %4 = icmp eq i64 %3, %1, !dbg !1071
  ret i1 %4
}

define fastcc i1 @USize_val_eq_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1075, !DIExpression(), !1076)
    #dbg_value(i64 %1, !1077, !DIExpression(), !1076)
  %4 = icmp eq i64 %3, %1, !dbg !1078
  ret i1 %4
}

define fastcc i64 @USize_box_clz_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !1082, !DIExpression(), !1083)
  %3 = call fastcc i64 @USize_val_u64_W(i64 %2), !dbg !1084
  %4 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %3, i1 false), !dbg !1087
  %5 = call fastcc i64 @U64_val_usize_Z(i64 %4), !dbg !1088
  ret i64 %5
}

define fastcc i64 @USize_val_clz_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !440, !DIExpression(), !1090)
  %3 = call fastcc i64 @USize_val_u64_W(i64 %2), !dbg !1091
  %4 = call range(i64 0, 65) i64 @llvm.ctlz.i64(i64 %3, i1 false), !dbg !1092
  %5 = call fastcc i64 @U64_val_usize_Z(i64 %4), !dbg !1093
  ret i64 %5
}

define fastcc i64 @USize_val_max_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !347, !DIExpression(), !1095)
    #dbg_value(i64 %1, !353, !DIExpression(), !1095)
  %4 = icmp ugt i64 %3, %1, !dbg !1096
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_max_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i64 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i64 %5
}

define fastcc i64 @USize_box_max_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1101, !DIExpression(), !1102)
    #dbg_value(i64 %1, !1103, !DIExpression(), !1102)
  %4 = icmp ugt i64 %3, %1, !dbg !1104
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_max_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_box_max_ZZ.exit

USize_box_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i64 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i64 %5
}

define fastcc i64 @USize_val_neg_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !1110, !DIExpression(), !1111)
  %3 = sub i64 0, %2, !dbg !1112
  ret i64 %3
}

define fastcc i64 @USize_box_neg_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %2 = load i64, ptr %1, align 8
    #dbg_value(i64 %2, !1116, !DIExpression(), !1117)
  %3 = sub i64 0, %2, !dbg !1118
  ret i64 %3
}

define fastcc i64 @USize_val_min_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !336, !DIExpression(), !1119)
    #dbg_value(i64 %1, !344, !DIExpression(), !1119)
  %4 = icmp ult i64 %3, %1, !dbg !1120
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i64 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i64 %5
}

define fastcc i64 @USize_box_min_ZZ_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1125, !DIExpression(), !1126)
    #dbg_value(i64 %1, !1127, !DIExpression(), !1126)
  %4 = icmp ult i64 %3, %1, !dbg !1128
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_box_min_ZZ.exit

USize_box_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i64 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i64 %5
}

define fastcc i64 @USize_val_create_pZZ_Unbox(ptr %0, i64 %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i64 %1, !1134, !DIExpression(), !1135)
    #dbg_value(i64 %2, !1136, !DIExpression(), !1135)
  ret i64 %2
}

define fastcc i1 @USize_val_lt_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1141, !DIExpression(), !1142)
    #dbg_value(i64 %1, !1143, !DIExpression(), !1142)
  %4 = icmp ult i64 %3, %1, !dbg !1144
  ret i1 %4
}

define fastcc i1 @USize_box_lt_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1148, !DIExpression(), !1149)
    #dbg_value(i64 %1, !1150, !DIExpression(), !1149)
  %4 = icmp ult i64 %3, %1, !dbg !1151
  ret i1 %4
}

define fastcc i1 @USize_val_gt_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1155, !DIExpression(), !1156)
    #dbg_value(i64 %1, !1157, !DIExpression(), !1156)
  %4 = icmp ugt i64 %3, %1, !dbg !1158
  ret i1 %4
}

define fastcc i1 @USize_box_gt_Zb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %3 = load i64, ptr %2, align 8
    #dbg_value(i64 %3, !1162, !DIExpression(), !1163)
    #dbg_value(i64 %1, !1164, !DIExpression(), !1163)
  %4 = icmp ugt i64 %3, %1, !dbg !1165
  ret i1 %4
}

define fastcc i1 @U8_val_eq_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i8
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i8 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i8 %7, !1511, !DIExpression(), !1513)
    #dbg_value(i8 %1, !1514, !DIExpression(), !1513)
  %8 = icmp eq i8 %7, %1, !dbg !1515
  ret i1 %8
}

define fastcc i1 @U8_box_eq_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i8
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i8 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i8 %7, !1519, !DIExpression(), !1520)
    #dbg_value(i8 %1, !1521, !DIExpression(), !1520)
  %8 = icmp eq i8 %7, %1, !dbg !1522
  ret i1 %8
}

define fastcc i8 @U8_val_create_pCC_Unbox(ptr %0, i8 %1, i8 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = icmp slt ptr %0, null
  br i1 %3, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
    #dbg_value(i8 %1, !1528, !DIExpression(), !1529)
    #dbg_value(i8 %2, !1530, !DIExpression(), !1529)
  ret i8 %2
}

define fastcc i1 @U8_val_ne_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i8
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i8 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i8 %7, !1535, !DIExpression(), !1536)
    #dbg_value(i8 %1, !1537, !DIExpression(), !1536)
  %8 = icmp ne i8 %7, %1, !dbg !1538
  ret i1 %8
}

define fastcc i1 @U8_box_ne_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = icmp slt ptr %0, null
  br i1 %2, label %unbox_tagged, label %unbox_heap

unbox_tagged:                                     ; preds = %entry
  %3 = ptrtoint ptr %0 to i64
  %4 = trunc i64 %3 to i8
  br label %unbox_merge

unbox_heap:                                       ; preds = %entry
  %5 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %6 = load i8, ptr %5, align 1
  br label %unbox_merge

unbox_merge:                                      ; preds = %unbox_heap, %unbox_tagged
  %7 = phi i8 [ %4, %unbox_tagged ], [ %6, %unbox_heap ]
    #dbg_value(i8 %7, !1542, !DIExpression(), !1543)
    #dbg_value(i8 %1, !1544, !DIExpression(), !1543)
  %8 = icmp ne i8 %7, %1, !dbg !1545
  ret i1 %8
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #7

; Function Attrs: nounwind
declare void @pony_send_next(ptr, ptr readnone) #8

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @pony_chain(ptr captures(none), ptr readnone) #9

attributes #0 = { nounwind memory(none) }
attributes #1 = { nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { nounwind memory(argmem: read) }
attributes #3 = { noreturn }
attributes #4 = { "target-cpu"="arrowlake" "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,-avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,-avx512vpopcntdq,+cmov,-avx512vp2intersect,+avxvnniint8,-avx512cd,+movbe,-ccmp,-amx-int8,-kl,-avx512bmm,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,-avx512vl,-uintr,-cf,-jmpabs,+clflushopt,-raoint,+cmpccxadd,+bmi,-amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,-avx512f,-amx-bf16,-avx512bf16,-avx512vnni,-push2pop2,+cx8,-avx512bw,+sse3,-pku,-nf,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,-wbnoinvd,-enqcmd,+avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,+avxifma,+f16c,-avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,-avx512vbmi2,-prefetchi,+rdpid,-amx-movrs,-fma4,-avx512vbmi,+shstk,+vaes,+waitpkg,-sgx,+fxsr,-avx512dq,-sse4a,+cx16,+sse2,+64bit,+64bit-mode" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind }
attributes #9 = { nounwind memory(argmem: readwrite) }

!llvm.module.flags = !{!0, !1}
!llvm.dbg.cu = !{!2}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus, file: !3, producer: "ponyc-0.78.2-e780f37e1", isOptimized: true, flags: "-r ir -b audit -o <experiment>/ir-off test/gc-root-audit ", runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false)
!3 = !DIFile(filename: "builtin", directory: "<checkout>/packages/builtin")
!4 = !{}
!5 = !DILocalVariable(name: "this", arg: 1, scope: !6, file: !7, line: 58, type: !19, flags: DIFlagArtificial)
!6 = distinct !DISubprogram(name: "_err", linkageName: "StdStream_tag__err_o", scope: !7, file: !7, line: 58, type: !8, scopeLine: 58, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !17, retainedNodes: !18)
!7 = !DIFile(filename: "<checkout>/packages/builtin/std_stream.pony", directory: "")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !10}
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64, align: 64, dwarfAddressSpace: 0)
!11 = !DICompositeType(tag: DW_TAG_structure_type, name: "StdStream", file: !7, line: 51, size: 2496, align: 64, elements: !12, identifier: "StdStream")
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "_stream", file: !7, line: 50, baseType: !14, size: 64, align: 64, offset: 2432, flags: DIFlagPrivate)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64, align: 64, dwarfAddressSpace: 0)
!15 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_U8_val", file: !16, line: 52, elements: !4, identifier: "Pointer_U8_val")
!16 = !DIFile(filename: "<checkout>/packages/builtin/pointer.pony", directory: "")
!17 = !DISubprogram(name: "_err", linkageName: "StdStream_tag__err_o", scope: !11, file: !7, line: 58, type: !8, scopeLine: 58, spFlags: 0)
!18 = !{!5}
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!20 = !DILocation(line: 0, scope: !6)
!21 = !DILocation(line: 62, column: 15, scope: !6)
!22 = !DILocation(line: 62, column: 13, scope: !6)
!23 = !DILocalVariable(name: "this", arg: 1, scope: !24, file: !7, line: 52, type: !19, flags: DIFlagArtificial)
!24 = distinct !DISubprogram(name: "_out", linkageName: "StdStream_tag__out_o", scope: !7, file: !7, line: 52, type: !8, scopeLine: 52, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !25, retainedNodes: !26)
!25 = !DISubprogram(name: "_out", linkageName: "StdStream_tag__out_o", scope: !11, file: !7, line: 52, type: !8, scopeLine: 52, spFlags: 0)
!26 = !{!23}
!27 = !DILocation(line: 0, scope: !24)
!28 = !DILocation(line: 56, column: 15, scope: !24)
!29 = !DILocation(line: 56, column: 13, scope: !24)
!30 = !DILocalVariable(name: "this", arg: 1, scope: !31, file: !32, line: 74, type: !50, flags: DIFlagArtificial)
!31 = distinct !DISubprogram(name: "_create", linkageName: "Stdin_tag__create_pbo", scope: !32, file: !32, line: 74, type: !33, scopeLine: 74, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !48, retainedNodes: !49)
!32 = !DIFile(filename: "<checkout>/packages/builtin/stdin.pony", directory: "")
!33 = !DISubroutineType(types: !34)
!34 = !{!35, !35, !47}
!35 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 64, align: 64, dwarfAddressSpace: 0)
!36 = !DICompositeType(tag: DW_TAG_structure_type, name: "Stdin", file: !32, line: 49, size: 2688, align: 64, elements: !37, identifier: "Stdin")
!37 = !{!38, !41, !43, !46}
!38 = !DIDerivedType(tag: DW_TAG_member, name: "_notify", file: !32, line: 69, baseType: !39, size: 64, align: 64, offset: 2432, flags: DIFlagPrivate)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 64, align: 64, dwarfAddressSpace: 0)
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "u2_InputNotify_ref_None_val", file: !32, line: 69, elements: !4, identifier: "u2_InputNotify_ref_None_val")
!41 = !DIDerivedType(tag: DW_TAG_member, name: "_chunk_size", file: !32, line: 70, baseType: !42, size: 64, align: 64, offset: 2496, flags: DIFlagPrivate)
!42 = !DIBasicType(name: "USize", size: 64, encoding: DW_ATE_unsigned)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "_event", file: !32, line: 71, baseType: !44, size: 64, align: 64, offset: 2560, flags: DIFlagPrivate)
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 64, align: 64, dwarfAddressSpace: 0)
!45 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_AsioEvent_val", file: !16, line: 1, elements: !4, identifier: "Pointer_AsioEvent_val")
!46 = !DIDerivedType(tag: DW_TAG_member, name: "_use_event", file: !32, line: 72, baseType: !47, size: 8, align: 8, offset: 2624, flags: DIFlagPrivate)
!47 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean)
!48 = !DISubprogram(name: "_create", linkageName: "Stdin_tag__create_pbo", scope: !36, file: !32, line: 74, type: !33, scopeLine: 74, spFlags: 0)
!49 = !{!30}
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!51 = !DILocation(line: 0, scope: !31)
!52 = !DILocalVariable(name: "use_event", arg: 2, scope: !31, file: !32, line: 74, type: !47)
!53 = !DILocalVariable(name: "this", arg: 1, scope: !54, file: !55, line: 1, type: !62, flags: DIFlagArtificial)
!54 = distinct !DISubprogram(name: "create", linkageName: "None_val_create_o", scope: !55, file: !55, line: 1, type: !56, scopeLine: 1, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !60, retainedNodes: !61)
!55 = !DIFile(filename: "<checkout>/packages/builtin/none.pony", directory: "")
!56 = !DISubroutineType(types: !57)
!57 = !{!58, !58}
!58 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !59, size: 64, align: 64, dwarfAddressSpace: 0)
!59 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", file: !55, line: 5, size: 64, align: 64, elements: !4, identifier: "None")
!60 = !DISubprogram(name: "create", linkageName: "None_val_create_o", scope: !59, file: !55, line: 1, type: !56, scopeLine: 1, spFlags: 0)
!61 = !{!53}
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !59, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!63 = !DILocation(line: 0, scope: !54, inlinedAt: !64)
!64 = distinct !DILocation(line: 69, column: 39, scope: !31)
!65 = !DILocation(line: 69, column: 3, scope: !31)
!66 = !DILocation(line: 70, column: 3, scope: !31)
!67 = !DILocalVariable(name: "this", arg: 1, scope: !68, file: !69, line: 6, type: !76, flags: DIFlagArtificial)
!68 = distinct !DISubprogram(name: "create", linkageName: "AsioEvent_val_create_o", scope: !69, file: !69, line: 6, type: !70, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !74, retainedNodes: !75)
!69 = !DIFile(filename: "<checkout>/packages/builtin/asio_event.pony", directory: "")
!70 = !DISubroutineType(types: !71)
!71 = !{!72, !72}
!72 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 64, align: 64, dwarfAddressSpace: 0)
!73 = !DICompositeType(tag: DW_TAG_structure_type, name: "AsioEvent", file: !69, line: 1, size: 64, align: 64, elements: !4, identifier: "AsioEvent")
!74 = !DISubprogram(name: "create", linkageName: "AsioEvent_val_create_o", scope: !73, file: !69, line: 6, type: !70, scopeLine: 6, spFlags: 0)
!75 = !{!67}
!76 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!77 = !DILocation(line: 0, scope: !68, inlinedAt: !78)
!78 = distinct !DILocation(line: 71, column: 38, scope: !31)
!79 = !DILocalVariable(name: "this", arg: 1, scope: !80, file: !69, line: 10, type: !76, flags: DIFlagArtificial)
!80 = distinct !DISubprogram(name: "none", linkageName: "AsioEvent_val_none_o", scope: !69, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !83, retainedNodes: !84)
!81 = !DISubroutineType(types: !82)
!82 = !{!44, !72}
!83 = !DISubprogram(name: "none", linkageName: "AsioEvent_val_none_o", scope: !73, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: 0)
!84 = !{!79}
!85 = !DILocation(line: 0, scope: !80, inlinedAt: !86)
!86 = distinct !DILocation(line: 71, column: 43, scope: !31)
!87 = !DILocation(line: 71, column: 3, scope: !31)
!88 = !DILocation(line: 78, column: 16, scope: !31)
!89 = !DILocalVariable(name: "this", arg: 1, scope: !90, file: !32, line: 143, type: !50, flags: DIFlagArtificial)
!90 = distinct !DISubprogram(name: "_read_again", linkageName: "Stdin_tag__read_again_o", scope: !32, file: !32, line: 143, type: !91, scopeLine: 143, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !93, retainedNodes: !94)
!91 = !DISubroutineType(types: !92)
!92 = !{!58, !35}
!93 = !DISubprogram(name: "_read_again", linkageName: "Stdin_tag__read_again_o", scope: !36, file: !32, line: 143, type: !91, scopeLine: 143, spFlags: 0)
!94 = !{!89}
!95 = !DILocation(line: 0, scope: !90)
!96 = !DILocation(line: 147, column: 10, scope: !90)
!97 = distinct !DISubprogram(name: "op_and", linkageName: "U32_val_op_and_II", scope: !98, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !102, retainedNodes: !103)
!98 = !DIFile(filename: "<checkout>/packages/builtin/unsigned.pony", directory: "")
!99 = !DISubroutineType(types: !100)
!100 = !{!101, !101, !101}
!101 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned)
!102 = !DISubprogram(name: "op_and", linkageName: "U32_val_op_and_II", scope: !101, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: 0)
!103 = !{!104}
!104 = !DILocalVariable(name: "this", arg: 1, scope: !97, file: !98, line: 384, type: !105, flags: DIFlagArtificial)
!105 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!106 = !DILocation(line: 0, scope: !97)
!107 = !DILocalVariable(name: "y", arg: 2, scope: !97, file: !98, line: 384, type: !101)
!108 = !DILocation(line: 384, column: 31, scope: !97)
!109 = distinct !DISubprogram(name: "op_and", linkageName: "U32_box_op_and_II", scope: !98, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !110, retainedNodes: !111)
!110 = !DISubprogram(name: "op_and", linkageName: "U32_box_op_and_II", scope: !101, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: 0)
!111 = !{!112}
!112 = !DILocalVariable(name: "this", arg: 1, scope: !109, file: !98, line: 384, type: !105, flags: DIFlagArtificial)
!113 = !DILocation(line: 0, scope: !109)
!114 = !DILocalVariable(name: "y", arg: 2, scope: !109, file: !98, line: 384, type: !101)
!115 = !DILocation(line: 384, column: 31, scope: !109)
!116 = distinct !DISubprogram(name: "shl", linkageName: "U32_val_shl_II", scope: !98, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !117, retainedNodes: !118)
!117 = !DISubprogram(name: "shl", linkageName: "U32_val_shl_II", scope: !101, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: 0)
!118 = !{!119}
!119 = !DILocalVariable(name: "this", arg: 1, scope: !116, file: !98, line: 445, type: !105, flags: DIFlagArtificial)
!120 = !DILocation(line: 0, scope: !116)
!121 = !DILocalVariable(name: "y", arg: 2, scope: !116, file: !98, line: 445, type: !101)
!122 = !DILocation(line: 445, column: 28, scope: !116)
!123 = distinct !DISubprogram(name: "shl", linkageName: "U32_box_shl_II", scope: !98, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !124, retainedNodes: !125)
!124 = !DISubprogram(name: "shl", linkageName: "U32_box_shl_II", scope: !101, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: 0)
!125 = !{!126}
!126 = !DILocalVariable(name: "this", arg: 1, scope: !123, file: !98, line: 445, type: !105, flags: DIFlagArtificial)
!127 = !DILocation(line: 0, scope: !123)
!128 = !DILocalVariable(name: "y", arg: 2, scope: !123, file: !98, line: 445, type: !101)
!129 = !DILocation(line: 445, column: 28, scope: !123)
!130 = distinct !DISubprogram(name: "ne", linkageName: "U32_val_ne_Ib", scope: !98, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !133, retainedNodes: !134)
!131 = !DISubroutineType(types: !132)
!132 = !{!47, !101, !101}
!133 = !DISubprogram(name: "ne", linkageName: "U32_val_ne_Ib", scope: !101, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: 0)
!134 = !{!135}
!135 = !DILocalVariable(name: "this", arg: 1, scope: !130, file: !98, line: 173, type: !105, flags: DIFlagArtificial)
!136 = !DILocation(line: 0, scope: !130)
!137 = !DILocalVariable(name: "y", arg: 2, scope: !130, file: !98, line: 173, type: !101)
!138 = !DILocation(line: 173, column: 35, scope: !130)
!139 = distinct !DISubprogram(name: "ne", linkageName: "U32_box_ne_Ib", scope: !98, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !140, retainedNodes: !141)
!140 = !DISubprogram(name: "ne", linkageName: "U32_box_ne_Ib", scope: !101, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: 0)
!141 = !{!142}
!142 = !DILocalVariable(name: "this", arg: 1, scope: !139, file: !98, line: 173, type: !105, flags: DIFlagArtificial)
!143 = !DILocation(line: 0, scope: !139)
!144 = !DILocalVariable(name: "y", arg: 2, scope: !139, file: !98, line: 173, type: !101)
!145 = !DILocation(line: 173, column: 35, scope: !139)
!146 = distinct !DISubprogram(name: "eq", linkageName: "U32_box_eq_Ib", scope: !98, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !147, retainedNodes: !148)
!147 = !DISubprogram(name: "eq", linkageName: "U32_box_eq_Ib", scope: !101, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: 0)
!148 = !{!149}
!149 = !DILocalVariable(name: "this", arg: 1, scope: !146, file: !98, line: 172, type: !105, flags: DIFlagArtificial)
!150 = !DILocation(line: 0, scope: !146)
!151 = !DILocalVariable(name: "y", arg: 2, scope: !146, file: !98, line: 172, type: !101)
!152 = !DILocation(line: 172, column: 35, scope: !146)
!153 = distinct !DISubprogram(name: "eq", linkageName: "U32_val_eq_Ib", scope: !98, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !154, retainedNodes: !155)
!154 = !DISubprogram(name: "eq", linkageName: "U32_val_eq_Ib", scope: !101, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: 0)
!155 = !{!156}
!156 = !DILocalVariable(name: "this", arg: 1, scope: !153, file: !98, line: 172, type: !105, flags: DIFlagArtificial)
!157 = !DILocation(line: 0, scope: !153)
!158 = !DILocalVariable(name: "y", arg: 2, scope: !153, file: !98, line: 172, type: !101)
!159 = !DILocation(line: 172, column: 35, scope: !153)
!160 = distinct !DISubprogram(name: "create", linkageName: "U32_val_create_pII", scope: !98, file: !98, line: 187, type: !99, scopeLine: 187, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !161, retainedNodes: !162)
!161 = !DISubprogram(name: "create", linkageName: "U32_val_create_pII", scope: !101, file: !98, line: 187, type: !99, scopeLine: 187, spFlags: 0)
!162 = !{!163}
!163 = !DILocalVariable(name: "this", arg: 1, scope: !160, file: !98, line: 187, type: !105, flags: DIFlagArtificial)
!164 = !DILocation(line: 0, scope: !160)
!165 = !DILocalVariable(name: "value", arg: 2, scope: !160, file: !98, line: 187, type: !101)
!166 = !DILocation(line: 187, column: 29, scope: !160)
!167 = distinct !DISubprogram(name: "create", linkageName: "$0$16_val_create_o", scope: !168, file: !168, line: 56, type: !169, scopeLine: 56, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !173, retainedNodes: !174)
!168 = !DIFile(filename: "<checkout>/packages/builtin/env.pony", directory: "")
!169 = !DISubroutineType(types: !170)
!170 = !{!171, !171}
!171 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !172, size: 64, align: 64, dwarfAddressSpace: 0)
!172 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$16", file: !168, line: 56, size: 64, align: 64, elements: !4, identifier: "$0$16")
!173 = !DISubprogram(name: "create", linkageName: "$0$16_val_create_o", scope: !172, file: !168, line: 56, type: !169, scopeLine: 56, spFlags: 0)
!174 = !{!175}
!175 = !DILocalVariable(name: "this", arg: 1, scope: !167, file: !168, line: 56, type: !176, flags: DIFlagArtificial)
!176 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !172, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!177 = !DILocation(line: 0, scope: !167)
!178 = !DILocation(line: 56, column: 16, scope: !167)
!179 = distinct !DISubprogram(name: "_create", linkageName: "AmbientAuth_val__create_o", scope: !180, file: !180, line: 15, type: !181, scopeLine: 15, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !185, retainedNodes: !186)
!180 = !DIFile(filename: "<checkout>/packages/builtin/ambient_auth.pony", directory: "")
!181 = !DISubroutineType(types: !182)
!182 = !{!183, !183}
!183 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !184, size: 64, align: 64, dwarfAddressSpace: 0)
!184 = !DICompositeType(tag: DW_TAG_structure_type, name: "AmbientAuth", file: !180, line: 9, size: 64, align: 64, elements: !4, identifier: "AmbientAuth")
!185 = !DISubprogram(name: "_create", linkageName: "AmbientAuth_val__create_o", scope: !184, file: !180, line: 15, type: !181, scopeLine: 15, spFlags: 0)
!186 = !{!187}
!187 = !DILocalVariable(name: "this", arg: 1, scope: !179, file: !180, line: 15, type: !188, flags: DIFlagArtificial)
!188 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !184, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!189 = !DILocation(line: 0, scope: !179)
!190 = !DILocation(line: 0, scope: !54, inlinedAt: !191)
!191 = distinct !DILocation(line: 16, column: 5, scope: !179)
!192 = !DILocation(line: 16, column: 5, scope: !179)
!193 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_ref_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !203, retainedNodes: !204)
!194 = !DIFile(filename: "<checkout>/packages/builtin/string.pony", directory: "")
!195 = !DISubroutineType(types: !196)
!196 = !{!47, !197}
!197 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 64, align: 64, dwarfAddressSpace: 0)
!198 = !DICompositeType(tag: DW_TAG_structure_type, name: "String", file: !194, line: 25, size: 256, align: 64, elements: !199, identifier: "String")
!199 = !{!200, !201, !202}
!200 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !194, line: 50, baseType: !42, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !194, line: 51, baseType: !42, size: 64, align: 64, offset: 128, flags: DIFlagPrivate)
!202 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !194, line: 52, baseType: !14, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!203 = !DISubprogram(name: "is_null_terminated", linkageName: "String_ref_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!204 = !{!205}
!205 = !DILocalVariable(name: "this", arg: 1, scope: !193, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!207 = !DILocation(line: 0, scope: !193)
!208 = !DILocation(line: 491, column: 40, scope: !193)
!209 = !DILocation(line: 491, column: 18, scope: !193)
!210 = !DILocation(line: 491, column: 13, scope: !193)
!211 = !DILocation(line: 491, column: 30, scope: !193)
!212 = !DILocation(line: 491, column: 64, scope: !193)
!213 = !DILocation(line: 491, column: 56, scope: !193)
!214 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_box_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !215, retainedNodes: !216)
!215 = !DISubprogram(name: "is_null_terminated", linkageName: "String_box_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!216 = !{!217}
!217 = !DILocalVariable(name: "this", arg: 1, scope: !214, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!218 = !DILocation(line: 0, scope: !214)
!219 = !DILocation(line: 491, column: 40, scope: !214)
!220 = !DILocation(line: 491, column: 18, scope: !214)
!221 = !DILocation(line: 491, column: 13, scope: !214)
!222 = !DILocation(line: 491, column: 30, scope: !214)
!223 = !DILocation(line: 491, column: 64, scope: !214)
!224 = !DILocation(line: 491, column: 56, scope: !214)
!225 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_val_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !226, retainedNodes: !227)
!226 = !DISubprogram(name: "is_null_terminated", linkageName: "String_val_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!227 = !{!228}
!228 = !DILocalVariable(name: "this", arg: 1, scope: !225, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!229 = !DILocation(line: 0, scope: !225)
!230 = !DILocation(line: 491, column: 40, scope: !225)
!231 = !DILocation(line: 491, column: 18, scope: !225)
!232 = !DILocation(line: 491, column: 13, scope: !225)
!233 = !DILocation(line: 491, column: 30, scope: !225)
!234 = !DILocation(line: 491, column: 64, scope: !225)
!235 = !DILocation(line: 491, column: 56, scope: !225)
!236 = distinct !DISubprogram(name: "cstring", linkageName: "String_box_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !239, retainedNodes: !240)
!237 = !DISubroutineType(types: !238)
!238 = !{!14, !197}
!239 = !DISubprogram(name: "cstring", linkageName: "String_box_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!240 = !{!241, !242}
!241 = !DILocalVariable(name: "this", arg: 1, scope: !236, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!242 = !DILocalVariable(name: "ptr", scope: !236, file: !194, line: 236, type: !14, align: 64)
!243 = !DILocation(line: 0, scope: !236)
!244 = !DILocation(line: 0, scope: !214, inlinedAt: !245)
!245 = distinct !DILocation(line: 232, column: 26, scope: !246)
!246 = distinct !DILexicalBlock(scope: !236, file: !194, line: 232, column: 5)
!247 = !DILocation(line: 491, column: 13, scope: !214, inlinedAt: !245)
!248 = !DILocation(line: 491, column: 30, scope: !214, inlinedAt: !245)
!249 = !DILocation(line: 491, column: 64, scope: !214, inlinedAt: !245)
!250 = !DILocation(line: 491, column: 56, scope: !214, inlinedAt: !245)
!251 = !DILocation(line: 233, column: 7, scope: !252)
!252 = distinct !DILexicalBlock(scope: !246, file: !194, line: 233, column: 7)
!253 = !DILocation(line: 0, scope: !54, inlinedAt: !254)
!254 = distinct !DILocation(line: 233, column: 14, scope: !255)
!255 = distinct !DILexicalBlock(scope: !246, file: !194, line: 233, column: 14)
!256 = !DILocation(line: 236, column: 40, scope: !236)
!257 = !DILocation(line: 236, column: 33, scope: !236)
!258 = !DILocation(line: 237, column: 18, scope: !236)
!259 = !DILocation(line: 238, column: 16, scope: !236)
!260 = !DILocation(line: 239, column: 5, scope: !236)
!261 = distinct !DISubprogram(name: "cstring", linkageName: "String_val_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !262, retainedNodes: !263)
!262 = !DISubprogram(name: "cstring", linkageName: "String_val_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!263 = !{!264, !265}
!264 = !DILocalVariable(name: "this", arg: 1, scope: !261, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!265 = !DILocalVariable(name: "ptr", scope: !261, file: !194, line: 236, type: !14, align: 64)
!266 = !DILocation(line: 0, scope: !261)
!267 = !DILocation(line: 0, scope: !225, inlinedAt: !268)
!268 = distinct !DILocation(line: 232, column: 26, scope: !269)
!269 = distinct !DILexicalBlock(scope: !261, file: !194, line: 232, column: 5)
!270 = !DILocation(line: 491, column: 13, scope: !225, inlinedAt: !268)
!271 = !DILocation(line: 491, column: 30, scope: !225, inlinedAt: !268)
!272 = !DILocation(line: 491, column: 64, scope: !225, inlinedAt: !268)
!273 = !DILocation(line: 491, column: 56, scope: !225, inlinedAt: !268)
!274 = !DILocation(line: 233, column: 7, scope: !275)
!275 = distinct !DILexicalBlock(scope: !269, file: !194, line: 233, column: 7)
!276 = !DILocation(line: 0, scope: !54, inlinedAt: !277)
!277 = distinct !DILocation(line: 233, column: 14, scope: !278)
!278 = distinct !DILexicalBlock(scope: !269, file: !194, line: 233, column: 14)
!279 = !DILocation(line: 236, column: 40, scope: !261)
!280 = !DILocation(line: 236, column: 33, scope: !261)
!281 = !DILocation(line: 237, column: 18, scope: !261)
!282 = !DILocation(line: 238, column: 16, scope: !261)
!283 = !DILocation(line: 239, column: 5, scope: !261)
!284 = distinct !DISubprogram(name: "cstring", linkageName: "String_ref_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !285, retainedNodes: !286)
!285 = !DISubprogram(name: "cstring", linkageName: "String_ref_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!286 = !{!287, !288}
!287 = !DILocalVariable(name: "this", arg: 1, scope: !284, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!288 = !DILocalVariable(name: "ptr", scope: !284, file: !194, line: 236, type: !14, align: 64)
!289 = !DILocation(line: 0, scope: !284)
!290 = !DILocation(line: 0, scope: !193, inlinedAt: !291)
!291 = distinct !DILocation(line: 232, column: 26, scope: !292)
!292 = distinct !DILexicalBlock(scope: !284, file: !194, line: 232, column: 5)
!293 = !DILocation(line: 491, column: 13, scope: !193, inlinedAt: !291)
!294 = !DILocation(line: 491, column: 30, scope: !193, inlinedAt: !291)
!295 = !DILocation(line: 491, column: 64, scope: !193, inlinedAt: !291)
!296 = !DILocation(line: 491, column: 56, scope: !193, inlinedAt: !291)
!297 = !DILocation(line: 233, column: 7, scope: !298)
!298 = distinct !DILexicalBlock(scope: !292, file: !194, line: 233, column: 7)
!299 = !DILocation(line: 0, scope: !54, inlinedAt: !300)
!300 = distinct !DILocation(line: 233, column: 14, scope: !301)
!301 = distinct !DILexicalBlock(scope: !292, file: !194, line: 233, column: 14)
!302 = !DILocation(line: 236, column: 40, scope: !284)
!303 = !DILocation(line: 236, column: 33, scope: !284)
!304 = !DILocation(line: 237, column: 18, scope: !284)
!305 = !DILocation(line: 238, column: 16, scope: !284)
!306 = !DILocation(line: 239, column: 5, scope: !284)
!307 = distinct !DISubprogram(name: "_set", linkageName: "String_ref__set_ZCC", scope: !194, file: !194, line: 1700, type: !308, scopeLine: 1700, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !311, retainedNodes: !312)
!308 = !DISubroutineType(types: !309)
!309 = !{!310, !197, !42, !310}
!310 = !DIBasicType(name: "U8", size: 8, encoding: DW_ATE_unsigned)
!311 = !DISubprogram(name: "_set", linkageName: "String_ref__set_ZCC", scope: !198, file: !194, line: 1700, type: !308, scopeLine: 1700, spFlags: 0)
!312 = !{!313}
!313 = !DILocalVariable(name: "this", arg: 1, scope: !307, file: !194, line: 1700, type: !206, flags: DIFlagArtificial)
!314 = !DILocation(line: 0, scope: !307)
!315 = !DILocalVariable(name: "i", arg: 2, scope: !307, file: !194, line: 1700, type: !42)
!316 = !DILocalVariable(name: "value", arg: 3, scope: !307, file: !194, line: 1700, type: !310)
!317 = !DILocation(line: 1704, column: 17, scope: !307)
!318 = distinct !DISubprogram(name: "create", linkageName: "String_ref_create_pZo", scope: !194, file: !194, line: 54, type: !319, scopeLine: 54, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !321, retainedNodes: !322)
!319 = !DISubroutineType(types: !320)
!320 = !{!197, !197, !42}
!321 = !DISubprogram(name: "create", linkageName: "String_ref_create_pZo", scope: !198, file: !194, line: 54, type: !319, scopeLine: 54, spFlags: 0)
!322 = !{!323}
!323 = !DILocalVariable(name: "this", arg: 1, scope: !318, file: !194, line: 54, type: !206, flags: DIFlagArtificial)
!324 = !DILocation(line: 0, scope: !318)
!325 = !DILocalVariable(name: "len", arg: 2, scope: !318, file: !194, line: 54, type: !42)
!326 = !DILocation(line: 58, column: 11, scope: !318)
!327 = !DILocalVariable(name: "this", arg: 1, scope: !328, file: !98, line: 490, type: !333, flags: DIFlagArtificial)
!328 = distinct !DISubprogram(name: "max_value", linkageName: "USize_val_max_value_Z", scope: !98, file: !98, line: 490, type: !329, scopeLine: 490, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !331, retainedNodes: !332)
!329 = !DISubroutineType(types: !330)
!330 = !{!42, !42}
!331 = !DISubprogram(name: "max_value", linkageName: "USize_val_max_value_Z", scope: !42, file: !98, line: 490, type: !329, scopeLine: 490, spFlags: 0)
!332 = !{!327}
!333 = !DIBasicType(name: "USize", size: 64, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!334 = !DILocation(line: 0, scope: !328, inlinedAt: !335)
!335 = distinct !DILocation(line: 59, column: 36, scope: !318)
!336 = !DILocalVariable(name: "this", arg: 1, scope: !337, file: !98, line: 564, type: !333, flags: DIFlagArtificial)
!337 = distinct !DISubprogram(name: "min", linkageName: "USize_val_min_ZZ", scope: !98, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !340, retainedNodes: !341)
!338 = !DISubroutineType(types: !339)
!339 = !{!42, !42, !42}
!340 = !DISubprogram(name: "min", linkageName: "USize_val_min_ZZ", scope: !42, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: 0)
!341 = !{!336}
!342 = !DILocation(line: 0, scope: !337, inlinedAt: !343)
!343 = distinct !DILocation(line: 59, column: 22, scope: !318)
!344 = !DILocalVariable(name: "y", arg: 2, scope: !337, file: !98, line: 564, type: !42)
!345 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !343)
!346 = distinct !DILexicalBlock(scope: !337, file: !98, line: 564, column: 31)
!347 = !DILocalVariable(name: "this", arg: 1, scope: !348, file: !98, line: 565, type: !333, flags: DIFlagArtificial)
!348 = distinct !DISubprogram(name: "max", linkageName: "USize_val_max_ZZ", scope: !98, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !349, retainedNodes: !350)
!349 = !DISubprogram(name: "max", linkageName: "USize_val_max_ZZ", scope: !42, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: 0)
!350 = !{!347}
!351 = !DILocation(line: 0, scope: !348, inlinedAt: !352)
!352 = distinct !DILocation(line: 59, column: 52, scope: !318)
!353 = !DILocalVariable(name: "y", arg: 2, scope: !348, file: !98, line: 565, type: !42)
!354 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !352)
!355 = distinct !DILexicalBlock(scope: !348, file: !98, line: 565, column: 31)
!356 = !DILocation(line: 59, column: 12, scope: !318)
!357 = !DILocation(line: 60, column: 30, scope: !318)
!358 = !DILocation(line: 60, column: 10, scope: !318)
!359 = !DILocation(line: 0, scope: !307, inlinedAt: !360)
!360 = distinct !DILocation(line: 61, column: 9, scope: !318)
!361 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !360)
!362 = !DILocation(line: 61, column: 9, scope: !318)
!363 = distinct !DISubprogram(name: "copy_cstring", linkageName: "String_ref_copy_cstring_moo", scope: !194, file: !194, line: 145, type: !364, scopeLine: 145, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !366, retainedNodes: !367)
!364 = !DISubroutineType(types: !365)
!365 = !{!197, !197, !14}
!366 = !DISubprogram(name: "copy_cstring", linkageName: "String_ref_copy_cstring_moo", scope: !198, file: !194, line: 145, type: !364, scopeLine: 145, spFlags: 0)
!367 = !{!368, !369}
!368 = !DILocalVariable(name: "this", arg: 1, scope: !363, file: !194, line: 145, type: !206, flags: DIFlagArtificial)
!369 = !DILocalVariable(name: "i", scope: !370, file: !194, line: 158, type: !42, align: 64)
!370 = distinct !DILexicalBlock(scope: !371, file: !194, line: 158, column: 7)
!371 = distinct !DILexicalBlock(scope: !363, file: !194, line: 152, column: 5)
!372 = !DILocation(line: 0, scope: !363)
!373 = !DILocalVariable(name: "str", arg: 2, scope: !363, file: !194, line: 145, type: !14)
!374 = !DILocation(line: 152, column: 19, scope: !371)
!375 = !DILocation(line: 153, column: 13, scope: !376)
!376 = distinct !DILexicalBlock(scope: !371, file: !194, line: 153, column: 7)
!377 = !DILocation(line: 154, column: 14, scope: !376)
!378 = !DILocation(line: 155, column: 32, scope: !376)
!379 = !DILocation(line: 155, column: 12, scope: !376)
!380 = !DILocation(line: 0, scope: !307, inlinedAt: !381)
!381 = distinct !DILocation(line: 156, column: 11, scope: !376)
!382 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !381)
!383 = !DILocation(line: 0, scope: !370)
!384 = !DILocation(line: 160, column: 23, scope: !385)
!385 = distinct !DILexicalBlock(scope: !370, file: !194, line: 160, column: 7)
!386 = !DILocation(line: 161, column: 15, scope: !387)
!387 = distinct !DILexicalBlock(scope: !385, file: !194, line: 161, column: 9)
!388 = !DILocation(line: 0, scope: !54, inlinedAt: !389)
!389 = distinct !DILocation(line: 161, column: 17, scope: !390)
!390 = distinct !DILexicalBlock(scope: !385, file: !194, line: 161, column: 17)
!391 = !DILocation(line: 164, column: 13, scope: !370)
!392 = !DILocation(line: 165, column: 19, scope: !370)
!393 = !DILocation(line: 0, scope: !348, inlinedAt: !394)
!394 = distinct !DILocation(line: 165, column: 27, scope: !370)
!395 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !394)
!396 = !DILocation(line: 165, column: 14, scope: !370)
!397 = !DILocation(line: 166, column: 32, scope: !370)
!398 = !DILocation(line: 166, column: 12, scope: !370)
!399 = !DILocation(line: 168, column: 28, scope: !370)
!400 = !DILocation(line: 168, column: 19, scope: !370)
!401 = !DILocation(line: 152, column: 5, scope: !363)
!402 = distinct !DISubprogram(name: "push", linkageName: "Array_String_val_ref_push_oo", scope: !403, file: !403, line: 653, type: !404, scopeLine: 653, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !414, retainedNodes: !415)
!403 = !DIFile(filename: "<checkout>/packages/builtin/array.pony", directory: "")
!404 = !DISubroutineType(types: !405)
!405 = !{!58, !406, !197}
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64, align: 64, dwarfAddressSpace: 0)
!407 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_String_val", file: !403, line: 25, size: 256, align: 64, elements: !408, identifier: "Array_String_val")
!408 = !{!409, !410, !411}
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !403, line: 89, baseType: !42, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!410 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !403, line: 90, baseType: !42, size: 64, align: 64, offset: 128, flags: DIFlagPrivate)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !403, line: 91, baseType: !412, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !413, size: 64, align: 64, dwarfAddressSpace: 0)
!413 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_String_val", file: !16, line: 91, elements: !4, identifier: "Pointer_String_val")
!414 = !DISubprogram(name: "push", linkageName: "Array_String_val_ref_push_oo", scope: !407, file: !403, line: 653, type: !404, scopeLine: 653, spFlags: 0)
!415 = !{!416}
!416 = !DILocalVariable(name: "this", arg: 1, scope: !402, file: !403, line: 653, type: !417, flags: DIFlagArtificial)
!417 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!418 = !DILocation(line: 0, scope: !402)
!419 = !DILocalVariable(name: "value", arg: 2, scope: !402, file: !403, line: 653, type: !197)
!420 = !DILocation(line: 657, column: 19, scope: !402)
!421 = !DILocalVariable(name: "this", arg: 1, scope: !422, file: !403, line: 178, type: !417, flags: DIFlagArtificial)
!422 = distinct !DISubprogram(name: "reserve", linkageName: "Array_String_val_ref_reserve_Zo", scope: !403, file: !403, line: 178, type: !423, scopeLine: 178, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !425, retainedNodes: !426)
!423 = !DISubroutineType(types: !424)
!424 = !{!58, !406, !42}
!425 = !DISubprogram(name: "reserve", linkageName: "Array_String_val_ref_reserve_Zo", scope: !407, file: !403, line: 178, type: !423, scopeLine: 178, spFlags: 0)
!426 = !{!421}
!427 = !DILocation(line: 0, scope: !422, inlinedAt: !428)
!428 = distinct !DILocation(line: 657, column: 12, scope: !402)
!429 = !DILocalVariable(name: "len", arg: 2, scope: !422, file: !403, line: 178, type: !42)
!430 = !DILocation(line: 185, column: 15, scope: !431, inlinedAt: !428)
!431 = distinct !DILexicalBlock(scope: !422, file: !403, line: 185, column: 5)
!432 = !DILocalVariable(name: "this", arg: 1, scope: !433, file: !98, line: 497, type: !333, flags: DIFlagArtificial)
!433 = distinct !DISubprogram(name: "next_pow2", linkageName: "USize_val_next_pow2_Z", scope: !98, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !434, retainedNodes: !435)
!434 = !DISubprogram(name: "next_pow2", linkageName: "USize_val_next_pow2_Z", scope: !42, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: 0)
!435 = !{!432, !436}
!436 = !DILocalVariable(name: "x", scope: !433, file: !98, line: 498, type: !42, align: 64)
!437 = !DILocation(line: 0, scope: !433, inlinedAt: !438)
!438 = distinct !DILocation(line: 186, column: 29, scope: !439, inlinedAt: !428)
!439 = distinct !DILexicalBlock(scope: !431, file: !403, line: 186, column: 7)
!440 = !DILocalVariable(name: "this", arg: 1, scope: !441, file: !98, line: 524, type: !333, flags: DIFlagArtificial)
!441 = distinct !DISubprogram(name: "clz", linkageName: "USize_val_clz_Z", scope: !98, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !442, retainedNodes: !443)
!442 = !DISubprogram(name: "clz", linkageName: "USize_val_clz_Z", scope: !42, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: 0)
!443 = !{!440}
!444 = !DILocation(line: 0, scope: !441, inlinedAt: !445)
!445 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !438)
!446 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !445)
!447 = distinct !DILexicalBlock(scope: !448, file: !98, line: 528, column: 7)
!448 = distinct !DILexicalBlock(scope: !441, file: !98, line: 525, column: 5)
!449 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !445)
!450 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !445)
!451 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !438)
!452 = distinct !DILexicalBlock(scope: !433, file: !98, line: 499, column: 11)
!453 = !DILocalVariable(name: "this", arg: 1, scope: !454, file: !98, line: 560, type: !333, flags: DIFlagArtificial)
!454 = distinct !DISubprogram(name: "bitwidth", linkageName: "USize_val_bitwidth_Z", scope: !98, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !455, retainedNodes: !456)
!455 = !DISubprogram(name: "bitwidth", linkageName: "USize_val_bitwidth_Z", scope: !42, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: 0)
!456 = !{!453}
!457 = !DILocation(line: 0, scope: !454, inlinedAt: !458)
!458 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !438)
!459 = distinct !DILexicalBlock(scope: !452, file: !98, line: 499, column: 33)
!460 = !DILocation(line: 0, scope: !348, inlinedAt: !461)
!461 = distinct !DILocation(line: 186, column: 35, scope: !439, inlinedAt: !428)
!462 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !461)
!463 = !DILocation(line: 0, scope: !348, inlinedAt: !464)
!464 = distinct !DILocation(line: 186, column: 44, scope: !439, inlinedAt: !428)
!465 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !464)
!466 = !DILocation(line: 0, scope: !348, inlinedAt: !467)
!467 = distinct !DILocation(line: 186, column: 51, scope: !439, inlinedAt: !428)
!468 = !DILocation(line: 186, column: 14, scope: !439, inlinedAt: !428)
!469 = !DILocation(line: 187, column: 27, scope: !439, inlinedAt: !428)
!470 = !DILocation(line: 187, column: 12, scope: !439, inlinedAt: !428)
!471 = !DILocation(line: 0, scope: !54, inlinedAt: !472)
!472 = distinct !DILocation(line: 187, column: 41, scope: !473, inlinedAt: !428)
!473 = distinct !DILexicalBlock(scope: !431, file: !403, line: 187, column: 41)
!474 = !DILocation(line: 0, scope: !54, inlinedAt: !475)
!475 = distinct !DILocation(line: 179, column: 5, scope: !422, inlinedAt: !428)
!476 = !DILocation(line: 658, column: 17, scope: !402)
!477 = !DILocation(line: 659, column: 19, scope: !402)
!478 = !DILocation(line: 659, column: 11, scope: !402)
!479 = !DILocation(line: 0, scope: !54, inlinedAt: !480)
!480 = distinct !DILocation(line: 654, column: 5, scope: !402)
!481 = !DILocation(line: 654, column: 5, scope: !402)
!482 = !DILocation(line: 0, scope: !422)
!483 = !DILocation(line: 185, column: 15, scope: !431)
!484 = !DILocation(line: 0, scope: !433, inlinedAt: !485)
!485 = distinct !DILocation(line: 186, column: 29, scope: !439)
!486 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !485)
!487 = !DILocation(line: 0, scope: !441, inlinedAt: !488)
!488 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !485)
!489 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !488)
!490 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !488)
!491 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !488)
!492 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !485)
!493 = !DILocation(line: 0, scope: !454, inlinedAt: !494)
!494 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !485)
!495 = !DILocation(line: 0, scope: !348, inlinedAt: !496)
!496 = distinct !DILocation(line: 186, column: 35, scope: !439)
!497 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !496)
!498 = !DILocation(line: 0, scope: !348, inlinedAt: !499)
!499 = distinct !DILocation(line: 186, column: 44, scope: !439)
!500 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !499)
!501 = !DILocation(line: 0, scope: !348, inlinedAt: !502)
!502 = distinct !DILocation(line: 186, column: 51, scope: !439)
!503 = !DILocation(line: 186, column: 14, scope: !439)
!504 = !DILocation(line: 187, column: 27, scope: !439)
!505 = !DILocation(line: 187, column: 12, scope: !439)
!506 = !DILocation(line: 0, scope: !54, inlinedAt: !507)
!507 = distinct !DILocation(line: 187, column: 41, scope: !473)
!508 = !DILocation(line: 0, scope: !54, inlinedAt: !509)
!509 = distinct !DILocation(line: 179, column: 5, scope: !422)
!510 = !DILocation(line: 179, column: 5, scope: !422)
!511 = distinct !DISubprogram(name: "create", linkageName: "Array_String_val_ref_create_pZo", scope: !403, file: !403, line: 93, type: !512, scopeLine: 93, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !514, retainedNodes: !515)
!512 = !DISubroutineType(types: !513)
!513 = !{!406, !406, !42}
!514 = !DISubprogram(name: "create", linkageName: "Array_String_val_ref_create_pZo", scope: !407, file: !403, line: 93, type: !512, scopeLine: 93, spFlags: 0)
!515 = !{!516}
!516 = !DILocalVariable(name: "this", arg: 1, scope: !511, file: !403, line: 93, type: !417, flags: DIFlagArtificial)
!517 = !DILocation(line: 0, scope: !511)
!518 = !DILocalVariable(name: "len", arg: 2, scope: !511, file: !403, line: 93, type: !42)
!519 = !DILocation(line: 97, column: 11, scope: !511)
!520 = !DILocation(line: 99, column: 12, scope: !521)
!521 = distinct !DILexicalBlock(scope: !511, file: !403, line: 99, column: 5)
!522 = !DILocation(line: 0, scope: !433, inlinedAt: !523)
!523 = distinct !DILocation(line: 100, column: 29, scope: !524)
!524 = distinct !DILexicalBlock(scope: !521, file: !403, line: 100, column: 7)
!525 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !523)
!526 = !DILocation(line: 0, scope: !441, inlinedAt: !527)
!527 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !523)
!528 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !527)
!529 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !527)
!530 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !527)
!531 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !523)
!532 = !DILocation(line: 0, scope: !454, inlinedAt: !533)
!533 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !523)
!534 = !DILocation(line: 0, scope: !348, inlinedAt: !535)
!535 = distinct !DILocation(line: 100, column: 35, scope: !524)
!536 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !535)
!537 = !DILocation(line: 0, scope: !348, inlinedAt: !538)
!538 = distinct !DILocation(line: 100, column: 44, scope: !524)
!539 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !538)
!540 = !DILocation(line: 0, scope: !348, inlinedAt: !541)
!541 = distinct !DILocation(line: 100, column: 51, scope: !524)
!542 = !DILocation(line: 100, column: 14, scope: !524)
!543 = !DILocation(line: 101, column: 31, scope: !524)
!544 = !DILocation(line: 101, column: 12, scope: !524)
!545 = !DILocation(line: 103, column: 14, scope: !546)
!546 = distinct !DILexicalBlock(scope: !521, file: !403, line: 103, column: 7)
!547 = !DILocation(line: 104, column: 12, scope: !546)
!548 = !DILocation(line: 99, column: 5, scope: !511)
!549 = distinct !DISubprogram(name: "op_not", linkageName: "Bool_box_op_not_b", scope: !550, file: !550, line: 9, type: !551, scopeLine: 9, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !553, retainedNodes: !554)
!550 = !DIFile(filename: "<checkout>/packages/builtin/bool.pony", directory: "")
!551 = !DISubroutineType(types: !552)
!552 = !{!47, !47}
!553 = !DISubprogram(name: "op_not", linkageName: "Bool_box_op_not_b", scope: !47, file: !550, line: 9, type: !551, scopeLine: 9, spFlags: 0)
!554 = !{!555}
!555 = !DILocalVariable(name: "this", arg: 1, scope: !549, file: !550, line: 9, type: !556, flags: DIFlagArtificial)
!556 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean, flags: DIFlagArtificial)
!557 = !DILocation(line: 0, scope: !549)
!558 = !DILocation(line: 9, column: 25, scope: !549)
!559 = distinct !DISubprogram(name: "op_not", linkageName: "Bool_val_op_not_b", scope: !550, file: !550, line: 9, type: !551, scopeLine: 9, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !560, retainedNodes: !561)
!560 = !DISubprogram(name: "op_not", linkageName: "Bool_val_op_not_b", scope: !47, file: !550, line: 9, type: !551, scopeLine: 9, spFlags: 0)
!561 = !{!562}
!562 = !DILocalVariable(name: "this", arg: 1, scope: !559, file: !550, line: 9, type: !556, flags: DIFlagArtificial)
!563 = !DILocation(line: 0, scope: !559)
!564 = !DILocation(line: 9, column: 25, scope: !559)
!565 = distinct !DISubprogram(name: "create", linkageName: "Bool_val_create_pbb", scope: !550, file: !550, line: 2, type: !566, scopeLine: 2, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !568, retainedNodes: !569)
!566 = !DISubroutineType(types: !567)
!567 = !{!47, !47, !47}
!568 = !DISubprogram(name: "create", linkageName: "Bool_val_create_pbb", scope: !47, file: !550, line: 2, type: !566, scopeLine: 2, spFlags: 0)
!569 = !{!570}
!570 = !DILocalVariable(name: "this", arg: 1, scope: !565, file: !550, line: 2, type: !556, flags: DIFlagArtificial)
!571 = !DILocation(line: 0, scope: !565)
!572 = !DILocalVariable(name: "from", arg: 2, scope: !565, file: !550, line: 2, type: !47)
!573 = !DILocation(line: 2, column: 29, scope: !565)
!574 = distinct !DISubprogram(name: "op_and", linkageName: "Bool_box_op_and_bb", scope: !550, file: !550, line: 6, type: !566, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !575, retainedNodes: !576)
!575 = !DISubprogram(name: "op_and", linkageName: "Bool_box_op_and_bb", scope: !47, file: !550, line: 6, type: !566, scopeLine: 6, spFlags: 0)
!576 = !{!577}
!577 = !DILocalVariable(name: "this", arg: 1, scope: !574, file: !550, line: 6, type: !556, flags: DIFlagArtificial)
!578 = !DILocation(line: 0, scope: !574)
!579 = !DILocalVariable(name: "y", arg: 2, scope: !574, file: !550, line: 6, type: !47)
!580 = !DILocation(line: 6, column: 37, scope: !574)
!581 = distinct !DISubprogram(name: "op_and", linkageName: "Bool_val_op_and_bb", scope: !550, file: !550, line: 6, type: !566, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !582, retainedNodes: !583)
!582 = !DISubprogram(name: "op_and", linkageName: "Bool_val_op_and_bb", scope: !47, file: !550, line: 6, type: !566, scopeLine: 6, spFlags: 0)
!583 = !{!584}
!584 = !DILocalVariable(name: "this", arg: 1, scope: !581, file: !550, line: 6, type: !556, flags: DIFlagArtificial)
!585 = !DILocation(line: 0, scope: !581)
!586 = !DILocalVariable(name: "y", arg: 2, scope: !581, file: !550, line: 6, type: !47)
!587 = !DILocation(line: 6, column: 37, scope: !581)
!588 = distinct !DISubprogram(name: "_read", linkageName: "Stdin_ref__read_b", scope: !32, file: !32, line: 149, type: !589, scopeLine: 149, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !591, retainedNodes: !592)
!589 = !DISubroutineType(types: !590)
!590 = !{!47, !35}
!591 = !DISubprogram(name: "_read", linkageName: "Stdin_ref__read_b", scope: !36, file: !32, line: 149, type: !589, scopeLine: 149, spFlags: 0)
!592 = !{!593, !594, !600, !601, !602, !605, !610}
!593 = !DILocalVariable(name: "this", arg: 1, scope: !588, file: !32, line: 149, type: !50, flags: DIFlagArtificial)
!594 = !DILocalVariable(name: "$0$15", scope: !595, file: !32, line: 155, type: !598, align: 64)
!595 = distinct !DILexicalBlock(scope: !596, file: !32, line: 155, column: 28)
!596 = distinct !DILexicalBlock(scope: !597, file: !32, line: 155, column: 28)
!597 = distinct !DILexicalBlock(scope: !588, file: !32, line: 155, column: 7)
!598 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !599, size: 64, align: 64, dwarfAddressSpace: 0)
!599 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputNotify", file: !32, line: 69, elements: !4, identifier: "InputNotify")
!600 = !DILocalVariable(name: "notify", scope: !597, file: !32, line: 155, type: !598, align: 64)
!601 = !DILocalVariable(name: "sum", scope: !597, file: !32, line: 156, type: !42, align: 64)
!602 = !DILocalVariable(name: "chunk_size", scope: !603, file: !32, line: 159, type: !42, align: 64)
!603 = distinct !DILexicalBlock(scope: !604, file: !32, line: 159, column: 9)
!604 = distinct !DILexicalBlock(scope: !597, file: !32, line: 158, column: 7)
!605 = !DILocalVariable(name: "data", scope: !603, file: !32, line: 160, type: !606, align: 64)
!606 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !607, size: 64, align: 64, dwarfAddressSpace: 0)
!607 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_U8_val", file: !403, line: 11, size: 256, align: 64, elements: !608, identifier: "Array_U8_val")
!608 = !{!409, !410, !609}
!609 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !403, line: 91, baseType: !14, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!610 = !DILocalVariable(name: "len", scope: !603, file: !32, line: 162, type: !42, align: 64)
!611 = !DILocation(line: 0, scope: !588)
!612 = !DILocation(line: 0, scope: !595)
!613 = !DILocation(line: 155, column: 28, scope: !614)
!614 = distinct !DILexicalBlock(scope: !615, file: !32, line: 155, column: 28)
!615 = distinct !DILexicalBlock(scope: !596, file: !32, line: 155, column: 28)
!616 = !DILocation(line: 0, scope: !597)
!617 = !DILocation(line: 0, scope: !603)
!618 = !DILocalVariable(name: "this", arg: 1, scope: !619, file: !403, line: 93, type: !624, flags: DIFlagArtificial)
!619 = distinct !DISubprogram(name: "create", linkageName: "Array_U8_val_ref_create_pZo", scope: !403, file: !403, line: 93, type: !620, scopeLine: 93, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !622, retainedNodes: !623)
!620 = !DISubroutineType(types: !621)
!621 = !{!606, !606, !42}
!622 = !DISubprogram(name: "create", linkageName: "Array_U8_val_ref_create_pZo", scope: !607, file: !403, line: 93, type: !620, scopeLine: 93, spFlags: 0)
!623 = !{!618}
!624 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !607, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!625 = !DILocation(line: 0, scope: !619, inlinedAt: !626)
!626 = distinct !DILocation(line: 160, column: 38, scope: !627)
!627 = distinct !DILexicalBlock(scope: !603, file: !32, line: 160, column: 28)
!628 = !DILocalVariable(name: "len", arg: 2, scope: !619, file: !403, line: 93, type: !42)
!629 = !DILocation(line: 97, column: 11, scope: !619, inlinedAt: !626)
!630 = !DILocation(line: 103, column: 14, scope: !631, inlinedAt: !626)
!631 = distinct !DILexicalBlock(scope: !632, file: !403, line: 103, column: 7)
!632 = distinct !DILexicalBlock(scope: !619, file: !403, line: 99, column: 5)
!633 = !DILocation(line: 104, column: 12, scope: !631, inlinedAt: !626)
!634 = !DILocalVariable(name: "this", arg: 1, scope: !635, file: !403, line: 214, type: !624, flags: DIFlagArtificial)
!635 = distinct !DISubprogram(name: "undefined", linkageName: "Array_U8_val_ref_undefined_U8_val_Zo", scope: !403, file: !403, line: 214, type: !636, scopeLine: 214, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !638, retainedNodes: !639)
!636 = !DISubroutineType(types: !637)
!637 = !{!58, !606, !42}
!638 = !DISubprogram(name: "undefined", linkageName: "Array_U8_val_ref_undefined_U8_val_Zo", scope: !607, file: !403, line: 214, type: !636, scopeLine: 214, spFlags: 0)
!639 = !{!634}
!640 = !DILocation(line: 0, scope: !635, inlinedAt: !641)
!641 = distinct !DILocation(line: 160, column: 50, scope: !627)
!642 = !DILocalVariable(name: "len", arg: 2, scope: !635, file: !403, line: 214, type: !42)
!643 = !DILocalVariable(name: "this", arg: 1, scope: !644, file: !403, line: 178, type: !624, flags: DIFlagArtificial)
!644 = distinct !DISubprogram(name: "reserve", linkageName: "Array_U8_val_ref_reserve_Zo", scope: !403, file: !403, line: 178, type: !636, scopeLine: 178, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !645, retainedNodes: !646)
!645 = !DISubprogram(name: "reserve", linkageName: "Array_U8_val_ref_reserve_Zo", scope: !607, file: !403, line: 178, type: !636, scopeLine: 178, spFlags: 0)
!646 = !{!643}
!647 = !DILocation(line: 0, scope: !644, inlinedAt: !648)
!648 = distinct !DILocation(line: 219, column: 12, scope: !635, inlinedAt: !641)
!649 = !DILocalVariable(name: "len", arg: 2, scope: !644, file: !403, line: 178, type: !42)
!650 = !DILocation(line: 185, column: 15, scope: !651, inlinedAt: !648)
!651 = distinct !DILexicalBlock(scope: !644, file: !403, line: 185, column: 5)
!652 = !DILocation(line: 0, scope: !433, inlinedAt: !653)
!653 = distinct !DILocation(line: 186, column: 29, scope: !654, inlinedAt: !648)
!654 = distinct !DILexicalBlock(scope: !651, file: !403, line: 186, column: 7)
!655 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !653)
!656 = !DILocation(line: 0, scope: !441, inlinedAt: !657)
!657 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !653)
!658 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !657)
!659 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !657)
!660 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !657)
!661 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !653)
!662 = !DILocation(line: 0, scope: !454, inlinedAt: !663)
!663 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !653)
!664 = !DILocation(line: 0, scope: !348, inlinedAt: !665)
!665 = distinct !DILocation(line: 186, column: 35, scope: !654, inlinedAt: !648)
!666 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !665)
!667 = !DILocation(line: 0, scope: !348, inlinedAt: !668)
!668 = distinct !DILocation(line: 186, column: 44, scope: !654, inlinedAt: !648)
!669 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !668)
!670 = !DILocation(line: 0, scope: !348, inlinedAt: !671)
!671 = distinct !DILocation(line: 186, column: 51, scope: !654, inlinedAt: !648)
!672 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !671)
!673 = !DILocation(line: 186, column: 14, scope: !654, inlinedAt: !648)
!674 = !DILocation(line: 187, column: 27, scope: !654, inlinedAt: !648)
!675 = !DILocation(line: 187, column: 12, scope: !654, inlinedAt: !648)
!676 = !DILocation(line: 0, scope: !54, inlinedAt: !677)
!677 = distinct !DILocation(line: 187, column: 41, scope: !678, inlinedAt: !648)
!678 = distinct !DILexicalBlock(scope: !651, file: !403, line: 187, column: 41)
!679 = !DILocation(line: 0, scope: !54, inlinedAt: !680)
!680 = distinct !DILocation(line: 179, column: 5, scope: !644, inlinedAt: !648)
!681 = !DILocation(line: 220, column: 11, scope: !635, inlinedAt: !641)
!682 = !DILocation(line: 0, scope: !54, inlinedAt: !683)
!683 = distinct !DILocation(line: 215, column: 5, scope: !635, inlinedAt: !641)
!684 = !DILocalVariable(name: "this", arg: 1, scope: !685, file: !403, line: 160, type: !624, flags: DIFlagArtificial)
!685 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_ref_cpointer_Zo", scope: !403, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !688, retainedNodes: !689)
!686 = !DISubroutineType(types: !687)
!687 = !{!14, !606, !42}
!688 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_ref_cpointer_Zo", scope: !607, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: 0)
!689 = !{!684}
!690 = !DILocation(line: 0, scope: !685, inlinedAt: !691)
!691 = distinct !DILocation(line: 162, column: 52, scope: !603)
!692 = !DILocalVariable(name: "offset", arg: 2, scope: !685, file: !403, line: 160, type: !42)
!693 = !DILocalVariable(name: "this", arg: 1, scope: !694, file: !403, line: 166, type: !624, flags: DIFlagArtificial)
!694 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_ref_size_Z", scope: !403, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !697, retainedNodes: !698)
!695 = !DISubroutineType(types: !696)
!696 = !{!42, !606}
!697 = !DISubprogram(name: "size", linkageName: "Array_U8_val_ref_size_Z", scope: !607, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: 0)
!698 = !{!693}
!699 = !DILocation(line: 0, scope: !694, inlinedAt: !700)
!700 = distinct !DILocation(line: 162, column: 65, scope: !603)
!701 = !DILocation(line: 162, column: 19, scope: !603)
!702 = !DILocation(line: 0, scope: !54, inlinedAt: !703)
!703 = distinct !DILocation(line: 204, column: 7, scope: !704)
!704 = distinct !DILexicalBlock(scope: !705, file: !32, line: 204, column: 7)
!705 = distinct !DILexicalBlock(scope: !706, file: !32, line: 165, column: 9)
!706 = distinct !DILexicalBlock(scope: !603, file: !32, line: 164, column: 9)
!707 = !DILocation(line: 166, column: 11, scope: !705)
!708 = !DILocalVariable(name: "this", arg: 1, scope: !709, file: !32, line: 207, type: !50, flags: DIFlagArtificial)
!709 = distinct !DISubprogram(name: "_close_event", linkageName: "Stdin_ref__close_event_o", scope: !32, file: !32, line: 207, type: !91, scopeLine: 207, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !710, retainedNodes: !711)
!710 = !DISubprogram(name: "_close_event", linkageName: "Stdin_ref__close_event_o", scope: !36, file: !32, line: 207, type: !91, scopeLine: 207, spFlags: 0)
!711 = !{!708}
!712 = !DILocation(line: 0, scope: !709, inlinedAt: !713)
!713 = distinct !DILocation(line: 168, column: 23, scope: !714)
!714 = distinct !DILexicalBlock(scope: !706, file: !32, line: 167, column: 9)
!715 = !DILocation(line: 211, column: 10, scope: !716, inlinedAt: !713)
!716 = distinct !DILexicalBlock(scope: !709, file: !32, line: 211, column: 7)
!717 = !DILocation(line: 211, column: 28, scope: !716, inlinedAt: !713)
!718 = !DILocation(line: 212, column: 9, scope: !719, inlinedAt: !713)
!719 = distinct !DILexicalBlock(scope: !716, file: !32, line: 212, column: 9)
!720 = !DILocation(line: 0, scope: !68, inlinedAt: !721)
!721 = distinct !DILocation(line: 213, column: 27, scope: !719, inlinedAt: !713)
!722 = !DILocation(line: 0, scope: !80, inlinedAt: !723)
!723 = distinct !DILocation(line: 213, column: 32, scope: !719, inlinedAt: !713)
!724 = !DILocation(line: 213, column: 16, scope: !719, inlinedAt: !713)
!725 = !DILocation(line: 0, scope: !54, inlinedAt: !726)
!726 = distinct !DILocation(line: 213, column: 33, scope: !727, inlinedAt: !713)
!727 = distinct !DILexicalBlock(scope: !716, file: !32, line: 213, column: 33)
!728 = !DILocation(line: 0, scope: !54, inlinedAt: !729)
!729 = distinct !DILocation(line: 208, column: 7, scope: !709, inlinedAt: !713)
!730 = !DILocation(line: 169, column: 25, scope: !714)
!731 = !DILocation(line: 0, scope: !54, inlinedAt: !732)
!732 = distinct !DILocation(line: 170, column: 21, scope: !714)
!733 = !DILocation(line: 170, column: 19, scope: !714)
!734 = !DILocation(line: 0, scope: !54, inlinedAt: !735)
!735 = distinct !DILocation(line: 204, column: 7, scope: !736)
!736 = distinct !DILexicalBlock(scope: !714, file: !32, line: 204, column: 7)
!737 = !DILocation(line: 171, column: 11, scope: !714)
!738 = !DILocation(line: 0, scope: !709, inlinedAt: !739)
!739 = distinct !DILocation(line: 173, column: 23, scope: !740)
!740 = distinct !DILexicalBlock(scope: !706, file: !32, line: 172, column: 9)
!741 = !DILocation(line: 211, column: 10, scope: !716, inlinedAt: !739)
!742 = !DILocation(line: 211, column: 28, scope: !716, inlinedAt: !739)
!743 = !DILocation(line: 212, column: 9, scope: !719, inlinedAt: !739)
!744 = !DILocation(line: 0, scope: !68, inlinedAt: !745)
!745 = distinct !DILocation(line: 213, column: 27, scope: !719, inlinedAt: !739)
!746 = !DILocation(line: 0, scope: !80, inlinedAt: !747)
!747 = distinct !DILocation(line: 213, column: 32, scope: !719, inlinedAt: !739)
!748 = !DILocation(line: 213, column: 16, scope: !719, inlinedAt: !739)
!749 = !DILocation(line: 0, scope: !54, inlinedAt: !750)
!750 = distinct !DILocation(line: 213, column: 33, scope: !727, inlinedAt: !739)
!751 = !DILocation(line: 0, scope: !54, inlinedAt: !752)
!752 = distinct !DILocation(line: 208, column: 7, scope: !709, inlinedAt: !739)
!753 = !DILocation(line: 174, column: 29, scope: !740)
!754 = !DILocation(line: 175, column: 25, scope: !740)
!755 = !DILocation(line: 0, scope: !54, inlinedAt: !756)
!756 = distinct !DILocation(line: 176, column: 21, scope: !740)
!757 = !DILocation(line: 176, column: 19, scope: !740)
!758 = !DILocation(line: 0, scope: !54, inlinedAt: !759)
!759 = distinct !DILocation(line: 204, column: 7, scope: !760)
!760 = distinct !DILexicalBlock(scope: !740, file: !32, line: 204, column: 7)
!761 = !DILocation(line: 177, column: 11, scope: !740)
!762 = !DILocation(line: 0, scope: !54, inlinedAt: !763)
!763 = distinct !DILocation(line: 177, column: 18, scope: !764)
!764 = distinct !DILexicalBlock(scope: !765, file: !32, line: 177, column: 18)
!765 = distinct !DILexicalBlock(scope: !706, file: !32, line: 177, column: 18)
!766 = !DILocalVariable(name: "this", arg: 1, scope: !767, file: !403, line: 391, type: !624, flags: DIFlagArtificial)
!767 = distinct !DISubprogram(name: "truncate", linkageName: "Array_U8_val_ref_truncate_Zo", scope: !403, file: !403, line: 391, type: !636, scopeLine: 391, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !768, retainedNodes: !769)
!768 = !DISubprogram(name: "truncate", linkageName: "Array_U8_val_ref_truncate_Zo", scope: !607, file: !403, line: 391, type: !636, scopeLine: 391, spFlags: 0)
!769 = !{!766}
!770 = !DILocation(line: 0, scope: !767, inlinedAt: !771)
!771 = distinct !DILocation(line: 180, column: 22, scope: !603)
!772 = !DILocalVariable(name: "len", arg: 2, scope: !767, file: !403, line: 391, type: !42)
!773 = !DILocation(line: 0, scope: !337, inlinedAt: !774)
!774 = distinct !DILocation(line: 396, column: 22, scope: !767, inlinedAt: !771)
!775 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !774)
!776 = !DILocation(line: 396, column: 11, scope: !767, inlinedAt: !771)
!777 = !DILocation(line: 0, scope: !54, inlinedAt: !778)
!778 = distinct !DILocation(line: 392, column: 5, scope: !767, inlinedAt: !771)
!779 = !DILocation(line: 181, column: 15, scope: !603)
!780 = !DILocation(line: 0, scope: !54, inlinedAt: !781)
!781 = distinct !DILocation(line: 187, column: 11, scope: !782)
!782 = distinct !DILexicalBlock(scope: !783, file: !32, line: 187, column: 11)
!783 = distinct !DILexicalBlock(scope: !603, file: !32, line: 183, column: 9)
!784 = !DILocation(line: 190, column: 19, scope: !603)
!785 = !DILocation(line: 194, column: 24, scope: !786)
!786 = distinct !DILexicalBlock(scope: !787, file: !32, line: 194, column: 13)
!787 = distinct !DILexicalBlock(scope: !788, file: !32, line: 193, column: 11)
!788 = distinct !DILexicalBlock(scope: !789, file: !32, line: 193, column: 11)
!789 = distinct !DILexicalBlock(scope: !603, file: !32, line: 192, column: 9)
!790 = !DILocation(line: 0, scope: !54, inlinedAt: !791)
!791 = distinct !DILocation(line: 194, column: 25, scope: !792)
!792 = distinct !DILexicalBlock(scope: !787, file: !32, line: 194, column: 25)
!793 = !DILocation(line: 197, column: 11, scope: !788)
!794 = !DILocation(line: 0, scope: !54, inlinedAt: !795)
!795 = distinct !DILocation(line: 197, column: 11, scope: !796)
!796 = distinct !DILexicalBlock(scope: !789, file: !32, line: 197, column: 11)
!797 = !DILocation(line: 0, scope: !54, inlinedAt: !798)
!798 = distinct !DILocation(line: 198, column: 9, scope: !799)
!799 = distinct !DILexicalBlock(scope: !604, file: !32, line: 198, column: 9)
!800 = !DILocation(line: 0, scope: !54, inlinedAt: !801)
!801 = distinct !DILocation(line: 204, column: 7, scope: !802)
!802 = distinct !DILexicalBlock(scope: !588, file: !32, line: 204, column: 7)
!803 = !DILocation(line: 0, scope: !709, inlinedAt: !804)
!804 = distinct !DILocation(line: 203, column: 19, scope: !805)
!805 = distinct !DILexicalBlock(scope: !588, file: !32, line: 203, column: 7)
!806 = !DILocation(line: 211, column: 10, scope: !716, inlinedAt: !804)
!807 = !DILocation(line: 211, column: 28, scope: !716, inlinedAt: !804)
!808 = !DILocation(line: 212, column: 9, scope: !719, inlinedAt: !804)
!809 = !DILocation(line: 0, scope: !68, inlinedAt: !810)
!810 = distinct !DILocation(line: 213, column: 27, scope: !719, inlinedAt: !804)
!811 = !DILocation(line: 0, scope: !80, inlinedAt: !812)
!812 = distinct !DILocation(line: 213, column: 32, scope: !719, inlinedAt: !804)
!813 = !DILocation(line: 213, column: 16, scope: !719, inlinedAt: !804)
!814 = !DILocation(line: 0, scope: !54, inlinedAt: !815)
!815 = distinct !DILocation(line: 213, column: 33, scope: !727, inlinedAt: !804)
!816 = !DILocation(line: 0, scope: !54, inlinedAt: !817)
!817 = distinct !DILocation(line: 208, column: 7, scope: !709, inlinedAt: !804)
!818 = !DILocation(line: 0, scope: !54, inlinedAt: !819)
!819 = distinct !DILocation(line: 204, column: 7, scope: !820)
!820 = distinct !DILexicalBlock(scope: !588, file: !32, line: 204, column: 7)
!821 = !DILocation(line: 154, column: 5, scope: !588)
!822 = !DILocation(line: 0, scope: !709)
!823 = !DILocation(line: 211, column: 10, scope: !716)
!824 = !DILocation(line: 211, column: 28, scope: !716)
!825 = !DILocation(line: 212, column: 9, scope: !719)
!826 = !DILocation(line: 0, scope: !68, inlinedAt: !827)
!827 = distinct !DILocation(line: 213, column: 27, scope: !719)
!828 = !DILocation(line: 0, scope: !80, inlinedAt: !829)
!829 = distinct !DILocation(line: 213, column: 32, scope: !719)
!830 = !DILocation(line: 213, column: 16, scope: !719)
!831 = !DILocation(line: 0, scope: !54, inlinedAt: !832)
!832 = distinct !DILocation(line: 213, column: 33, scope: !727)
!833 = !DILocation(line: 0, scope: !54, inlinedAt: !834)
!834 = distinct !DILocation(line: 208, column: 7, scope: !709)
!835 = !DILocation(line: 208, column: 7, scope: !709)
!836 = distinct !DISubprogram(name: "_event_notify", linkageName: "Stdin_tag__event_notify_topIpIo", scope: !32, file: !32, line: 125, type: !837, scopeLine: 125, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !839, retainedNodes: !840)
!837 = !DISubroutineType(types: !838)
!838 = !{!58, !35, !44, !101, !101}
!839 = !DISubprogram(name: "_event_notify", linkageName: "Stdin_tag__event_notify_topIpIo", scope: !36, file: !32, line: 125, type: !837, scopeLine: 125, spFlags: 0)
!840 = !{!841, !842, !849}
!841 = !DILocalVariable(name: "this", arg: 1, scope: !836, file: !32, line: 125, type: !50, flags: DIFlagArtificial)
!842 = !DILocalVariable(name: "$0$14", scope: !843, file: !32, line: 134, type: !598, align: 64)
!843 = distinct !DILexicalBlock(scope: !844, file: !32, line: 134, column: 30)
!844 = distinct !DILexicalBlock(scope: !845, file: !32, line: 134, column: 30)
!845 = distinct !DILexicalBlock(scope: !846, file: !32, line: 134, column: 9)
!846 = distinct !DILexicalBlock(scope: !847, file: !32, line: 132, column: 7)
!847 = distinct !DILexicalBlock(scope: !848, file: !32, line: 131, column: 5)
!848 = distinct !DILexicalBlock(scope: !836, file: !32, line: 129, column: 5)
!849 = !DILocalVariable(name: "notify", scope: !845, file: !32, line: 134, type: !598, align: 64)
!850 = !DILocation(line: 0, scope: !836)
!851 = !DILocalVariable(name: "event", arg: 2, scope: !836, file: !32, line: 125, type: !44)
!852 = !DILocalVariable(name: "flags", arg: 3, scope: !836, file: !32, line: 125, type: !101)
!853 = !DILocalVariable(name: "arg", arg: 4, scope: !836, file: !32, line: 125, type: !101)
!854 = !DILocation(line: 0, scope: !68, inlinedAt: !855)
!855 = distinct !DILocation(line: 129, column: 17, scope: !848)
!856 = !DILocalVariable(name: "this", arg: 1, scope: !857, file: !69, line: 28, type: !76, flags: DIFlagArtificial)
!857 = distinct !DISubprogram(name: "disposable", linkageName: "AsioEvent_val_disposable_Ib", scope: !69, file: !69, line: 28, type: !858, scopeLine: 28, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !860, retainedNodes: !861)
!858 = !DISubroutineType(types: !859)
!859 = !{!47, !72, !101}
!860 = !DISubprogram(name: "disposable", linkageName: "AsioEvent_val_disposable_Ib", scope: !73, file: !69, line: 28, type: !858, scopeLine: 28, spFlags: 0)
!861 = !{!856}
!862 = !DILocation(line: 0, scope: !857, inlinedAt: !863)
!863 = distinct !DILocation(line: 129, column: 28, scope: !848)
!864 = !DILocalVariable(name: "flags", arg: 2, scope: !857, file: !69, line: 28, type: !101)
!865 = !DILocation(line: 32, column: 11, scope: !857, inlinedAt: !863)
!866 = !DILocation(line: 130, column: 7, scope: !867)
!867 = distinct !DILexicalBlock(scope: !848, file: !32, line: 130, column: 7)
!868 = !DILocation(line: 131, column: 30, scope: !847)
!869 = !DILocation(line: 131, column: 20, scope: !847)
!870 = !DILocation(line: 0, scope: !68, inlinedAt: !871)
!871 = distinct !DILocation(line: 131, column: 43, scope: !847)
!872 = !DILocalVariable(name: "this", arg: 1, scope: !873, file: !69, line: 34, type: !76, flags: DIFlagArtificial)
!873 = distinct !DISubprogram(name: "errored", linkageName: "AsioEvent_val_errored_Ib", scope: !69, file: !69, line: 34, type: !858, scopeLine: 34, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !874, retainedNodes: !875)
!874 = !DISubprogram(name: "errored", linkageName: "AsioEvent_val_errored_Ib", scope: !73, file: !69, line: 34, type: !858, scopeLine: 34, spFlags: 0)
!875 = !{!872}
!876 = !DILocation(line: 0, scope: !873, inlinedAt: !877)
!877 = distinct !DILocation(line: 131, column: 51, scope: !847)
!878 = !DILocalVariable(name: "flags", arg: 2, scope: !873, file: !69, line: 34, type: !101)
!879 = !DILocation(line: 0, scope: !709, inlinedAt: !880)
!880 = distinct !DILocation(line: 132, column: 19, scope: !846)
!881 = !DILocation(line: 211, column: 10, scope: !716, inlinedAt: !880)
!882 = !DILocation(line: 211, column: 28, scope: !716, inlinedAt: !880)
!883 = !DILocation(line: 212, column: 9, scope: !719, inlinedAt: !880)
!884 = !DILocation(line: 0, scope: !68, inlinedAt: !885)
!885 = distinct !DILocation(line: 213, column: 27, scope: !719, inlinedAt: !880)
!886 = !DILocation(line: 0, scope: !80, inlinedAt: !887)
!887 = distinct !DILocation(line: 213, column: 32, scope: !719, inlinedAt: !880)
!888 = !DILocation(line: 213, column: 16, scope: !719, inlinedAt: !880)
!889 = !DILocation(line: 0, scope: !54, inlinedAt: !890)
!890 = distinct !DILocation(line: 213, column: 33, scope: !727, inlinedAt: !880)
!891 = !DILocation(line: 0, scope: !54, inlinedAt: !892)
!892 = distinct !DILocation(line: 208, column: 7, scope: !709, inlinedAt: !880)
!893 = !DILocation(line: 0, scope: !843)
!894 = !DILocation(line: 134, column: 30, scope: !895)
!895 = distinct !DILexicalBlock(scope: !896, file: !32, line: 134, column: 30)
!896 = distinct !DILexicalBlock(scope: !844, file: !32, line: 134, column: 30)
!897 = !DILocation(line: 0, scope: !845)
!898 = !DILocation(line: 135, column: 27, scope: !845)
!899 = !DILocation(line: 136, column: 23, scope: !845)
!900 = !DILocation(line: 0, scope: !54, inlinedAt: !901)
!901 = distinct !DILocation(line: 136, column: 24, scope: !902)
!902 = distinct !DILexicalBlock(scope: !846, file: !32, line: 136, column: 24)
!903 = !DILocation(line: 0, scope: !54, inlinedAt: !904)
!904 = distinct !DILocation(line: 136, column: 24, scope: !905)
!905 = distinct !DILexicalBlock(scope: !846, file: !32, line: 136, column: 24)
!906 = !DILocation(line: 0, scope: !54, inlinedAt: !907)
!907 = distinct !DILocation(line: 136, column: 24, scope: !908)
!908 = distinct !DILexicalBlock(scope: !846, file: !32, line: 136, column: 24)
!909 = !DILocation(line: 0, scope: !54, inlinedAt: !910)
!910 = distinct !DILocation(line: 138, column: 17, scope: !846)
!911 = !DILocation(line: 138, column: 15, scope: !846)
!912 = !DILocation(line: 139, column: 30, scope: !913)
!913 = distinct !DILexicalBlock(scope: !847, file: !32, line: 139, column: 5)
!914 = !DILocation(line: 139, column: 20, scope: !913)
!915 = !DILocation(line: 0, scope: !68, inlinedAt: !916)
!916 = distinct !DILocation(line: 139, column: 43, scope: !913)
!917 = !DILocalVariable(name: "this", arg: 1, scope: !918, file: !69, line: 16, type: !76, flags: DIFlagArtificial)
!918 = distinct !DISubprogram(name: "readable", linkageName: "AsioEvent_val_readable_Ib", scope: !69, file: !69, line: 16, type: !858, scopeLine: 16, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !919, retainedNodes: !920)
!919 = !DISubprogram(name: "readable", linkageName: "AsioEvent_val_readable_Ib", scope: !73, file: !69, line: 16, type: !858, scopeLine: 16, spFlags: 0)
!920 = !{!917}
!921 = !DILocation(line: 0, scope: !918, inlinedAt: !922)
!922 = distinct !DILocation(line: 139, column: 52, scope: !913)
!923 = !DILocalVariable(name: "flags", arg: 2, scope: !918, file: !69, line: 16, type: !101)
!924 = !DILocation(line: 140, column: 12, scope: !925)
!925 = distinct !DILexicalBlock(scope: !913, file: !32, line: 140, column: 7)
!926 = !DILocation(line: 0, scope: !54, inlinedAt: !927)
!927 = distinct !DILocation(line: 140, column: 13, scope: !928)
!928 = distinct !DILexicalBlock(scope: !913, file: !32, line: 140, column: 13)
!929 = distinct !DISubprogram(name: "create", linkageName: "I32_val_create_pii", scope: !930, file: !930, line: 202, type: !931, scopeLine: 202, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !934, retainedNodes: !935)
!930 = !DIFile(filename: "<checkout>/packages/builtin/signed.pony", directory: "")
!931 = !DISubroutineType(types: !932)
!932 = !{!933, !933, !933}
!933 = !DIBasicType(name: "I32", size: 32, encoding: DW_ATE_signed)
!934 = !DISubprogram(name: "create", linkageName: "I32_val_create_pii", scope: !933, file: !930, line: 202, type: !931, scopeLine: 202, spFlags: 0)
!935 = !{!936}
!936 = !DILocalVariable(name: "this", arg: 1, scope: !929, file: !930, line: 202, type: !937, flags: DIFlagArtificial)
!937 = !DIBasicType(name: "I32", size: 32, encoding: DW_ATE_signed, flags: DIFlagArtificial)
!938 = !DILocation(line: 0, scope: !929)
!939 = !DILocalVariable(name: "value", arg: 2, scope: !929, file: !930, line: 202, type: !933)
!940 = !DILocation(line: 202, column: 29, scope: !929)
!941 = distinct !DISubprogram(name: "eq", linkageName: "U64_val_eq_Wb", scope: !98, file: !98, line: 172, type: !942, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !945, retainedNodes: !946)
!942 = !DISubroutineType(types: !943)
!943 = !{!47, !944, !944}
!944 = !DIBasicType(name: "U64", size: 64, encoding: DW_ATE_unsigned)
!945 = !DISubprogram(name: "eq", linkageName: "U64_val_eq_Wb", scope: !944, file: !98, line: 172, type: !942, scopeLine: 172, spFlags: 0)
!946 = !{!947}
!947 = !DILocalVariable(name: "this", arg: 1, scope: !941, file: !98, line: 172, type: !948, flags: DIFlagArtificial)
!948 = !DIBasicType(name: "U64", size: 64, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!949 = !DILocation(line: 0, scope: !941)
!950 = !DILocalVariable(name: "y", arg: 2, scope: !941, file: !98, line: 172, type: !944)
!951 = !DILocation(line: 172, column: 35, scope: !941)
!952 = distinct !DISubprogram(name: "eq", linkageName: "U64_box_eq_Wb", scope: !98, file: !98, line: 172, type: !942, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !953, retainedNodes: !954)
!953 = !DISubprogram(name: "eq", linkageName: "U64_box_eq_Wb", scope: !944, file: !98, line: 172, type: !942, scopeLine: 172, spFlags: 0)
!954 = !{!955}
!955 = !DILocalVariable(name: "this", arg: 1, scope: !952, file: !98, line: 172, type: !948, flags: DIFlagArtificial)
!956 = !DILocation(line: 0, scope: !952)
!957 = !DILocalVariable(name: "y", arg: 2, scope: !952, file: !98, line: 172, type: !944)
!958 = !DILocation(line: 172, column: 35, scope: !952)
!959 = distinct !DISubprogram(name: "create", linkageName: "U64_val_create_pWW", scope: !98, file: !98, line: 259, type: !960, scopeLine: 259, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !962, retainedNodes: !963)
!960 = !DISubroutineType(types: !961)
!961 = !{!944, !944, !944}
!962 = !DISubprogram(name: "create", linkageName: "U64_val_create_pWW", scope: !944, file: !98, line: 259, type: !960, scopeLine: 259, spFlags: 0)
!963 = !{!964}
!964 = !DILocalVariable(name: "this", arg: 1, scope: !959, file: !98, line: 259, type: !948, flags: DIFlagArtificial)
!965 = !DILocation(line: 0, scope: !959)
!966 = !DILocalVariable(name: "value", arg: 2, scope: !959, file: !98, line: 259, type: !944)
!967 = !DILocation(line: 259, column: 29, scope: !959)
!968 = !DILocation(line: 0, scope: !454)
!969 = !DILocation(line: 560, column: 28, scope: !454)
!970 = distinct !DISubprogram(name: "bitwidth", linkageName: "USize_box_bitwidth_Z", scope: !98, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !971, retainedNodes: !972)
!971 = !DISubprogram(name: "bitwidth", linkageName: "USize_box_bitwidth_Z", scope: !42, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: 0)
!972 = !{!973}
!973 = !DILocalVariable(name: "this", arg: 1, scope: !970, file: !98, line: 560, type: !333, flags: DIFlagArtificial)
!974 = !DILocation(line: 0, scope: !970)
!975 = !DILocation(line: 560, column: 28, scope: !970)
!976 = distinct !DISubprogram(name: "sub", linkageName: "USize_box_sub_ZZ", scope: !98, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !977, retainedNodes: !978)
!977 = !DISubprogram(name: "sub", linkageName: "USize_box_sub_ZZ", scope: !42, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: 0)
!978 = !{!979}
!979 = !DILocalVariable(name: "this", arg: 1, scope: !976, file: !98, line: 142, type: !333, flags: DIFlagArtificial)
!980 = !DILocation(line: 0, scope: !976)
!981 = !DILocalVariable(name: "y", arg: 2, scope: !976, file: !98, line: 142, type: !42)
!982 = !DILocation(line: 142, column: 28, scope: !976)
!983 = distinct !DISubprogram(name: "sub", linkageName: "USize_val_sub_ZZ", scope: !98, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !984, retainedNodes: !985)
!984 = !DISubprogram(name: "sub", linkageName: "USize_val_sub_ZZ", scope: !42, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: 0)
!985 = !{!986}
!986 = !DILocalVariable(name: "this", arg: 1, scope: !983, file: !98, line: 142, type: !333, flags: DIFlagArtificial)
!987 = !DILocation(line: 0, scope: !983)
!988 = !DILocalVariable(name: "y", arg: 2, scope: !983, file: !98, line: 142, type: !42)
!989 = !DILocation(line: 142, column: 28, scope: !983)
!990 = distinct !DISubprogram(name: "shl", linkageName: "USize_val_shl_ZZ", scope: !98, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !991, retainedNodes: !992)
!991 = !DISubprogram(name: "shl", linkageName: "USize_val_shl_ZZ", scope: !42, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: 0)
!992 = !{!993}
!993 = !DILocalVariable(name: "this", arg: 1, scope: !990, file: !98, line: 445, type: !333, flags: DIFlagArtificial)
!994 = !DILocation(line: 0, scope: !990)
!995 = !DILocalVariable(name: "y", arg: 2, scope: !990, file: !98, line: 445, type: !42)
!996 = !DILocation(line: 445, column: 28, scope: !990)
!997 = distinct !DISubprogram(name: "shl", linkageName: "USize_box_shl_ZZ", scope: !98, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !998, retainedNodes: !999)
!998 = !DISubprogram(name: "shl", linkageName: "USize_box_shl_ZZ", scope: !42, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: 0)
!999 = !{!1000}
!1000 = !DILocalVariable(name: "this", arg: 1, scope: !997, file: !98, line: 445, type: !333, flags: DIFlagArtificial)
!1001 = !DILocation(line: 0, scope: !997)
!1002 = !DILocalVariable(name: "y", arg: 2, scope: !997, file: !98, line: 445, type: !42)
!1003 = !DILocation(line: 445, column: 28, scope: !997)
!1004 = distinct !DISubprogram(name: "ne", linkageName: "USize_val_ne_Zb", scope: !98, file: !98, line: 173, type: !1005, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1007, retainedNodes: !1008)
!1005 = !DISubroutineType(types: !1006)
!1006 = !{!47, !42, !42}
!1007 = !DISubprogram(name: "ne", linkageName: "USize_val_ne_Zb", scope: !42, file: !98, line: 173, type: !1005, scopeLine: 173, spFlags: 0)
!1008 = !{!1009}
!1009 = !DILocalVariable(name: "this", arg: 1, scope: !1004, file: !98, line: 173, type: !333, flags: DIFlagArtificial)
!1010 = !DILocation(line: 0, scope: !1004)
!1011 = !DILocalVariable(name: "y", arg: 2, scope: !1004, file: !98, line: 173, type: !42)
!1012 = !DILocation(line: 173, column: 35, scope: !1004)
!1013 = distinct !DISubprogram(name: "ne", linkageName: "USize_box_ne_Zb", scope: !98, file: !98, line: 173, type: !1005, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1014, retainedNodes: !1015)
!1014 = !DISubprogram(name: "ne", linkageName: "USize_box_ne_Zb", scope: !42, file: !98, line: 173, type: !1005, scopeLine: 173, spFlags: 0)
!1015 = !{!1016}
!1016 = !DILocalVariable(name: "this", arg: 1, scope: !1013, file: !98, line: 173, type: !333, flags: DIFlagArtificial)
!1017 = !DILocation(line: 0, scope: !1013)
!1018 = !DILocalVariable(name: "y", arg: 2, scope: !1013, file: !98, line: 173, type: !42)
!1019 = !DILocation(line: 173, column: 35, scope: !1013)
!1020 = !DILocation(line: 0, scope: !328)
!1021 = !DILocation(line: 491, column: 5, scope: !328)
!1022 = distinct !DISubprogram(name: "add", linkageName: "USize_val_add_ZZ", scope: !98, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1023, retainedNodes: !1024)
!1023 = !DISubprogram(name: "add", linkageName: "USize_val_add_ZZ", scope: !42, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: 0)
!1024 = !{!1025}
!1025 = !DILocalVariable(name: "this", arg: 1, scope: !1022, file: !98, line: 141, type: !333, flags: DIFlagArtificial)
!1026 = !DILocation(line: 0, scope: !1022)
!1027 = !DILocalVariable(name: "y", arg: 2, scope: !1022, file: !98, line: 141, type: !42)
!1028 = !DILocation(line: 141, column: 28, scope: !1022)
!1029 = distinct !DISubprogram(name: "add", linkageName: "USize_box_add_ZZ", scope: !98, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1030, retainedNodes: !1031)
!1030 = !DISubprogram(name: "add", linkageName: "USize_box_add_ZZ", scope: !42, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: 0)
!1031 = !{!1032}
!1032 = !DILocalVariable(name: "this", arg: 1, scope: !1029, file: !98, line: 141, type: !333, flags: DIFlagArtificial)
!1033 = !DILocation(line: 0, scope: !1029)
!1034 = !DILocalVariable(name: "y", arg: 2, scope: !1029, file: !98, line: 141, type: !42)
!1035 = !DILocation(line: 141, column: 28, scope: !1029)
!1036 = !DILocation(line: 0, scope: !433)
!1037 = !DILocation(line: 498, column: 19, scope: !433)
!1038 = !DILocation(line: 0, scope: !441, inlinedAt: !1039)
!1039 = distinct !DILocation(line: 498, column: 27, scope: !433)
!1040 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1039)
!1041 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1039)
!1042 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1039)
!1043 = !DILocation(line: 499, column: 16, scope: !452)
!1044 = !DILocation(line: 0, scope: !454, inlinedAt: !1045)
!1045 = distinct !DILocation(line: 499, column: 41, scope: !459)
!1046 = !DILocation(line: 499, column: 7, scope: !433)
!1047 = distinct !DISubprogram(name: "next_pow2", linkageName: "USize_box_next_pow2_Z", scope: !98, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1048, retainedNodes: !1049)
!1048 = !DISubprogram(name: "next_pow2", linkageName: "USize_box_next_pow2_Z", scope: !42, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: 0)
!1049 = !{!1050, !1051}
!1050 = !DILocalVariable(name: "this", arg: 1, scope: !1047, file: !98, line: 497, type: !333, flags: DIFlagArtificial)
!1051 = !DILocalVariable(name: "x", scope: !1047, file: !98, line: 498, type: !42, align: 64)
!1052 = !DILocation(line: 0, scope: !1047)
!1053 = !DILocation(line: 498, column: 19, scope: !1047)
!1054 = !DILocation(line: 0, scope: !441, inlinedAt: !1055)
!1055 = distinct !DILocation(line: 498, column: 27, scope: !1047)
!1056 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1055)
!1057 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1055)
!1058 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1055)
!1059 = !DILocation(line: 499, column: 16, scope: !1060)
!1060 = distinct !DILexicalBlock(scope: !1047, file: !98, line: 499, column: 11)
!1061 = !DILocation(line: 0, scope: !454, inlinedAt: !1062)
!1062 = distinct !DILocation(line: 499, column: 41, scope: !1063)
!1063 = distinct !DILexicalBlock(scope: !1060, file: !98, line: 499, column: 33)
!1064 = !DILocation(line: 499, column: 7, scope: !1047)
!1065 = distinct !DISubprogram(name: "eq", linkageName: "USize_box_eq_Zb", scope: !98, file: !98, line: 172, type: !1005, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1066, retainedNodes: !1067)
!1066 = !DISubprogram(name: "eq", linkageName: "USize_box_eq_Zb", scope: !42, file: !98, line: 172, type: !1005, scopeLine: 172, spFlags: 0)
!1067 = !{!1068}
!1068 = !DILocalVariable(name: "this", arg: 1, scope: !1065, file: !98, line: 172, type: !333, flags: DIFlagArtificial)
!1069 = !DILocation(line: 0, scope: !1065)
!1070 = !DILocalVariable(name: "y", arg: 2, scope: !1065, file: !98, line: 172, type: !42)
!1071 = !DILocation(line: 172, column: 35, scope: !1065)
!1072 = distinct !DISubprogram(name: "eq", linkageName: "USize_val_eq_Zb", scope: !98, file: !98, line: 172, type: !1005, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1073, retainedNodes: !1074)
!1073 = !DISubprogram(name: "eq", linkageName: "USize_val_eq_Zb", scope: !42, file: !98, line: 172, type: !1005, scopeLine: 172, spFlags: 0)
!1074 = !{!1075}
!1075 = !DILocalVariable(name: "this", arg: 1, scope: !1072, file: !98, line: 172, type: !333, flags: DIFlagArtificial)
!1076 = !DILocation(line: 0, scope: !1072)
!1077 = !DILocalVariable(name: "y", arg: 2, scope: !1072, file: !98, line: 172, type: !42)
!1078 = !DILocation(line: 172, column: 35, scope: !1072)
!1079 = distinct !DISubprogram(name: "clz", linkageName: "USize_box_clz_Z", scope: !98, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1080, retainedNodes: !1081)
!1080 = !DISubprogram(name: "clz", linkageName: "USize_box_clz_Z", scope: !42, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: 0)
!1081 = !{!1082}
!1082 = !DILocalVariable(name: "this", arg: 1, scope: !1079, file: !98, line: 524, type: !333, flags: DIFlagArtificial)
!1083 = !DILocation(line: 0, scope: !1079)
!1084 = !DILocation(line: 528, column: 32, scope: !1085)
!1085 = distinct !DILexicalBlock(scope: !1086, file: !98, line: 528, column: 7)
!1086 = distinct !DILexicalBlock(scope: !1079, file: !98, line: 525, column: 5)
!1087 = !DILocation(line: 528, column: 7, scope: !1085)
!1088 = !DILocation(line: 528, column: 48, scope: !1085)
!1089 = !DILocation(line: 525, column: 5, scope: !1079)
!1090 = !DILocation(line: 0, scope: !441)
!1091 = !DILocation(line: 528, column: 32, scope: !447)
!1092 = !DILocation(line: 528, column: 7, scope: !447)
!1093 = !DILocation(line: 528, column: 48, scope: !447)
!1094 = !DILocation(line: 525, column: 5, scope: !441)
!1095 = !DILocation(line: 0, scope: !348)
!1096 = !DILocation(line: 565, column: 39, scope: !355)
!1097 = !DILocation(line: 565, column: 31, scope: !348)
!1098 = distinct !DISubprogram(name: "max", linkageName: "USize_box_max_ZZ", scope: !98, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1099, retainedNodes: !1100)
!1099 = !DISubprogram(name: "max", linkageName: "USize_box_max_ZZ", scope: !42, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: 0)
!1100 = !{!1101}
!1101 = !DILocalVariable(name: "this", arg: 1, scope: !1098, file: !98, line: 565, type: !333, flags: DIFlagArtificial)
!1102 = !DILocation(line: 0, scope: !1098)
!1103 = !DILocalVariable(name: "y", arg: 2, scope: !1098, file: !98, line: 565, type: !42)
!1104 = !DILocation(line: 565, column: 39, scope: !1105)
!1105 = distinct !DILexicalBlock(scope: !1098, file: !98, line: 565, column: 31)
!1106 = !DILocation(line: 565, column: 31, scope: !1098)
!1107 = distinct !DISubprogram(name: "neg", linkageName: "USize_val_neg_Z", scope: !98, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1108, retainedNodes: !1109)
!1108 = !DISubprogram(name: "neg", linkageName: "USize_val_neg_Z", scope: !42, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: 0)
!1109 = !{!1110}
!1110 = !DILocalVariable(name: "this", arg: 1, scope: !1107, file: !98, line: 159, type: !333, flags: DIFlagArtificial)
!1111 = !DILocation(line: 0, scope: !1107)
!1112 = !DILocation(line: 159, column: 19, scope: !1107)
!1113 = distinct !DISubprogram(name: "neg", linkageName: "USize_box_neg_Z", scope: !98, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1114, retainedNodes: !1115)
!1114 = !DISubprogram(name: "neg", linkageName: "USize_box_neg_Z", scope: !42, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: 0)
!1115 = !{!1116}
!1116 = !DILocalVariable(name: "this", arg: 1, scope: !1113, file: !98, line: 159, type: !333, flags: DIFlagArtificial)
!1117 = !DILocation(line: 0, scope: !1113)
!1118 = !DILocation(line: 159, column: 19, scope: !1113)
!1119 = !DILocation(line: 0, scope: !337)
!1120 = !DILocation(line: 564, column: 39, scope: !346)
!1121 = !DILocation(line: 564, column: 31, scope: !337)
!1122 = distinct !DISubprogram(name: "min", linkageName: "USize_box_min_ZZ", scope: !98, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1123, retainedNodes: !1124)
!1123 = !DISubprogram(name: "min", linkageName: "USize_box_min_ZZ", scope: !42, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: 0)
!1124 = !{!1125}
!1125 = !DILocalVariable(name: "this", arg: 1, scope: !1122, file: !98, line: 564, type: !333, flags: DIFlagArtificial)
!1126 = !DILocation(line: 0, scope: !1122)
!1127 = !DILocalVariable(name: "y", arg: 2, scope: !1122, file: !98, line: 564, type: !42)
!1128 = !DILocation(line: 564, column: 39, scope: !1129)
!1129 = distinct !DILexicalBlock(scope: !1122, file: !98, line: 564, column: 31)
!1130 = !DILocation(line: 564, column: 31, scope: !1122)
!1131 = distinct !DISubprogram(name: "create", linkageName: "USize_val_create_pZZ", scope: !98, file: !98, line: 485, type: !338, scopeLine: 485, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1132, retainedNodes: !1133)
!1132 = !DISubprogram(name: "create", linkageName: "USize_val_create_pZZ", scope: !42, file: !98, line: 485, type: !338, scopeLine: 485, spFlags: 0)
!1133 = !{!1134}
!1134 = !DILocalVariable(name: "this", arg: 1, scope: !1131, file: !98, line: 485, type: !333, flags: DIFlagArtificial)
!1135 = !DILocation(line: 0, scope: !1131)
!1136 = !DILocalVariable(name: "value", arg: 2, scope: !1131, file: !98, line: 485, type: !42)
!1137 = !DILocation(line: 485, column: 31, scope: !1131)
!1138 = distinct !DISubprogram(name: "lt", linkageName: "USize_val_lt_Zb", scope: !98, file: !98, line: 174, type: !1005, scopeLine: 174, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1139, retainedNodes: !1140)
!1139 = !DISubprogram(name: "lt", linkageName: "USize_val_lt_Zb", scope: !42, file: !98, line: 174, type: !1005, scopeLine: 174, spFlags: 0)
!1140 = !{!1141}
!1141 = !DILocalVariable(name: "this", arg: 1, scope: !1138, file: !98, line: 174, type: !333, flags: DIFlagArtificial)
!1142 = !DILocation(line: 0, scope: !1138)
!1143 = !DILocalVariable(name: "y", arg: 2, scope: !1138, file: !98, line: 174, type: !42)
!1144 = !DILocation(line: 174, column: 35, scope: !1138)
!1145 = distinct !DISubprogram(name: "lt", linkageName: "USize_box_lt_Zb", scope: !98, file: !98, line: 174, type: !1005, scopeLine: 174, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1146, retainedNodes: !1147)
!1146 = !DISubprogram(name: "lt", linkageName: "USize_box_lt_Zb", scope: !42, file: !98, line: 174, type: !1005, scopeLine: 174, spFlags: 0)
!1147 = !{!1148}
!1148 = !DILocalVariable(name: "this", arg: 1, scope: !1145, file: !98, line: 174, type: !333, flags: DIFlagArtificial)
!1149 = !DILocation(line: 0, scope: !1145)
!1150 = !DILocalVariable(name: "y", arg: 2, scope: !1145, file: !98, line: 174, type: !42)
!1151 = !DILocation(line: 174, column: 35, scope: !1145)
!1152 = distinct !DISubprogram(name: "gt", linkageName: "USize_val_gt_Zb", scope: !98, file: !98, line: 177, type: !1005, scopeLine: 177, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1153, retainedNodes: !1154)
!1153 = !DISubprogram(name: "gt", linkageName: "USize_val_gt_Zb", scope: !42, file: !98, line: 177, type: !1005, scopeLine: 177, spFlags: 0)
!1154 = !{!1155}
!1155 = !DILocalVariable(name: "this", arg: 1, scope: !1152, file: !98, line: 177, type: !333, flags: DIFlagArtificial)
!1156 = !DILocation(line: 0, scope: !1152)
!1157 = !DILocalVariable(name: "y", arg: 2, scope: !1152, file: !98, line: 177, type: !42)
!1158 = !DILocation(line: 177, column: 35, scope: !1152)
!1159 = distinct !DISubprogram(name: "gt", linkageName: "USize_box_gt_Zb", scope: !98, file: !98, line: 177, type: !1005, scopeLine: 177, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1160, retainedNodes: !1161)
!1160 = !DISubprogram(name: "gt", linkageName: "USize_box_gt_Zb", scope: !42, file: !98, line: 177, type: !1005, scopeLine: 177, spFlags: 0)
!1161 = !{!1162}
!1162 = !DILocalVariable(name: "this", arg: 1, scope: !1159, file: !98, line: 177, type: !333, flags: DIFlagArtificial)
!1163 = !DILocation(line: 0, scope: !1159)
!1164 = !DILocalVariable(name: "y", arg: 2, scope: !1159, file: !98, line: 177, type: !42)
!1165 = !DILocation(line: 177, column: 35, scope: !1159)
!1166 = !DILocation(line: 0, scope: !694)
!1167 = !DILocation(line: 170, column: 5, scope: !694)
!1168 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_val_size_Z", scope: !403, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1169, retainedNodes: !1170)
!1169 = !DISubprogram(name: "size", linkageName: "Array_U8_val_val_size_Z", scope: !607, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: 0)
!1170 = !{!1171}
!1171 = !DILocalVariable(name: "this", arg: 1, scope: !1168, file: !403, line: 166, type: !624, flags: DIFlagArtificial)
!1172 = !DILocation(line: 0, scope: !1168)
!1173 = !DILocation(line: 170, column: 5, scope: !1168)
!1174 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_box_size_Z", scope: !403, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1175, retainedNodes: !1176)
!1175 = !DISubprogram(name: "size", linkageName: "Array_U8_val_box_size_Z", scope: !607, file: !403, line: 166, type: !695, scopeLine: 166, spFlags: 0)
!1176 = !{!1177}
!1177 = !DILocalVariable(name: "this", arg: 1, scope: !1174, file: !403, line: 166, type: !624, flags: DIFlagArtificial)
!1178 = !DILocation(line: 0, scope: !1174)
!1179 = !DILocation(line: 170, column: 5, scope: !1174)
!1180 = !DILocation(line: 0, scope: !644)
!1181 = !DILocation(line: 185, column: 15, scope: !651)
!1182 = !DILocation(line: 0, scope: !433, inlinedAt: !1183)
!1183 = distinct !DILocation(line: 186, column: 29, scope: !654)
!1184 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !1183)
!1185 = !DILocation(line: 0, scope: !441, inlinedAt: !1186)
!1186 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !1183)
!1187 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1186)
!1188 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1186)
!1189 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1186)
!1190 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !1183)
!1191 = !DILocation(line: 0, scope: !454, inlinedAt: !1192)
!1192 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !1183)
!1193 = !DILocation(line: 0, scope: !348, inlinedAt: !1194)
!1194 = distinct !DILocation(line: 186, column: 35, scope: !654)
!1195 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1194)
!1196 = !DILocation(line: 0, scope: !348, inlinedAt: !1197)
!1197 = distinct !DILocation(line: 186, column: 44, scope: !654)
!1198 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1197)
!1199 = !DILocation(line: 0, scope: !348, inlinedAt: !1200)
!1200 = distinct !DILocation(line: 186, column: 51, scope: !654)
!1201 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1200)
!1202 = !DILocation(line: 186, column: 14, scope: !654)
!1203 = !DILocation(line: 187, column: 27, scope: !654)
!1204 = !DILocation(line: 187, column: 12, scope: !654)
!1205 = !DILocation(line: 0, scope: !54, inlinedAt: !1206)
!1206 = distinct !DILocation(line: 187, column: 41, scope: !678)
!1207 = !DILocation(line: 0, scope: !54, inlinedAt: !1208)
!1208 = distinct !DILocation(line: 179, column: 5, scope: !644)
!1209 = !DILocation(line: 179, column: 5, scope: !644)
!1210 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_box_cpointer_Zo", scope: !403, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1211, retainedNodes: !1212)
!1211 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_box_cpointer_Zo", scope: !607, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: 0)
!1212 = !{!1213}
!1213 = !DILocalVariable(name: "this", arg: 1, scope: !1210, file: !403, line: 160, type: !624, flags: DIFlagArtificial)
!1214 = !DILocation(line: 0, scope: !1210)
!1215 = !DILocalVariable(name: "offset", arg: 2, scope: !1210, file: !403, line: 160, type: !42)
!1216 = !DILocation(line: 164, column: 17, scope: !1210)
!1217 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_val_cpointer_Zo", scope: !403, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1218, retainedNodes: !1219)
!1218 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_val_cpointer_Zo", scope: !607, file: !403, line: 160, type: !686, scopeLine: 160, spFlags: 0)
!1219 = !{!1220}
!1220 = !DILocalVariable(name: "this", arg: 1, scope: !1217, file: !403, line: 160, type: !624, flags: DIFlagArtificial)
!1221 = !DILocation(line: 0, scope: !1217)
!1222 = !DILocalVariable(name: "offset", arg: 2, scope: !1217, file: !403, line: 160, type: !42)
!1223 = !DILocation(line: 164, column: 17, scope: !1217)
!1224 = !DILocation(line: 0, scope: !685)
!1225 = !DILocation(line: 164, column: 17, scope: !685)
!1226 = !DILocation(line: 0, scope: !635)
!1227 = !DILocation(line: 0, scope: !644, inlinedAt: !1228)
!1228 = distinct !DILocation(line: 219, column: 12, scope: !635)
!1229 = !DILocation(line: 185, column: 15, scope: !651, inlinedAt: !1228)
!1230 = !DILocation(line: 0, scope: !433, inlinedAt: !1231)
!1231 = distinct !DILocation(line: 186, column: 29, scope: !654, inlinedAt: !1228)
!1232 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !1231)
!1233 = !DILocation(line: 0, scope: !441, inlinedAt: !1234)
!1234 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !1231)
!1235 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1234)
!1236 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1234)
!1237 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1234)
!1238 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !1231)
!1239 = !DILocation(line: 0, scope: !454, inlinedAt: !1240)
!1240 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !1231)
!1241 = !DILocation(line: 0, scope: !348, inlinedAt: !1242)
!1242 = distinct !DILocation(line: 186, column: 35, scope: !654, inlinedAt: !1228)
!1243 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1242)
!1244 = !DILocation(line: 0, scope: !348, inlinedAt: !1245)
!1245 = distinct !DILocation(line: 186, column: 44, scope: !654, inlinedAt: !1228)
!1246 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1245)
!1247 = !DILocation(line: 0, scope: !348, inlinedAt: !1248)
!1248 = distinct !DILocation(line: 186, column: 51, scope: !654, inlinedAt: !1228)
!1249 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1248)
!1250 = !DILocation(line: 186, column: 14, scope: !654, inlinedAt: !1228)
!1251 = !DILocation(line: 187, column: 27, scope: !654, inlinedAt: !1228)
!1252 = !DILocation(line: 187, column: 12, scope: !654, inlinedAt: !1228)
!1253 = !DILocation(line: 0, scope: !54, inlinedAt: !1254)
!1254 = distinct !DILocation(line: 187, column: 41, scope: !678, inlinedAt: !1228)
!1255 = !DILocation(line: 0, scope: !54, inlinedAt: !1256)
!1256 = distinct !DILocation(line: 179, column: 5, scope: !644, inlinedAt: !1228)
!1257 = !DILocation(line: 220, column: 11, scope: !635)
!1258 = !DILocation(line: 0, scope: !54, inlinedAt: !1259)
!1259 = distinct !DILocation(line: 215, column: 5, scope: !635)
!1260 = !DILocation(line: 215, column: 5, scope: !635)
!1261 = !DILocation(line: 0, scope: !619)
!1262 = !DILocation(line: 97, column: 11, scope: !619)
!1263 = !DILocation(line: 99, column: 12, scope: !632)
!1264 = !DILocation(line: 0, scope: !433, inlinedAt: !1265)
!1265 = distinct !DILocation(line: 100, column: 29, scope: !1266)
!1266 = distinct !DILexicalBlock(scope: !632, file: !403, line: 100, column: 7)
!1267 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !1265)
!1268 = !DILocation(line: 0, scope: !441, inlinedAt: !1269)
!1269 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !1265)
!1270 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1269)
!1271 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1269)
!1272 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1269)
!1273 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !1265)
!1274 = !DILocation(line: 0, scope: !454, inlinedAt: !1275)
!1275 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !1265)
!1276 = !DILocation(line: 0, scope: !348, inlinedAt: !1277)
!1277 = distinct !DILocation(line: 100, column: 35, scope: !1266)
!1278 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1277)
!1279 = !DILocation(line: 0, scope: !348, inlinedAt: !1280)
!1280 = distinct !DILocation(line: 100, column: 44, scope: !1266)
!1281 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1280)
!1282 = !DILocation(line: 0, scope: !348, inlinedAt: !1283)
!1283 = distinct !DILocation(line: 100, column: 51, scope: !1266)
!1284 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1283)
!1285 = !DILocation(line: 100, column: 14, scope: !1266)
!1286 = !DILocation(line: 101, column: 31, scope: !1266)
!1287 = !DILocation(line: 101, column: 12, scope: !1266)
!1288 = !DILocation(line: 103, column: 14, scope: !631)
!1289 = !DILocation(line: 104, column: 12, scope: !631)
!1290 = !DILocation(line: 99, column: 5, scope: !619)
!1291 = !DILocation(line: 0, scope: !767)
!1292 = !DILocation(line: 0, scope: !337, inlinedAt: !1293)
!1293 = distinct !DILocation(line: 396, column: 22, scope: !767)
!1294 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !1293)
!1295 = !DILocation(line: 396, column: 11, scope: !767)
!1296 = !DILocation(line: 0, scope: !54, inlinedAt: !1297)
!1297 = distinct !DILocation(line: 392, column: 5, scope: !767)
!1298 = !DILocation(line: 392, column: 5, scope: !767)
!1299 = distinct !DISubprogram(name: "_create", linkageName: "Env_ref__create_pIioioo", scope: !168, file: !168, line: 37, type: !1300, scopeLine: 37, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1320, retainedNodes: !1321)
!1300 = !DISubroutineType(types: !1301)
!1301 = !{!1302, !1302, !101, !1318, !1318}
!1302 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1303, size: 64, align: 64, dwarfAddressSpace: 0)
!1303 = !DICompositeType(tag: DW_TAG_structure_type, name: "Env", file: !168, line: 75, size: 512, align: 64, elements: !1304, identifier: "Env")
!1304 = !{!1305, !1306, !1309, !1312, !1313, !1314, !1315}
!1305 = !DIDerivedType(tag: DW_TAG_member, name: "root", file: !168, line: 9, baseType: !183, size: 64, align: 64, offset: 64)
!1306 = !DIDerivedType(tag: DW_TAG_member, name: "input", file: !168, line: 14, baseType: !1307, size: 64, align: 64, offset: 128)
!1307 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1308, size: 64, align: 64, dwarfAddressSpace: 0)
!1308 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputStream", file: !32, line: 14, elements: !4, identifier: "InputStream")
!1309 = !DIDerivedType(tag: DW_TAG_member, name: "out", file: !168, line: 19, baseType: !1310, size: 64, align: 64, offset: 192)
!1310 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1311, size: 64, align: 64, dwarfAddressSpace: 0)
!1311 = !DICompositeType(tag: DW_TAG_structure_type, name: "OutStream", file: !7, line: 19, elements: !4, identifier: "OutStream")
!1312 = !DIDerivedType(tag: DW_TAG_member, name: "err", file: !168, line: 22, baseType: !1310, size: 64, align: 64, offset: 256)
!1313 = !DIDerivedType(tag: DW_TAG_member, name: "args", file: !168, line: 25, baseType: !406, size: 64, align: 64, offset: 320)
!1314 = !DIDerivedType(tag: DW_TAG_member, name: "vars", file: !168, line: 28, baseType: !406, size: 64, align: 64, offset: 384)
!1315 = !DIDerivedType(tag: DW_TAG_member, name: "exitcode", file: !168, line: 31, baseType: !1316, size: 64, align: 64, offset: 448)
!1316 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1317, size: 64, align: 64, dwarfAddressSpace: 0)
!1317 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$6", file: !168, line: 31, elements: !4, identifier: "$0$6")
!1318 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1319, size: 64, align: 64, dwarfAddressSpace: 0)
!1319 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_Pointer_U8_val_ref", file: !16, line: 39, elements: !4, identifier: "Pointer_Pointer_U8_val_ref")
!1320 = !DISubprogram(name: "_create", linkageName: "Env_ref__create_pIioioo", scope: !1303, file: !168, line: 37, type: !1300, scopeLine: 37, spFlags: 0)
!1321 = !{!1322}
!1322 = !DILocalVariable(name: "this", arg: 1, scope: !1299, file: !168, line: 37, type: !1323, flags: DIFlagArtificial)
!1323 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1303, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!1324 = !DILocation(line: 0, scope: !1299)
!1325 = !DILocalVariable(name: "argc", arg: 2, scope: !1299, file: !168, line: 37, type: !101)
!1326 = !DILocalVariable(name: "argv", arg: 3, scope: !1299, file: !168, line: 37, type: !1318)
!1327 = !DILocalVariable(name: "envp", arg: 4, scope: !1299, file: !168, line: 37, type: !1318)
!1328 = !DILocation(line: 0, scope: !179, inlinedAt: !1329)
!1329 = distinct !DILocation(line: 46, column: 31, scope: !1299)
!1330 = !DILocation(line: 0, scope: !54, inlinedAt: !1331)
!1331 = distinct !DILocation(line: 16, column: 5, scope: !179, inlinedAt: !1329)
!1332 = !DILocation(line: 46, column: 10, scope: !1299)
!1333 = !DILocation(line: 47, column: 5, scope: !1299)
!1334 = !DILocation(line: 49, column: 27, scope: !1299)
!1335 = !DILocation(line: 49, column: 26, scope: !1299)
!1336 = !DILocation(line: 49, column: 11, scope: !1299)
!1337 = !DILocation(line: 50, column: 25, scope: !1299)
!1338 = !DILocation(line: 50, column: 9, scope: !1299)
!1339 = !DILocation(line: 51, column: 25, scope: !1299)
!1340 = !DILocation(line: 51, column: 9, scope: !1299)
!1341 = !DILocation(line: 53, column: 51, scope: !1299)
!1342 = !DILocation(line: 53, column: 34, scope: !1299)
!1343 = !DILocation(line: 53, column: 10, scope: !1299)
!1344 = !DILocalVariable(name: "this", arg: 1, scope: !1345, file: !168, line: 76, type: !1323, flags: DIFlagArtificial)
!1345 = distinct !DISubprogram(name: "_count_strings", linkageName: "Env_tag__count_strings_oZ", scope: !168, file: !168, line: 76, type: !1346, scopeLine: 76, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1348, retainedNodes: !1349)
!1346 = !DISubroutineType(types: !1347)
!1347 = !{!42, !1302, !1318}
!1348 = !DISubprogram(name: "_count_strings", linkageName: "Env_tag__count_strings_oZ", scope: !1303, file: !168, line: 76, type: !1346, scopeLine: 76, spFlags: 0)
!1349 = !{!1344, !1350, !1351}
!1350 = !DILocalVariable(name: "i", scope: !1345, file: !168, line: 81, type: !42, align: 64)
!1351 = !DILocalVariable(name: "entry", scope: !1352, file: !168, line: 84, type: !14, align: 64)
!1352 = distinct !DILexicalBlock(scope: !1345, file: !168, line: 83, column: 5)
!1353 = !DILocation(line: 0, scope: !1345, inlinedAt: !1354)
!1354 = distinct !DILocation(line: 54, column: 55, scope: !1299)
!1355 = !DILocalVariable(name: "data", arg: 2, scope: !1345, file: !168, line: 76, type: !1318)
!1356 = !DILocation(line: 77, column: 20, scope: !1357, inlinedAt: !1354)
!1357 = distinct !DILexicalBlock(scope: !1345, file: !168, line: 77, column: 5)
!1358 = !DILocation(line: 78, column: 7, scope: !1359, inlinedAt: !1354)
!1359 = distinct !DILexicalBlock(scope: !1357, file: !168, line: 78, column: 7)
!1360 = !DILocation(line: 0, scope: !54, inlinedAt: !1361)
!1361 = distinct !DILocation(line: 78, column: 14, scope: !1362, inlinedAt: !1354)
!1362 = distinct !DILexicalBlock(scope: !1357, file: !168, line: 78, column: 14)
!1363 = !DILocation(line: 84, column: 30, scope: !1352, inlinedAt: !1354)
!1364 = !DILocation(line: 0, scope: !1352, inlinedAt: !1354)
!1365 = !DILocation(line: 85, column: 24, scope: !1352, inlinedAt: !1354)
!1366 = !DILocation(line: 87, column: 13, scope: !1367, inlinedAt: !1354)
!1367 = distinct !DILexicalBlock(scope: !1352, file: !168, line: 87, column: 7)
!1368 = !DILocation(line: 0, scope: !54, inlinedAt: !1369)
!1369 = distinct !DILocation(line: 87, column: 15, scope: !1370, inlinedAt: !1354)
!1370 = distinct !DILexicalBlock(scope: !1352, file: !168, line: 87, column: 15)
!1371 = !DILocation(line: 89, column: 5, scope: !1345, inlinedAt: !1354)
!1372 = !DILocation(line: 54, column: 34, scope: !1299)
!1373 = !DILocation(line: 54, column: 10, scope: !1299)
!1374 = !DILocation(line: 0, scope: !167, inlinedAt: !1375)
!1375 = distinct !DILocation(line: 56, column: 16, scope: !1299)
!1376 = !DILocation(line: 56, column: 14, scope: !1299)
!1377 = !DILocation(line: 0, scope: !1345)
!1378 = !DILocation(line: 77, column: 20, scope: !1357)
!1379 = !DILocation(line: 78, column: 7, scope: !1359)
!1380 = !DILocation(line: 0, scope: !54, inlinedAt: !1381)
!1381 = distinct !DILocation(line: 78, column: 14, scope: !1362)
!1382 = !DILocation(line: 84, column: 30, scope: !1352)
!1383 = !DILocation(line: 0, scope: !1352)
!1384 = !DILocation(line: 85, column: 24, scope: !1352)
!1385 = !DILocation(line: 87, column: 13, scope: !1367)
!1386 = !DILocation(line: 0, scope: !54, inlinedAt: !1387)
!1387 = distinct !DILocation(line: 87, column: 15, scope: !1370)
!1388 = !DILocation(line: 89, column: 5, scope: !1345)
!1389 = distinct !DISubprogram(name: "_strings_from_pointers", linkageName: "Env_tag__strings_from_pointers_oZo", scope: !168, file: !168, line: 91, type: !1390, scopeLine: 91, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1392, retainedNodes: !1393)
!1390 = !DISubroutineType(types: !1391)
!1391 = !{!406, !1302, !1318, !42}
!1392 = !DISubprogram(name: "_strings_from_pointers", linkageName: "Env_tag__strings_from_pointers_oZo", scope: !1303, file: !168, line: 91, type: !1390, scopeLine: 91, spFlags: 0)
!1393 = !{!1394, !1395, !1396, !1397}
!1394 = !DILocalVariable(name: "this", arg: 1, scope: !1389, file: !168, line: 91, type: !1323, flags: DIFlagArtificial)
!1395 = !DILocalVariable(name: "array", scope: !1389, file: !168, line: 96, type: !406, align: 64)
!1396 = !DILocalVariable(name: "i", scope: !1389, file: !168, line: 97, type: !42, align: 64)
!1397 = !DILocalVariable(name: "entry", scope: !1398, file: !168, line: 100, type: !14, align: 64)
!1398 = distinct !DILexicalBlock(scope: !1399, file: !168, line: 100, column: 7)
!1399 = distinct !DILexicalBlock(scope: !1389, file: !168, line: 99, column: 5)
!1400 = !DILocation(line: 0, scope: !1389)
!1401 = !DILocalVariable(name: "data", arg: 2, scope: !1389, file: !168, line: 91, type: !1318)
!1402 = !DILocalVariable(name: "len", arg: 3, scope: !1389, file: !168, line: 91, type: !42)
!1403 = !DILocation(line: 0, scope: !511, inlinedAt: !1404)
!1404 = distinct !DILocation(line: 96, column: 38, scope: !1405)
!1405 = distinct !DILexicalBlock(scope: !1389, file: !168, line: 96, column: 25)
!1406 = !DILocation(line: 97, column: 11, scope: !511, inlinedAt: !1404)
!1407 = !DILocation(line: 99, column: 12, scope: !521, inlinedAt: !1404)
!1408 = !DILocation(line: 0, scope: !433, inlinedAt: !1409)
!1409 = distinct !DILocation(line: 100, column: 29, scope: !524, inlinedAt: !1404)
!1410 = !DILocation(line: 498, column: 19, scope: !433, inlinedAt: !1409)
!1411 = !DILocation(line: 0, scope: !441, inlinedAt: !1412)
!1412 = distinct !DILocation(line: 498, column: 27, scope: !433, inlinedAt: !1409)
!1413 = !DILocation(line: 528, column: 32, scope: !447, inlinedAt: !1412)
!1414 = !DILocation(line: 528, column: 7, scope: !447, inlinedAt: !1412)
!1415 = !DILocation(line: 528, column: 48, scope: !447, inlinedAt: !1412)
!1416 = !DILocation(line: 499, column: 16, scope: !452, inlinedAt: !1409)
!1417 = !DILocation(line: 0, scope: !454, inlinedAt: !1418)
!1418 = distinct !DILocation(line: 499, column: 41, scope: !459, inlinedAt: !1409)
!1419 = !DILocation(line: 0, scope: !348, inlinedAt: !1420)
!1420 = distinct !DILocation(line: 100, column: 35, scope: !524, inlinedAt: !1404)
!1421 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1420)
!1422 = !DILocation(line: 0, scope: !348, inlinedAt: !1423)
!1423 = distinct !DILocation(line: 100, column: 44, scope: !524, inlinedAt: !1404)
!1424 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1423)
!1425 = !DILocation(line: 0, scope: !348, inlinedAt: !1426)
!1426 = distinct !DILocation(line: 100, column: 51, scope: !524, inlinedAt: !1404)
!1427 = !DILocation(line: 100, column: 14, scope: !524, inlinedAt: !1404)
!1428 = !DILocation(line: 101, column: 31, scope: !524, inlinedAt: !1404)
!1429 = !DILocation(line: 101, column: 12, scope: !524, inlinedAt: !1404)
!1430 = !DILocation(line: 103, column: 14, scope: !546, inlinedAt: !1404)
!1431 = !DILocation(line: 104, column: 12, scope: !546, inlinedAt: !1404)
!1432 = !DILocation(line: 99, column: 13, scope: !1399)
!1433 = !DILocation(line: 0, scope: !1398)
!1434 = !DILocation(line: 100, column: 37, scope: !1398)
!1435 = !DILocation(line: 100, column: 30, scope: !1398)
!1436 = !DILocation(line: 0, scope: !363, inlinedAt: !1437)
!1437 = distinct !DILocation(line: 101, column: 45, scope: !1438)
!1438 = distinct !DILexicalBlock(scope: !1398, file: !168, line: 101, column: 26)
!1439 = !DILocation(line: 152, column: 19, scope: !371, inlinedAt: !1437)
!1440 = !DILocation(line: 153, column: 13, scope: !376, inlinedAt: !1437)
!1441 = !DILocation(line: 154, column: 14, scope: !376, inlinedAt: !1437)
!1442 = !DILocation(line: 155, column: 32, scope: !376, inlinedAt: !1437)
!1443 = !DILocation(line: 155, column: 12, scope: !376, inlinedAt: !1437)
!1444 = !DILocation(line: 0, scope: !307, inlinedAt: !1445)
!1445 = distinct !DILocation(line: 156, column: 11, scope: !376, inlinedAt: !1437)
!1446 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !1445)
!1447 = !DILocation(line: 0, scope: !370, inlinedAt: !1437)
!1448 = !DILocation(line: 160, column: 23, scope: !385, inlinedAt: !1437)
!1449 = !DILocation(line: 161, column: 15, scope: !387, inlinedAt: !1437)
!1450 = !DILocation(line: 0, scope: !54, inlinedAt: !1451)
!1451 = distinct !DILocation(line: 161, column: 17, scope: !390, inlinedAt: !1437)
!1452 = !DILocation(line: 164, column: 13, scope: !370, inlinedAt: !1437)
!1453 = !DILocation(line: 165, column: 19, scope: !370, inlinedAt: !1437)
!1454 = !DILocation(line: 0, scope: !348, inlinedAt: !1455)
!1455 = distinct !DILocation(line: 165, column: 27, scope: !370, inlinedAt: !1437)
!1456 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1455)
!1457 = !DILocation(line: 165, column: 14, scope: !370, inlinedAt: !1437)
!1458 = !DILocation(line: 166, column: 32, scope: !370, inlinedAt: !1437)
!1459 = !DILocation(line: 166, column: 12, scope: !370, inlinedAt: !1437)
!1460 = !DILocation(line: 168, column: 28, scope: !370, inlinedAt: !1437)
!1461 = !DILocation(line: 168, column: 19, scope: !370, inlinedAt: !1437)
!1462 = !DILocation(line: 101, column: 17, scope: !1398)
!1463 = !DILocation(line: 0, scope: !54, inlinedAt: !1464)
!1464 = distinct !DILocation(line: 101, column: 56, scope: !1465)
!1465 = distinct !DILexicalBlock(scope: !1399, file: !168, line: 101, column: 56)
!1466 = !DILocation(line: 104, column: 5, scope: !1389)
!1467 = !DILocation(line: 0, scope: !54)
!1468 = !DILocation(line: 1, column: 1, scope: !54)
!1469 = !DILocation(line: 0, scope: !918)
!1470 = !DILocation(line: 20, column: 26, scope: !918)
!1471 = distinct !DISubprogram(name: "readable", linkageName: "AsioEvent_box_readable_Ib", scope: !69, file: !69, line: 16, type: !858, scopeLine: 16, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1472, retainedNodes: !1473)
!1472 = !DISubprogram(name: "readable", linkageName: "AsioEvent_box_readable_Ib", scope: !73, file: !69, line: 16, type: !858, scopeLine: 16, spFlags: 0)
!1473 = !{!1474}
!1474 = !DILocalVariable(name: "this", arg: 1, scope: !1471, file: !69, line: 16, type: !76, flags: DIFlagArtificial)
!1475 = !DILocation(line: 0, scope: !1471)
!1476 = !DILocalVariable(name: "flags", arg: 2, scope: !1471, file: !69, line: 16, type: !101)
!1477 = !DILocation(line: 20, column: 26, scope: !1471)
!1478 = distinct !DISubprogram(name: "errored", linkageName: "AsioEvent_box_errored_Ib", scope: !69, file: !69, line: 34, type: !858, scopeLine: 34, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1479, retainedNodes: !1480)
!1479 = !DISubprogram(name: "errored", linkageName: "AsioEvent_box_errored_Ib", scope: !73, file: !69, line: 34, type: !858, scopeLine: 34, spFlags: 0)
!1480 = !{!1481}
!1481 = !DILocalVariable(name: "this", arg: 1, scope: !1478, file: !69, line: 34, type: !76, flags: DIFlagArtificial)
!1482 = !DILocation(line: 0, scope: !1478)
!1483 = !DILocalVariable(name: "flags", arg: 2, scope: !1478, file: !69, line: 34, type: !101)
!1484 = !DILocation(line: 40, column: 26, scope: !1478)
!1485 = !DILocation(line: 0, scope: !873)
!1486 = !DILocation(line: 40, column: 26, scope: !873)
!1487 = distinct !DISubprogram(name: "disposable", linkageName: "AsioEvent_box_disposable_Ib", scope: !69, file: !69, line: 28, type: !858, scopeLine: 28, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1488, retainedNodes: !1489)
!1488 = !DISubprogram(name: "disposable", linkageName: "AsioEvent_box_disposable_Ib", scope: !73, file: !69, line: 28, type: !858, scopeLine: 28, spFlags: 0)
!1489 = !{!1490}
!1490 = !DILocalVariable(name: "this", arg: 1, scope: !1487, file: !69, line: 28, type: !76, flags: DIFlagArtificial)
!1491 = !DILocation(line: 0, scope: !1487)
!1492 = !DILocalVariable(name: "flags", arg: 2, scope: !1487, file: !69, line: 28, type: !101)
!1493 = !DILocation(line: 32, column: 11, scope: !1487)
!1494 = !DILocation(line: 0, scope: !857)
!1495 = !DILocation(line: 32, column: 11, scope: !857)
!1496 = distinct !DISubprogram(name: "none", linkageName: "AsioEvent_box_none_o", scope: !69, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1497, retainedNodes: !1498)
!1497 = !DISubprogram(name: "none", linkageName: "AsioEvent_box_none_o", scope: !73, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: 0)
!1498 = !{!1499}
!1499 = !DILocalVariable(name: "this", arg: 1, scope: !1496, file: !69, line: 10, type: !76, flags: DIFlagArtificial)
!1500 = !DILocation(line: 0, scope: !1496)
!1501 = !DILocation(line: 14, column: 5, scope: !1496)
!1502 = !DILocation(line: 0, scope: !80)
!1503 = !DILocation(line: 14, column: 5, scope: !80)
!1504 = !DILocation(line: 0, scope: !68)
!1505 = !DILocation(line: 6, column: 1, scope: !68)
!1506 = distinct !DISubprogram(name: "eq", linkageName: "U8_val_eq_Cb", scope: !98, file: !98, line: 172, type: !1507, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1509, retainedNodes: !1510)
!1507 = !DISubroutineType(types: !1508)
!1508 = !{!47, !310, !310}
!1509 = !DISubprogram(name: "eq", linkageName: "U8_val_eq_Cb", scope: !310, file: !98, line: 172, type: !1507, scopeLine: 172, spFlags: 0)
!1510 = !{!1511}
!1511 = !DILocalVariable(name: "this", arg: 1, scope: !1506, file: !98, line: 172, type: !1512, flags: DIFlagArtificial)
!1512 = !DIBasicType(name: "U8", size: 8, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!1513 = !DILocation(line: 0, scope: !1506)
!1514 = !DILocalVariable(name: "y", arg: 2, scope: !1506, file: !98, line: 172, type: !310)
!1515 = !DILocation(line: 172, column: 35, scope: !1506)
!1516 = distinct !DISubprogram(name: "eq", linkageName: "U8_box_eq_Cb", scope: !98, file: !98, line: 172, type: !1507, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1517, retainedNodes: !1518)
!1517 = !DISubprogram(name: "eq", linkageName: "U8_box_eq_Cb", scope: !310, file: !98, line: 172, type: !1507, scopeLine: 172, spFlags: 0)
!1518 = !{!1519}
!1519 = !DILocalVariable(name: "this", arg: 1, scope: !1516, file: !98, line: 172, type: !1512, flags: DIFlagArtificial)
!1520 = !DILocation(line: 0, scope: !1516)
!1521 = !DILocalVariable(name: "y", arg: 2, scope: !1516, file: !98, line: 172, type: !310)
!1522 = !DILocation(line: 172, column: 35, scope: !1516)
!1523 = distinct !DISubprogram(name: "create", linkageName: "U8_val_create_pCC", scope: !98, file: !98, line: 43, type: !1524, scopeLine: 43, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1526, retainedNodes: !1527)
!1524 = !DISubroutineType(types: !1525)
!1525 = !{!310, !310, !310}
!1526 = !DISubprogram(name: "create", linkageName: "U8_val_create_pCC", scope: !310, file: !98, line: 43, type: !1524, scopeLine: 43, spFlags: 0)
!1527 = !{!1528}
!1528 = !DILocalVariable(name: "this", arg: 1, scope: !1523, file: !98, line: 43, type: !1512, flags: DIFlagArtificial)
!1529 = !DILocation(line: 0, scope: !1523)
!1530 = !DILocalVariable(name: "value", arg: 2, scope: !1523, file: !98, line: 43, type: !310)
!1531 = !DILocation(line: 43, column: 28, scope: !1523)
!1532 = distinct !DISubprogram(name: "ne", linkageName: "U8_val_ne_Cb", scope: !98, file: !98, line: 173, type: !1507, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1533, retainedNodes: !1534)
!1533 = !DISubprogram(name: "ne", linkageName: "U8_val_ne_Cb", scope: !310, file: !98, line: 173, type: !1507, scopeLine: 173, spFlags: 0)
!1534 = !{!1535}
!1535 = !DILocalVariable(name: "this", arg: 1, scope: !1532, file: !98, line: 173, type: !1512, flags: DIFlagArtificial)
!1536 = !DILocation(line: 0, scope: !1532)
!1537 = !DILocalVariable(name: "y", arg: 2, scope: !1532, file: !98, line: 173, type: !310)
!1538 = !DILocation(line: 173, column: 35, scope: !1532)
!1539 = distinct !DISubprogram(name: "ne", linkageName: "U8_box_ne_Cb", scope: !98, file: !98, line: 173, type: !1507, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1540, retainedNodes: !1541)
!1540 = !DISubprogram(name: "ne", linkageName: "U8_box_ne_Cb", scope: !310, file: !98, line: 173, type: !1507, scopeLine: 173, spFlags: 0)
!1541 = !{!1542}
!1542 = !DILocalVariable(name: "this", arg: 1, scope: !1539, file: !98, line: 173, type: !1512, flags: DIFlagArtificial)
!1543 = !DILocation(line: 0, scope: !1539)
!1544 = !DILocalVariable(name: "y", arg: 2, scope: !1539, file: !98, line: 173, type: !310)
!1545 = !DILocation(line: 173, column: 35, scope: !1539)
