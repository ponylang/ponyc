; ModuleID = 'gc-root-audit'
source_filename = "gc-root-audit"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%Main_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%Resource_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%Effect_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%t2_Leaf_val_Leaf_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [28 x ptr] }
%Worker_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%Sink_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%Leaf_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%Parcel_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%None = type { ptr }
%Env_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%String_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%String = type { ptr, i64, i64, ptr }
%t2_Leaf_val_Leaf_val = type { ptr, ptr }

@Main_Desc = constant %Main_Desc { i32 1, i32 304, i32 0, i32 0, ptr null, ptr @21, ptr @Main_GetBehaviourName, ptr null, ptr @Main_Dispatch, ptr null, i32 -1, i1 true, ptr @Main_Traits, ptr null, [2 x ptr] [ptr @Main_runtime_override_defaults_oo, ptr @Main_tag_create_ioo__send] }
@0 = private unnamed_addr constant [15 x i8] c"Main.*UNKNOWN*\00"
@Resource_Desc = constant %Resource_Desc { i32 21, i32 8, i32 0, i32 0, ptr null, ptr @22, ptr null, ptr null, ptr null, ptr @Resource_box__final_o, i32 -1, i1 true, ptr @Resource_Traits, ptr null, [2 x ptr] [ptr @Resource_box__final_o, ptr @Resource_iso_create_o] }
@Effect_Desc = constant %Effect_Desc { i32 23, i32 8, i32 0, i32 0, ptr null, ptr @23, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Effect_Traits, ptr null, [9 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Effect_val_create_o] }
@t2_Leaf_val_Leaf_val_Desc = constant %t2_Leaf_val_Leaf_val_Desc { i32 2, i32 24, i32 2, i32 8, ptr null, ptr @24, ptr null, ptr @t2_Leaf_val_Leaf_val_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @t2_Leaf_val_Leaf_val_Traits, ptr @t2_Leaf_val_Leaf_val_Fields, [28 x ptr] [ptr @t2_Leaf_val_Leaf_val_box___is_, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @t2_Leaf_val_Leaf_val_box___digestof_] }
@Worker_Desc = constant %Worker_Desc { i32 11, i32 312, i32 0, i32 304, ptr null, ptr @25, ptr @Worker_GetBehaviourName, ptr null, ptr @Worker_Dispatch, ptr null, i32 -1, i1 true, ptr @Worker_Traits, ptr null, [9 x ptr] [ptr @Worker_tag_with_resource_o__send, ptr @Worker_tag_audit_transfer_motoo__send, ptr @Worker_tag_audit_finalisers_o__send, ptr @Worker_tag_audit_tuple_ii2ooo__send, ptr @Worker_tag_hold_ioo__send, ptr @Worker_tag_audit_constructor_o__send, ptr @Worker_tag_audit_roots_toiotopWo__send, ptr @Worker_tag_set_sentinel_o__send, ptr @Worker_tag_create_o__send] }
@1 = private unnamed_addr constant [17 x i8] c"Worker.*UNKNOWN*\00"
@Sink_Desc = constant %Sink_Desc { i32 17, i32 312, i32 0, i32 304, ptr null, ptr @26, ptr @Sink_GetBehaviourName, ptr @Sink_Trace, ptr @Sink_Dispatch, ptr null, i32 -1, i1 true, ptr @Sink_Traits, ptr null, [9 x ptr] [ptr @Sink_tag_take_moo__send, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Sink_tag_create_o__send] }
@2 = private unnamed_addr constant [15 x i8] c"Sink.*UNKNOWN*\00"
@Leaf_Desc = constant %Leaf_Desc { i32 19, i32 16, i32 0, i32 8, ptr null, ptr @27, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Leaf_Traits, ptr null, [1 x ptr] [ptr @Leaf_val_create_pWo] }
@Parcel_Desc = constant %Parcel_Desc { i32 15, i32 16, i32 0, i32 8, ptr null, ptr @28, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Parcel_Traits, ptr null, [2 x ptr] [ptr @Parcel_trn_create_trn_pWo, ptr @Parcel_ref_create_pWo] }
@__NumSizeTable = constant [7 x i32] [i32 8, i32 1, i32 1, i32 4, i32 8, i32 4, i32 8], align 4
@None_Inst = external global %None
@Env_Desc = external global %Env_Desc
@3 = private unnamed_addr constant [12 x i8] c"Main.create\00"
@String_Desc = external global %String_Desc
@4 = private unnamed_addr constant [19 x i8] c"resource finalized\00"
@5 = private unnamed_addr constant %String { ptr @String_Desc, i64 18, i64 19, ptr @4 }
@6 = private unnamed_addr constant [12 x i8] c"constructed\00"
@7 = private unnamed_addr constant %String { ptr @String_Desc, i64 11, i64 12, ptr @6 }
@8 = private unnamed_addr constant [19 x i8] c"Worker.audit_tuple\00"
@9 = private unnamed_addr constant [21 x i8] c"Worker.with_resource\00"
@10 = private unnamed_addr constant [12 x i8] c"Worker.hold\00"
@11 = private unnamed_addr constant [25 x i8] c"Worker.audit_constructor\00"
@12 = private unnamed_addr constant [20 x i8] c"Worker.set_sentinel\00"
@13 = private unnamed_addr constant [5 x i8] c"sent\00"
@14 = private unnamed_addr constant %String { ptr @String_Desc, i64 4, i64 5, ptr @13 }
@15 = private unnamed_addr constant [22 x i8] c"Worker.audit_transfer\00"
@16 = private unnamed_addr constant [24 x i8] c"Worker.audit_finalisers\00"
@17 = private unnamed_addr constant [14 x i8] c"Worker.create\00"
@18 = private unnamed_addr constant [19 x i8] c"Worker.audit_roots\00"
@19 = private unnamed_addr constant [12 x i8] c"Sink.create\00"
@20 = private unnamed_addr constant [10 x i8] c"Sink.take\00"
@21 = private unnamed_addr constant [5 x i8] c"Main\00"
@Main_Traits = constant [1 x i64] zeroinitializer
@22 = private unnamed_addr constant [9 x i8] c"Resource\00"
@Resource_Traits = constant [1 x i64] zeroinitializer
@23 = private unnamed_addr constant [7 x i8] c"Effect\00"
@Effect_Traits = constant [1 x i64] zeroinitializer
@24 = private unnamed_addr constant [21 x i8] c"t2_Leaf_val_Leaf_val\00"
@t2_Leaf_val_Leaf_val_Traits = constant [1 x i64] zeroinitializer
@t2_Leaf_val_Leaf_val_Fields = constant [2 x { i32, ptr }] [{ i32, ptr } { i32 0, ptr @Leaf_Desc }, { i32, ptr } { i32 8, ptr @Leaf_Desc }]
@25 = private unnamed_addr constant [7 x i8] c"Worker\00"
@Worker_Traits = constant [1 x i64] zeroinitializer
@26 = private unnamed_addr constant [5 x i8] c"Sink\00"
@Sink_Traits = constant [1 x i64] zeroinitializer
@27 = private unnamed_addr constant [5 x i8] c"Leaf\00"
@Leaf_Traits = constant [1 x i64] zeroinitializer
@28 = private unnamed_addr constant [7 x i8] c"Parcel\00"
@Parcel_Traits = constant [1 x i64] [i64 8]
@29 = private unnamed_addr constant [31 x i8] c"Error: couldn't start runtime!\00"

; Function Attrs: nounwind memory(none)
declare ptr @pony_ctx() #0

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(304) ptr @pony_create(ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_destroy(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv_single(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_alloc(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(32) ptr @pony_alloc_small(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(1024) ptr @pony_alloc_large(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_realloc(ptr, ptr, i64, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable_or_null(32) ptr @pony_alloc_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(32) ptr @pony_alloc_small_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(1024) ptr @pony_alloc_large_final(ptr, i64) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 ptr @pony_alloc_msg(i32, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_trace(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceknown(ptr, ptr readonly, ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceunknown(ptr, ptr readonly, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_send(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_recv(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_send_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_recv_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i32 @pony_init(i32, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_become(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i1 @pony_start(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: read)
declare i32 @pony_get_exitcode() #2

declare void @pony_coverage_init(i32)

declare void @pony_coverage_write(ptr)

; Function Attrs: noreturn
declare void @abort() #3

; Function Attrs: nounwind memory(argmem: read)
declare i32 @memcmp(ptr readonly, ptr readonly, i64) #2

declare i32 @puts(ptr)

define fastcc i64 @U32_box_usize_Z(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = zext i32 %0 to i64
  ret i64 %1
}

define fastcc i64 @U32_val_usize_Z(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = zext i32 %0 to i64
  ret i64 %1
}

define fastcc i64 @U64_box_usize_Z(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @U64_val_usize_Z(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @USize_box_u64_W(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define fastcc i64 @USize_val_u64_W(i64 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i64 %0
}

define { i32, i32, i32, i32 } @internal.x86.cpuid(i32 %0) unnamed_addr #4 {
entry:
  %1 = call { i32, i32, i32, i32 } asm "cpuid", "={ax},={bx},={cx},={dx},{ax}"(i32 %0) #5
  ret { i32, i32, i32, i32 } %1
}

; Function Attrs: nounwind
declare { i64, i32 } @llvm.x86.rdtscp() #5

define i64 @internal.x86.rdtscp(ptr %0) unnamed_addr #4 {
entry:
  %1 = call { i64, i32 } @llvm.x86.rdtscp()
  %2 = extractvalue { i64, i32 } %1, 1
  store i32 %2, ptr %0, align 4
  %3 = extractvalue { i64, i32 } %1, 0
  ret i64 %3
}

define void @Main_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 1, label %handler
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %5 = load ptr, ptr %4, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Env_Desc, i32 1)
  call void @pony_recv_done(ptr %0)
  %6 = call ptr @pony_ctx()
    #dbg_value(ptr %1, !5, !DIExpression(), !48)
    #dbg_value(ptr %5, !49, !DIExpression(), !48)
  call void @pony_exitcode(i32 1), !dbg !50
  %7 = call ptr @pony_create(ptr %0, ptr nonnull @Worker_Desc, i1 true)
  %8 = call ptr @pony_alloc_msg(i32 0, i32 8), !dbg !51, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %7, ptr %8, ptr %8, i1 true), !dbg !51, !pony.msgsend !4
  ret void
}

define ptr @Main_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 1, label %handler
  ]

default:                                          ; preds = %entry
  ret ptr @0

handler:                                          ; preds = %entry
  ret ptr @3
}

define void @t2_Leaf_val_Leaf_val_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 8
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Leaf_Desc, i32 1)
  %4 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %5 = load ptr, ptr %4, align 8
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Leaf_Desc, i32 1)
  ret void
}

define void @Worker_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 3, label %handler
    i32 0, label %handler1
    i32 4, label %handler2
    i32 5, label %handler3
    i32 7, label %handler4
    i32 1, label %handler5
    i32 2, label %handler6
    i32 8, label %handler7
    i32 6, label %handler8
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %.unpack = load ptr, ptr %4, align 8
  %5 = insertvalue %t2_Leaf_val_Leaf_val poison, ptr %.unpack, 0
  %.elt9 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %.unpack10 = load ptr, ptr %.elt9, align 8
  %6 = insertvalue %t2_Leaf_val_Leaf_val %5, ptr %.unpack10, 1
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %.unpack, ptr nonnull @Leaf_Desc, i32 1)
  call void @pony_traceknown(ptr %0, ptr %.unpack10, ptr nonnull @Leaf_Desc, i32 1)
  call void @pony_recv_done(ptr %0)
    #dbg_value(ptr %1, !52, !DIExpression(), !76)
    #dbg_value(ptr poison, !77, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !76)
    #dbg_value(ptr poison, !77, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !76)
  %7 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !78, !pony.newcall !4
  ret void

handler1:                                         ; preds = %entry
  call fastcc void @Worker_tag_with_resource_o(ptr %1)
  ret void

handler2:                                         ; preds = %entry
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %9 = load ptr, ptr %8, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @Resource_Desc, i32 1)
  call void @pony_recv_done(ptr %0)
    #dbg_value(ptr %1, !79, !DIExpression(), !87)
    #dbg_value(ptr %9, !88, !DIExpression(), !87)
  %10 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !89, !pony.newcall !4
  ret void

handler3:                                         ; preds = %entry
  %11 = call ptr @pony_ctx()
    #dbg_value(ptr %1, !90, !DIExpression(), !99)
  %12 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Effect_Desc, ptr %12, align 8
    #dbg_value(ptr %12, !100, !DIExpression(), !107)
  %13 = call fastcc ptr @String_val_cstring_o(ptr nonnull @7), !dbg !109
  %14 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %13), !dbg !110
    #dbg_value(ptr %12, !96, !DIExpression(), !99)
  %15 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !111, !pony.newcall !4
  ret void

handler4:                                         ; preds = %entry
    #dbg_value(ptr %1, !112, !DIExpression(), !116)
  %16 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !117
  store i8 1, ptr %16, align 1, !dbg !117
  ret void

handler5:                                         ; preds = %entry
  %17 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %18 = load ptr, ptr %17, align 8
  %19 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %20 = load ptr, ptr %19, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %18, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_traceknown(ptr %0, ptr %20, ptr nonnull @Sink_Desc, i32 2)
  call void @pony_recv_done(ptr %0)
  call void @llvm.experimental.noalias.scope.decl(metadata !118)
  %21 = call ptr @pony_ctx()
    #dbg_value(ptr %1, !121, !DIExpression(), !137)
    #dbg_value(ptr %18, !138, !DIExpression(), !137)
    #dbg_value(ptr %20, !139, !DIExpression(), !137)
  %22 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !140, !noalias !118, !pony.msgsend !4
  %23 = getelementptr inbounds nuw i8, ptr %22, i64 16, !dbg !140
  store ptr %18, ptr %23, align 8, !dbg !140, !noalias !118
  call void @pony_gc_send(ptr %0, ptr nonnull dereferenceable(312) %20), !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr nonnull dereferenceable(16) %18, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_send_done(ptr %0), !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr nonnull dereferenceable(312) %20, ptr %22, ptr %22, i1 true), !pony.msgsend !4
  %24 = call fastcc ptr @String_val_cstring_o(ptr nonnull @14), !dbg !141
  %25 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %24), !dbg !142
  ret void

handler6:                                         ; preds = %entry
    #dbg_value(ptr %1, !143, !DIExpression(), !147)
  %26 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !148, !pony.newcall !4
  ret void

handler7:                                         ; preds = %entry
  call fastcc void @Worker_tag_create_o(ptr %1)
  ret void

handler8:                                         ; preds = %entry
  %27 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %28 = load ptr, ptr %27, align 8
  %29 = getelementptr inbounds nuw i8, ptr %2, i64 24
  %30 = load ptr, ptr %29, align 8
  %31 = getelementptr inbounds nuw i8, ptr %2, i64 32
  %32 = load ptr, ptr %31, align 8
  %33 = getelementptr inbounds nuw i8, ptr %2, i64 40
  %34 = load i64, ptr %33, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %28, ptr nonnull @Worker_Desc, i32 2)
  call void @pony_traceknown(ptr %0, ptr %30, ptr nonnull @Leaf_Desc, i32 1)
  call void @pony_traceknown(ptr %0, ptr %32, ptr nonnull @Leaf_Desc, i32 2)
  call void @pony_recv_done(ptr %0)
  call fastcc void @Worker_tag_audit_roots_toiotopWo(ptr %1, ptr %28, ptr %30, ptr %32, i64 %34)
  ret void
}

define ptr @Worker_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 3, label %handler
    i32 0, label %handler1
    i32 4, label %handler2
    i32 5, label %handler3
    i32 7, label %handler4
    i32 1, label %handler5
    i32 2, label %handler6
    i32 8, label %handler7
    i32 6, label %handler8
  ]

default:                                          ; preds = %entry
  ret ptr @1

handler:                                          ; preds = %entry
  ret ptr @8

handler1:                                         ; preds = %entry
  ret ptr @9

handler2:                                         ; preds = %entry
  ret ptr @10

handler3:                                         ; preds = %entry
  ret ptr @11

handler4:                                         ; preds = %entry
  ret ptr @12

handler5:                                         ; preds = %entry
  ret ptr @15

handler6:                                         ; preds = %entry
  ret ptr @16

handler7:                                         ; preds = %entry
  ret ptr @17

handler8:                                         ; preds = %entry
  ret ptr @18
}

define void @Sink_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 8, label %handler
    i32 0, label %handler1
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
    #dbg_value(ptr %1, !149, !DIExpression(), !156)
  %4 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !157, !pony.newcall !4
  %5 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !158
  store ptr %4, ptr %5, align 8, !dbg !158
  ret void

handler1:                                         ; preds = %entry
  %6 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %7 = load ptr, ptr %6, align 8
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %7, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_recv_done(ptr %0)
  call void @llvm.experimental.noalias.scope.decl(metadata !159)
    #dbg_value(ptr %1, !162, !DIExpression(), !168)
    #dbg_value(ptr %7, !169, !DIExpression(), !168)
  %8 = getelementptr inbounds nuw i8, ptr %7, i64 8, !dbg !170
  store i64 17, ptr %8, align 8, !dbg !170, !alias.scope !159
  %9 = getelementptr inbounds nuw i8, ptr %1, i64 304, !dbg !171
  store ptr %7, ptr %9, align 8, !dbg !171, !noalias !159
  ret void
}

define ptr @Sink_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 8, label %handler
    i32 0, label %handler1
  ]

default:                                          ; preds = %entry
  ret ptr @2

handler:                                          ; preds = %entry
  ret ptr @19

handler1:                                         ; preds = %entry
  ret ptr @20
}

define void @Sink_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 304
  %3 = load ptr, ptr %2, align 8
  call void @pony_traceunknown(ptr %0, ptr %3, i32 0)
  ret void
}

define fastcc ptr @Main_tag_create_ioo__send(ptr %0, ptr dereferenceable(64) %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr %1, ptr %4, align 8
  call void @pony_gc_send(ptr %2, ptr %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %2, ptr nonnull %1, ptr nonnull @Env_Desc, i32 1)
  call void @pony_send_done(ptr %2), !pony.msgsend !4
  call void @pony_sendv_single(ptr %2, ptr %0, ptr %3, ptr %3, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Main_tag_create_ioo(ptr %this, ptr dereferenceable(64) %env) unnamed_addr #4 !dbg !6 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !5, !DIExpression(), !48)
    #dbg_value(ptr %env, !49, !DIExpression(), !48)
  call void @pony_exitcode(i32 1), !dbg !50
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Worker_Desc, i1 true)
  %2 = call ptr @pony_alloc_msg(i32 0, i32 8), !dbg !51, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %1, ptr %2, ptr %2, i1 true), !dbg !51, !pony.msgsend !4
  ret void
}

define void @Main_runtime_override_defaults_oo(ptr dereferenceable(112) %rto) #4 !dbg !172 !pony.abi !4 {
entry:
    #dbg_value(ptr %rto, !208, !DIExpression(), !210)
  %0 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !211, !pony.newcall !4
  ret void, !dbg !211
}

define fastcc noalias align 32 dereferenceable(304) ptr @Main_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Main_Desc, i1 false)
  ret ptr %1
}

define fastcc void @Resource_iso_create_o(ptr %this) unnamed_addr #4 !dbg !212 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !217, !DIExpression(), !219)
  ret void, !dbg !220
}

define void @Resource_box__final_o(ptr dereferenceable(8) %this) unnamed_addr #4 !dbg !221 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !226, !DIExpression(), !227)
  %0 = call fastcc ptr @String_val_cstring_o(ptr nonnull @5), !dbg !228
  %1 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %0), !dbg !229
  %2 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !229, !pony.newcall !4
  ret void, !dbg !229
}

define fastcc noalias align 32 dereferenceable(8) ptr @Resource_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small_final(ptr %0, i32 0)
  store volatile ptr @Resource_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc void @Effect_val_create_o(ptr %this) unnamed_addr #4 !dbg !101 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !100, !DIExpression(), !230)
  %0 = call fastcc ptr @String_val_cstring_o(ptr nonnull @7), !dbg !231
  %1 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %0), !dbg !232
  ret void, !dbg !232
}

define fastcc noalias align 32 dereferenceable(8) ptr @Effect_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Effect_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc i64 @t2_Leaf_val_Leaf_val_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %.unpack = load ptr, ptr %1, align 8
  %.elt1 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %.unpack2 = load ptr, ptr %.elt1, align 8
  %2 = ptrtoint ptr %.unpack to i64
  %3 = ptrtoint ptr %.unpack2 to i64
  %4 = xor i64 %2, %3
  ret i64 %4
}

define fastcc i1 @t2_Leaf_val_Leaf_val_box___is_(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %.unpack = load ptr, ptr %3, align 8
  %.elt10 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %.unpack11 = load ptr, ptr %.elt10, align 8
  %4 = getelementptr inbounds nuw i8, ptr %2, i64 12
  %5 = load i32, ptr %4, align 4
  %6 = zext i32 %5 to i64
  %7 = getelementptr inbounds nuw i8, ptr %1, i64 %6
  %8 = getelementptr inbounds nuw i8, ptr %2, i64 80
  %9 = load ptr, ptr %8, align 8
  %10 = load { i32, ptr }, ptr %9, align 8
  %11 = extractvalue { i32, ptr } %10, 0
  %12 = zext i32 %11 to i64
  %13 = getelementptr inbounds nuw i8, ptr %7, i64 %12
  %14 = extractvalue { i32, ptr } %10, 1
  %15 = icmp eq ptr %14, null
  br i1 %15, label %is_tuple_null_desc, label %is_tuple_nonnull_desc

is_tuple_null_desc:                               ; preds = %entry
  %16 = load ptr, ptr %13, align 8
  %17 = icmp eq ptr %.unpack, %16
  br label %is_tuple_merge_desc

is_tuple_nonnull_desc:                            ; preds = %entry
  %18 = load i32, ptr %14, align 4
  %19 = and i32 %18, 3
  switch i32 %19, label %is_tuple_nonbox [
    i32 0, label %is_tuple_num
    i32 2, label %is_tuple_tuple
  ]

is_tuple_num:                                     ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_tuple:                                   ; preds = %is_tuple_nonnull_desc
  br label %is_tuple_post1

is_tuple_nonbox:                                  ; preds = %is_tuple_nonnull_desc
  %20 = load ptr, ptr %13, align 8
  %21 = icmp eq ptr %.unpack, %20
  br label %is_tuple_post1

is_tuple_post1:                                   ; preds = %is_tuple_nonbox, %is_tuple_tuple, %is_tuple_num
  %22 = phi i1 [ false, %is_tuple_num ], [ false, %is_tuple_tuple ], [ %21, %is_tuple_nonbox ]
  br label %is_tuple_merge_desc

is_tuple_merge_desc:                              ; preds = %is_tuple_post1, %is_tuple_null_desc
  %23 = phi i1 [ %17, %is_tuple_null_desc ], [ %22, %is_tuple_post1 ]
  br i1 %23, label %is_tuple_next, label %is_tuple_post

is_tuple_next:                                    ; preds = %is_tuple_merge_desc
  %24 = getelementptr inbounds nuw i8, ptr %2, i64 80
  %25 = load ptr, ptr %24, align 8
  %26 = getelementptr inbounds nuw i8, ptr %25, i64 16
  %27 = load { i32, ptr }, ptr %26, align 8
  %28 = extractvalue { i32, ptr } %27, 0
  %29 = zext i32 %28 to i64
  %30 = getelementptr inbounds nuw i8, ptr %7, i64 %29
  %31 = extractvalue { i32, ptr } %27, 1
  %32 = icmp eq ptr %31, null
  br i1 %32, label %is_tuple_null_desc2, label %is_tuple_nonnull_desc3

is_tuple_null_desc2:                              ; preds = %is_tuple_next
  %33 = load ptr, ptr %30, align 8
  %34 = icmp eq ptr %.unpack11, %33
  br label %is_tuple_merge_desc4

is_tuple_nonnull_desc3:                           ; preds = %is_tuple_next
  %35 = load i32, ptr %31, align 4
  %36 = and i32 %35, 3
  switch i32 %36, label %is_tuple_nonbox7 [
    i32 0, label %is_tuple_num5
    i32 2, label %is_tuple_tuple6
  ]

is_tuple_num5:                                    ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post8

is_tuple_tuple6:                                  ; preds = %is_tuple_nonnull_desc3
  br label %is_tuple_post8

is_tuple_nonbox7:                                 ; preds = %is_tuple_nonnull_desc3
  %37 = load ptr, ptr %30, align 8
  %38 = icmp eq ptr %.unpack11, %37
  br label %is_tuple_post8

is_tuple_post8:                                   ; preds = %is_tuple_nonbox7, %is_tuple_tuple6, %is_tuple_num5
  %39 = phi i1 [ false, %is_tuple_num5 ], [ false, %is_tuple_tuple6 ], [ %38, %is_tuple_nonbox7 ]
  br label %is_tuple_merge_desc4

is_tuple_merge_desc4:                             ; preds = %is_tuple_post8, %is_tuple_null_desc2
  %40 = phi i1 [ %34, %is_tuple_null_desc2 ], [ %39, %is_tuple_post8 ]
  br i1 %40, label %is_tuple_next9, label %is_tuple_post

is_tuple_next9:                                   ; preds = %is_tuple_merge_desc4
  br label %is_tuple_post

is_tuple_post:                                    ; preds = %is_tuple_next9, %is_tuple_merge_desc4, %is_tuple_merge_desc
  %41 = phi i1 [ false, %is_tuple_merge_desc ], [ false, %is_tuple_merge_desc4 ], [ true, %is_tuple_next9 ]
  ret i1 %41
}

define fastcc ptr @Worker_tag_audit_tuple_ii2ooo__send(ptr dereferenceable(312) %0, %t2_Leaf_val_Leaf_val %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc_msg(i32 0, i32 3), !pony.msgsend !4
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16
  %.elt = extractvalue %t2_Leaf_val_Leaf_val %1, 0
  store ptr %.elt, ptr %4, align 8
  %.repack1 = getelementptr inbounds nuw i8, ptr %3, i64 24
  %.elt2 = extractvalue %t2_Leaf_val_Leaf_val %1, 1
  store ptr %.elt2, ptr %.repack1, align 8
  call void @pony_gc_send(ptr %2, ptr nonnull %0), !pony.msgsend !4
  %5 = extractvalue %t2_Leaf_val_Leaf_val %1, 0
  call void @pony_traceknown(ptr %2, ptr %5, ptr nonnull @Leaf_Desc, i32 1)
  %6 = extractvalue %t2_Leaf_val_Leaf_val %1, 1
  call void @pony_traceknown(ptr %2, ptr %6, ptr nonnull @Leaf_Desc, i32 1)
  call void @pony_send_done(ptr %2), !pony.msgsend !4
  call void @pony_sendv(ptr %2, ptr nonnull %0, ptr %3, ptr %3, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_audit_tuple_ii2ooo(ptr dereferenceable(312) %this, %t2_Leaf_val_Leaf_val %pair) unnamed_addr #4 !dbg !53 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !52, !DIExpression(), !76)
    #dbg_value(ptr poison, !77, !DIExpression(DW_OP_LLVM_fragment, 0, 64), !76)
    #dbg_value(ptr poison, !77, !DIExpression(DW_OP_LLVM_fragment, 64, 64), !76)
  %0 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !78, !pony.newcall !4
  ret void
}

define fastcc ptr @Worker_tag_with_resource_o__send(ptr dereferenceable(312) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_with_resource_o(ptr dereferenceable(312) %this) unnamed_addr #4 !dbg !233 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !236, !DIExpression(), !238)
  %1 = call ptr @pony_alloc_small_final(ptr %0, i32 0)
  store volatile ptr @Resource_Desc, ptr %1, align 8
    #dbg_value(ptr %1, !217, !DIExpression(), !239)
    #dbg_value(ptr %1, !237, !DIExpression(), !238)
  %2 = call ptr @pony_alloc_msg(i32 0, i32 2), !dbg !241, !pony.msgsend !4
  %3 = call ptr @pony_alloc_msg(i32 0, i32 4), !dbg !242, !pony.msgsend !4
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16, !dbg !242
  store ptr %1, ptr %4, align 8, !dbg !242
  call void @pony_gc_send(ptr %0, ptr nonnull %this), !dbg !242, !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr nonnull %1, ptr nonnull @Resource_Desc, i32 1), !dbg !242
  call void @pony_send_done(ptr %0), !dbg !242, !pony.msgsend !4
  tail call void @pony_chain(ptr %2, ptr %3)
  call void @pony_sendv(ptr %0, ptr nonnull %this, ptr %2, ptr %3, i1 true), !dbg !242, !pony.msgsend !4
  ret void
}

define fastcc ptr @Worker_tag_hold_ioo__send(ptr dereferenceable(312) %0, ptr dereferenceable(8) %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc_msg(i32 0, i32 4), !pony.msgsend !4
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr %1, ptr %4, align 8
  call void @pony_gc_send(ptr %2, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %2, ptr nonnull %1, ptr nonnull @Resource_Desc, i32 1)
  call void @pony_send_done(ptr %2), !pony.msgsend !4
  call void @pony_sendv(ptr %2, ptr nonnull %0, ptr %3, ptr %3, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_hold_ioo(ptr dereferenceable(312) %this, ptr dereferenceable(8) %resource) unnamed_addr #4 !dbg !80 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !79, !DIExpression(), !87)
    #dbg_value(ptr %resource, !88, !DIExpression(), !87)
  %0 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !89, !pony.newcall !4
  ret void
}

define fastcc ptr @Worker_tag_audit_constructor_o__send(ptr dereferenceable(312) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 5), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_audit_constructor_o(ptr dereferenceable(312) %this) unnamed_addr #4 !dbg !91 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !90, !DIExpression(), !99)
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Effect_Desc, ptr %1, align 8
    #dbg_value(ptr %1, !100, !DIExpression(), !107)
  %2 = call fastcc ptr @String_val_cstring_o(ptr nonnull @7), !dbg !109
  %3 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %2), !dbg !110
    #dbg_value(ptr %1, !96, !DIExpression(), !99)
  %4 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !111, !pony.newcall !4
  ret void
}

define fastcc ptr @Worker_tag_set_sentinel_o__send(ptr dereferenceable(312) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 7), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_set_sentinel_o(ptr dereferenceable(312) %this) unnamed_addr #4 !dbg !113 !pony.abi !4 !pony.noalloc !4 {
entry:
    #dbg_value(ptr %this, !112, !DIExpression(), !116)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !117
  store i8 1, ptr %0, align 1, !dbg !117
  ret void
}

define fastcc ptr @Worker_tag_audit_transfer_motoo__send(ptr dereferenceable(312) %0, ptr noalias dereferenceable(16) %1, ptr dereferenceable(312) %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = call ptr @pony_ctx()
  %4 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store ptr %1, ptr %5, align 8
  %6 = getelementptr inbounds nuw i8, ptr %4, i64 24
  store ptr %2, ptr %6, align 8
  call void @pony_gc_send(ptr %3, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %3, ptr nonnull %1, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_traceknown(ptr %3, ptr nonnull %2, ptr nonnull @Sink_Desc, i32 2)
  call void @pony_send_done(ptr %3), !pony.msgsend !4
  call void @pony_sendv(ptr %3, ptr nonnull %0, ptr %4, ptr %4, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_audit_transfer_motoo(ptr dereferenceable(312) %this, ptr noalias dereferenceable(16) %item, ptr dereferenceable(312) %sink) unnamed_addr #4 !dbg !122 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !121, !DIExpression(), !137)
    #dbg_value(ptr %item, !138, !DIExpression(), !137)
    #dbg_value(ptr %sink, !139, !DIExpression(), !137)
  %1 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !140, !pony.msgsend !4
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 16, !dbg !140
  store ptr %item, ptr %2, align 8, !dbg !140
  call void @pony_gc_send(ptr %0, ptr nonnull %sink), !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr nonnull %item, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_send_done(ptr %0), !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr nonnull %sink, ptr %1, ptr %1, i1 true), !pony.msgsend !4
  %3 = call fastcc ptr @String_val_cstring_o(ptr nonnull @14), !dbg !141
  %4 = call i32 @puts(ptr noundef nonnull dereferenceable(1) %3), !dbg !142
  ret void
}

define fastcc ptr @Worker_tag_audit_finalisers_o__send(ptr dereferenceable(312) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 2), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_audit_finalisers_o(ptr dereferenceable(312) %this) unnamed_addr #4 !dbg !144 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !143, !DIExpression(), !147)
  %0 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !148, !pony.newcall !4
  ret void
}

define fastcc ptr @Worker_tag_create_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 8), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Worker_tag_create_o(ptr %this) unnamed_addr #4 !dbg !243 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !248, !DIExpression(), !250)
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !251
  store i8 0, ptr %1, align 1, !dbg !251
  %2 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Leaf_Desc, ptr %2, align 8
    #dbg_value(ptr %2, !252, !DIExpression(), !259)
    #dbg_value(i64 7, !261, !DIExpression(), !259)
  %3 = getelementptr inbounds nuw i8, ptr %2, i64 8, !dbg !262
  store i64 7, ptr %3, align 8, !dbg !262
    #dbg_value(ptr %2, !249, !DIExpression(), !250)
  %4 = call ptr @pony_alloc_msg(i32 0, i32 7), !dbg !263, !pony.msgsend !4
  %5 = call ptr @pony_alloc_msg(i32 1, i32 6), !dbg !264, !pony.msgsend !4
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 16, !dbg !264
  store ptr %this, ptr %6, align 8, !dbg !264
  %7 = getelementptr inbounds nuw i8, ptr %5, i64 24, !dbg !264
  store ptr %2, ptr %7, align 8, !dbg !264
  %8 = getelementptr inbounds nuw i8, ptr %5, i64 32, !dbg !264
  store ptr %2, ptr %8, align 8, !dbg !264
  %9 = getelementptr inbounds nuw i8, ptr %5, i64 40, !dbg !264
  store i64 11, ptr %9, align 8, !dbg !264
  call void @pony_gc_send(ptr %0, ptr %this), !dbg !264, !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr %this, ptr nonnull @Worker_Desc, i32 2), !dbg !264
  call void @pony_traceknown(ptr %0, ptr nonnull %2, ptr nonnull @Leaf_Desc, i32 1), !dbg !264
  call void @pony_traceknown(ptr %0, ptr nonnull %2, ptr nonnull @Leaf_Desc, i32 2), !dbg !264
  call void @pony_send_done(ptr %0), !dbg !264, !pony.msgsend !4
  tail call void @pony_chain(ptr %4, ptr %5)
  call void @pony_sendv(ptr %0, ptr %this, ptr %4, ptr %5, i1 true), !dbg !264, !pony.msgsend !4
  %10 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Parcel_Desc, ptr %10, align 8
    #dbg_value(ptr %10, !265, !DIExpression(), !272)
    #dbg_value(i64 5, !275, !DIExpression(), !272)
  %11 = getelementptr inbounds nuw i8, ptr %10, i64 8, !dbg !276
  store i64 5, ptr %11, align 8, !dbg !276
  %12 = call ptr @pony_create(ptr %0, ptr nonnull @Sink_Desc, i1 false)
  %13 = call ptr @pony_alloc_msg(i32 0, i32 8), !dbg !277, !pony.msgsend !4
  %14 = call ptr @pony_alloc_msg(i32 0, i32 1), !dbg !278, !pony.msgsend !4
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 16, !dbg !278
  store ptr %10, ptr %15, align 8, !dbg !278
  %16 = getelementptr inbounds nuw i8, ptr %14, i64 24, !dbg !278
  store ptr %12, ptr %16, align 8, !dbg !278
  %17 = call ptr @pony_alloc_msg(i32 0, i32 5), !dbg !279, !pony.msgsend !4
  call void @pony_gc_send(ptr %0, ptr %this), !dbg !278, !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr nonnull %10, ptr nonnull @Parcel_Desc, i32 0), !dbg !278
  call void @pony_traceknown(ptr %0, ptr nonnull %12, ptr nonnull @Sink_Desc, i32 2), !dbg !278
  call void @pony_send_done(ptr %0), !dbg !278, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %12, ptr %13, ptr %13, i1 true), !dbg !277, !pony.msgsend !4
  tail call void @pony_chain(ptr %14, ptr %17)
  call void @pony_sendv(ptr %0, ptr %this, ptr %14, ptr %17, i1 true), !dbg !279, !pony.msgsend !4
  ret void
}

define fastcc ptr @Worker_tag_audit_roots_toiotopWo__send(ptr dereferenceable(312) %0, ptr dereferenceable(312) %1, ptr dereferenceable(16) %2, ptr dereferenceable(16) %3, i64 %4) unnamed_addr #4 !pony.abi !4 {
entry:
  %5 = call ptr @pony_ctx()
  %6 = call ptr @pony_alloc_msg(i32 1, i32 6), !pony.msgsend !4
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 16
  store ptr %1, ptr %7, align 8
  %8 = getelementptr inbounds nuw i8, ptr %6, i64 24
  store ptr %2, ptr %8, align 8
  %9 = getelementptr inbounds nuw i8, ptr %6, i64 32
  store ptr %3, ptr %9, align 8
  %10 = getelementptr inbounds nuw i8, ptr %6, i64 40
  store i64 %4, ptr %10, align 8
  call void @pony_gc_send(ptr %5, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %5, ptr nonnull %1, ptr nonnull @Worker_Desc, i32 2)
  call void @pony_traceknown(ptr %5, ptr nonnull %2, ptr nonnull @Leaf_Desc, i32 1)
  call void @pony_traceknown(ptr %5, ptr nonnull %3, ptr nonnull @Leaf_Desc, i32 2)
  call void @pony_send_done(ptr %5), !pony.msgsend !4
  call void @pony_sendv(ptr %5, ptr nonnull %0, ptr %6, ptr %6, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Worker_tag_audit_roots_toiotopWo(ptr dereferenceable(312) %this, ptr dereferenceable(312) %peer, ptr dereferenceable(16) %a, ptr dereferenceable(16) %b, i64 %n) unnamed_addr #4 !dbg !280 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !285, !DIExpression(), !291)
    #dbg_value(ptr %peer, !292, !DIExpression(), !291)
    #dbg_value(ptr %a, !293, !DIExpression(), !291)
    #dbg_value(ptr %b, !294, !DIExpression(), !291)
    #dbg_value(i64 %n, !295, !DIExpression(), !291)
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Leaf_Desc, ptr %1, align 8
    #dbg_value(ptr %1, !252, !DIExpression(), !296)
    #dbg_value(i64 %n, !261, !DIExpression(), !296)
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 8, !dbg !298
  store i64 %n, ptr %2, align 8, !dbg !298
    #dbg_value(ptr %1, !286, !DIExpression(), !291)
    #dbg_value(ptr %1, !287, !DIExpression(), !291)
    #dbg_value(ptr %a, !288, !DIExpression(), !291)
  %3 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Parcel_Desc, ptr %3, align 8
    #dbg_value(ptr %3, !265, !DIExpression(), !299)
    #dbg_value(i64 %n, !275, !DIExpression(), !299)
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 8, !dbg !301
  store i64 %n, ptr %4, align 8, !dbg !301
    #dbg_value(ptr %3, !289, !DIExpression(), !291)
  %5 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Parcel_Desc, ptr %5, align 8
    #dbg_value(ptr %5, !302, !DIExpression(), !306)
    #dbg_value(i64 %n, !308, !DIExpression(), !306)
  %6 = getelementptr inbounds nuw i8, ptr %5, i64 8, !dbg !309
  store i64 %n, ptr %6, align 8, !dbg !309
    #dbg_value(ptr %5, !290, !DIExpression(), !291)
  br label %sc_left, !dbg !310

sc_left:                                          ; preds = %entry
  br label %sc_left6, !dbg !312

sc_left6:                                         ; preds = %sc_left
  br label %sc_left7, !dbg !313

sc_left7:                                         ; preds = %sc_left6
  br label %sc_left8, !dbg !314

sc_left8:                                         ; preds = %sc_left7
  %7 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !314
  %8 = load i8, ptr %7, align 1, !dbg !314
  %9 = trunc i8 %8 to i1, !dbg !314
  br i1 %9, label %sc_right, label %sc_post, !dbg !314

sc_right:                                         ; preds = %sc_left8
  %10 = icmp eq ptr %peer, %this, !dbg !315
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left8
  %11 = phi i1 [ false, %sc_left8 ], [ %10, %sc_right ]
  br i1 %11, label %sc_right9, label %sc_post10

sc_right9:                                        ; preds = %sc_post
  %12 = icmp eq ptr %a, %b, !dbg !316
  br label %sc_post10

sc_post10:                                        ; preds = %sc_right9, %sc_post
  %13 = phi i1 [ false, %sc_post ], [ %12, %sc_right9 ]
  br i1 %13, label %sc_right11, label %sc_post12

sc_right11:                                       ; preds = %sc_post10
  br label %sc_post12

sc_post12:                                        ; preds = %sc_right11, %sc_post10
  br i1 %13, label %sc_right13, label %sc_post14

sc_right13:                                       ; preds = %sc_post12
  %14 = getelementptr inbounds nuw i8, ptr %1, i64 8, !dbg !317
  %15 = load i64, ptr %14, align 8, !dbg !317
  %16 = icmp eq i64 %15, %n, !dbg !317
  br label %sc_post14

sc_post14:                                        ; preds = %sc_right13, %sc_post12
  %17 = phi i1 [ false, %sc_post12 ], [ %16, %sc_right13 ]
  br i1 %17, label %if_then, label %if_else

if_then:                                          ; preds = %sc_post14
  call void @pony_exitcode(i32 0), !dbg !318
  br label %if_post

if_else:                                          ; preds = %sc_post14
  %18 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !320, !pony.newcall !4
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %19 = call ptr @pony_alloc_msg(i32 0, i32 3), !dbg !322, !pony.msgsend !4
  %20 = getelementptr inbounds nuw i8, ptr %19, i64 16, !dbg !322
  store ptr %a, ptr %20, align 8, !dbg !322
  %.repack19 = getelementptr inbounds nuw i8, ptr %19, i64 24, !dbg !322
  store ptr %a, ptr %.repack19, align 8, !dbg !322
  %21 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !323, !pony.msgsend !4
  call void @pony_gc_send(ptr %0, ptr nonnull %this), !dbg !322, !pony.msgsend !4
  call void @pony_traceknown(ptr %0, ptr nonnull %a, ptr nonnull @Leaf_Desc, i32 1), !dbg !322
  call void @pony_traceknown(ptr %0, ptr nonnull %a, ptr nonnull @Leaf_Desc, i32 1), !dbg !322
  call void @pony_send_done(ptr %0), !dbg !322, !pony.msgsend !4
  tail call void @pony_chain(ptr %19, ptr %21)
  call void @pony_sendv(ptr %0, ptr nonnull %this, ptr %19, ptr %21, i1 true), !dbg !323, !pony.msgsend !4
  ret void
}

define fastcc noalias align 32 dereferenceable(312) ptr @Worker_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Worker_Desc, i1 false)
  ret ptr %1
}

define fastcc ptr @Sink_tag_create_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 8), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define fastcc void @Sink_tag_create_o(ptr %this) unnamed_addr #4 !dbg !150 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !149, !DIExpression(), !156)
  %0 = call fastcc ptr @None_val_create_o(ptr nonnull @None_Inst), !dbg !157, !pony.newcall !4
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !158
  store ptr %0, ptr %1, align 8, !dbg !158
  ret void
}

define fastcc ptr @Sink_tag_take_moo__send(ptr dereferenceable(312) %0, ptr noalias dereferenceable(16) %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  %4 = getelementptr inbounds nuw i8, ptr %3, i64 16
  store ptr %1, ptr %4, align 8
  call void @pony_gc_send(ptr %2, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %2, ptr nonnull %1, ptr nonnull @Parcel_Desc, i32 0)
  call void @pony_send_done(ptr %2), !pony.msgsend !4
  call void @pony_sendv(ptr %2, ptr nonnull %0, ptr %3, ptr %3, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define fastcc void @Sink_tag_take_moo(ptr dereferenceable(312) %this, ptr noalias dereferenceable(16) %item) unnamed_addr #4 !dbg !163 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !162, !DIExpression(), !168)
    #dbg_value(ptr %item, !169, !DIExpression(), !168)
  %0 = getelementptr inbounds nuw i8, ptr %item, i64 8, !dbg !170
  store i64 17, ptr %0, align 8, !dbg !170
  %1 = getelementptr inbounds nuw i8, ptr %this, i64 304, !dbg !171
  store ptr %item, ptr %1, align 8, !dbg !171
  ret void
}

define fastcc noalias align 32 dereferenceable(312) ptr @Sink_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Sink_Desc, i1 false)
  ret ptr %1
}

define fastcc void @Leaf_val_create_pWo(ptr %this, i64 %"n'") unnamed_addr #4 !dbg !253 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !252, !DIExpression(), !324)
    #dbg_value(i64 %"n'", !261, !DIExpression(), !324)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !325
  store i64 %"n'", ptr %0, align 8, !dbg !325
  ret void, !dbg !325
}

define fastcc noalias align 32 dereferenceable(16) ptr @Leaf_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Leaf_Desc, ptr %1, align 8
  ret ptr %1
}

define fastcc void @Parcel_ref_create_pWo(ptr %this, i64 %"n'") unnamed_addr #4 !dbg !266 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !265, !DIExpression(), !326)
    #dbg_value(i64 %"n'", !275, !DIExpression(), !326)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !327
  store i64 %"n'", ptr %0, align 8, !dbg !327
  ret void, !dbg !327
}

define fastcc void @Parcel_trn_create_trn_pWo(ptr %this, i64 %"n'") unnamed_addr #4 !dbg !303 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !302, !DIExpression(), !328)
    #dbg_value(i64 %"n'", !308, !DIExpression(), !328)
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8, !dbg !329
  store i64 %"n'", ptr %0, align 8, !dbg !329
  ret void, !dbg !329
}

define fastcc noalias align 32 dereferenceable(16) ptr @Parcel_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Parcel_Desc, ptr %1, align 8
  ret ptr %1
}

declare void @pony_exitcode(i32)

declare ptr @None_val_create_o(ptr)

declare ptr @String_val_cstring_o(ptr dereferenceable(32))

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

define i32 @main(i32 %argc, ptr %argv, ptr %envp) #4 {
entry:
  %0 = alloca { i8 }, align 8
  %argc1 = call i32 @pony_init(i32 %argc, ptr %argv)
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_create(ptr %1, ptr nonnull @Main_Desc, i1 false)
  call void @ponyint_become(ptr %1, ptr nonnull %2)
  %3 = call ptr @pony_alloc_small(ptr %1, i32 1)
  store volatile ptr @Env_Desc, ptr %3, align 8
  call fastcc void @Env_ref__create_pIioioo(ptr nonnull %3, i32 %argc1, ptr %argv, ptr %envp)
  %4 = call ptr @pony_alloc_msg(i32 0, i32 1)
  %5 = getelementptr inbounds nuw i8, ptr %4, i64 16
  store ptr %3, ptr %5, align 8
  call void @pony_gc_send(ptr %1, ptr null)
  call void @pony_traceknown(ptr %1, ptr nonnull %3, ptr nonnull @Env_Desc, i32 1)
  call void @pony_send_done(ptr %1)
  call void @pony_sendv_single(ptr %1, ptr nonnull %2, ptr %4, ptr %4, i1 true)
  call void @ponyint_become(ptr %1, ptr null)
  store i8 1, ptr %0, align 1
  %6 = call i1 @pony_start(ptr null, ptr nonnull %0)
  br i1 %6, label %post, label %start_fail

start_fail:                                       ; preds = %entry
  %7 = call i32 @puts(ptr noundef nonnull dereferenceable(1) @29)
  br label %post

post:                                             ; preds = %start_fail, %entry
  call void @ponyint_become(ptr %1, ptr null)
  %8 = call i32 @pony_get_exitcode()
  %9 = select i1 %6, i32 %8, i32 -1
  ret i32 %9
}

declare void @Env_ref__create_pIioioo(ptr, i32, ptr, ptr)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #7

; Function Attrs: nounwind
declare void @pony_send_next(ptr, ptr readnone) #5

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @pony_chain(ptr captures(none), ptr readnone) #8

attributes #0 = { nounwind memory(none) }
attributes #1 = { nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { nounwind memory(argmem: read) }
attributes #3 = { noreturn }
attributes #4 = { "target-cpu"="arrowlake" "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,-avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,-avx512vpopcntdq,+cmov,-avx512vp2intersect,+avxvnniint8,-avx512cd,+movbe,-ccmp,-amx-int8,-kl,-avx512bmm,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,-avx512vl,-uintr,-cf,-jmpabs,+clflushopt,-raoint,+cmpccxadd,+bmi,-amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,-avx512f,-amx-bf16,-avx512bf16,-avx512vnni,-push2pop2,+cx8,-avx512bw,+sse3,-pku,-nf,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,-wbnoinvd,-enqcmd,+avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,+avxifma,+f16c,-avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,-avx512vbmi2,-prefetchi,+rdpid,-amx-movrs,-fma4,-avx512vbmi,+shstk,+vaes,+waitpkg,-sgx,+fxsr,-avx512dq,-sse4a,+cx16,+sse2,+64bit,+64bit-mode" }
attributes #5 = { nounwind }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #8 = { nounwind memory(argmem: readwrite) }

!llvm.module.flags = !{!0, !1}
!llvm.dbg.cu = !{!2}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus, file: !3, producer: "ponyc-0.78.2-e780f37e1", isOptimized: true, flags: "-r ir -b audit -o <experiment>/ir-off test/gc-root-audit ", runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false)
!3 = !DIFile(filename: "gc-root-audit", directory: "<checkout>/test/gc-root-audit")
!4 = !{}
!5 = !DILocalVariable(name: "this", arg: 1, scope: !6, file: !7, line: 75, type: !47, flags: DIFlagArtificial)
!6 = distinct !DISubprogram(name: "create", linkageName: "Main_tag_create_ioo", scope: !7, file: !7, line: 75, type: !8, scopeLine: 75, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !45, retainedNodes: !46)
!7 = !DIFile(filename: "<checkout>/test/gc-root-audit/gc_root_audit.pony", directory: "")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !10, !12}
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64, align: 64, dwarfAddressSpace: 0)
!11 = !DICompositeType(tag: DW_TAG_structure_type, name: "Main", file: !7, line: 74, size: 2432, align: 64, elements: !4, identifier: "Main")
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64, align: 64, dwarfAddressSpace: 0)
!13 = !DICompositeType(tag: DW_TAG_structure_type, name: "Env", file: !14, line: 75, size: 512, align: 64, elements: !15, identifier: "Env")
!14 = !DIFile(filename: "<checkout>/packages/builtin/env.pony", directory: "")
!15 = !{!16, !20, !24, !28, !29, !41, !42}
!16 = !DIDerivedType(tag: DW_TAG_member, name: "root", file: !14, line: 9, baseType: !17, size: 64, align: 64, offset: 64)
!17 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !18, size: 64, align: 64, dwarfAddressSpace: 0)
!18 = !DICompositeType(tag: DW_TAG_structure_type, name: "AmbientAuth", file: !19, line: 9, size: 64, align: 64, elements: !4, identifier: "AmbientAuth")
!19 = !DIFile(filename: "<checkout>/packages/builtin/ambient_auth.pony", directory: "")
!20 = !DIDerivedType(tag: DW_TAG_member, name: "input", file: !14, line: 14, baseType: !21, size: 64, align: 64, offset: 128)
!21 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !22, size: 64, align: 64, dwarfAddressSpace: 0)
!22 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputStream", file: !23, line: 14, elements: !4, identifier: "InputStream")
!23 = !DIFile(filename: "<checkout>/packages/builtin/stdin.pony", directory: "")
!24 = !DIDerivedType(tag: DW_TAG_member, name: "out", file: !14, line: 19, baseType: !25, size: 64, align: 64, offset: 192)
!25 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !26, size: 64, align: 64, dwarfAddressSpace: 0)
!26 = !DICompositeType(tag: DW_TAG_structure_type, name: "OutStream", file: !27, line: 19, elements: !4, identifier: "OutStream")
!27 = !DIFile(filename: "<checkout>/packages/builtin/std_stream.pony", directory: "")
!28 = !DIDerivedType(tag: DW_TAG_member, name: "err", file: !14, line: 22, baseType: !25, size: 64, align: 64, offset: 256)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "args", file: !14, line: 25, baseType: !30, size: 64, align: 64, offset: 320)
!30 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !31, size: 64, align: 64, dwarfAddressSpace: 0)
!31 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_String_val", file: !32, line: 25, size: 256, align: 64, elements: !33, identifier: "Array_String_val")
!32 = !DIFile(filename: "<checkout>/packages/builtin/array.pony", directory: "")
!33 = !{!34, !36, !37}
!34 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !32, line: 89, baseType: !35, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!35 = !DIBasicType(name: "USize", size: 64, encoding: DW_ATE_unsigned)
!36 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !32, line: 90, baseType: !35, size: 64, align: 64, offset: 128, flags: DIFlagPrivate)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !32, line: 91, baseType: !38, size: 64, align: 64, offset: 192, flags: DIFlagPrivate)
!38 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !39, size: 64, align: 64, dwarfAddressSpace: 0)
!39 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_String_val", file: !40, line: 91, elements: !4, identifier: "Pointer_String_val")
!40 = !DIFile(filename: "<checkout>/packages/builtin/pointer.pony", directory: "")
!41 = !DIDerivedType(tag: DW_TAG_member, name: "vars", file: !14, line: 28, baseType: !30, size: 64, align: 64, offset: 384)
!42 = !DIDerivedType(tag: DW_TAG_member, name: "exitcode", file: !14, line: 31, baseType: !43, size: 64, align: 64, offset: 448)
!43 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !44, size: 64, align: 64, dwarfAddressSpace: 0)
!44 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$6", file: !14, line: 31, elements: !4, identifier: "$0$6")
!45 = !DISubprogram(name: "create", linkageName: "Main_tag_create_ioo", scope: !11, file: !7, line: 75, type: !8, scopeLine: 75, spFlags: 0)
!46 = !{!5}
!47 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!48 = !DILocation(line: 0, scope: !6)
!49 = !DILocalVariable(name: "env", arg: 2, scope: !6, file: !7, line: 75, type: !12)
!50 = !DILocation(line: 76, column: 5, scope: !6)
!51 = !DILocation(line: 77, column: 5, scope: !6)
!52 = !DILocalVariable(name: "this", arg: 1, scope: !53, file: !7, line: 59, type: !75, flags: DIFlagArtificial)
!53 = distinct !DISubprogram(name: "audit_tuple", linkageName: "Worker_tag_audit_tuple_ii2ooo", scope: !7, file: !7, line: 59, type: !54, scopeLine: 59, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !73, retainedNodes: !74)
!54 = !DISubroutineType(types: !55)
!55 = !{!56, !59, !64}
!56 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !57, size: 64, align: 64, dwarfAddressSpace: 0)
!57 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", file: !58, line: 5, size: 64, align: 64, elements: !4, identifier: "None")
!58 = !DIFile(filename: "<checkout>/packages/builtin/none.pony", directory: "")
!59 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64, align: 64, dwarfAddressSpace: 0)
!60 = !DICompositeType(tag: DW_TAG_structure_type, name: "Worker", file: !7, line: 77, size: 2496, align: 64, elements: !61, identifier: "Worker")
!61 = !{!62}
!62 = !DIDerivedType(tag: DW_TAG_member, name: "_ran", file: !7, line: 33, baseType: !63, size: 8, align: 8, offset: 2432, flags: DIFlagPrivate)
!63 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean)
!64 = !DICompositeType(tag: DW_TAG_structure_type, name: "t2_Leaf_val_Leaf_val", file: !7, line: 59, size: 128, align: 64, elements: !65, identifier: "t2_Leaf_val_Leaf_val")
!65 = !{!66, !72}
!66 = !DIDerivedType(tag: DW_TAG_member, name: "_1", file: !7, line: 59, baseType: !67, size: 64, align: 64)
!67 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !68, size: 64, align: 64, dwarfAddressSpace: 0)
!68 = !DICompositeType(tag: DW_TAG_structure_type, name: "Leaf", file: !7, line: 48, size: 128, align: 64, elements: !69, identifier: "Leaf")
!69 = !{!70}
!70 = !DIDerivedType(tag: DW_TAG_member, name: "n", file: !7, line: 9, baseType: !71, size: 64, align: 64, offset: 64)
!71 = !DIBasicType(name: "U64", size: 64, encoding: DW_ATE_unsigned)
!72 = !DIDerivedType(tag: DW_TAG_member, name: "_2", file: !7, line: 59, baseType: !67, size: 64, align: 64, offset: 64)
!73 = !DISubprogram(name: "audit_tuple", linkageName: "Worker_tag_audit_tuple_ii2ooo", scope: !60, file: !7, line: 59, type: !54, scopeLine: 59, spFlags: 0)
!74 = !{!52}
!75 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !60, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!76 = !DILocation(line: 0, scope: !53)
!77 = !DILocalVariable(name: "pair", arg: 2, scope: !53, file: !7, line: 59, type: !64)
!78 = !DILocation(line: 59, column: 49, scope: !53)
!79 = !DILocalVariable(name: "this", arg: 1, scope: !80, file: !7, line: 72, type: !75, flags: DIFlagArtificial)
!80 = distinct !DISubprogram(name: "hold", linkageName: "Worker_tag_hold_ioo", scope: !7, file: !7, line: 72, type: !81, scopeLine: 72, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !85, retainedNodes: !86)
!81 = !DISubroutineType(types: !82)
!82 = !{!56, !59, !83}
!83 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64, align: 64, dwarfAddressSpace: 0)
!84 = !DICompositeType(tag: DW_TAG_structure_type, name: "Resource", file: !7, line: 72, size: 64, align: 64, elements: !4, identifier: "Resource")
!85 = !DISubprogram(name: "hold", linkageName: "Worker_tag_hold_ioo", scope: !60, file: !7, line: 72, type: !81, scopeLine: 72, spFlags: 0)
!86 = !{!79}
!87 = !DILocation(line: 0, scope: !80)
!88 = !DILocalVariable(name: "resource", arg: 2, scope: !80, file: !7, line: 72, type: !83)
!89 = !DILocation(line: 72, column: 34, scope: !80)
!90 = !DILocalVariable(name: "this", arg: 1, scope: !91, file: !7, line: 44, type: !75, flags: DIFlagArtificial)
!91 = distinct !DISubprogram(name: "audit_constructor", linkageName: "Worker_tag_audit_constructor_o", scope: !7, file: !7, line: 44, type: !92, scopeLine: 44, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !94, retainedNodes: !95)
!92 = !DISubroutineType(types: !93)
!93 = !{!56, !59}
!94 = !DISubprogram(name: "audit_constructor", linkageName: "Worker_tag_audit_constructor_o", scope: !60, file: !7, line: 44, type: !92, scopeLine: 44, spFlags: 0)
!95 = !{!90, !96}
!96 = !DILocalVariable(name: "e", scope: !91, file: !7, line: 45, type: !97, align: 64)
!97 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !98, size: 64, align: 64, dwarfAddressSpace: 0)
!98 = !DICompositeType(tag: DW_TAG_structure_type, name: "Effect", file: !7, line: 45, size: 64, align: 64, elements: !4, identifier: "Effect")
!99 = !DILocation(line: 0, scope: !91)
!100 = !DILocalVariable(name: "this", arg: 1, scope: !101, file: !7, line: 23, type: !106, flags: DIFlagArtificial)
!101 = distinct !DISubprogram(name: "create", linkageName: "Effect_val_create_o", scope: !7, file: !7, line: 23, type: !102, scopeLine: 23, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !104, retainedNodes: !105)
!102 = !DISubroutineType(types: !103)
!103 = !{!97, !97}
!104 = !DISubprogram(name: "create", linkageName: "Effect_val_create_o", scope: !98, file: !7, line: 23, type: !102, scopeLine: 23, spFlags: 0)
!105 = !{!100}
!106 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !98, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!107 = !DILocation(line: 0, scope: !101, inlinedAt: !108)
!108 = distinct !DILocation(line: 45, column: 25, scope: !91)
!109 = !DILocation(line: 23, column: 50, scope: !101, inlinedAt: !108)
!110 = !DILocation(line: 23, column: 23, scope: !101, inlinedAt: !108)
!111 = !DILocation(line: 46, column: 5, scope: !91)
!112 = !DILocalVariable(name: "this", arg: 1, scope: !113, file: !7, line: 42, type: !75, flags: DIFlagArtificial)
!113 = distinct !DISubprogram(name: "set_sentinel", linkageName: "Worker_tag_set_sentinel_o", scope: !7, file: !7, line: 42, type: !92, scopeLine: 42, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !114, retainedNodes: !115)
!114 = !DISubprogram(name: "set_sentinel", linkageName: "Worker_tag_set_sentinel_o", scope: !60, file: !7, line: 42, type: !92, scopeLine: 42, spFlags: 0)
!115 = !{!112}
!116 = !DILocation(line: 0, scope: !113)
!117 = !DILocation(line: 42, column: 39, scope: !113)
!118 = !{!119}
!119 = distinct !{!119, !120, !"Worker_tag_audit_transfer_motoo: %item"}
!120 = distinct !{!120, !"Worker_tag_audit_transfer_motoo"}
!121 = !DILocalVariable(name: "this", arg: 1, scope: !122, file: !7, line: 61, type: !75, flags: DIFlagArtificial)
!122 = distinct !DISubprogram(name: "audit_transfer", linkageName: "Worker_tag_audit_transfer_motoo", scope: !7, file: !7, line: 61, type: !123, scopeLine: 61, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !135, retainedNodes: !136)
!123 = !DISubroutineType(types: !124)
!124 = !{!56, !59, !125, !129}
!125 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !126, size: 64, align: 64, dwarfAddressSpace: 0)
!126 = !DICompositeType(tag: DW_TAG_structure_type, name: "Parcel", file: !7, line: 61, size: 128, align: 64, elements: !127, identifier: "Parcel")
!127 = !{!128}
!128 = !DIDerivedType(tag: DW_TAG_member, name: "n", file: !7, line: 17, baseType: !71, size: 64, align: 64, offset: 64)
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64, align: 64, dwarfAddressSpace: 0)
!130 = !DICompositeType(tag: DW_TAG_structure_type, name: "Sink", file: !7, line: 61, size: 2496, align: 64, elements: !131, identifier: "Sink")
!131 = !{!132}
!132 = !DIDerivedType(tag: DW_TAG_member, name: "parcel", file: !7, line: 26, baseType: !133, size: 64, align: 64, offset: 2432)
!133 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !134, size: 64, align: 64, dwarfAddressSpace: 0)
!134 = !DICompositeType(tag: DW_TAG_structure_type, name: "u2_Parcel_ref_None_val", file: !7, line: 26, elements: !4, identifier: "u2_Parcel_ref_None_val")
!135 = !DISubprogram(name: "audit_transfer", linkageName: "Worker_tag_audit_transfer_motoo", scope: !60, file: !7, line: 61, type: !123, scopeLine: 61, spFlags: 0)
!136 = !{!121}
!137 = !DILocation(line: 0, scope: !122)
!138 = !DILocalVariable(name: "item", arg: 2, scope: !122, file: !7, line: 61, type: !125)
!139 = !DILocalVariable(name: "sink", arg: 3, scope: !122, file: !7, line: 61, type: !129)
!140 = !DILocation(line: 62, column: 14, scope: !122)
!141 = !DILocation(line: 63, column: 25, scope: !122)
!142 = !DILocation(line: 63, column: 5, scope: !122)
!143 = !DILocalVariable(name: "this", arg: 1, scope: !144, file: !7, line: 70, type: !75, flags: DIFlagArtificial)
!144 = distinct !DISubprogram(name: "audit_finalisers", linkageName: "Worker_tag_audit_finalisers_o", scope: !7, file: !7, line: 70, type: !92, scopeLine: 70, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !145, retainedNodes: !146)
!145 = !DISubprogram(name: "audit_finalisers", linkageName: "Worker_tag_audit_finalisers_o", scope: !60, file: !7, line: 70, type: !92, scopeLine: 70, spFlags: 0)
!146 = !{!143}
!147 = !DILocation(line: 0, scope: !144)
!148 = !DILocation(line: 70, column: 28, scope: !144)
!149 = !DILocalVariable(name: "this", arg: 1, scope: !150, file: !7, line: 25, type: !155, flags: DIFlagArtificial)
!150 = distinct !DISubprogram(name: "create", linkageName: "Sink_tag_create_o", scope: !7, file: !7, line: 25, type: !151, scopeLine: 25, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !153, retainedNodes: !154)
!151 = !DISubroutineType(types: !152)
!152 = !{!129, !129}
!153 = !DISubprogram(name: "create", linkageName: "Sink_tag_create_o", scope: !130, file: !7, line: 25, type: !151, scopeLine: 25, spFlags: 0)
!154 = !{!149}
!155 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !130, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!156 = !DILocation(line: 0, scope: !150)
!157 = !DILocation(line: 26, column: 33, scope: !150)
!158 = !DILocation(line: 26, column: 3, scope: !150)
!159 = !{!160}
!160 = distinct !{!160, !161, !"Sink_tag_take_moo: %item"}
!161 = distinct !{!161, !"Sink_tag_take_moo"}
!162 = !DILocalVariable(name: "this", arg: 1, scope: !163, file: !7, line: 28, type: !155, flags: DIFlagArtificial)
!163 = distinct !DISubprogram(name: "take", linkageName: "Sink_tag_take_moo", scope: !7, file: !7, line: 28, type: !164, scopeLine: 28, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !166, retainedNodes: !167)
!164 = !DISubroutineType(types: !165)
!165 = !{!56, !129, !125}
!166 = !DISubprogram(name: "take", linkageName: "Sink_tag_take_moo", scope: !130, file: !7, line: 28, type: !164, scopeLine: 28, spFlags: 0)
!167 = !{!162}
!168 = !DILocation(line: 0, scope: !163)
!169 = !DILocalVariable(name: "item", arg: 2, scope: !163, file: !7, line: 28, type: !125)
!170 = !DILocation(line: 29, column: 12, scope: !163)
!171 = !DILocation(line: 30, column: 12, scope: !163)
!172 = distinct !DISubprogram(name: "runtime_override_defaults", linkageName: "Main_runtime_override_defaults_oo", scope: !7, file: !7, line: 74, type: !173, scopeLine: 74, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !206, retainedNodes: !207)
!173 = !DISubroutineType(types: !174)
!174 = !{!56, !175}
!175 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !176, size: 64, align: 64, dwarfAddressSpace: 0)
!176 = !DICompositeType(tag: DW_TAG_structure_type, name: "RuntimeOptions", file: !177, line: 74, size: 896, align: 64, elements: !178, identifier: "RuntimeOptions")
!177 = !DIFile(filename: "<checkout>/packages/builtin/runtime_options.pony", directory: "")
!178 = !{!179, !181, !182, !183, !184, !185, !186, !188, !189, !190, !191, !192, !193, !194, !195, !196, !197, !200, !201, !202, !203, !204, !205}
!179 = !DIDerivedType(tag: DW_TAG_member, name: "ponymaxthreads", file: !177, line: 37, baseType: !180, size: 32, align: 32)
!180 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned)
!181 = !DIDerivedType(tag: DW_TAG_member, name: "ponyminthreads", file: !177, line: 44, baseType: !180, size: 32, align: 32, offset: 32)
!182 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoscale", file: !177, line: 53, baseType: !63, size: 8, align: 8, offset: 64)
!183 = !DIDerivedType(tag: DW_TAG_member, name: "ponysuspendthreshold", file: !177, line: 60, baseType: !180, size: 32, align: 32, offset: 96)
!184 = !DIDerivedType(tag: DW_TAG_member, name: "ponycdinterval", file: !177, line: 67, baseType: !180, size: 32, align: 32, offset: 128)
!185 = !DIDerivedType(tag: DW_TAG_member, name: "ponygcinitial", file: !177, line: 73, baseType: !35, size: 64, align: 64, offset: 192)
!186 = !DIDerivedType(tag: DW_TAG_member, name: "ponygcfactor", file: !177, line: 79, baseType: !187, size: 64, align: 64, offset: 256)
!187 = !DIBasicType(name: "F64", size: 64, encoding: DW_ATE_float)
!188 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoyield", file: !177, line: 85, baseType: !63, size: 8, align: 8, offset: 320)
!189 = !DIDerivedType(tag: DW_TAG_member, name: "ponynoblock", file: !177, line: 90, baseType: !63, size: 8, align: 8, offset: 328)
!190 = !DIDerivedType(tag: DW_TAG_member, name: "ponypin", file: !177, line: 95, baseType: !63, size: 8, align: 8, offset: 336)
!191 = !DIDerivedType(tag: DW_TAG_member, name: "ponypinasio", file: !177, line: 101, baseType: !63, size: 8, align: 8, offset: 344)
!192 = !DIDerivedType(tag: DW_TAG_member, name: "ponypinpinnedactorthread", file: !177, line: 107, baseType: !63, size: 8, align: 8, offset: 352)
!193 = !DIDerivedType(tag: DW_TAG_member, name: "ponyprintstatsinterval", file: !177, line: 113, baseType: !180, size: 32, align: 32, offset: 384)
!194 = !DIDerivedType(tag: DW_TAG_member, name: "ponyversion", file: !177, line: 119, baseType: !63, size: 8, align: 8, offset: 416)
!195 = !DIDerivedType(tag: DW_TAG_member, name: "ponyhelp", file: !177, line: 124, baseType: !63, size: 8, align: 8, offset: 424)
!196 = !DIDerivedType(tag: DW_TAG_member, name: "ponymemoryprofile", file: !177, line: 129, baseType: !180, size: 32, align: 32, offset: 448)
!197 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingformat", file: !177, line: 146, baseType: !198, size: 64, align: 64, offset: 512)
!198 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !199, size: 64, align: 64, dwarfAddressSpace: 0)
!199 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_U8_val", file: !40, line: 52, elements: !4, identifier: "Pointer_U8_val")
!200 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingoutput", file: !177, line: 151, baseType: !198, size: 64, align: 64, offset: 576)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingcategories", file: !177, line: 156, baseType: !198, size: 64, align: 64, offset: 640)
!202 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingmode", file: !177, line: 163, baseType: !198, size: 64, align: 64, offset: 704)
!203 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingflightrecorderbuffer", file: !177, line: 169, baseType: !35, size: 64, align: 64, offset: 768)
!204 = !DIDerivedType(tag: DW_TAG_member, name: "ponytracingflightrecorderhandletermint", file: !177, line: 175, baseType: !63, size: 8, align: 8, offset: 832)
!205 = !DIDerivedType(tag: DW_TAG_member, name: "ponypintracingthread", file: !177, line: 181, baseType: !63, size: 8, align: 8, offset: 840)
!206 = !DISubprogram(name: "runtime_override_defaults", linkageName: "Main_runtime_override_defaults_oo", scope: !11, file: !7, line: 74, type: !173, scopeLine: 74, spFlags: 0)
!207 = !{!208}
!208 = !DILocalVariable(name: "rto", arg: 1, scope: !172, file: !7, line: 74, type: !209, flags: DIFlagArtificial)
!209 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !176, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!210 = !DILocation(line: 0, scope: !172)
!211 = !DILocation(line: 74, column: 1, scope: !172)
!212 = distinct !DISubprogram(name: "create", linkageName: "Resource_iso_create_o", scope: !7, file: !7, line: 13, type: !213, scopeLine: 13, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !215, retainedNodes: !216)
!213 = !DISubroutineType(types: !214)
!214 = !{!83, !83}
!215 = !DISubprogram(name: "create", linkageName: "Resource_iso_create_o", scope: !84, file: !7, line: 13, type: !213, scopeLine: 13, spFlags: 0)
!216 = !{!217}
!217 = !DILocalVariable(name: "this", arg: 1, scope: !212, file: !7, line: 13, type: !218, flags: DIFlagArtificial)
!218 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !84, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!219 = !DILocation(line: 0, scope: !212)
!220 = !DILocation(line: 13, column: 1, scope: !212)
!221 = distinct !DISubprogram(name: "_final", linkageName: "Resource_box__final_o", scope: !7, file: !7, line: 14, type: !222, scopeLine: 14, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !224, retainedNodes: !225)
!222 = !DISubroutineType(types: !223)
!223 = !{!56, !83}
!224 = !DISubprogram(name: "_final", linkageName: "Resource_box__final_o", scope: !84, file: !7, line: 14, type: !222, scopeLine: 14, spFlags: 0)
!225 = !{!226}
!226 = !DILocalVariable(name: "this", arg: 1, scope: !221, file: !7, line: 14, type: !218, flags: DIFlagArtificial)
!227 = !DILocation(line: 0, scope: !221)
!228 = !DILocation(line: 14, column: 53, scope: !221)
!229 = !DILocation(line: 14, column: 19, scope: !221)
!230 = !DILocation(line: 0, scope: !101)
!231 = !DILocation(line: 23, column: 50, scope: !101)
!232 = !DILocation(line: 23, column: 23, scope: !101)
!233 = distinct !DISubprogram(name: "with_resource", linkageName: "Worker_tag_with_resource_o", scope: !7, file: !7, line: 65, type: !92, scopeLine: 65, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !234, retainedNodes: !235)
!234 = !DISubprogram(name: "with_resource", linkageName: "Worker_tag_with_resource_o", scope: !60, file: !7, line: 65, type: !92, scopeLine: 65, spFlags: 0)
!235 = !{!236, !237}
!236 = !DILocalVariable(name: "this", arg: 1, scope: !233, file: !7, line: 65, type: !75, flags: DIFlagArtificial)
!237 = !DILocalVariable(name: "resource", scope: !233, file: !7, line: 66, type: !83, align: 64)
!238 = !DILocation(line: 0, scope: !233)
!239 = !DILocation(line: 0, scope: !212, inlinedAt: !240)
!240 = distinct !DILocation(line: 66, column: 34, scope: !233)
!241 = !DILocation(line: 67, column: 21, scope: !233)
!242 = !DILocation(line: 68, column: 9, scope: !233)
!243 = distinct !DISubprogram(name: "create", linkageName: "Worker_tag_create_o", scope: !7, file: !7, line: 35, type: !244, scopeLine: 35, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !246, retainedNodes: !247)
!244 = !DISubroutineType(types: !245)
!245 = !{!59, !59}
!246 = !DISubprogram(name: "create", linkageName: "Worker_tag_create_o", scope: !60, file: !7, line: 35, type: !244, scopeLine: 35, spFlags: 0)
!247 = !{!248, !249}
!248 = !DILocalVariable(name: "this", arg: 1, scope: !243, file: !7, line: 35, type: !75, flags: DIFlagArtificial)
!249 = !DILocalVariable(name: "a", scope: !243, file: !7, line: 36, type: !67, align: 64)
!250 = !DILocation(line: 0, scope: !243)
!251 = !DILocation(line: 33, column: 3, scope: !243)
!252 = !DILocalVariable(name: "this", arg: 1, scope: !253, file: !7, line: 11, type: !258, flags: DIFlagArtificial)
!253 = distinct !DISubprogram(name: "create", linkageName: "Leaf_val_create_pWo", scope: !7, file: !7, line: 11, type: !254, scopeLine: 11, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !256, retainedNodes: !257)
!254 = !DISubroutineType(types: !255)
!255 = !{!67, !67, !71}
!256 = !DISubprogram(name: "create", linkageName: "Leaf_val_create_pWo", scope: !68, file: !7, line: 11, type: !254, scopeLine: 11, spFlags: 0)
!257 = !{!252}
!258 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !68, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!259 = !DILocation(line: 0, scope: !253, inlinedAt: !260)
!260 = distinct !DILocation(line: 36, column: 17, scope: !243)
!261 = !DILocalVariable(name: "n'", arg: 2, scope: !253, file: !7, line: 11, type: !71)
!262 = !DILocation(line: 11, column: 32, scope: !253, inlinedAt: !260)
!263 = !DILocation(line: 37, column: 17, scope: !243)
!264 = !DILocation(line: 38, column: 16, scope: !243)
!265 = !DILocalVariable(name: "this", arg: 1, scope: !266, file: !7, line: 19, type: !271, flags: DIFlagArtificial)
!266 = distinct !DISubprogram(name: "create", linkageName: "Parcel_ref_create_pWo", scope: !7, file: !7, line: 19, type: !267, scopeLine: 19, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !269, retainedNodes: !270)
!267 = !DISubroutineType(types: !268)
!268 = !{!125, !125, !71}
!269 = !DISubprogram(name: "create", linkageName: "Parcel_ref_create_pWo", scope: !126, file: !7, line: 19, type: !267, scopeLine: 19, spFlags: 0)
!270 = !{!265}
!271 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !126, size: 64, align: 64, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!272 = !DILocation(line: 0, scope: !266, inlinedAt: !273)
!273 = distinct !DILocation(line: 39, column: 38, scope: !274)
!274 = distinct !DILexicalBlock(scope: !243, file: !7, line: 39, column: 32)
!275 = !DILocalVariable(name: "n'", arg: 2, scope: !266, file: !7, line: 19, type: !71)
!276 = !DILocation(line: 19, column: 32, scope: !266, inlinedAt: !273)
!277 = !DILocation(line: 39, column: 47, scope: !243)
!278 = !DILocation(line: 39, column: 19, scope: !243)
!279 = !DILocation(line: 40, column: 22, scope: !243)
!280 = distinct !DISubprogram(name: "audit_roots", linkageName: "Worker_tag_audit_roots_toiotopWo", scope: !7, file: !7, line: 48, type: !281, scopeLine: 48, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !283, retainedNodes: !284)
!281 = !DISubroutineType(types: !282)
!282 = !{!56, !59, !59, !67, !67, !71}
!283 = !DISubprogram(name: "audit_roots", linkageName: "Worker_tag_audit_roots_toiotopWo", scope: !60, file: !7, line: 48, type: !281, scopeLine: 48, spFlags: 0)
!284 = !{!285, !286, !287, !288, !289, !290}
!285 = !DILocalVariable(name: "this", arg: 1, scope: !280, file: !7, line: 48, type: !75, flags: DIFlagArtificial)
!286 = !DILocalVariable(name: "x", scope: !280, file: !7, line: 49, type: !67, align: 64)
!287 = !DILocalVariable(name: "y", scope: !280, file: !7, line: 50, type: !67, align: 64)
!288 = !DILocalVariable(name: "alias_of_a", scope: !280, file: !7, line: 50, type: !67, align: 64)
!289 = !DILocalVariable(name: "mut", scope: !280, file: !7, line: 51, type: !125, align: 64)
!290 = !DILocalVariable(name: "unique", scope: !280, file: !7, line: 52, type: !125, align: 64)
!291 = !DILocation(line: 0, scope: !280)
!292 = !DILocalVariable(name: "peer", arg: 2, scope: !280, file: !7, line: 48, type: !59)
!293 = !DILocalVariable(name: "a", arg: 3, scope: !280, file: !7, line: 48, type: !67)
!294 = !DILocalVariable(name: "b", arg: 4, scope: !280, file: !7, line: 48, type: !67)
!295 = !DILocalVariable(name: "n", arg: 5, scope: !280, file: !7, line: 48, type: !71)
!296 = !DILocation(line: 0, scope: !253, inlinedAt: !297)
!297 = distinct !DILocation(line: 49, column: 27, scope: !280)
!298 = !DILocation(line: 11, column: 32, scope: !253, inlinedAt: !297)
!299 = !DILocation(line: 0, scope: !266, inlinedAt: !300)
!300 = distinct !DILocation(line: 51, column: 33, scope: !280)
!301 = !DILocation(line: 19, column: 32, scope: !266, inlinedAt: !300)
!302 = !DILocalVariable(name: "this", arg: 1, scope: !303, file: !7, line: 20, type: !271, flags: DIFlagArtificial)
!303 = distinct !DISubprogram(name: "create_trn", linkageName: "Parcel_trn_create_trn_pWo", scope: !7, file: !7, line: 20, type: !267, scopeLine: 20, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !304, retainedNodes: !305)
!304 = !DISubprogram(name: "create_trn", linkageName: "Parcel_trn_create_trn_pWo", scope: !126, file: !7, line: 20, type: !267, scopeLine: 20, spFlags: 0)
!305 = !{!302}
!306 = !DILocation(line: 0, scope: !303, inlinedAt: !307)
!307 = distinct !DILocation(line: 52, column: 47, scope: !280)
!308 = !DILocalVariable(name: "n'", arg: 2, scope: !303, file: !7, line: 20, type: !71)
!309 = !DILocation(line: 20, column: 36, scope: !303, inlinedAt: !307)
!310 = !DILocation(line: 53, column: 58, scope: !311)
!311 = distinct !DILexicalBlock(scope: !280, file: !7, line: 53, column: 5)
!312 = !DILocation(line: 53, column: 45, scope: !311)
!313 = !DILocation(line: 53, column: 32, scope: !311)
!314 = !DILocation(line: 53, column: 13, scope: !311)
!315 = !DILocation(line: 53, column: 23, scope: !311)
!316 = !DILocation(line: 53, column: 39, scope: !311)
!317 = !DILocation(line: 53, column: 67, scope: !311)
!318 = !DILocation(line: 54, column: 7, scope: !319)
!319 = distinct !DILexicalBlock(scope: !311, file: !7, line: 54, column: 7)
!320 = !DILocation(line: 54, column: 23, scope: !321)
!321 = distinct !DILexicalBlock(scope: !311, file: !7, line: 54, column: 23)
!322 = !DILocation(line: 56, column: 16, scope: !280)
!323 = !DILocation(line: 57, column: 18, scope: !280)
!324 = !DILocation(line: 0, scope: !253)
!325 = !DILocation(line: 11, column: 32, scope: !253)
!326 = !DILocation(line: 0, scope: !266)
!327 = !DILocation(line: 19, column: 32, scope: !266)
!328 = !DILocation(line: 0, scope: !303)
!329 = !DILocation(line: 20, column: 36, scope: !303)
