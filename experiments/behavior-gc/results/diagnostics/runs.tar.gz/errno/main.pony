use @close[I32](fd: I32)
use @pony_os_errno[I32]()
use @pony_exitcode[None](code: I32)
actor Main
  new create(env: Env) => test()
  be test() =>
    @close(-1)
    @pony_exitcode(@pony_os_errno())
