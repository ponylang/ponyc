use @puts[I32](s: Pointer[U8] tag)
class val C[A: Any val]
  let n: U64
  new val create(x: U64) => n = x
  new val create(x: U64) iftype A <: U64 =>
    @puts("specialized body".cstring())
    n = x
actor Main
  new create(env: Env) => run()
  be run() =>
    let x = C[U64](1)
    @puts("end".cstring())
