; ModuleID = 'gc-root-audit.builtin'
source_filename = "gc-root-audit.builtin"
target datalayout = "e-m:e-p:32:32-p270:32:32-p271:32:32-p272:64:64-i128:128-f64:32:64-f80:32-n8:16:32-S128"
target triple = "i386-unknown-linux-gnu"

%U32_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%Pointer_AsioEvent_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [21 x ptr] }
%"$0$16_Desc" = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%Pointer_Pointer_U8_val_ref_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [21 x ptr] }
%AmbientAuth_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [1 x ptr] }
%StdStream_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [2 x ptr] }
%Pointer_String_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [20 x ptr] }
%String_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Array_String_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Bool_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%F64_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%Stdin_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [5 x ptr] }
%I32_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%U64_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%USize_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [31 x ptr] }
%RuntimeOptions_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [0 x ptr] }
%Array_U8_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [10 x ptr] }
%Env_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%None_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%AsioEvent_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [9 x ptr] }
%U8_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [27 x ptr] }
%Pointer_U8_val_Desc = type { i32, i32, i32, i32, ptr, ptr, ptr, ptr, ptr, ptr, i32, i1, ptr, ptr, [25 x ptr] }
%"$0$16" = type { ptr }
%AmbientAuth = type { ptr }
%None = type { ptr }
%AsioEvent = type { ptr }

@U32_Desc = constant %U32_Desc { i32 20, i32 8, i32 0, i32 4, ptr null, ptr @11, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U32_Traits, ptr null, [27 x ptr] [ptr @U32_box_usize_Z_Unbox, ptr @U32_box_shl_II_Unbox, ptr @U32_val_usize_Z_Unbox, ptr @U32_val_ne_Ib_Unbox, ptr @U32_box_eq_Ib_Unbox, ptr @U32_val_op_and_II_Unbox, ptr @U32_val_shl_II_Unbox, ptr @U32_val_eq_Ib_Unbox, ptr @U32_box_ne_Ib_Unbox, ptr @U32_box_op_and_II_Unbox, ptr @U32_val_create_pII_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U32_box___digestof_] }
@Pointer_AsioEvent_val_Desc = constant %Pointer_AsioEvent_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @12, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_AsioEvent_val_Traits, ptr null, [21 x ptr] [ptr null, ptr @Pointer_AsioEvent_val_ref_create_o, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr @Pointer_AsioEvent_val_tag_is_null_b, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_AsioEvent_val_tag_is_null_b] }
@"$0$16_Desc" = constant %"$0$16_Desc" { i32 25, i32 4, i32 0, i32 0, ptr @"$0$16_Inst", ptr @13, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @"$0$16_Traits", ptr null, [9 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @"$0$16_val_create_o"] }
@Pointer_Pointer_U8_val_ref_Desc = constant %Pointer_Pointer_U8_val_ref_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @14, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_Pointer_U8_val_ref_Traits, ptr null, [21 x ptr] [ptr @Pointer_Pointer_U8_val_ref_val__apply_Zo, ptr @Pointer_Pointer_U8_val_ref_ref__apply_Zo, ptr @Pointer_Pointer_U8_val_ref_box__apply_Zo, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_Pointer_U8_val_ref_tag_is_null_b] }
@AmbientAuth_Desc = constant %AmbientAuth_Desc { i32 3, i32 4, i32 0, i32 0, ptr @AmbientAuth_Inst, ptr @15, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @AmbientAuth_Traits, ptr null, [1 x ptr] [ptr @AmbientAuth_val__create_o] }
@StdStream_Desc = constant %StdStream_Desc { i32 27, i32 304, i32 0, i32 300, ptr null, ptr @16, ptr @StdStream_GetBehaviourName, ptr @StdStream_Trace, ptr @StdStream_Dispatch, ptr null, i32 -1, i1 true, ptr @StdStream_Traits, ptr null, [2 x ptr] [ptr @StdStream_tag__err_o__send, ptr @StdStream_tag__out_o__send] }
@0 = private unnamed_addr constant [20 x i8] c"StdStream.*UNKNOWN*\00"
@Pointer_String_val_Desc = constant %Pointer_String_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @17, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_String_val_Traits, ptr null, [20 x ptr] [ptr @Pointer_String_val_ref__alloc_pZo, ptr @Pointer_String_val_ref_create_o, ptr @Pointer_String_val_tag__min_alloc_Z, ptr @Pointer_String_val_ref__update_Zoo, ptr null, ptr null, ptr null, ptr @Pointer_String_val_tag__min_alloc_Z, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_String_val_ref__realloc_ZZo, ptr null, ptr null, ptr null, ptr null, ptr @Pointer_String_val_tag__min_alloc_Z, ptr @Pointer_String_val_tag__min_alloc_Z] }
@String_Desc = constant %String_Desc { i32 5, i32 16, i32 0, i32 4, ptr null, ptr @18, ptr null, ptr @String_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @String_Traits, ptr null, [10 x ptr] [ptr @String_box_cstring_o, ptr @String_val_cstring_o, ptr @String_val_is_null_terminated_b, ptr @String_ref__set_ZCC, ptr @String_ref_is_null_terminated_b, ptr @String_ref_copy_cstring_moo, ptr @String_ref_cstring_o, ptr @String_box_is_null_terminated_b, ptr null, ptr @String_ref_create_pZo] }
@Array_String_val_Desc = constant %Array_String_val_Desc { i32 7, i32 16, i32 0, i32 4, ptr null, ptr @19, ptr null, ptr @Array_String_val_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Array_String_val_Traits, ptr null, [10 x ptr] [ptr @Array_String_val_ref_push_oo, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Array_String_val_ref_reserve_Zo, ptr null, ptr null, ptr @Array_String_val_ref_create_pZo] }
@Bool_Desc = constant %Bool_Desc { i32 8, i32 8, i32 0, i32 4, ptr null, ptr @20, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Bool_Traits, ptr null, [27 x ptr] [ptr @Bool_val_op_and_bb_Unbox, ptr @Bool_box_op_not_b_Unbox, ptr @Bool_box_op_and_bb_Unbox, ptr @Bool_val_op_not_b_Unbox, ptr @Bool_val_create_pbb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @Bool_box___digestof_] }
@F64_Desc = constant %F64_Desc { i32 24, i32 12, i32 0, i32 4, ptr null, ptr @21, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @F64_Traits, ptr null, [27 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @F64_box___digestof_] }
@Stdin_Desc = constant %Stdin_Desc { i32 31, i32 316, i32 0, i32 300, ptr null, ptr @22, ptr @Stdin_GetBehaviourName, ptr @Stdin_Trace, ptr @Stdin_Dispatch, ptr null, i32 1, i1 true, ptr @Stdin_Traits, ptr null, [5 x ptr] [ptr @Stdin_tag__create_pbo__send, ptr @Stdin_tag__event_notify_topIpIo__send, ptr @Stdin_ref__read_b, ptr @Stdin_ref__close_event_o, ptr @Stdin_tag__read_again_o__send] }
@1 = private unnamed_addr constant [16 x i8] c"Stdin.*UNKNOWN*\00"
@I32_Desc = constant %I32_Desc { i32 12, i32 8, i32 0, i32 4, ptr null, ptr @23, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @I32_Traits, ptr null, [27 x ptr] [ptr @I32_val_create_pii_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @I32_box___digestof_] }
@U64_Desc = constant %U64_Desc { i32 16, i32 12, i32 0, i32 4, ptr null, ptr @24, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U64_Traits, ptr null, [27 x ptr] [ptr @U64_val_create_pWW_Unbox, ptr @U64_box_eq_Wb_Unbox, ptr @U64_val_eq_Wb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U64_box___digestof_] }
@USize_Desc = constant %USize_Desc { i32 0, i32 8, i32 0, i32 4, ptr null, ptr @25, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @USize_Traits, ptr null, [31 x ptr] [ptr @USize_val_create_pZZ_Unbox, ptr @USize_val_add_ZZ_Unbox, ptr @USize_val_ne_Zb_Unbox, ptr @USize_box_neg_Z_Unbox, ptr @USize_val_max_value_Z_Unbox, ptr @USize_val_next_pow2_Z_Unbox, ptr @USize_val_neg_Z_Unbox, ptr @USize_box_min_ZZ_Unbox, ptr @USize_box_eq_Zb_Unbox, ptr @USize_box_shl_ZZ_Unbox, ptr @USize_val_gt_Zb_Unbox, ptr @USize_box_sub_ZZ_Unbox, ptr @USize_box_clz_Z_Unbox, ptr @USize_box_add_ZZ_Unbox, ptr @USize_val_min_ZZ_Unbox, ptr @USize_val_u32_I_Unbox, ptr @USize_box_bitwidth_Z_Unbox, ptr @USize_box_ne_Zb_Unbox, ptr @USize_box_next_pow2_Z_Unbox, ptr @USize_val_sub_ZZ_Unbox, ptr @USize_box_max_ZZ_Unbox, ptr @USize_val_max_ZZ_Unbox, ptr @USize_val_eq_Zb_Unbox, ptr @USize_val_shl_ZZ_Unbox, ptr @USize_box_lt_Zb_Unbox, ptr @USize_val_lt_Zb_Unbox, ptr @USize_box___digestof_, ptr @USize_val_clz_Z_Unbox, ptr @USize_val_bitwidth_Z_Unbox, ptr @USize_box_u32_I_Unbox, ptr @USize_box_gt_Zb_Unbox] }
@RuntimeOptions_Desc = constant %RuntimeOptions_Desc { i32 -1, i32 76, i32 0, i32 0, ptr null, ptr @26, ptr null, ptr @RuntimeOptions_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @RuntimeOptions_Traits, ptr null, [0 x ptr] zeroinitializer }
@Array_U8_val_Desc = constant %Array_U8_val_Desc { i32 33, i32 16, i32 0, i32 4, ptr null, ptr @27, ptr null, ptr @Array_U8_val_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Array_U8_val_Traits, ptr null, [10 x ptr] [ptr @Array_U8_val_ref_cpointer_Zo, ptr @Array_U8_val_box_size_Z, ptr @Array_U8_val_val_cpointer_Zo, ptr @Array_U8_val_ref_truncate_Zo, ptr @Array_U8_val_ref_undefined_U8_val_Zo, ptr @Array_U8_val_ref_size_Z, ptr @Array_U8_val_ref_reserve_Zo, ptr @Array_U8_val_val_size_Z, ptr @Array_U8_val_box_cpointer_Zo, ptr @Array_U8_val_ref_create_pZo] }
@Env_Desc = constant %Env_Desc { i32 9, i32 32, i32 0, i32 4, ptr null, ptr @28, ptr null, ptr @Env_Trace, ptr null, ptr null, i32 -1, i1 true, ptr @Env_Traits, ptr null, [9 x ptr] [ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_ref__create_pIioioo, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__count_strings_oZ, ptr @Env_tag__strings_from_pointers_oZo, ptr @Env_tag__strings_from_pointers_oZo] }
@None_Desc = constant %None_Desc { i32 13, i32 4, i32 0, i32 0, ptr @None_Inst, ptr @29, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @None_Traits, ptr null, [9 x ptr] [ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @None_val_create_o] }
@AsioEvent_Desc = constant %AsioEvent_Desc { i32 29, i32 4, i32 0, i32 0, ptr @AsioEvent_Inst, ptr @30, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @AsioEvent_Traits, ptr null, [9 x ptr] [ptr @AsioEvent_val_disposable_Ib, ptr @AsioEvent_val_none_o, ptr @AsioEvent_box_none_o, ptr @AsioEvent_box_disposable_Ib, ptr @AsioEvent_box_readable_Ib, ptr @AsioEvent_val_errored_Ib, ptr @AsioEvent_val_readable_Ib, ptr @AsioEvent_box_errored_Ib, ptr @AsioEvent_val_create_o] }
@U8_Desc = constant %U8_Desc { i32 4, i32 8, i32 0, i32 4, ptr null, ptr @31, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @U8_Traits, ptr null, [27 x ptr] [ptr @U8_box_ne_Cb_Unbox, ptr @U8_val_create_pCC_Unbox, ptr @U8_val_eq_Cb_Unbox, ptr @U8_val_ne_Cb_Unbox, ptr @U8_box_eq_Cb_Unbox, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr null, ptr @U8_box___digestof_] }
@Pointer_U8_val_Desc = constant %Pointer_U8_val_Desc { i32 -1, i32 0, i32 0, i32 0, ptr null, ptr @32, ptr null, ptr null, ptr null, ptr null, i32 -1, i1 true, ptr @Pointer_U8_val_Traits, ptr null, [25 x ptr] [ptr @Pointer_U8_val_ref__alloc_pZo, ptr @Pointer_U8_val_ref_create_o, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_box__apply_ZC, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_box__copy_to_oZo, ptr @Pointer_U8_val_ref__apply_ZC, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_box__offset_Zo, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_ref__realloc_ZZo, ptr @Pointer_U8_val_ref__copy_to_oZo, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_tag__unsafe_o, ptr @Pointer_U8_val_val__apply_ZC, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag__min_alloc_Z, ptr @Pointer_U8_val_tag_is_null_b, ptr @Pointer_U8_val_ref__update_ZCC, ptr @Pointer_U8_val_val__offset_Zo, ptr @Pointer_U8_val_ref__offset_Zo, ptr @Pointer_U8_val_val__copy_to_oZo] }
@"$0$16_Inst" = constant %"$0$16" { ptr @"$0$16_Desc" }
@AmbientAuth_Inst = constant %AmbientAuth { ptr @AmbientAuth_Desc }
@None_Inst = constant %None { ptr @None_Desc }
@AsioEvent_Inst = constant %AsioEvent { ptr @AsioEvent_Desc }
@2 = private unnamed_addr constant [15 x i8] c"StdStream._err\00"
@3 = private unnamed_addr constant [15 x i8] c"StdStream._out\00"
@4 = private unnamed_addr constant [14 x i8] c"Stdin._create\00"
@5 = private unnamed_addr constant [24 x i8] c"Stdin_tag__read_again_o\00"
@6 = private unnamed_addr constant [16 x i8] c"receiver-layout\00"
@7 = private unnamed_addr constant [18 x i8] c"Stdin._read_again\00"
@8 = private unnamed_addr constant [32 x i8] c"Stdin_tag__event_notify_topIpIo\00"
@9 = private unnamed_addr constant [16 x i8] c"receiver-layout\00"
@10 = private unnamed_addr constant [20 x i8] c"Stdin._event_notify\00"
@11 = private unnamed_addr constant [4 x i8] c"U32\00"
@U32_Traits = constant [1 x i32] zeroinitializer
@12 = private unnamed_addr constant [22 x i8] c"Pointer_AsioEvent_val\00"
@Pointer_AsioEvent_val_Traits = constant [1 x i32] zeroinitializer
@13 = private unnamed_addr constant [6 x i8] c"$0$16\00"
@"$0$16_Traits" = constant [1 x i32] [i32 4]
@14 = private unnamed_addr constant [27 x i8] c"Pointer_Pointer_U8_val_ref\00"
@Pointer_Pointer_U8_val_ref_Traits = constant [1 x i32] zeroinitializer
@15 = private unnamed_addr constant [12 x i8] c"AmbientAuth\00"
@AmbientAuth_Traits = constant [1 x i32] zeroinitializer
@16 = private unnamed_addr constant [10 x i8] c"StdStream\00"
@StdStream_Traits = constant [1 x i32] [i32 2]
@17 = private unnamed_addr constant [19 x i8] c"Pointer_String_val\00"
@Pointer_String_val_Traits = constant [1 x i32] zeroinitializer
@18 = private unnamed_addr constant [7 x i8] c"String\00"
@String_Traits = constant [1 x i32] zeroinitializer
@19 = private unnamed_addr constant [17 x i8] c"Array_String_val\00"
@Array_String_val_Traits = constant [1 x i32] zeroinitializer
@20 = private unnamed_addr constant [5 x i8] c"Bool\00"
@Bool_Traits = constant [1 x i32] zeroinitializer
@21 = private unnamed_addr constant [4 x i8] c"F64\00"
@F64_Traits = constant [1 x i32] zeroinitializer
@22 = private unnamed_addr constant [6 x i8] c"Stdin\00"
@Stdin_Traits = constant [1 x i32] [i32 1]
@23 = private unnamed_addr constant [4 x i8] c"I32\00"
@I32_Traits = constant [1 x i32] zeroinitializer
@24 = private unnamed_addr constant [4 x i8] c"U64\00"
@U64_Traits = constant [1 x i32] zeroinitializer
@25 = private unnamed_addr constant [6 x i8] c"USize\00"
@USize_Traits = constant [1 x i32] zeroinitializer
@26 = private unnamed_addr constant [15 x i8] c"RuntimeOptions\00"
@RuntimeOptions_Traits = constant [1 x i32] zeroinitializer
@27 = private unnamed_addr constant [13 x i8] c"Array_U8_val\00"
@Array_U8_val_Traits = constant [1 x i32] zeroinitializer
@28 = private unnamed_addr constant [4 x i8] c"Env\00"
@Env_Traits = constant [1 x i32] zeroinitializer
@29 = private unnamed_addr constant [5 x i8] c"None\00"
@None_Traits = constant [1 x i32] [i32 24]
@30 = private unnamed_addr constant [10 x i8] c"AsioEvent\00"
@AsioEvent_Traits = constant [1 x i32] zeroinitializer
@31 = private unnamed_addr constant [3 x i8] c"U8\00"
@U8_Traits = constant [1 x i32] zeroinitializer
@32 = private unnamed_addr constant [15 x i8] c"Pointer_U8_val\00"
@Pointer_U8_val_Traits = constant [1 x i32] zeroinitializer

declare void @ponyint_gc_root_audit(ptr, ptr, ptr, i32, i32, ptr, i32, ptr, ptr)

; Function Attrs: nounwind memory(none)
declare ptr @pony_ctx() #0

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(300) ptr @pony_create(ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_destroy(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_sendv_single(ptr, ptr, ptr, ptr, i1) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_alloc(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(32) ptr @pony_alloc_small(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable(1024) ptr @pony_alloc_large(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 dereferenceable_or_null(32) ptr @pony_realloc(ptr, ptr, i32, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable_or_null(32) ptr @pony_alloc_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(32) ptr @pony_alloc_small_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare align 32 dereferenceable(1024) ptr @pony_alloc_large_final(ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare noalias align 32 ptr @pony_alloc_msg(i32, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_trace(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceknown(ptr, ptr readonly, ptr, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_traceunknown(ptr, ptr readonly, i32) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_send(ptr, ptr readnone) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_gc_recv(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_send_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @pony_recv_done(ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i32 @pony_init(i32, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @ponyint_become(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: readwrite, inaccessiblemem: readwrite)
declare i1 @pony_start(ptr, ptr) #1

; Function Attrs: nounwind memory(argmem: read)
declare i32 @pony_get_exitcode() #2

declare void @pony_coverage_init(i32)

declare void @pony_coverage_write(ptr)

; Function Attrs: noreturn
declare void @abort() #3

; Function Attrs: nounwind memory(argmem: read)
declare i32 @memcmp(ptr readonly, ptr readonly, i32) #2

declare i32 @puts(ptr)

define void @StdStream_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i32 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 0, label %handler
    i32 1, label %handler1
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
    #dbg_value(ptr %1, !5, !DIExpression(), !20)
  %4 = call ptr @pony_os_stderr(), !dbg !21
  %5 = getelementptr inbounds nuw i8, ptr %1, i32 300, !dbg !22
  store ptr %4, ptr %5, align 4, !dbg !22
  ret void

handler1:                                         ; preds = %entry
    #dbg_value(ptr %1, !23, !DIExpression(), !27)
  %6 = call ptr @pony_os_stdout(), !dbg !28
  %7 = getelementptr inbounds nuw i8, ptr %1, i32 300, !dbg !29
  store ptr %6, ptr %7, align 4, !dbg !29
  ret void
}

define ptr @StdStream_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 0, label %handler
    i32 1, label %handler1
  ]

default:                                          ; preds = %entry
  ret ptr @0

handler:                                          ; preds = %entry
  ret ptr @2

handler1:                                         ; preds = %entry
  ret ptr @3
}

define void @StdStream_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 300
  %3 = load ptr, ptr %2, align 4
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @String_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 12
  %3 = load ptr, ptr %2, align 4
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @Array_String_val_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 12
  %3 = load ptr, ptr %2, align 4
  call void @pony_trace(ptr %0, ptr %3)
  %4 = getelementptr inbounds nuw i8, ptr %1, i32 4
  %5 = load i32, ptr %4, align 4
  br label %cond

cond:                                             ; preds = %body, %entry
  %6 = phi i32 [ 0, %entry ], [ %10, %body ]
  %7 = icmp ult i32 %6, %5
  br i1 %7, label %body, label %post

body:                                             ; preds = %cond
  %8 = getelementptr inbounds [4 x i8], ptr %3, i32 %6
  %9 = load ptr, ptr %8, align 4
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @String_Desc, i32 1)
  %10 = add i32 %6, 1
  br label %cond

post:                                             ; preds = %cond
  ret void
}

define void @Stdin_Dispatch(ptr %0, ptr %1, ptr %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds nuw i8, ptr %2, i32 4
  %id = load i32, ptr %3, align 4
  switch i32 %id, label %unreachable [
    i32 0, label %handler
    i32 4, label %handler1
    i32 1, label %handler2
  ]

unreachable:                                      ; preds = %entry
  unreachable

handler:                                          ; preds = %entry
  %4 = getelementptr inbounds nuw i8, ptr %2, i32 12
  %5 = load i8, ptr %4, align 1
  %6 = trunc i8 %5 to i1
    #dbg_value(ptr %1, !30, !DIExpression(), !51)
    #dbg_value(i1 %6, !52, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !51)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !63)
  %7 = getelementptr inbounds nuw i8, ptr %1, i32 300, !dbg !65
  store ptr @None_Inst, ptr %7, align 4, !dbg !65
  %8 = getelementptr inbounds nuw i8, ptr %1, i32 304, !dbg !66
  store i32 32, ptr %8, align 4, !dbg !66
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !77)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !85)
  %9 = getelementptr inbounds nuw i8, ptr %1, i32 308, !dbg !87
  store ptr null, ptr %9, align 4, !dbg !87
  %10 = getelementptr inbounds nuw i8, ptr %1, i32 312, !dbg !88
  %11 = zext i1 %6 to i8, !dbg !88
  store i8 %11, ptr %10, align 1, !dbg !88
  ret void

handler1:                                         ; preds = %entry
  %12 = call ptr @pony_ctx()
    #dbg_value(ptr %1, !89, !DIExpression(), !95)
  call void @ponyint_gc_root_audit(ptr %0, ptr nonnull dereferenceable(316) %1, ptr nonnull @5, i32 147, i32 10, ptr nonnull @6, i32 0, ptr null, ptr null)
  %13 = call i1 @Stdin_ref__read_b(ptr nonnull dereferenceable(316) %1), !dbg !96
  ret void

handler2:                                         ; preds = %entry
  %14 = getelementptr inbounds nuw i8, ptr %2, i32 12
  %15 = load ptr, ptr %14, align 4
  %16 = getelementptr inbounds nuw i8, ptr %2, i32 16
  %17 = load i32, ptr %16, align 4
  %18 = getelementptr inbounds nuw i8, ptr %2, i32 20
  %19 = load i32, ptr %18, align 4
  call void @pony_gc_recv(ptr %0)
  call void @pony_traceknown(ptr %0, ptr %15, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  call void @pony_recv_done(ptr %0)
  call void @Stdin_tag__event_notify_topIpIo(ptr %1, ptr %15, i32 %17, i32 %19)
  ret void
}

define ptr @Stdin_GetBehaviourName(i32 %0) unnamed_addr #4 !pony.abi !4 {
entry:
  switch i32 %0, label %default [
    i32 0, label %handler
    i32 4, label %handler1
    i32 1, label %handler2
  ]

default:                                          ; preds = %entry
  ret ptr @1

handler:                                          ; preds = %entry
  ret ptr @4

handler1:                                         ; preds = %entry
  ret ptr @7

handler2:                                         ; preds = %entry
  ret ptr @10
}

define void @Stdin_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 300
  %3 = load ptr, ptr %2, align 4
  call void @pony_traceunknown(ptr %0, ptr %3, i32 0)
  %4 = getelementptr inbounds nuw i8, ptr %1, i32 308
  %5 = load ptr, ptr %4, align 4
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  ret void
}

define void @RuntimeOptions_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 52
  %3 = load ptr, ptr %2, align 4
  call void @pony_traceknown(ptr %0, ptr %3, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %4 = getelementptr inbounds nuw i8, ptr %1, i32 56
  %5 = load ptr, ptr %4, align 4
  call void @pony_traceknown(ptr %0, ptr %5, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %6 = getelementptr inbounds nuw i8, ptr %1, i32 60
  %7 = load ptr, ptr %6, align 4
  call void @pony_traceknown(ptr %0, ptr %7, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  %8 = getelementptr inbounds nuw i8, ptr %1, i32 64
  %9 = load ptr, ptr %8, align 4
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @Pointer_U8_val_Desc, i32 0)
  ret void
}

define void @Array_U8_val_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 12
  %3 = load ptr, ptr %2, align 4
  call void @pony_trace(ptr %0, ptr %3)
  ret void
}

define void @Env_Trace(ptr %0, ptr %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 8
  %3 = load ptr, ptr %2, align 4
  call void @pony_traceunknown(ptr %0, ptr %3, i32 2)
  %4 = getelementptr inbounds nuw i8, ptr %1, i32 12
  %5 = load ptr, ptr %4, align 4
  call void @pony_traceunknown(ptr %0, ptr %5, i32 2)
  %6 = getelementptr inbounds nuw i8, ptr %1, i32 16
  %7 = load ptr, ptr %6, align 4
  call void @pony_traceunknown(ptr %0, ptr %7, i32 2)
  %8 = getelementptr inbounds nuw i8, ptr %1, i32 20
  %9 = load ptr, ptr %8, align 4
  call void @pony_traceknown(ptr %0, ptr %9, ptr nonnull @Array_String_val_Desc, i32 1)
  %10 = getelementptr inbounds nuw i8, ptr %1, i32 24
  %11 = load ptr, ptr %10, align 4
  call void @pony_traceknown(ptr %0, ptr %11, ptr nonnull @Array_String_val_Desc, i32 1)
  %12 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %13 = load ptr, ptr %12, align 4
  call void @pony_traceunknown(ptr %0, ptr %13, i32 1)
  ret void
}

define i32 @U32_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  ret i32 %2
}

define i32 @U32_val_op_and_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !97 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !104, !DIExpression(), !106)
    #dbg_value(i32 %y, !107, !DIExpression(), !106)
  %0 = and i32 %this, %y, !dbg !108
  ret i32 %0, !dbg !108
}

define i32 @U32_box_op_and_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !109 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !112, !DIExpression(), !113)
    #dbg_value(i32 %y, !114, !DIExpression(), !113)
  %0 = and i32 %this, %y, !dbg !115
  ret i32 %0, !dbg !115
}

define i32 @U32_val_shl_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !116 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !119, !DIExpression(), !120)
    #dbg_value(i32 %y, !121, !DIExpression(), !120)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !122
  %1 = shl i32 %this, %0, !dbg !122
  ret i32 %1, !dbg !122
}

define i32 @U32_box_shl_II(i32 %this, i32 %y) unnamed_addr #4 !dbg !123 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !126, !DIExpression(), !127)
    #dbg_value(i32 %y, !128, !DIExpression(), !127)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !129
  %1 = shl i32 %this, %0, !dbg !129
  ret i32 %1, !dbg !129
}

define i1 @U32_val_ne_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !130 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !135, !DIExpression(), !136)
    #dbg_value(i32 %y, !137, !DIExpression(), !136)
  %0 = icmp ne i32 %this, %y, !dbg !138
  ret i1 %0, !dbg !138
}

define i1 @U32_box_ne_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !139 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !142, !DIExpression(), !143)
    #dbg_value(i32 %y, !144, !DIExpression(), !143)
  %0 = icmp ne i32 %this, %y, !dbg !145
  ret i1 %0, !dbg !145
}

define i1 @U32_box_eq_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !146 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !149, !DIExpression(), !150)
    #dbg_value(i32 %y, !151, !DIExpression(), !150)
  %0 = icmp eq i32 %this, %y, !dbg !152
  ret i1 %0, !dbg !152
}

define i1 @U32_val_eq_Ib(i32 %this, i32 %y) unnamed_addr #4 !dbg !153 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !156, !DIExpression(), !157)
    #dbg_value(i32 %y, !158, !DIExpression(), !157)
  %0 = icmp eq i32 %this, %y, !dbg !159
  ret i1 %0, !dbg !159
}

define i32 @U32_val_create_pII(i32 %this, i32 %value) unnamed_addr #4 !dbg !160 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !163, !DIExpression(), !164)
    #dbg_value(i32 %value, !165, !DIExpression(), !164)
  ret i32 %value, !dbg !166
}

define ptr @Pointer_AsioEvent_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define i1 @Pointer_AsioEvent_val_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

define ptr @"$0$16_val_create_o"(ptr %this) unnamed_addr #4 !dbg !167 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !175, !DIExpression(), !177)
  ret ptr %this, !dbg !178
}

define ptr @"$0$16_Alloc"() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @"$0$16_Inst"
}

define ptr @Pointer_Pointer_U8_val_ref_box__apply_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [4 x i8], ptr %0, i32 %1
  %3 = load ptr, ptr %2, align 4
  ret ptr %3
}

define ptr @Pointer_Pointer_U8_val_ref_ref__apply_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [4 x i8], ptr %0, i32 %1
  %3 = load ptr, ptr %2, align 4
  ret ptr %3
}

define ptr @Pointer_Pointer_U8_val_ref_val__apply_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds [4 x i8], ptr %0, i32 %1
  %3 = load ptr, ptr %2, align 4
  ret ptr %3
}

define i1 @Pointer_Pointer_U8_val_ref_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

define ptr @AmbientAuth_val__create_o(ptr %this) unnamed_addr #4 !dbg !179 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !187, !DIExpression(), !189)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !190)
  ret ptr %this, !dbg !192
}

define ptr @AmbientAuth_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @AmbientAuth_Inst
}

define ptr @StdStream_tag__err_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define void @StdStream_tag__err_o(ptr %this) unnamed_addr #4 !dbg !6 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !5, !DIExpression(), !20)
  %0 = call ptr @pony_os_stderr(), !dbg !21
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !22
  store ptr %0, ptr %1, align 4, !dbg !22
  ret void
}

define ptr @StdStream_tag__out_o__send(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  call void @pony_sendv_single(ptr %1, ptr %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr %0
}

define void @StdStream_tag__out_o(ptr %this) unnamed_addr #4 !dbg !24 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !23, !DIExpression(), !27)
  %0 = call ptr @pony_os_stdout(), !dbg !28
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !29
  store ptr %0, ptr %1, align 4, !dbg !29
  ret void
}

define noalias align 32 dereferenceable(304) ptr @StdStream_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  ret ptr %1
}

define ptr @Pointer_String_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define noalias align 32 dereferenceable_or_null(4) ptr @Pointer_String_val_ref__alloc_pZo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = shl i32 %1, 2
  %4 = call ptr @pony_alloc(ptr %2, i32 %3)
  ret ptr %4
}

define noalias align 32 dereferenceable_or_null(4) ptr @Pointer_String_val_ref__realloc_ZZo(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = call ptr @pony_ctx()
  %4 = shl i32 %1, 2
  %5 = shl i32 %2, 2
  %6 = call ptr @pony_realloc(ptr %3, ptr %0, i32 %4, i32 %5)
  ret ptr %6
}

define ptr @Pointer_String_val_ref__update_Zoo(ptr %0, i32 %1, ptr dereferenceable(16) %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds [4 x i8], ptr %0, i32 %1
  %4 = load ptr, ptr %3, align 4
  store ptr %2, ptr %3, align 4
  ret ptr %4
}

define i32 @Pointer_String_val_tag__min_alloc_Z(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i32 8
}

define i1 @String_ref_is_null_terminated_b(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !193 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !205, !DIExpression(), !207)
  br label %sc_left, !dbg !208

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !209

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !210
  %1 = load i32, ptr %0, align 4, !dbg !210
  %.not = icmp eq i32 %1, 0, !dbg !210
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !211
  %3 = load i32, ptr %2, align 4, !dbg !211
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !211
  %5 = load i32, ptr %4, align 4, !dbg !211
  %6 = icmp ne i32 %3, %5, !dbg !211
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !212
  %9 = load i32, ptr %8, align 4, !dbg !212
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !212
  %11 = load ptr, ptr %10, align 4, !dbg !212
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !213
  %13 = load i8, ptr %12, align 1, !dbg !213
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !208
}

define i1 @String_box_is_null_terminated_b(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !214 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !217, !DIExpression(), !218)
  br label %sc_left, !dbg !219

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !220

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !221
  %1 = load i32, ptr %0, align 4, !dbg !221
  %.not = icmp eq i32 %1, 0, !dbg !221
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !222
  %3 = load i32, ptr %2, align 4, !dbg !222
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !222
  %5 = load i32, ptr %4, align 4, !dbg !222
  %6 = icmp ne i32 %3, %5, !dbg !222
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !223
  %9 = load i32, ptr %8, align 4, !dbg !223
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !223
  %11 = load ptr, ptr %10, align 4, !dbg !223
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !224
  %13 = load i8, ptr %12, align 1, !dbg !224
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !219
}

define i1 @String_val_is_null_terminated_b(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !225 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !228, !DIExpression(), !229)
  br label %sc_left, !dbg !230

sc_left:                                          ; preds = %entry
  br label %sc_left2, !dbg !231

sc_left2:                                         ; preds = %sc_left
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !232
  %1 = load i32, ptr %0, align 4, !dbg !232
  %.not = icmp eq i32 %1, 0, !dbg !232
  br i1 %.not, label %sc_post, label %sc_right

sc_right:                                         ; preds = %sc_left2
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !233
  %3 = load i32, ptr %2, align 4, !dbg !233
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !233
  %5 = load i32, ptr %4, align 4, !dbg !233
  %6 = icmp ne i32 %3, %5, !dbg !233
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left2
  %7 = phi i1 [ false, %sc_left2 ], [ %6, %sc_right ]
  br i1 %7, label %sc_right3, label %sc_post4

sc_right3:                                        ; preds = %sc_post
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !234
  %9 = load i32, ptr %8, align 4, !dbg !234
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !234
  %11 = load ptr, ptr %10, align 4, !dbg !234
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !235
  %13 = load i8, ptr %12, align 1, !dbg !235
  %14 = icmp eq i8 %13, 0
  br label %sc_post4

sc_post4:                                         ; preds = %sc_right3, %sc_post
  %15 = phi i1 [ false, %sc_post ], [ %14, %sc_right3 ]
  ret i1 %15, !dbg !230
}

define ptr @String_box_cstring_o(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !236 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !241, !DIExpression(), !243)
    #dbg_value(ptr %this, !217, !DIExpression(), !244)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !247
  %1 = load i32, ptr %0, align 4, !dbg !247
  %.not.i = icmp eq i32 %1, 0, !dbg !247
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !248
  %3 = load i32, ptr %2, align 4, !dbg !248
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !248
  %5 = load i32, ptr %4, align 4, !dbg !248
  %6 = icmp ne i32 %3, %5, !dbg !248
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_box_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !249
  %9 = load i32, ptr %8, align 4, !dbg !249
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !249
  %11 = load ptr, ptr %10, align 4, !dbg !249
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !250
  %13 = load i8, ptr %12, align 1, !dbg !250
  %14 = icmp eq i8 %13, 0
  br label %String_box_is_null_terminated_b.exit

String_box_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_box_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %17 = load ptr, ptr %16, align 4
  ret ptr %17, !dbg !251

if_else:                                          ; preds = %String_box_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !253)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !256
  %19 = load i32, ptr %18, align 4, !dbg !256
  %20 = add i32 %19, 1, !dbg !256
  %21 = call ptr @pony_ctx(), !dbg !257
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i32 %20), !dbg !257
    #dbg_value(ptr %22, !242, !DIExpression(), !243)
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %26 = load ptr, ptr %25, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %22, ptr align 1 %26, i32 %24, i1 false), !dbg !258
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr inbounds i8, ptr %22, i32 %28, !dbg !259
  %30 = load i8, ptr %29, align 1, !dbg !259
  store i8 0, ptr %29, align 1, !dbg !259
  ret ptr %22, !dbg !260
}

define ptr @String_val_cstring_o(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !261 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !264, !DIExpression(), !266)
    #dbg_value(ptr %this, !228, !DIExpression(), !267)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !270
  %1 = load i32, ptr %0, align 4, !dbg !270
  %.not.i = icmp eq i32 %1, 0, !dbg !270
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !271
  %3 = load i32, ptr %2, align 4, !dbg !271
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !271
  %5 = load i32, ptr %4, align 4, !dbg !271
  %6 = icmp ne i32 %3, %5, !dbg !271
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_val_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !272
  %9 = load i32, ptr %8, align 4, !dbg !272
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !272
  %11 = load ptr, ptr %10, align 4, !dbg !272
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !273
  %13 = load i8, ptr %12, align 1, !dbg !273
  %14 = icmp eq i8 %13, 0
  br label %String_val_is_null_terminated_b.exit

String_val_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_val_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %17 = load ptr, ptr %16, align 4
  ret ptr %17, !dbg !274

if_else:                                          ; preds = %String_val_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !276)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !279
  %19 = load i32, ptr %18, align 4, !dbg !279
  %20 = add i32 %19, 1, !dbg !279
  %21 = call ptr @pony_ctx(), !dbg !280
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i32 %20), !dbg !280
    #dbg_value(ptr %22, !265, !DIExpression(), !266)
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %26 = load ptr, ptr %25, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %22, ptr align 1 %26, i32 %24, i1 false), !dbg !281
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr inbounds i8, ptr %22, i32 %28, !dbg !282
  %30 = load i8, ptr %29, align 1, !dbg !282
  store i8 0, ptr %29, align 1, !dbg !282
  ret ptr %22, !dbg !283
}

define ptr @String_ref_cstring_o(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !284 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !287, !DIExpression(), !289)
    #dbg_value(ptr %this, !205, !DIExpression(), !290)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !293
  %1 = load i32, ptr %0, align 4, !dbg !293
  %.not.i = icmp eq i32 %1, 0, !dbg !293
  br i1 %.not.i, label %sc_post.i, label %sc_right.i

sc_right.i:                                       ; preds = %entry
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !294
  %3 = load i32, ptr %2, align 4, !dbg !294
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !294
  %5 = load i32, ptr %4, align 4, !dbg !294
  %6 = icmp ne i32 %3, %5, !dbg !294
  br label %sc_post.i

sc_post.i:                                        ; preds = %sc_right.i, %entry
  %7 = phi i1 [ false, %entry ], [ %6, %sc_right.i ]
  br i1 %7, label %sc_right3.i, label %String_ref_is_null_terminated_b.exit

sc_right3.i:                                      ; preds = %sc_post.i
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !295
  %9 = load i32, ptr %8, align 4, !dbg !295
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !295
  %11 = load ptr, ptr %10, align 4, !dbg !295
  %12 = getelementptr inbounds i8, ptr %11, i32 %9, !dbg !296
  %13 = load i8, ptr %12, align 1, !dbg !296
  %14 = icmp eq i8 %13, 0
  br label %String_ref_is_null_terminated_b.exit

String_ref_is_null_terminated_b.exit:             ; preds = %sc_post.i, %sc_right3.i
  %15 = phi i1 [ false, %sc_post.i ], [ %14, %sc_right3.i ]
  br i1 %15, label %if_then, label %if_else

if_then:                                          ; preds = %String_ref_is_null_terminated_b.exit
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %17 = load ptr, ptr %16, align 4
  ret ptr %17, !dbg !297

if_else:                                          ; preds = %String_ref_is_null_terminated_b.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !299)
  br label %if_post

if_post:                                          ; preds = %if_else
  %18 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !302
  %19 = load i32, ptr %18, align 4, !dbg !302
  %20 = add i32 %19, 1, !dbg !302
  %21 = call ptr @pony_ctx(), !dbg !303
  %22 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %21, i32 %20), !dbg !303
    #dbg_value(ptr %22, !288, !DIExpression(), !289)
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %24 = load i32, ptr %23, align 4
  %25 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %26 = load ptr, ptr %25, align 4
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %22, ptr align 1 %26, i32 %24, i1 false), !dbg !304
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %28 = load i32, ptr %27, align 4
  %29 = getelementptr inbounds i8, ptr %22, i32 %28, !dbg !305
  %30 = load i8, ptr %29, align 1, !dbg !305
  store i8 0, ptr %29, align 1, !dbg !305
  ret ptr %22, !dbg !306
}

define i8 @String_ref__set_ZCC(ptr dereferenceable(16) %this, i32 %i, i8 %value) unnamed_addr #4 !dbg !307 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !313, !DIExpression(), !314)
    #dbg_value(i32 %i, !315, !DIExpression(), !314)
    #dbg_value(i8 %value, !316, !DIExpression(), !314)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %1 = load ptr, ptr %0, align 4
  %2 = getelementptr inbounds i8, ptr %1, i32 %i, !dbg !317
  %3 = load i8, ptr %2, align 1, !dbg !317
  store i8 %value, ptr %2, align 1, !dbg !317
  ret i8 %3, !dbg !317
}

define void @String_ref_create_pZo(ptr %this, i32 %len) unnamed_addr #4 !dbg !318 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !323, !DIExpression(), !324)
    #dbg_value(i32 %len, !325, !DIExpression(), !324)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !326
  store i32 0, ptr %0, align 4, !dbg !326
    #dbg_value(i32 0, !327, !DIExpression(), !334)
  %1 = add i32 -1, -1
    #dbg_value(i32 %len, !336, !DIExpression(), !342)
    #dbg_value(i32 %1, !344, !DIExpression(), !342)
  %2 = icmp ult i32 %len, %1, !dbg !345
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %3 = phi i32 [ %len, %if_then.i ], [ %1, %if_else.i ]
  %4 = add i32 %3, 1
    #dbg_value(i32 %4, !347, !DIExpression(), !351)
    #dbg_value(i32 32, !353, !DIExpression(), !351)
  %5 = icmp ugt i32 %4, 32, !dbg !354
  br i1 %5, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_min_ZZ.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_min_ZZ.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %6 = phi i32 [ %4, %if_then.i4 ], [ 32, %if_else.i3 ]
  %7 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !356
  store i32 %6, ptr %7, align 4, !dbg !356
  %8 = call ptr @pony_ctx(), !dbg !357
  %9 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %8, i32 %6), !dbg !357
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !358
  store ptr %9, ptr %10, align 4, !dbg !358
    #dbg_value(ptr %this, !313, !DIExpression(), !359)
    #dbg_value(i32 0, !315, !DIExpression(), !359)
    #dbg_value(i8 0, !316, !DIExpression(), !359)
  %11 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %12 = load ptr, ptr %11, align 4
  %13 = load i8, ptr %12, align 1, !dbg !361
  store i8 0, ptr %12, align 1, !dbg !361
  ret void, !dbg !362
}

define void @String_ref_copy_cstring_moo(ptr %this, ptr %str) unnamed_addr #4 !dbg !363 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !368, !DIExpression(), !372)
    #dbg_value(ptr %str, !373, !DIExpression(), !372)
  %0 = icmp eq ptr %str, null, !dbg !374
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !375
  store i32 0, ptr %1, align 4, !dbg !375
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !377
  store i32 32, ptr %2, align 4, !dbg !377
  %3 = call ptr @pony_ctx(), !dbg !378
  %4 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %3, i32 32), !dbg !378
  %5 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !379
  store ptr %4, ptr %5, align 4, !dbg !379
    #dbg_value(ptr %this, !313, !DIExpression(), !380)
    #dbg_value(i32 0, !315, !DIExpression(), !380)
    #dbg_value(i8 0, !316, !DIExpression(), !380)
  %6 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %7 = load ptr, ptr %6, align 4
  %8 = load i8, ptr %7, align 1, !dbg !382
  store i8 0, ptr %7, align 1, !dbg !382
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i32 0, !369, !DIExpression(), !383)
  br label %while_init

while_init:                                       ; preds = %if_else
  %9 = load i8, ptr %str, align 1, !dbg !384
  %.not = icmp eq i8 %9, 0
  br i1 %.not, label %while_else, label %while_body

while_body:                                       ; preds = %while_body, %while_init
  %i.0 = phi i32 [ 0, %while_init ], [ %10, %while_body ]
    #dbg_value(i32 %i.0, !369, !DIExpression(), !383)
  %10 = add i32 %i.0, 1, !dbg !386
    #dbg_value(i32 %10, !369, !DIExpression(), !383)
  %11 = getelementptr inbounds i8, ptr %str, i32 %10, !dbg !384
  %12 = load i8, ptr %11, align 1, !dbg !384
  %.not10 = icmp eq i8 %12, 0
  br i1 %.not10, label %while_post, label %while_body

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !388)
  br label %while_post

while_post:                                       ; preds = %while_else, %while_body
  %i.1 = phi i32 [ %10, %while_body ], [ 0, %while_else ]
    #dbg_value(i32 %i.1, !369, !DIExpression(), !383)
  %13 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !391
  store i32 %i.1, ptr %13, align 4, !dbg !391
  %14 = add i32 %i.1, 1, !dbg !392
    #dbg_value(i32 %14, !347, !DIExpression(), !393)
    #dbg_value(i32 32, !353, !DIExpression(), !393)
  %15 = icmp ugt i32 %14, 32, !dbg !395
  br i1 %15, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %while_post
  br label %USize_val_max_ZZ.exit

if_else.i:                                        ; preds = %while_post
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %16 = phi i32 [ %14, %if_then.i ], [ 32, %if_else.i ]
  %17 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !396
  store i32 %16, ptr %17, align 4, !dbg !396
  %18 = call ptr @pony_ctx(), !dbg !397
  %19 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %18, i32 %16), !dbg !397
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !398
  store ptr %19, ptr %20, align 4, !dbg !398
  %21 = add i32 %i.1, 1, !dbg !399
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %19, ptr align 1 %str, i32 %21, i1 false), !dbg !400
  br label %if_post

if_post:                                          ; preds = %USize_val_max_ZZ.exit, %if_then
  ret void, !dbg !401
}

define noalias align 32 dereferenceable(16) ptr @String_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @String_Desc, ptr %1, align 4
  ret ptr %1
}

define ptr @Array_String_val_ref_push_oo(ptr dereferenceable(16) %this, ptr dereferenceable(16) %value) unnamed_addr #4 !dbg !402 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !416, !DIExpression(), !418)
    #dbg_value(ptr %value, !419, !DIExpression(), !418)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !420
  %1 = load i32, ptr %0, align 4, !dbg !420
  %2 = add i32 %1, 1, !dbg !420
  %3 = call ptr @Array_String_val_ref_reserve_Zo(ptr nonnull %this, i32 %2), !dbg !421
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %5 = load i32, ptr %4, align 4
  %6 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %7 = load ptr, ptr %6, align 4
  %8 = getelementptr inbounds [4 x i8], ptr %7, i32 %5, !dbg !422
  %9 = load ptr, ptr %8, align 4, !dbg !422
  store ptr %value, ptr %8, align 4, !dbg !422
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !423
  %11 = load i32, ptr %10, align 4, !dbg !423
  %12 = add i32 %11, 1, !dbg !423
  %13 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !424
  store i32 %12, ptr %13, align 4, !dbg !424
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !425)
  ret ptr @None_Inst, !dbg !427
}

define ptr @Array_String_val_ref_reserve_Zo(ptr dereferenceable(16) %this, i32 %len) unnamed_addr #4 !dbg !428 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !433, !DIExpression(), !434)
    #dbg_value(i32 %len, !435, !DIExpression(), !434)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !436
  %1 = load i32, ptr %0, align 4, !dbg !436
  %2 = icmp ult i32 %1, %len, !dbg !436
  br i1 %2, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %4 = load ptr, ptr %3, align 4
    #dbg_value(i32 %len, !438, !DIExpression(), !443)
  %5 = add i32 %len, -1, !dbg !446
    #dbg_value(i32 %5, !447, !DIExpression(), !451)
  %6 = call i32 @USize_val_u32_I(i32 %5), !dbg !453
  %7 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %6, i1 false), !dbg !456
  %8 = call i32 @U32_val_usize_Z(i32 %7), !dbg !457
    #dbg_value(i32 %8, !442, !DIExpression(), !443)
  %9 = icmp eq i32 %8, 0, !dbg !458
  br i1 %9, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i32 %len, !460, !DIExpression(), !464)
  %10 = sub i32 32, %8
  %11 = call i32 @llvm.umin.i32(i32 %10, i32 31)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %12 = phi i32 [ 0, %if_then.i ], [ %11, %if_else.i ]
  %13 = shl nuw i32 1, %12
    #dbg_value(i32 %13, !347, !DIExpression(), !467)
    #dbg_value(i32 %len, !353, !DIExpression(), !467)
  %14 = icmp ugt i32 %13, %len, !dbg !469
  br i1 %14, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %15 = phi i32 [ %13, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i32 %15, !347, !DIExpression(), !470)
    #dbg_value(i32 8, !353, !DIExpression(), !470)
  %16 = icmp ugt i32 %15, 8, !dbg !472
  br i1 %16, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %17 = phi i32 [ %15, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i32 %17, !347, !DIExpression(), !473)
    #dbg_value(i32 8, !353, !DIExpression(), !473)
  %18 = icmp ugt i32 %17, 8, !dbg !475
  br i1 %18, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %19 = phi i32 [ %17, %if_then.i9 ], [ 8, %if_else.i8 ]
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !476
  store i32 %19, ptr %20, align 4, !dbg !476
  %21 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %24 = load ptr, ptr %23, align 4
  %25 = call ptr @pony_ctx(), !dbg !477
  %26 = shl i32 %19, 2, !dbg !477
  %27 = shl i32 %22, 2, !dbg !477
  %28 = call noalias align 32 dereferenceable_or_null(4) ptr @pony_realloc(ptr %25, ptr %24, i32 %26, i32 %27), !dbg !477
  %29 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !478
  store ptr %28, ptr %29, align 4, !dbg !478
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !479)
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !482)
  ret ptr @None_Inst, !dbg !484
}

define void @Array_String_val_ref_create_pZo(ptr %this, i32 %len) unnamed_addr #4 !dbg !485 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !490, !DIExpression(), !491)
    #dbg_value(i32 %len, !492, !DIExpression(), !491)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !493
  store i32 0, ptr %0, align 4, !dbg !493
  %.not = icmp eq i32 %len, 0, !dbg !494
  br i1 %.not, label %if_else, label %if_then

if_then:                                          ; preds = %entry
    #dbg_value(i32 %len, !438, !DIExpression(), !496)
  %1 = add i32 %len, -1, !dbg !499
    #dbg_value(i32 %1, !447, !DIExpression(), !500)
  %2 = call i32 @USize_val_u32_I(i32 %1), !dbg !502
  %3 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %2, i1 false), !dbg !503
  %4 = call i32 @U32_val_usize_Z(i32 %3), !dbg !504
    #dbg_value(i32 %4, !442, !DIExpression(), !496)
  %5 = icmp eq i32 %4, 0, !dbg !505
  br i1 %5, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i32 %len, !460, !DIExpression(), !506)
  %6 = sub i32 32, %4
  %7 = call i32 @llvm.umin.i32(i32 %6, i32 31)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %8 = phi i32 [ 0, %if_then.i ], [ %7, %if_else.i ]
  %9 = shl nuw i32 1, %8
    #dbg_value(i32 %9, !347, !DIExpression(), !508)
    #dbg_value(i32 %len, !353, !DIExpression(), !508)
  %10 = icmp ugt i32 %9, %len, !dbg !510
  br i1 %10, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %11 = phi i32 [ %9, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i32 %11, !347, !DIExpression(), !511)
    #dbg_value(i32 8, !353, !DIExpression(), !511)
  %12 = icmp ugt i32 %11, 8, !dbg !513
  br i1 %12, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %13 = phi i32 [ %11, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i32 %13, !347, !DIExpression(), !514)
    #dbg_value(i32 8, !353, !DIExpression(), !514)
  %14 = icmp ugt i32 %13, 8, !dbg !516
  br i1 %14, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %15 = phi i32 [ %13, %if_then.i9 ], [ 8, %if_else.i8 ]
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !517
  store i32 %15, ptr %16, align 4, !dbg !517
  %17 = call ptr @pony_ctx(), !dbg !518
  %18 = shl i32 %15, 2, !dbg !518
  %19 = call noalias align 32 dereferenceable_or_null(4) ptr @pony_alloc(ptr %17, i32 %18), !dbg !518
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !519
  store ptr %19, ptr %20, align 4, !dbg !519
  br label %if_post

if_else:                                          ; preds = %entry
  %21 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !520
  store i32 0, ptr %21, align 4, !dbg !520
  %22 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !522
  store ptr null, ptr %22, align 4, !dbg !522
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
  ret void, !dbg !523
}

define noalias align 32 dereferenceable(16) ptr @Array_String_val_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_String_val_Desc, ptr %1, align 4
  ret ptr %1
}

define i32 @Bool_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i8, ptr %1, align 1
  %3 = and i8 %2, 1
  %4 = zext nneg i8 %3 to i32
  ret i32 %4
}

define i1 @Bool_box_op_not_b(i1 %this) unnamed_addr #4 !dbg !524 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !530, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !532)
  %0 = xor i1 %this, true, !dbg !533
  ret i1 %0, !dbg !533
}

define i1 @Bool_val_op_not_b(i1 %this) unnamed_addr #4 !dbg !534 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !537, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !538)
  %0 = xor i1 %this, true, !dbg !539
  ret i1 %0, !dbg !539
}

define i1 @Bool_val_create_pbb(i1 %this, i1 %from) unnamed_addr #4 !dbg !540 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !545, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !546)
    #dbg_value(i1 %from, !547, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !546)
  ret i1 %from, !dbg !548
}

define i1 @Bool_box_op_and_bb(i1 %this, i1 %y) unnamed_addr #4 !dbg !549 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !552, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !553)
    #dbg_value(i1 %y, !554, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !553)
  br label %sc_left, !dbg !555

sc_left:                                          ; preds = %entry
  br i1 %this, label %sc_right, label %sc_post, !dbg !555

sc_right:                                         ; preds = %sc_left
  br label %sc_post, !dbg !555

sc_post:                                          ; preds = %sc_right, %sc_left
  %0 = phi i1 [ false, %sc_left ], [ %y, %sc_right ], !dbg !555
  ret i1 %0, !dbg !555
}

define i1 @Bool_val_op_and_bb(i1 %this, i1 %y) unnamed_addr #4 !dbg !556 !pony.abi !4 {
entry:
    #dbg_value(i1 %this, !559, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !560)
    #dbg_value(i1 %y, !561, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !560)
  br label %sc_left, !dbg !562

sc_left:                                          ; preds = %entry
  br i1 %this, label %sc_right, label %sc_post, !dbg !562

sc_right:                                         ; preds = %sc_left
  br label %sc_post, !dbg !562

sc_post:                                          ; preds = %sc_right, %sc_left
  %0 = phi i1 [ false, %sc_left ], [ %y, %sc_right ], !dbg !562
  ret i1 %0, !dbg !562
}

define i32 @F64_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i64, ptr %1, align 4
  %3 = lshr i64 %2, 32
  %4 = xor i64 %2, %3
  %5 = trunc i64 %4 to i32
  ret i32 %5
}

define ptr @Stdin_tag__create_pbo__send(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = zext i1 %1 to i8
  %4 = call ptr @pony_alloc_msg(i32 0, i32 0), !pony.msgsend !4
  %5 = getelementptr inbounds nuw i8, ptr %4, i32 12
  store i8 %3, ptr %5, align 1
  call void @pony_sendv_single(ptr %2, ptr %0, ptr %4, ptr %4, i1 true), !pony.msgsend !4
  ret ptr %0
}

define void @Stdin_tag__create_pbo(ptr %this, i1 %use_event) unnamed_addr #4 !dbg !31 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !30, !DIExpression(), !51)
    #dbg_value(i1 %use_event, !52, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !51)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !63)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !65
  store ptr @None_Inst, ptr %0, align 4, !dbg !65
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 304, !dbg !66
  store i32 32, ptr %1, align 4, !dbg !66
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !77)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !85)
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !87
  store ptr null, ptr %2, align 4, !dbg !87
  %3 = getelementptr inbounds nuw i8, ptr %this, i32 312, !dbg !88
  %4 = zext i1 %use_event to i8, !dbg !88
  store i8 %4, ptr %3, align 1, !dbg !88
  ret void
}

define i1 @Stdin_ref__read_b(ptr dereferenceable(316) %this) unnamed_addr #4 !dbg !563 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !568, !DIExpression(), !586)
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 300
  %2 = load ptr, ptr %1, align 4
  br label %case_pattern

case_pattern:                                     ; preds = %entry
  %3 = load ptr, ptr %2, align 4
  %4 = getelementptr inbounds nuw i8, ptr %3, i32 48
  %5 = load ptr, ptr %4, align 4
  %6 = load i32, ptr %5, align 4
  %7 = and i32 %6, 32
  %.not = icmp ne i32 %7, 0
  br i1 %.not, label %pattern_continue, label %match_else

pattern_continue:                                 ; preds = %case_pattern
    #dbg_value(ptr %2, !569, !DIExpression(), !587)
  br label %match_post

match_else:                                       ; preds = %case_pattern
  br label %try_else, !dbg !588

match_post:                                       ; preds = %pattern_continue
    #dbg_value(ptr %2, !575, !DIExpression(), !591)
    #dbg_value(i32 0, !576, !DIExpression(), !591)
  br label %while_init

while_init:                                       ; preds = %match_post
  br i1 true, label %while_body, label %while_else

while_body:                                       ; preds = %if_post15, %while_init
  %sum.0 = phi i32 [ 0, %while_init ], [ %85, %if_post15 ]
    #dbg_value(i32 poison, !585, !DIExpression(), !592)
    #dbg_value(i32 %sum.0, !576, !DIExpression(), !591)
    #dbg_value(i32 poison, !577, !DIExpression(), !592)
    #dbg_value(ptr poison, !580, !DIExpression(), !592)
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 304
  %9 = load i32, ptr %8, align 4
    #dbg_value(i32 %9, !577, !DIExpression(), !592)
  %10 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_U8_val_Desc, ptr %10, align 4
    #dbg_value(ptr %10, !593, !DIExpression(), !600)
    #dbg_value(i32 0, !603, !DIExpression(), !600)
  %11 = getelementptr inbounds nuw i8, ptr %10, i32 4, !dbg !604
  store i32 0, ptr %11, align 4, !dbg !604
  %12 = getelementptr inbounds nuw i8, ptr %10, i32 8, !dbg !605
  store i32 0, ptr %12, align 4, !dbg !605
  %13 = getelementptr inbounds nuw i8, ptr %10, i32 12, !dbg !608
  store ptr null, ptr %13, align 4, !dbg !608
    #dbg_value(ptr %10, !609, !DIExpression(), !615)
    #dbg_value(i32 %9, !617, !DIExpression(), !615)
    #dbg_value(ptr %10, !618, !DIExpression(), !622)
    #dbg_value(i32 %9, !624, !DIExpression(), !622)
  %14 = getelementptr inbounds nuw i8, ptr %10, i32 8, !dbg !625
  %15 = load i32, ptr %14, align 4, !dbg !625
  %16 = icmp ult i32 %15, %9, !dbg !625
  br i1 %16, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %while_body
  %17 = getelementptr inbounds nuw i8, ptr %10, i32 12
  %18 = load ptr, ptr %17, align 4
    #dbg_value(i32 %9, !438, !DIExpression(), !627)
  %19 = add i32 %9, -1, !dbg !630
    #dbg_value(i32 %19, !447, !DIExpression(), !631)
  %20 = call i32 @USize_val_u32_I(i32 %19), !dbg !633
  %21 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %20, i1 false), !dbg !634
  %22 = call i32 @U32_val_usize_Z(i32 %21), !dbg !635
    #dbg_value(i32 %22, !442, !DIExpression(), !627)
  %23 = icmp eq i32 %22, 0, !dbg !636
  br i1 %23, label %if_then.i.i.i, label %if_else.i.i.i

if_then.i.i.i:                                    ; preds = %if_then.i.i
  br label %USize_val_next_pow2_Z.exit.i.i

if_else.i.i.i:                                    ; preds = %if_then.i.i
    #dbg_value(i32 %9, !460, !DIExpression(), !637)
  %24 = sub i32 32, %22
  %25 = call i32 @llvm.umin.i32(i32 %24, i32 31)
  br label %USize_val_next_pow2_Z.exit.i.i

USize_val_next_pow2_Z.exit.i.i:                   ; preds = %if_else.i.i.i, %if_then.i.i.i
  %26 = phi i32 [ 0, %if_then.i.i.i ], [ %25, %if_else.i.i.i ]
  %27 = shl nuw i32 1, %26
    #dbg_value(i32 %27, !347, !DIExpression(), !639)
    #dbg_value(i32 %9, !353, !DIExpression(), !639)
  %28 = icmp ugt i32 %27, %9, !dbg !641
  br i1 %28, label %if_then.i4.i.i, label %if_else.i3.i.i

if_then.i4.i.i:                                   ; preds = %USize_val_next_pow2_Z.exit.i.i
  br label %USize_val_max_ZZ.exit.i.i

if_else.i3.i.i:                                   ; preds = %USize_val_next_pow2_Z.exit.i.i
  br label %USize_val_max_ZZ.exit.i.i

USize_val_max_ZZ.exit.i.i:                        ; preds = %if_else.i3.i.i, %if_then.i4.i.i
  %29 = phi i32 [ %27, %if_then.i4.i.i ], [ %9, %if_else.i3.i.i ]
    #dbg_value(i32 %29, !347, !DIExpression(), !642)
    #dbg_value(i32 8, !353, !DIExpression(), !642)
  %30 = icmp ugt i32 %29, 8, !dbg !644
  br i1 %30, label %if_then.i6.i.i, label %if_else.i5.i.i

if_then.i6.i.i:                                   ; preds = %USize_val_max_ZZ.exit.i.i
  br label %USize_val_max_ZZ.exit7.i.i

if_else.i5.i.i:                                   ; preds = %USize_val_max_ZZ.exit.i.i
  br label %USize_val_max_ZZ.exit7.i.i

USize_val_max_ZZ.exit7.i.i:                       ; preds = %if_else.i5.i.i, %if_then.i6.i.i
  %31 = phi i32 [ %29, %if_then.i6.i.i ], [ 8, %if_else.i5.i.i ]
    #dbg_value(i32 %31, !347, !DIExpression(), !645)
    #dbg_value(i32 32, !353, !DIExpression(), !645)
  %32 = icmp ugt i32 %31, 32, !dbg !647
  br i1 %32, label %if_then.i9.i.i, label %if_else.i8.i.i

if_then.i9.i.i:                                   ; preds = %USize_val_max_ZZ.exit7.i.i
  br label %USize_val_max_ZZ.exit10.i.i

if_else.i8.i.i:                                   ; preds = %USize_val_max_ZZ.exit7.i.i
  br label %USize_val_max_ZZ.exit10.i.i

USize_val_max_ZZ.exit10.i.i:                      ; preds = %if_else.i8.i.i, %if_then.i9.i.i
  %33 = phi i32 [ %31, %if_then.i9.i.i ], [ 32, %if_else.i8.i.i ]
  %34 = getelementptr inbounds nuw i8, ptr %10, i32 8, !dbg !648
  store i32 %33, ptr %34, align 4, !dbg !648
  %35 = getelementptr inbounds nuw i8, ptr %10, i32 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr inbounds nuw i8, ptr %10, i32 12
  %38 = load ptr, ptr %37, align 4
  %39 = call ptr @pony_ctx(), !dbg !649
  %40 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %39, ptr %38, i32 %33, i32 %36), !dbg !649
  %41 = getelementptr inbounds nuw i8, ptr %10, i32 12, !dbg !650
  store ptr %40, ptr %41, align 4, !dbg !650
  br label %Array_U8_val_ref_undefined_U8_val_Zo.exit

if_else.i.i:                                      ; preds = %while_body
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !651)
  br label %Array_U8_val_ref_undefined_U8_val_Zo.exit

Array_U8_val_ref_undefined_U8_val_Zo.exit:        ; preds = %USize_val_max_ZZ.exit10.i.i, %if_else.i.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !654)
  %42 = getelementptr inbounds nuw i8, ptr %10, i32 4, !dbg !656
  store i32 %9, ptr %42, align 4, !dbg !656
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !657)
    #dbg_value(ptr %10, !580, !DIExpression(), !592)
    #dbg_value(ptr %10, !659, !DIExpression(), !665)
    #dbg_value(i32 0, !667, !DIExpression(), !665)
  %43 = getelementptr inbounds nuw i8, ptr %10, i32 12
  %44 = load ptr, ptr %43, align 4
    #dbg_value(ptr %10, !668, !DIExpression(), !674)
  %45 = getelementptr inbounds nuw i8, ptr %10, i32 4
  %46 = load i32, ptr %45, align 4
  %47 = call i32 @pony_os_stdin_read(ptr %44, i32 %46), !dbg !676
    #dbg_value(i32 %47, !585, !DIExpression(), !592)
  br label %case_pattern2

case_pattern2:                                    ; preds = %Array_U8_val_ref_undefined_U8_val_Zo.exit
  %48 = icmp eq i32 %47, -1
  br i1 %48, label %pattern_continue6, label %case_pattern5

pattern_continue6:                                ; preds = %case_pattern2
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !677)
  ret i1 true, !dbg !682

case_pattern5:                                    ; preds = %case_pattern2
  %49 = icmp eq i32 %47, 0
  br i1 %49, label %pattern_continue8, label %case_pattern7

pattern_continue8:                                ; preds = %case_pattern5
    #dbg_value(ptr %this, !683, !DIExpression(), !687)
  %50 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !690
  %51 = load ptr, ptr %50, align 4, !dbg !690
  %52 = icmp eq ptr %51, null, !dbg !692
  br i1 %52, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %pattern_continue8
  %53 = getelementptr inbounds nuw i8, ptr %this, i32 308
  %54 = load ptr, ptr %53, align 4
  call void @pony_asio_event_unsubscribe(ptr %54), !dbg !693
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !695)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !697)
  %55 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !699
  store ptr null, ptr %55, align 4, !dbg !699
  br label %Stdin_ref__close_event_o.exit

if_else.i:                                        ; preds = %pattern_continue8
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !700)
  br label %Stdin_ref__close_event_o.exit

Stdin_ref__close_event_o.exit:                    ; preds = %if_then.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !703)
  %56 = load ptr, ptr %2, align 4
  %57 = getelementptr inbounds nuw i8, ptr %56, i32 64
  %58 = load ptr, ptr %57, align 4
  %59 = call ptr %58(ptr nonnull %2), !dbg !705
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !706)
  %60 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !708
  store ptr @None_Inst, ptr %60, align 4, !dbg !708
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !709)
  ret i1 false, !dbg !712

case_pattern7:                                    ; preds = %case_pattern5
  %61 = icmp eq i32 %47, -2
  br i1 %61, label %pattern_continue9, label %match_else4

pattern_continue9:                                ; preds = %case_pattern7
    #dbg_value(ptr %this, !683, !DIExpression(), !713)
  %62 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !716
  %63 = load ptr, ptr %62, align 4, !dbg !716
  %64 = icmp eq ptr %63, null, !dbg !717
  br i1 %64, label %if_else.i36, label %if_then.i35

if_then.i35:                                      ; preds = %pattern_continue9
  %65 = getelementptr inbounds nuw i8, ptr %this, i32 308
  %66 = load ptr, ptr %65, align 4
  call void @pony_asio_event_unsubscribe(ptr %66), !dbg !718
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !719)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !721)
  %67 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !723
  store ptr null, ptr %67, align 4, !dbg !723
  br label %Stdin_ref__close_event_o.exit37

if_else.i36:                                      ; preds = %pattern_continue9
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !724)
  br label %Stdin_ref__close_event_o.exit37

Stdin_ref__close_event_o.exit37:                  ; preds = %if_then.i35, %if_else.i36
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !726)
  %68 = load ptr, ptr %2, align 4
  %69 = getelementptr inbounds nuw i8, ptr %68, i32 60
  %70 = load ptr, ptr %69, align 4
  %71 = call ptr %70(ptr nonnull %2), !dbg !728
  %72 = load ptr, ptr %2, align 4
  %73 = getelementptr inbounds nuw i8, ptr %72, i32 64
  %74 = load ptr, ptr %73, align 4
  %75 = call ptr %74(ptr nonnull %2), !dbg !729
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !730)
  %76 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !732
  store ptr @None_Inst, ptr %76, align 4, !dbg !732
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !733)
  ret i1 false, !dbg !736

match_else4:                                      ; preds = %case_pattern7
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !737)
  br label %match_post3

match_post3:                                      ; preds = %match_else4
    #dbg_value(ptr %10, !741, !DIExpression(), !745)
    #dbg_value(i32 %47, !747, !DIExpression(), !745)
  %77 = getelementptr inbounds nuw i8, ptr %10, i32 4
  %78 = load i32, ptr %77, align 4
    #dbg_value(i32 %78, !336, !DIExpression(), !748)
    #dbg_value(i32 %47, !344, !DIExpression(), !748)
  %79 = icmp ult i32 %78, %47, !dbg !750
  br i1 %79, label %if_then.i.i39, label %if_else.i.i38

if_then.i.i39:                                    ; preds = %match_post3
  br label %Array_U8_val_ref_truncate_Zo.exit

if_else.i.i38:                                    ; preds = %match_post3
  br label %Array_U8_val_ref_truncate_Zo.exit

Array_U8_val_ref_truncate_Zo.exit:                ; preds = %if_then.i.i39, %if_else.i.i38
  %80 = phi i32 [ %78, %if_then.i.i39 ], [ %47, %if_else.i.i38 ]
  %81 = getelementptr inbounds nuw i8, ptr %10, i32 4, !dbg !751
  store i32 %80, ptr %81, align 4, !dbg !751
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !752)
  %82 = load ptr, ptr %2, align 4
  %VTABLE12 = getelementptr inbounds nuw i8, ptr %82, i32 56
  %83 = load ptr, ptr %VTABLE12, align 4
  %84 = call ptr %83(ptr nonnull %2, ptr nonnull %10), !dbg !754
  br i1 false, label %if_then, label %if_else

if_then:                                          ; preds = %Array_U8_val_ref_truncate_Zo.exit
  unreachable

if_else:                                          ; preds = %Array_U8_val_ref_truncate_Zo.exit
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !755)
  br label %if_post

if_post:                                          ; preds = %if_else
  %85 = add i32 %sum.0, %47, !dbg !759
    #dbg_value(i32 %85, !576, !DIExpression(), !591)
  %86 = icmp ugt i32 %85, 4096
  br i1 %86, label %if_then13, label %if_else14

if_then13:                                        ; preds = %if_post
  %87 = getelementptr inbounds nuw i8, ptr %this, i32 312
  %88 = load i8, ptr %87, align 1
  %89 = trunc i8 %88 to i1
  br i1 %89, label %if_then16, label %if_else17

if_then16:                                        ; preds = %if_then13
  %90 = call ptr @pony_alloc_msg(i32 0, i32 4), !dbg !760, !pony.msgsend !4
  call void @pony_sendv(ptr %0, ptr nonnull %this, ptr %90, ptr %90, i1 true), !dbg !760, !pony.msgsend !4
  br label %if_post18

if_else17:                                        ; preds = %if_then13
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !765)
  br label %if_post18

if_post18:                                        ; preds = %if_else17, %if_then16
  br label %while_else, !dbg !768

if_else14:                                        ; preds = %if_post
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !769)
  br label %if_post15

if_post15:                                        ; preds = %if_else14
  br i1 true, label %while_body, label %while_post

while_else:                                       ; preds = %if_post18, %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !772)
  br label %while_post

while_post:                                       ; preds = %while_else, %if_post15
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !775)
  br label %try_post

try_else:                                         ; preds = %match_else
    #dbg_value(ptr %this, !683, !DIExpression(), !778)
  %91 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !781
  %92 = load ptr, ptr %91, align 4, !dbg !781
  %93 = icmp eq ptr %92, null, !dbg !782
  br i1 %93, label %if_else.i41, label %if_then.i40

if_then.i40:                                      ; preds = %try_else
  %94 = getelementptr inbounds nuw i8, ptr %this, i32 308
  %95 = load ptr, ptr %94, align 4
  call void @pony_asio_event_unsubscribe(ptr %95), !dbg !783
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !784)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !786)
  %96 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !788
  store ptr null, ptr %96, align 4, !dbg !788
  br label %Stdin_ref__close_event_o.exit42

if_else.i41:                                      ; preds = %try_else
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !789)
  br label %Stdin_ref__close_event_o.exit42

Stdin_ref__close_event_o.exit42:                  ; preds = %if_then.i40, %if_else.i41
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !791)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !793)
  br label %try_post

try_post:                                         ; preds = %Stdin_ref__close_event_o.exit42, %while_post
  ret i1 %.not, !dbg !796
}

define ptr @Stdin_tag__read_again_o__send(ptr dereferenceable(316) %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = call ptr @pony_ctx()
  %2 = call ptr @pony_alloc_msg(i32 0, i32 4), !pony.msgsend !4
  call void @pony_sendv(ptr %1, ptr nonnull %0, ptr %2, ptr %2, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define void @Stdin_tag__read_again_o(ptr dereferenceable(316) %this) unnamed_addr #4 !dbg !90 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !89, !DIExpression(), !95)
  call void @ponyint_gc_root_audit(ptr %0, ptr nonnull %this, ptr nonnull @5, i32 147, i32 10, ptr nonnull @6, i32 0, ptr null, ptr null)
  %1 = call i1 @Stdin_ref__read_b(ptr nonnull %this), !dbg !96
  ret void
}

define ptr @Stdin_ref__close_event_o(ptr dereferenceable(316) %this) unnamed_addr #4 !dbg !684 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !683, !DIExpression(), !797)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !798
  %1 = load ptr, ptr %0, align 4, !dbg !798
  %2 = icmp eq ptr %1, null, !dbg !799
  br i1 %2, label %if_else, label %if_then

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i32 308
  %4 = load ptr, ptr %3, align 4
  call void @pony_asio_event_unsubscribe(ptr %4), !dbg !800
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !801)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !803)
  %5 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !805
  store ptr null, ptr %5, align 4, !dbg !805
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !806)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !808)
  ret ptr @None_Inst, !dbg !810
}

define ptr @Stdin_tag__event_notify_topIpIo__send(ptr dereferenceable(316) %0, ptr %1, i32 %2, i32 %3) unnamed_addr #4 !pony.abi !4 {
entry:
  %4 = call ptr @pony_ctx()
  %5 = call ptr @pony_alloc_msg(i32 0, i32 1), !pony.msgsend !4
  %6 = getelementptr inbounds nuw i8, ptr %5, i32 12
  store ptr %1, ptr %6, align 4
  %7 = getelementptr inbounds nuw i8, ptr %5, i32 16
  store i32 %2, ptr %7, align 4
  %8 = getelementptr inbounds nuw i8, ptr %5, i32 20
  store i32 %3, ptr %8, align 4
  call void @pony_gc_send(ptr %4, ptr nonnull %0), !pony.msgsend !4
  call void @pony_traceknown(ptr %4, ptr %1, ptr nonnull @Pointer_AsioEvent_val_Desc, i32 2)
  call void @pony_send_done(ptr %4), !pony.msgsend !4
  call void @pony_sendv(ptr %4, ptr nonnull %0, ptr %5, ptr %5, i1 true), !pony.msgsend !4
  ret ptr @None_Inst
}

define void @Stdin_tag__event_notify_topIpIo(ptr dereferenceable(316) %this, ptr %event, i32 %flags, i32 %arg) unnamed_addr #4 !dbg !811 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !816, !DIExpression(), !825)
    #dbg_value(ptr %event, !826, !DIExpression(), !825)
    #dbg_value(i32 %flags, !827, !DIExpression(), !825)
    #dbg_value(i32 %arg, !828, !DIExpression(), !825)
  call void @ponyint_gc_root_audit(ptr %0, ptr nonnull %this, ptr nonnull @8, i32 129, i32 5, ptr nonnull @9, i32 0, ptr null, ptr null)
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !829)
    #dbg_value(ptr @AsioEvent_Inst, !831, !DIExpression(), !837)
    #dbg_value(i32 %flags, !839, !DIExpression(), !837)
  %1 = icmp eq i32 %flags, 0, !dbg !840
  br i1 %1, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  call void @pony_asio_event_destroy(ptr %event), !dbg !841
  br label %if_post

if_else:                                          ; preds = %entry
  br label %sc_left, !dbg !843

sc_left:                                          ; preds = %if_else
  %2 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !843
  %3 = load ptr, ptr %2, align 4, !dbg !843
  %4 = icmp eq ptr %3, %event, !dbg !844
  br i1 %4, label %sc_right, label %sc_post

sc_right:                                         ; preds = %sc_left
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !845)
    #dbg_value(ptr @AsioEvent_Inst, !847, !DIExpression(), !851)
    #dbg_value(i32 %flags, !853, !DIExpression(), !851)
  %5 = and i32 %flags, 16
  %6 = icmp ne i32 %5, 0
  br label %sc_post

sc_post:                                          ; preds = %sc_right, %sc_left
  %7 = phi i1 [ false, %sc_left ], [ %6, %sc_right ]
  br i1 %7, label %if_then5, label %if_else6

if_then5:                                         ; preds = %sc_post
    #dbg_value(ptr %this, !683, !DIExpression(), !854)
  %8 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !856
  %9 = load ptr, ptr %8, align 4, !dbg !856
  %10 = icmp eq ptr %9, null, !dbg !857
  br i1 %10, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %if_then5
  %11 = getelementptr inbounds nuw i8, ptr %this, i32 308
  %12 = load ptr, ptr %11, align 4
  call void @pony_asio_event_unsubscribe(ptr %12), !dbg !858
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !859)
    #dbg_value(ptr @AsioEvent_Inst, !79, !DIExpression(), !861)
  %13 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !863
  store ptr null, ptr %13, align 4, !dbg !863
  br label %Stdin_ref__close_event_o.exit

if_else.i:                                        ; preds = %if_then5
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !864)
  br label %Stdin_ref__close_event_o.exit

Stdin_ref__close_event_o.exit:                    ; preds = %if_then.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !866)
  %14 = getelementptr inbounds nuw i8, ptr %this, i32 300
  %15 = load ptr, ptr %14, align 4
  br label %case_pattern

case_pattern:                                     ; preds = %Stdin_ref__close_event_o.exit
  %16 = load ptr, ptr %15, align 4
  %17 = getelementptr inbounds nuw i8, ptr %16, i32 48
  %18 = load ptr, ptr %17, align 4
  %19 = load i32, ptr %18, align 4
  %20 = and i32 %19, 32
  %.not = icmp eq i32 %20, 0
  br i1 %.not, label %match_else, label %pattern_continue

pattern_continue:                                 ; preds = %case_pattern
    #dbg_value(ptr %15, !817, !DIExpression(), !868)
  br label %match_post

match_else:                                       ; preds = %case_pattern
  br label %try_else, !dbg !869

match_post:                                       ; preds = %pattern_continue
    #dbg_value(ptr %15, !824, !DIExpression(), !872)
  %21 = load ptr, ptr %15, align 4
  %22 = getelementptr inbounds nuw i8, ptr %21, i32 60
  %23 = load ptr, ptr %22, align 4
  %24 = call ptr %23(ptr nonnull %15), !dbg !873
  %25 = load ptr, ptr %15, align 4
  %26 = getelementptr inbounds nuw i8, ptr %25, i32 64
  %27 = load ptr, ptr %26, align 4
  %28 = call ptr %27(ptr nonnull %15), !dbg !874
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !875)
  br label %try_post

try_else:                                         ; preds = %match_else
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !878)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !881)
  br label %try_post

try_post:                                         ; preds = %try_else, %match_post
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !884)
  %29 = getelementptr inbounds nuw i8, ptr %this, i32 300, !dbg !886
  store ptr @None_Inst, ptr %29, align 4, !dbg !886
  br label %if_post7

if_else6:                                         ; preds = %sc_post
  br label %sc_left9, !dbg !887

sc_left9:                                         ; preds = %if_else6
  %30 = getelementptr inbounds nuw i8, ptr %this, i32 308, !dbg !887
  %31 = load ptr, ptr %30, align 4, !dbg !887
  %32 = icmp eq ptr %31, %event, !dbg !889
  br i1 %32, label %sc_right10, label %sc_post11

sc_right10:                                       ; preds = %sc_left9
    #dbg_value(ptr @AsioEvent_Inst, !67, !DIExpression(), !890)
    #dbg_value(ptr @AsioEvent_Inst, !892, !DIExpression(), !896)
    #dbg_value(i32 %flags, !898, !DIExpression(), !896)
  %33 = trunc i32 %flags to i1
  br label %sc_post11

sc_post11:                                        ; preds = %sc_right10, %sc_left9
  %34 = phi i1 [ false, %sc_left9 ], [ %33, %sc_right10 ]
  br i1 %34, label %if_then12, label %if_else13

if_then12:                                        ; preds = %sc_post11
  %35 = call i1 @Stdin_ref__read_b(ptr nonnull %this), !dbg !899
  br label %if_post14

if_else13:                                        ; preds = %sc_post11
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !901)
  br label %if_post14

if_post14:                                        ; preds = %if_else13, %if_then12
  br label %if_post7

if_post7:                                         ; preds = %if_post14, %try_post
  br label %if_post

if_post:                                          ; preds = %if_post7, %if_then
  ret void
}

define noalias align 32 dereferenceable(316) ptr @Stdin_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_create(ptr %0, ptr nonnull @Stdin_Desc, i1 false)
  ret ptr %1
}

define i32 @I32_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  ret i32 %2
}

define i32 @I32_val_create_pii(i32 %this, i32 %value) unnamed_addr #4 !dbg !904 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !911, !DIExpression(), !913)
    #dbg_value(i32 %value, !914, !DIExpression(), !913)
  ret i32 %value, !dbg !915
}

define i32 @U64_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i64, ptr %1, align 4
  %3 = lshr i64 %2, 32
  %4 = xor i64 %2, %3
  %5 = trunc i64 %4 to i32
  ret i32 %5
}

define i1 @U64_val_eq_Wb(i64 %this, i64 %y) unnamed_addr #4 !dbg !916 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !922, !DIExpression(), !924)
    #dbg_value(i64 %y, !925, !DIExpression(), !924)
  %0 = icmp eq i64 %this, %y, !dbg !926
  ret i1 %0, !dbg !926
}

define i1 @U64_box_eq_Wb(i64 %this, i64 %y) unnamed_addr #4 !dbg !927 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !930, !DIExpression(), !931)
    #dbg_value(i64 %y, !932, !DIExpression(), !931)
  %0 = icmp eq i64 %this, %y, !dbg !933
  ret i1 %0, !dbg !933
}

define i64 @U64_val_create_pWW(i64 %this, i64 %value) unnamed_addr #4 !dbg !934 !pony.abi !4 {
entry:
    #dbg_value(i64 %this, !939, !DIExpression(), !940)
    #dbg_value(i64 %value, !941, !DIExpression(), !940)
  ret i64 %value, !dbg !942
}

define i32 @USize_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  ret i32 %2
}

define i32 @USize_val_bitwidth_Z(i32 %this) unnamed_addr #4 !dbg !461 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !460, !DIExpression(), !943)
  br i1 true, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i32 32, !dbg !944
}

define i32 @USize_box_bitwidth_Z(i32 %this) unnamed_addr #4 !dbg !945 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !948, !DIExpression(), !949)
  br i1 true, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i32 32, !dbg !950
}

define i32 @USize_box_sub_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !951 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !954, !DIExpression(), !955)
    #dbg_value(i32 %y, !956, !DIExpression(), !955)
  %0 = sub i32 %this, %y, !dbg !957
  ret i32 %0, !dbg !957
}

define i32 @USize_val_sub_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !958 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !961, !DIExpression(), !962)
    #dbg_value(i32 %y, !963, !DIExpression(), !962)
  %0 = sub i32 %this, %y, !dbg !964
  ret i32 %0, !dbg !964
}

define i32 @USize_val_shl_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !965 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !968, !DIExpression(), !969)
    #dbg_value(i32 %y, !970, !DIExpression(), !969)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !971
  %1 = shl i32 %this, %0, !dbg !971
  ret i32 %1, !dbg !971
}

define i32 @USize_box_shl_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !972 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !975, !DIExpression(), !976)
    #dbg_value(i32 %y, !977, !DIExpression(), !976)
  %0 = call i32 @llvm.umin.i32(i32 %y, i32 31), !dbg !978
  %1 = shl i32 %this, %0, !dbg !978
  ret i32 %1, !dbg !978
}

define i1 @USize_val_ne_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !979 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !984, !DIExpression(), !985)
    #dbg_value(i32 %y, !986, !DIExpression(), !985)
  %0 = icmp ne i32 %this, %y, !dbg !987
  ret i1 %0, !dbg !987
}

define i1 @USize_box_ne_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !988 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !991, !DIExpression(), !992)
    #dbg_value(i32 %y, !993, !DIExpression(), !992)
  %0 = icmp ne i32 %this, %y, !dbg !994
  ret i1 %0, !dbg !994
}

define i32 @USize_val_max_value_Z(i32 %this) unnamed_addr #4 !dbg !328 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !327, !DIExpression(), !995)
  br i1 true, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  ret i32 -1, !dbg !996
}

define i32 @USize_val_add_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !997 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1000, !DIExpression(), !1001)
    #dbg_value(i32 %y, !1002, !DIExpression(), !1001)
  %0 = add i32 %this, %y, !dbg !1003
  ret i32 %0, !dbg !1003
}

define i32 @USize_box_add_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !1004 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1007, !DIExpression(), !1008)
    #dbg_value(i32 %y, !1009, !DIExpression(), !1008)
  %0 = add i32 %this, %y, !dbg !1010
  ret i32 %0, !dbg !1010
}

define i32 @USize_val_next_pow2_Z(i32 %this) unnamed_addr #4 !dbg !439 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !438, !DIExpression(), !1011)
  %0 = add i32 %this, -1, !dbg !1012
    #dbg_value(i32 %0, !447, !DIExpression(), !1013)
  %1 = call i32 @USize_val_u32_I(i32 %0), !dbg !1015
  %2 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %1, i1 false), !dbg !1016
  %3 = call i32 @U32_val_usize_Z(i32 %2), !dbg !1017
    #dbg_value(i32 %3, !442, !DIExpression(), !1011)
  %4 = icmp eq i32 %3, 0, !dbg !1018
  br i1 %4, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i32 %this, !460, !DIExpression(), !1019)
  %5 = sub i32 32, %3
  %6 = call i32 @llvm.umin.i32(i32 %5, i32 31)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %7 = phi i32 [ 0, %if_then ], [ %6, %if_else ]
  %8 = shl nuw i32 1, %7
  ret i32 %8, !dbg !1021
}

define i32 @USize_box_next_pow2_Z(i32 %this) unnamed_addr #4 !dbg !1022 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1025, !DIExpression(), !1027)
  %0 = add i32 %this, -1, !dbg !1028
    #dbg_value(i32 %0, !447, !DIExpression(), !1029)
  %1 = call i32 @USize_val_u32_I(i32 %0), !dbg !1031
  %2 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %1, i1 false), !dbg !1032
  %3 = call i32 @U32_val_usize_Z(i32 %2), !dbg !1033
    #dbg_value(i32 %3, !1026, !DIExpression(), !1027)
  %4 = icmp eq i32 %3, 0, !dbg !1034
  br i1 %4, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(i32 %this, !460, !DIExpression(), !1036)
  %5 = sub i32 32, %3
  %6 = call i32 @llvm.umin.i32(i32 %5, i32 31)
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %7 = phi i32 [ 0, %if_then ], [ %6, %if_else ]
  %8 = shl nuw i32 1, %7
  ret i32 %8, !dbg !1039
}

define i1 @USize_box_eq_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1040 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1043, !DIExpression(), !1044)
    #dbg_value(i32 %y, !1045, !DIExpression(), !1044)
  %0 = icmp eq i32 %this, %y, !dbg !1046
  ret i1 %0, !dbg !1046
}

define i1 @USize_val_eq_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1047 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1050, !DIExpression(), !1051)
    #dbg_value(i32 %y, !1052, !DIExpression(), !1051)
  %0 = icmp eq i32 %this, %y, !dbg !1053
  ret i1 %0, !dbg !1053
}

define i32 @USize_box_clz_Z(i32 %this) unnamed_addr #4 !dbg !1054 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1057, !DIExpression(), !1058)
  br i1 true, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %0 = call i32 @USize_val_u32_I(i32 %this), !dbg !1059
  %1 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %0, i1 false), !dbg !1062
  %2 = call i32 @U32_val_usize_Z(i32 %1), !dbg !1063
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %3 = phi i32 [ %2, %if_then ], [ poison, %if_else ]
  ret i32 %3, !dbg !1064
}

define i32 @USize_val_clz_Z(i32 %this) unnamed_addr #4 !dbg !448 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !447, !DIExpression(), !1065)
  br i1 true, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %0 = call i32 @USize_val_u32_I(i32 %this), !dbg !1066
  %1 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %0, i1 false), !dbg !1067
  %2 = call i32 @U32_val_usize_Z(i32 %1), !dbg !1068
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %3 = phi i32 [ %2, %if_then ], [ poison, %if_else ]
  ret i32 %3, !dbg !1069
}

define i32 @USize_val_max_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !348 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !347, !DIExpression(), !1070)
    #dbg_value(i32 %y, !353, !DIExpression(), !1070)
  %0 = icmp ugt i32 %this, %y, !dbg !1071
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i32 [ %this, %if_then ], [ %y, %if_else ]
  ret i32 %1, !dbg !1072
}

define i32 @USize_box_max_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !1073 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1076, !DIExpression(), !1077)
    #dbg_value(i32 %y, !1078, !DIExpression(), !1077)
  %0 = icmp ugt i32 %this, %y, !dbg !1079
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i32 [ %this, %if_then ], [ %y, %if_else ]
  ret i32 %1, !dbg !1081
}

define i32 @USize_val_neg_Z(i32 %this) unnamed_addr #4 !dbg !1082 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1085, !DIExpression(), !1086)
  %0 = sub i32 0, %this, !dbg !1087
  ret i32 %0, !dbg !1087
}

define i32 @USize_box_neg_Z(i32 %this) unnamed_addr #4 !dbg !1088 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1091, !DIExpression(), !1092)
  %0 = sub i32 0, %this, !dbg !1093
  ret i32 %0, !dbg !1093
}

define i32 @USize_val_min_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !337 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !336, !DIExpression(), !1094)
    #dbg_value(i32 %y, !344, !DIExpression(), !1094)
  %0 = icmp ult i32 %this, %y, !dbg !1095
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i32 [ %this, %if_then ], [ %y, %if_else ]
  ret i32 %1, !dbg !1096
}

define i32 @USize_box_min_ZZ(i32 %this, i32 %y) unnamed_addr #4 !dbg !1097 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1100, !DIExpression(), !1101)
    #dbg_value(i32 %y, !1102, !DIExpression(), !1101)
  %0 = icmp ult i32 %this, %y, !dbg !1103
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  br label %if_post

if_else:                                          ; preds = %entry
  br label %if_post

if_post:                                          ; preds = %if_else, %if_then
  %1 = phi i32 [ %this, %if_then ], [ %y, %if_else ]
  ret i32 %1, !dbg !1105
}

define i32 @USize_val_create_pZZ(i32 %this, i32 %value) unnamed_addr #4 !dbg !1106 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1109, !DIExpression(), !1110)
    #dbg_value(i32 %value, !1111, !DIExpression(), !1110)
  ret i32 %value, !dbg !1112
}

define i1 @USize_val_lt_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1113 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1116, !DIExpression(), !1117)
    #dbg_value(i32 %y, !1118, !DIExpression(), !1117)
  %0 = icmp ult i32 %this, %y, !dbg !1119
  ret i1 %0, !dbg !1119
}

define i1 @USize_box_lt_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1120 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1123, !DIExpression(), !1124)
    #dbg_value(i32 %y, !1125, !DIExpression(), !1124)
  %0 = icmp ult i32 %this, %y, !dbg !1126
  ret i1 %0, !dbg !1126
}

define i1 @USize_val_gt_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1127 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1130, !DIExpression(), !1131)
    #dbg_value(i32 %y, !1132, !DIExpression(), !1131)
  %0 = icmp ugt i32 %this, %y, !dbg !1133
  ret i1 %0, !dbg !1133
}

define i1 @USize_box_gt_Zb(i32 %this, i32 %y) unnamed_addr #4 !dbg !1134 !pony.abi !4 {
entry:
    #dbg_value(i32 %this, !1137, !DIExpression(), !1138)
    #dbg_value(i32 %y, !1139, !DIExpression(), !1138)
  %0 = icmp ugt i32 %this, %y, !dbg !1140
  ret i1 %0, !dbg !1140
}

define noalias align 32 dereferenceable(76) ptr @RuntimeOptions_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 2)
  ret ptr %1
}

define i32 @Array_U8_val_ref_size_Z(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !669 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !668, !DIExpression(), !1141)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %1 = load i32, ptr %0, align 4
  ret i32 %1, !dbg !1142
}

define i32 @Array_U8_val_val_size_Z(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !1143 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1146, !DIExpression(), !1147)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %1 = load i32, ptr %0, align 4
  ret i32 %1, !dbg !1148
}

define i32 @Array_U8_val_box_size_Z(ptr dereferenceable(16) %this) unnamed_addr #4 !dbg !1149 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1152, !DIExpression(), !1153)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %1 = load i32, ptr %0, align 4
  ret i32 %1, !dbg !1154
}

define ptr @Array_U8_val_ref_reserve_Zo(ptr dereferenceable(16) %this, i32 %len) unnamed_addr #4 !dbg !619 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !618, !DIExpression(), !1155)
    #dbg_value(i32 %len, !624, !DIExpression(), !1155)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1156
  %1 = load i32, ptr %0, align 4, !dbg !1156
  %2 = icmp ult i32 %1, %len, !dbg !1156
  br i1 %2, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %4 = load ptr, ptr %3, align 4
    #dbg_value(i32 %len, !438, !DIExpression(), !1157)
  %5 = add i32 %len, -1, !dbg !1159
    #dbg_value(i32 %5, !447, !DIExpression(), !1160)
  %6 = call i32 @USize_val_u32_I(i32 %5), !dbg !1162
  %7 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %6, i1 false), !dbg !1163
  %8 = call i32 @U32_val_usize_Z(i32 %7), !dbg !1164
    #dbg_value(i32 %8, !442, !DIExpression(), !1157)
  %9 = icmp eq i32 %8, 0, !dbg !1165
  br i1 %9, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i32 %len, !460, !DIExpression(), !1166)
  %10 = sub i32 32, %8
  %11 = call i32 @llvm.umin.i32(i32 %10, i32 31)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %12 = phi i32 [ 0, %if_then.i ], [ %11, %if_else.i ]
  %13 = shl nuw i32 1, %12
    #dbg_value(i32 %13, !347, !DIExpression(), !1168)
    #dbg_value(i32 %len, !353, !DIExpression(), !1168)
  %14 = icmp ugt i32 %13, %len, !dbg !1170
  br i1 %14, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %15 = phi i32 [ %13, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i32 %15, !347, !DIExpression(), !1171)
    #dbg_value(i32 8, !353, !DIExpression(), !1171)
  %16 = icmp ugt i32 %15, 8, !dbg !1173
  br i1 %16, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %17 = phi i32 [ %15, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i32 %17, !347, !DIExpression(), !1174)
    #dbg_value(i32 32, !353, !DIExpression(), !1174)
  %18 = icmp ugt i32 %17, 32, !dbg !1176
  br i1 %18, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %19 = phi i32 [ %17, %if_then.i9 ], [ 32, %if_else.i8 ]
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1177
  store i32 %19, ptr %20, align 4, !dbg !1177
  %21 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %24 = load ptr, ptr %23, align 4
  %25 = call ptr @pony_ctx(), !dbg !1178
  %26 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %25, ptr %24, i32 %19, i32 %22), !dbg !1178
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !1179
  store ptr %26, ptr %27, align 4, !dbg !1179
  br label %if_post

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1180)
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1182)
  ret ptr @None_Inst, !dbg !1184
}

define ptr @Array_U8_val_box_cpointer_Zo(ptr dereferenceable(16) %this, i32 %offset) unnamed_addr #4 !dbg !1185 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1188, !DIExpression(), !1189)
    #dbg_value(i32 %offset, !1190, !DIExpression(), !1189)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %1 = load ptr, ptr %0, align 4
  %2 = getelementptr inbounds i8, ptr %1, i32 %offset, !dbg !1191
  ret ptr %2, !dbg !1191
}

define ptr @Array_U8_val_val_cpointer_Zo(ptr dereferenceable(16) %this, i32 %offset) unnamed_addr #4 !dbg !1192 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1195, !DIExpression(), !1196)
    #dbg_value(i32 %offset, !1197, !DIExpression(), !1196)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %1 = load ptr, ptr %0, align 4
  %2 = getelementptr inbounds i8, ptr %1, i32 %offset, !dbg !1198
  ret ptr %2, !dbg !1198
}

define ptr @Array_U8_val_ref_cpointer_Zo(ptr dereferenceable(16) %this, i32 %offset) unnamed_addr #4 !dbg !660 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !659, !DIExpression(), !1199)
    #dbg_value(i32 %offset, !667, !DIExpression(), !1199)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %1 = load ptr, ptr %0, align 4
  %2 = getelementptr inbounds i8, ptr %1, i32 %offset, !dbg !1200
  ret ptr %2, !dbg !1200
}

define ptr @Array_U8_val_ref_undefined_U8_val_Zo(ptr dereferenceable(16) %this, i32 %len) unnamed_addr #4 !dbg !610 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !609, !DIExpression(), !1201)
    #dbg_value(i32 %len, !617, !DIExpression(), !1201)
    #dbg_value(ptr %this, !618, !DIExpression(), !1202)
    #dbg_value(i32 %len, !624, !DIExpression(), !1202)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1204
  %1 = load i32, ptr %0, align 4, !dbg !1204
  %2 = icmp ult i32 %1, %len, !dbg !1204
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  %3 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %4 = load ptr, ptr %3, align 4
    #dbg_value(i32 %len, !438, !DIExpression(), !1205)
  %5 = add i32 %len, -1, !dbg !1207
    #dbg_value(i32 %5, !447, !DIExpression(), !1208)
  %6 = call i32 @USize_val_u32_I(i32 %5), !dbg !1210
  %7 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %6, i1 false), !dbg !1211
  %8 = call i32 @U32_val_usize_Z(i32 %7), !dbg !1212
    #dbg_value(i32 %8, !442, !DIExpression(), !1205)
  %9 = icmp eq i32 %8, 0, !dbg !1213
  br i1 %9, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %if_then.i
  br label %USize_val_next_pow2_Z.exit.i

if_else.i.i:                                      ; preds = %if_then.i
    #dbg_value(i32 %len, !460, !DIExpression(), !1214)
  %10 = sub i32 32, %8
  %11 = call i32 @llvm.umin.i32(i32 %10, i32 31)
  br label %USize_val_next_pow2_Z.exit.i

USize_val_next_pow2_Z.exit.i:                     ; preds = %if_else.i.i, %if_then.i.i
  %12 = phi i32 [ 0, %if_then.i.i ], [ %11, %if_else.i.i ]
  %13 = shl nuw i32 1, %12
    #dbg_value(i32 %13, !347, !DIExpression(), !1216)
    #dbg_value(i32 %len, !353, !DIExpression(), !1216)
  %14 = icmp ugt i32 %13, %len, !dbg !1218
  br i1 %14, label %if_then.i4.i, label %if_else.i3.i

if_then.i4.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

if_else.i3.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

USize_val_max_ZZ.exit.i:                          ; preds = %if_else.i3.i, %if_then.i4.i
  %15 = phi i32 [ %13, %if_then.i4.i ], [ %len, %if_else.i3.i ]
    #dbg_value(i32 %15, !347, !DIExpression(), !1219)
    #dbg_value(i32 8, !353, !DIExpression(), !1219)
  %16 = icmp ugt i32 %15, 8, !dbg !1221
  br i1 %16, label %if_then.i6.i, label %if_else.i5.i

if_then.i6.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

if_else.i5.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

USize_val_max_ZZ.exit7.i:                         ; preds = %if_else.i5.i, %if_then.i6.i
  %17 = phi i32 [ %15, %if_then.i6.i ], [ 8, %if_else.i5.i ]
    #dbg_value(i32 %17, !347, !DIExpression(), !1222)
    #dbg_value(i32 32, !353, !DIExpression(), !1222)
  %18 = icmp ugt i32 %17, 32, !dbg !1224
  br i1 %18, label %if_then.i9.i, label %if_else.i8.i

if_then.i9.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

if_else.i8.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

USize_val_max_ZZ.exit10.i:                        ; preds = %if_else.i8.i, %if_then.i9.i
  %19 = phi i32 [ %17, %if_then.i9.i ], [ 32, %if_else.i8.i ]
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1225
  store i32 %19, ptr %20, align 4, !dbg !1225
  %21 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %22 = load i32, ptr %21, align 4
  %23 = getelementptr inbounds nuw i8, ptr %this, i32 12
  %24 = load ptr, ptr %23, align 4
  %25 = call ptr @pony_ctx(), !dbg !1226
  %26 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_realloc(ptr %25, ptr %24, i32 %19, i32 %22), !dbg !1226
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !1227
  store ptr %26, ptr %27, align 4, !dbg !1227
  br label %Array_U8_val_ref_reserve_Zo.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1228)
  br label %Array_U8_val_ref_reserve_Zo.exit

Array_U8_val_ref_reserve_Zo.exit:                 ; preds = %USize_val_max_ZZ.exit10.i, %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1230)
  %28 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !1232
  store i32 %len, ptr %28, align 4, !dbg !1232
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1233)
  ret ptr @None_Inst, !dbg !1235
}

define void @Array_U8_val_ref_create_pZo(ptr %this, i32 %len) unnamed_addr #4 !dbg !594 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !593, !DIExpression(), !1236)
    #dbg_value(i32 %len, !603, !DIExpression(), !1236)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !1237
  store i32 0, ptr %0, align 4, !dbg !1237
  %.not = icmp eq i32 %len, 0, !dbg !1238
  br i1 %.not, label %if_else, label %if_then

if_then:                                          ; preds = %entry
    #dbg_value(i32 %len, !438, !DIExpression(), !1239)
  %1 = add i32 %len, -1, !dbg !1242
    #dbg_value(i32 %1, !447, !DIExpression(), !1243)
  %2 = call i32 @USize_val_u32_I(i32 %1), !dbg !1245
  %3 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %2, i1 false), !dbg !1246
  %4 = call i32 @U32_val_usize_Z(i32 %3), !dbg !1247
    #dbg_value(i32 %4, !442, !DIExpression(), !1239)
  %5 = icmp eq i32 %4, 0, !dbg !1248
  br i1 %5, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %if_then
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %if_then
    #dbg_value(i32 %len, !460, !DIExpression(), !1249)
  %6 = sub i32 32, %4
  %7 = call i32 @llvm.umin.i32(i32 %6, i32 31)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %8 = phi i32 [ 0, %if_then.i ], [ %7, %if_else.i ]
  %9 = shl nuw i32 1, %8
    #dbg_value(i32 %9, !347, !DIExpression(), !1251)
    #dbg_value(i32 %len, !353, !DIExpression(), !1251)
  %10 = icmp ugt i32 %9, %len, !dbg !1253
  br i1 %10, label %if_then.i4, label %if_else.i3

if_then.i4:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

if_else.i3:                                       ; preds = %USize_val_next_pow2_Z.exit
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i4, %if_else.i3
  %11 = phi i32 [ %9, %if_then.i4 ], [ %len, %if_else.i3 ]
    #dbg_value(i32 %11, !347, !DIExpression(), !1254)
    #dbg_value(i32 8, !353, !DIExpression(), !1254)
  %12 = icmp ugt i32 %11, 8, !dbg !1256
  br i1 %12, label %if_then.i6, label %if_else.i5

if_then.i6:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

if_else.i5:                                       ; preds = %USize_val_max_ZZ.exit
  br label %USize_val_max_ZZ.exit7

USize_val_max_ZZ.exit7:                           ; preds = %if_then.i6, %if_else.i5
  %13 = phi i32 [ %11, %if_then.i6 ], [ 8, %if_else.i5 ]
    #dbg_value(i32 %13, !347, !DIExpression(), !1257)
    #dbg_value(i32 32, !353, !DIExpression(), !1257)
  %14 = icmp ugt i32 %13, 32, !dbg !1259
  br i1 %14, label %if_then.i9, label %if_else.i8

if_then.i9:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

if_else.i8:                                       ; preds = %USize_val_max_ZZ.exit7
  br label %USize_val_max_ZZ.exit10

USize_val_max_ZZ.exit10:                          ; preds = %if_then.i9, %if_else.i8
  %15 = phi i32 [ %13, %if_then.i9 ], [ 32, %if_else.i8 ]
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1260
  store i32 %15, ptr %16, align 4, !dbg !1260
  %17 = call ptr @pony_ctx(), !dbg !1261
  %18 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %17, i32 %15), !dbg !1261
  %19 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !1262
  store ptr %18, ptr %19, align 4, !dbg !1262
  br label %if_post

if_else:                                          ; preds = %entry
  %20 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1263
  store i32 0, ptr %20, align 4, !dbg !1263
  %21 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !1264
  store ptr null, ptr %21, align 4, !dbg !1264
  br label %if_post

if_post:                                          ; preds = %if_else, %USize_val_max_ZZ.exit10
  ret void, !dbg !1265
}

define ptr @Array_U8_val_ref_truncate_Zo(ptr dereferenceable(16) %this, i32 %len) unnamed_addr #4 !dbg !742 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !741, !DIExpression(), !1266)
    #dbg_value(i32 %len, !747, !DIExpression(), !1266)
  %0 = getelementptr inbounds nuw i8, ptr %this, i32 4
  %1 = load i32, ptr %0, align 4
    #dbg_value(i32 %1, !336, !DIExpression(), !1267)
    #dbg_value(i32 %len, !344, !DIExpression(), !1267)
  %2 = icmp ult i32 %1, %len, !dbg !1269
  br i1 %2, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %3 = phi i32 [ %1, %if_then.i ], [ %len, %if_else.i ]
  %4 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !1270
  store i32 %3, ptr %4, align 4, !dbg !1270
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1271)
  ret ptr @None_Inst, !dbg !1273
}

define noalias align 32 dereferenceable(16) ptr @Array_U8_val_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_U8_val_Desc, ptr %1, align 4
  ret ptr %1
}

define void @Env_ref__create_pIioioo(ptr %this, i32 %argc, ptr %argv, ptr %envp) unnamed_addr #4 !dbg !1274 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !1297, !DIExpression(), !1299)
    #dbg_value(i32 %argc, !1300, !DIExpression(), !1299)
    #dbg_value(ptr %argv, !1301, !DIExpression(), !1299)
    #dbg_value(ptr %envp, !1302, !DIExpression(), !1299)
    #dbg_value(ptr @AmbientAuth_Inst, !187, !DIExpression(), !1303)
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1305)
  %1 = getelementptr inbounds nuw i8, ptr %this, i32 4, !dbg !1307
  store ptr @AmbientAuth_Inst, ptr %1, align 4, !dbg !1307
  call void @pony_os_stdout_setup(), !dbg !1308
  %2 = call i1 @pony_os_stdin_setup(), !dbg !1309
  %3 = call ptr @pony_create(ptr %0, ptr nonnull @Stdin_Desc, i1 false)
  %4 = zext i1 %2 to i8, !dbg !1310
  %5 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !1310, !pony.msgsend !4
  %6 = getelementptr inbounds nuw i8, ptr %5, i32 12, !dbg !1310
  store i8 %4, ptr %6, align 1, !dbg !1310
  call void @pony_sendv_single(ptr %0, ptr nonnull %3, ptr %5, ptr %5, i1 true), !dbg !1310, !pony.msgsend !4
  %7 = getelementptr inbounds nuw i8, ptr %this, i32 8, !dbg !1311
  store ptr %3, ptr %7, align 4, !dbg !1311
  %8 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  %9 = call ptr @pony_alloc_msg(i32 0, i32 1), !dbg !1312, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %8, ptr %9, ptr %9, i1 true), !dbg !1312, !pony.msgsend !4
  %10 = getelementptr inbounds nuw i8, ptr %this, i32 12, !dbg !1313
  store ptr %8, ptr %10, align 4, !dbg !1313
  %11 = call ptr @pony_create(ptr %0, ptr nonnull @StdStream_Desc, i1 false)
  %12 = call ptr @pony_alloc_msg(i32 0, i32 0), !dbg !1314, !pony.msgsend !4
  call void @pony_sendv_single(ptr %0, ptr nonnull %11, ptr %12, ptr %12, i1 true), !dbg !1314, !pony.msgsend !4
  %13 = getelementptr inbounds nuw i8, ptr %this, i32 16, !dbg !1315
  store ptr %11, ptr %13, align 4, !dbg !1315
  %14 = call i32 @U32_val_usize_Z(i32 %argc), !dbg !1316
  %15 = call ptr @Env_tag__strings_from_pointers_oZo(ptr %this, ptr %argv, i32 %14), !dbg !1317
  %16 = getelementptr inbounds nuw i8, ptr %this, i32 20, !dbg !1318
  store ptr %15, ptr %16, align 4, !dbg !1318
    #dbg_value(ptr %this, !1319, !DIExpression(), !1328)
    #dbg_value(ptr %envp, !1330, !DIExpression(), !1328)
  %17 = icmp eq ptr %envp, null, !dbg !1331
  br i1 %17, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %Env_tag__count_strings_oZ.exit, !dbg !1333

if_else.i:                                        ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1335)
    #dbg_value(i32 0, !1325, !DIExpression(), !1328)
  %18 = load ptr, ptr %envp, align 4, !dbg !1338
    #dbg_value(ptr %18, !1326, !DIExpression(), !1339)
  %19 = icmp eq ptr %18, null, !dbg !1340
  br i1 %19, label %while_else.i, label %while_body.i

while_body.i:                                     ; preds = %while_body.i, %if_else.i
  %i.0.i = phi i32 [ 0, %if_else.i ], [ %20, %while_body.i ]
    #dbg_value(ptr poison, !1326, !DIExpression(), !1339)
    #dbg_value(i32 %i.0.i, !1325, !DIExpression(), !1328)
  %20 = add i32 %i.0.i, 1, !dbg !1341
    #dbg_value(i32 %20, !1325, !DIExpression(), !1328)
  %21 = getelementptr inbounds [4 x i8], ptr %envp, i32 %20, !dbg !1338
  %22 = load ptr, ptr %21, align 4, !dbg !1338
    #dbg_value(ptr %22, !1326, !DIExpression(), !1339)
  %23 = icmp eq ptr %22, null, !dbg !1340
  br i1 %23, label %while_post.i, label %while_body.i

while_else.i:                                     ; preds = %if_else.i
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1343)
  br label %while_post.i

while_post.i:                                     ; preds = %while_else.i, %while_body.i
  %i.1.i = phi i32 [ %20, %while_body.i ], [ 0, %while_else.i ]
    #dbg_value(i32 %i.1.i, !1325, !DIExpression(), !1328)
  br label %Env_tag__count_strings_oZ.exit, !dbg !1346

Env_tag__count_strings_oZ.exit:                   ; preds = %while_post.i, %if_then.i
  %24 = phi i32 [ 0, %if_then.i ], [ %i.1.i, %while_post.i ]
  %25 = call ptr @Env_tag__strings_from_pointers_oZo(ptr nonnull %this, ptr %envp, i32 %24), !dbg !1347
  %26 = getelementptr inbounds nuw i8, ptr %this, i32 24, !dbg !1348
  store ptr %25, ptr %26, align 4, !dbg !1348
    #dbg_value(ptr @"$0$16_Inst", !175, !DIExpression(), !1349)
  %27 = getelementptr inbounds nuw i8, ptr %this, i32 28, !dbg !1351
  store ptr @"$0$16_Inst", ptr %27, align 4, !dbg !1351
  ret void, !dbg !1351
}

define i32 @Env_tag__count_strings_oZ(ptr dereferenceable(32) %this, ptr %data) unnamed_addr #4 !dbg !1320 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1319, !DIExpression(), !1352)
    #dbg_value(ptr %data, !1330, !DIExpression(), !1352)
  %0 = icmp eq ptr %data, null, !dbg !1353
  br i1 %0, label %if_then, label %if_else

if_then:                                          ; preds = %entry
  ret i32 0, !dbg !1354

if_else:                                          ; preds = %entry
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1355)
  br label %if_post

if_post:                                          ; preds = %if_else
    #dbg_value(i32 0, !1325, !DIExpression(), !1352)
  br label %while_init

while_init:                                       ; preds = %if_post
  %1 = load ptr, ptr %data, align 4, !dbg !1357
    #dbg_value(ptr %1, !1326, !DIExpression(), !1358)
  %2 = icmp eq ptr %1, null, !dbg !1359
  br i1 %2, label %while_else, label %while_body

while_body:                                       ; preds = %while_body, %while_init
  %i.0 = phi i32 [ 0, %while_init ], [ %3, %while_body ]
    #dbg_value(ptr poison, !1326, !DIExpression(), !1358)
    #dbg_value(i32 %i.0, !1325, !DIExpression(), !1352)
  %3 = add i32 %i.0, 1, !dbg !1360
    #dbg_value(i32 %3, !1325, !DIExpression(), !1352)
  %4 = getelementptr inbounds [4 x i8], ptr %data, i32 %3, !dbg !1357
  %5 = load ptr, ptr %4, align 4, !dbg !1357
    #dbg_value(ptr %5, !1326, !DIExpression(), !1358)
  %6 = icmp eq ptr %5, null, !dbg !1359
  br i1 %6, label %while_post, label %while_body

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1361)
  br label %while_post

while_post:                                       ; preds = %while_else, %while_body
  %i.1 = phi i32 [ %3, %while_body ], [ 0, %while_else ]
    #dbg_value(i32 %i.1, !1325, !DIExpression(), !1352)
  ret i32 %i.1, !dbg !1363
}

define ptr @Env_tag__strings_from_pointers_oZo(ptr dereferenceable(32) %this, ptr %data, i32 %len) unnamed_addr #4 !dbg !1364 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
    #dbg_value(ptr %this, !1369, !DIExpression(), !1375)
    #dbg_value(ptr %data, !1376, !DIExpression(), !1375)
    #dbg_value(i32 %len, !1377, !DIExpression(), !1375)
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Array_String_val_Desc, ptr %1, align 4
    #dbg_value(ptr %1, !490, !DIExpression(), !1378)
    #dbg_value(i32 %len, !492, !DIExpression(), !1378)
  %2 = getelementptr inbounds nuw i8, ptr %1, i32 4, !dbg !1381
  store i32 0, ptr %2, align 4, !dbg !1381
  %.not.i = icmp eq i32 %len, 0, !dbg !1382
  br i1 %.not.i, label %if_else.i, label %if_then.i

if_then.i:                                        ; preds = %entry
    #dbg_value(i32 %len, !438, !DIExpression(), !1383)
  %3 = add i32 %len, -1, !dbg !1385
    #dbg_value(i32 %3, !447, !DIExpression(), !1386)
  %4 = call i32 @USize_val_u32_I(i32 %3), !dbg !1388
  %5 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %4, i1 false), !dbg !1389
  %6 = call i32 @U32_val_usize_Z(i32 %5), !dbg !1390
    #dbg_value(i32 %6, !442, !DIExpression(), !1383)
  %7 = icmp eq i32 %6, 0, !dbg !1391
  br i1 %7, label %if_then.i.i, label %if_else.i.i

if_then.i.i:                                      ; preds = %if_then.i
  br label %USize_val_next_pow2_Z.exit.i

if_else.i.i:                                      ; preds = %if_then.i
    #dbg_value(i32 %len, !460, !DIExpression(), !1392)
  %8 = sub i32 32, %6
  %9 = call i32 @llvm.umin.i32(i32 %8, i32 31)
  br label %USize_val_next_pow2_Z.exit.i

USize_val_next_pow2_Z.exit.i:                     ; preds = %if_else.i.i, %if_then.i.i
  %10 = phi i32 [ 0, %if_then.i.i ], [ %9, %if_else.i.i ]
  %11 = shl nuw i32 1, %10
    #dbg_value(i32 %11, !347, !DIExpression(), !1394)
    #dbg_value(i32 %len, !353, !DIExpression(), !1394)
  %12 = icmp ugt i32 %11, %len, !dbg !1396
  br i1 %12, label %if_then.i4.i, label %if_else.i3.i

if_then.i4.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

if_else.i3.i:                                     ; preds = %USize_val_next_pow2_Z.exit.i
  br label %USize_val_max_ZZ.exit.i

USize_val_max_ZZ.exit.i:                          ; preds = %if_else.i3.i, %if_then.i4.i
  %13 = phi i32 [ %11, %if_then.i4.i ], [ %len, %if_else.i3.i ]
    #dbg_value(i32 %13, !347, !DIExpression(), !1397)
    #dbg_value(i32 8, !353, !DIExpression(), !1397)
  %14 = icmp ugt i32 %13, 8, !dbg !1399
  br i1 %14, label %if_then.i6.i, label %if_else.i5.i

if_then.i6.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

if_else.i5.i:                                     ; preds = %USize_val_max_ZZ.exit.i
  br label %USize_val_max_ZZ.exit7.i

USize_val_max_ZZ.exit7.i:                         ; preds = %if_else.i5.i, %if_then.i6.i
  %15 = phi i32 [ %13, %if_then.i6.i ], [ 8, %if_else.i5.i ]
    #dbg_value(i32 %15, !347, !DIExpression(), !1400)
    #dbg_value(i32 8, !353, !DIExpression(), !1400)
  %16 = icmp ugt i32 %15, 8, !dbg !1402
  br i1 %16, label %if_then.i9.i, label %if_else.i8.i

if_then.i9.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

if_else.i8.i:                                     ; preds = %USize_val_max_ZZ.exit7.i
  br label %USize_val_max_ZZ.exit10.i

USize_val_max_ZZ.exit10.i:                        ; preds = %if_else.i8.i, %if_then.i9.i
  %17 = phi i32 [ %15, %if_then.i9.i ], [ 8, %if_else.i8.i ]
  %18 = getelementptr inbounds nuw i8, ptr %1, i32 8, !dbg !1403
  store i32 %17, ptr %18, align 4, !dbg !1403
  %19 = call ptr @pony_ctx(), !dbg !1404
  %20 = shl i32 %17, 2, !dbg !1404
  %21 = call noalias align 32 dereferenceable_or_null(4) ptr @pony_alloc(ptr %19, i32 %20), !dbg !1404
  %22 = getelementptr inbounds nuw i8, ptr %1, i32 12, !dbg !1405
  store ptr %21, ptr %22, align 4, !dbg !1405
  br label %Array_String_val_ref_create_pZo.exit

if_else.i:                                        ; preds = %entry
  %23 = getelementptr inbounds nuw i8, ptr %1, i32 8, !dbg !1406
  store i32 0, ptr %23, align 4, !dbg !1406
  %24 = getelementptr inbounds nuw i8, ptr %1, i32 12, !dbg !1407
  store ptr null, ptr %24, align 4, !dbg !1407
  br label %Array_String_val_ref_create_pZo.exit

Array_String_val_ref_create_pZo.exit:             ; preds = %USize_val_max_ZZ.exit10.i, %if_else.i
    #dbg_value(ptr %1, !1370, !DIExpression(), !1375)
    #dbg_value(i32 0, !1371, !DIExpression(), !1375)
  br label %while_init

while_init:                                       ; preds = %Array_String_val_ref_create_pZo.exit
  %.not = icmp eq i32 %len, 0, !dbg !1408
  br i1 %.not, label %while_else, label %while_body

while_body:                                       ; preds = %String_ref_copy_cstring_moo.exit, %while_init
  %i.0 = phi i32 [ 0, %while_init ], [ %25, %String_ref_copy_cstring_moo.exit ]
    #dbg_value(ptr poison, !1372, !DIExpression(), !1409)
    #dbg_value(i32 %i.0, !1371, !DIExpression(), !1375)
  %25 = add i32 %i.0, 1, !dbg !1410
    #dbg_value(i32 %25, !1371, !DIExpression(), !1375)
  %26 = getelementptr inbounds [4 x i8], ptr %data, i32 %i.0, !dbg !1411
  %27 = load ptr, ptr %26, align 4, !dbg !1411
    #dbg_value(ptr %27, !1372, !DIExpression(), !1409)
  %28 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @String_Desc, ptr %28, align 4
    #dbg_value(ptr %28, !368, !DIExpression(), !1412)
    #dbg_value(ptr %27, !373, !DIExpression(), !1412)
  %29 = icmp eq ptr %27, null, !dbg !1415
  br i1 %29, label %if_then.i17, label %if_else.i12

if_then.i17:                                      ; preds = %while_body
  %30 = getelementptr inbounds nuw i8, ptr %28, i32 4, !dbg !1416
  store i32 0, ptr %30, align 4, !dbg !1416
  %31 = getelementptr inbounds nuw i8, ptr %28, i32 8, !dbg !1417
  store i32 32, ptr %31, align 4, !dbg !1417
  %32 = call ptr @pony_ctx(), !dbg !1418
  %33 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %32, i32 32), !dbg !1418
  %34 = getelementptr inbounds nuw i8, ptr %28, i32 12, !dbg !1419
  store ptr %33, ptr %34, align 4, !dbg !1419
    #dbg_value(ptr %28, !313, !DIExpression(), !1420)
    #dbg_value(i32 0, !315, !DIExpression(), !1420)
    #dbg_value(i8 0, !316, !DIExpression(), !1420)
  %35 = getelementptr inbounds nuw i8, ptr %28, i32 12
  %36 = load ptr, ptr %35, align 4
  %37 = load i8, ptr %36, align 1, !dbg !1422
  store i8 0, ptr %36, align 1, !dbg !1422
  br label %String_ref_copy_cstring_moo.exit

if_else.i12:                                      ; preds = %while_body
    #dbg_value(i32 0, !369, !DIExpression(), !1423)
  %38 = load i8, ptr %27, align 1, !dbg !1424
  %.not.i13 = icmp eq i8 %38, 0
  br i1 %.not.i13, label %while_else.i, label %while_body.i

while_body.i:                                     ; preds = %while_body.i, %if_else.i12
  %i.0.i = phi i32 [ 0, %if_else.i12 ], [ %39, %while_body.i ]
    #dbg_value(i32 %i.0.i, !369, !DIExpression(), !1423)
  %39 = add i32 %i.0.i, 1, !dbg !1425
    #dbg_value(i32 %39, !369, !DIExpression(), !1423)
  %40 = getelementptr inbounds i8, ptr %27, i32 %39, !dbg !1424
  %41 = load i8, ptr %40, align 1, !dbg !1424
  %.not10.i = icmp eq i8 %41, 0
  br i1 %.not10.i, label %while_post.i, label %while_body.i

while_else.i:                                     ; preds = %if_else.i12
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1426)
  br label %while_post.i

while_post.i:                                     ; preds = %while_else.i, %while_body.i
  %i.1.i = phi i32 [ %39, %while_body.i ], [ 0, %while_else.i ]
    #dbg_value(i32 %i.1.i, !369, !DIExpression(), !1423)
  %42 = getelementptr inbounds nuw i8, ptr %28, i32 4, !dbg !1428
  store i32 %i.1.i, ptr %42, align 4, !dbg !1428
  %43 = add i32 %i.1.i, 1, !dbg !1429
    #dbg_value(i32 %43, !347, !DIExpression(), !1430)
    #dbg_value(i32 32, !353, !DIExpression(), !1430)
  %44 = icmp ugt i32 %43, 32, !dbg !1432
  br i1 %44, label %if_then.i.i16, label %if_else.i.i14

if_then.i.i16:                                    ; preds = %while_post.i
  br label %USize_val_max_ZZ.exit.i15

if_else.i.i14:                                    ; preds = %while_post.i
  br label %USize_val_max_ZZ.exit.i15

USize_val_max_ZZ.exit.i15:                        ; preds = %if_else.i.i14, %if_then.i.i16
  %45 = phi i32 [ %43, %if_then.i.i16 ], [ 32, %if_else.i.i14 ]
  %46 = getelementptr inbounds nuw i8, ptr %28, i32 8, !dbg !1433
  store i32 %45, ptr %46, align 4, !dbg !1433
  %47 = call ptr @pony_ctx(), !dbg !1434
  %48 = call noalias align 32 dereferenceable_or_null(1) ptr @pony_alloc(ptr %47, i32 %45), !dbg !1434
  %49 = getelementptr inbounds nuw i8, ptr %28, i32 12, !dbg !1435
  store ptr %48, ptr %49, align 4, !dbg !1435
  %50 = add i32 %i.1.i, 1, !dbg !1436
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %48, ptr align 1 %27, i32 %50, i1 false), !dbg !1437
  br label %String_ref_copy_cstring_moo.exit

String_ref_copy_cstring_moo.exit:                 ; preds = %if_then.i17, %USize_val_max_ZZ.exit.i15
    #dbg_value(ptr %1, !416, !DIExpression(), !1438)
    #dbg_value(ptr %28, !419, !DIExpression(), !1438)
  %51 = getelementptr inbounds nuw i8, ptr %1, i32 4, !dbg !1440
  %52 = load i32, ptr %51, align 4, !dbg !1440
  %53 = add i32 %52, 1, !dbg !1440
  %54 = call ptr @Array_String_val_ref_reserve_Zo(ptr nonnull dereferenceable(16) %1, i32 %53), !dbg !1441
  %55 = getelementptr inbounds nuw i8, ptr %1, i32 4
  %56 = load i32, ptr %55, align 4
  %57 = getelementptr inbounds nuw i8, ptr %1, i32 12
  %58 = load ptr, ptr %57, align 4
  %59 = getelementptr inbounds [4 x i8], ptr %58, i32 %56, !dbg !1442
  %60 = load ptr, ptr %59, align 4, !dbg !1442
  store ptr %28, ptr %59, align 4, !dbg !1442
  %61 = getelementptr inbounds nuw i8, ptr %1, i32 4, !dbg !1443
  %62 = load i32, ptr %61, align 4, !dbg !1443
  %63 = add i32 %62, 1, !dbg !1443
  %64 = getelementptr inbounds nuw i8, ptr %1, i32 4, !dbg !1444
  store i32 %63, ptr %64, align 4, !dbg !1444
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1445)
  %65 = icmp ult i32 %25, %len, !dbg !1408
  br i1 %65, label %while_body, label %while_post

while_else:                                       ; preds = %while_init
    #dbg_value(ptr @None_Inst, !53, !DIExpression(), !1447)
  br label %while_post

while_post:                                       ; preds = %while_else, %String_ref_copy_cstring_moo.exit
  ret ptr %1, !dbg !1450
}

define noalias align 32 dereferenceable(32) ptr @Env_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  %0 = call ptr @pony_ctx()
  %1 = call ptr @pony_alloc_small(ptr %0, i32 0)
  store volatile ptr @Env_Desc, ptr %1, align 4
  ret ptr %1
}

define ptr @None_val_create_o(ptr %this) unnamed_addr #4 !dbg !54 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !53, !DIExpression(), !1451)
  ret ptr %this, !dbg !1452
}

define ptr @None_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @None_Inst
}

define i1 @AsioEvent_val_readable_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !893 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !892, !DIExpression(), !1453)
    #dbg_value(i32 %flags, !898, !DIExpression(), !1453)
  %0 = trunc i32 %flags to i1
  ret i1 %0, !dbg !1454
}

define i1 @AsioEvent_box_readable_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !1455 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1458, !DIExpression(), !1459)
    #dbg_value(i32 %flags, !1460, !DIExpression(), !1459)
  %0 = trunc i32 %flags to i1
  ret i1 %0, !dbg !1461
}

define i1 @AsioEvent_box_errored_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !1462 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1465, !DIExpression(), !1466)
    #dbg_value(i32 %flags, !1467, !DIExpression(), !1466)
  %0 = and i32 %flags, 16
  %1 = icmp ne i32 %0, 0
  ret i1 %1, !dbg !1468
}

define i1 @AsioEvent_val_errored_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !848 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !847, !DIExpression(), !1469)
    #dbg_value(i32 %flags, !853, !DIExpression(), !1469)
  %0 = and i32 %flags, 16
  %1 = icmp ne i32 %0, 0
  ret i1 %1, !dbg !1470
}

define i1 @AsioEvent_box_disposable_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !1471 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1474, !DIExpression(), !1475)
    #dbg_value(i32 %flags, !1476, !DIExpression(), !1475)
  %0 = icmp eq i32 %flags, 0, !dbg !1477
  ret i1 %0, !dbg !1477
}

define i1 @AsioEvent_val_disposable_Ib(ptr dereferenceable(4) %this, i32 %flags) unnamed_addr #4 !dbg !832 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !831, !DIExpression(), !1478)
    #dbg_value(i32 %flags, !839, !DIExpression(), !1478)
  %0 = icmp eq i32 %flags, 0, !dbg !1479
  ret i1 %0, !dbg !1479
}

define ptr @AsioEvent_box_none_o(ptr dereferenceable(4) %this) unnamed_addr #4 !dbg !1480 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !1483, !DIExpression(), !1484)
  ret ptr null, !dbg !1485
}

define ptr @AsioEvent_val_none_o(ptr dereferenceable(4) %this) unnamed_addr #4 !dbg !80 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !79, !DIExpression(), !1486)
  ret ptr null, !dbg !1487
}

define ptr @AsioEvent_val_create_o(ptr %this) unnamed_addr #4 !dbg !68 !pony.abi !4 {
entry:
    #dbg_value(ptr %this, !67, !DIExpression(), !1488)
  ret ptr %this, !dbg !1489
}

define ptr @AsioEvent_Alloc() unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr @AsioEvent_Inst
}

define i32 @U8_box___digestof_(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i8, ptr %1, align 1
  %3 = zext i8 %2 to i32
  ret i32 %3
}

define i1 @U8_val_eq_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1490 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1495, !DIExpression(), !1497)
    #dbg_value(i8 %y, !1498, !DIExpression(), !1497)
  %0 = icmp eq i8 %this, %y, !dbg !1499
  ret i1 %0, !dbg !1499
}

define i1 @U8_box_eq_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1500 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1503, !DIExpression(), !1504)
    #dbg_value(i8 %y, !1505, !DIExpression(), !1504)
  %0 = icmp eq i8 %this, %y, !dbg !1506
  ret i1 %0, !dbg !1506
}

define i8 @U8_val_create_pCC(i8 %this, i8 %value) unnamed_addr #4 !dbg !1507 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1512, !DIExpression(), !1513)
    #dbg_value(i8 %value, !1514, !DIExpression(), !1513)
  ret i8 %value, !dbg !1515
}

define i1 @U8_val_ne_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1516 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1519, !DIExpression(), !1520)
    #dbg_value(i8 %y, !1521, !DIExpression(), !1520)
  %0 = icmp ne i8 %this, %y, !dbg !1522
  ret i1 %0, !dbg !1522
}

define i1 @U8_box_ne_Cb(i8 %this, i8 %y) unnamed_addr #4 !dbg !1523 !pony.abi !4 {
entry:
    #dbg_value(i8 %this, !1526, !DIExpression(), !1527)
    #dbg_value(i8 %y, !1528, !DIExpression(), !1527)
  %0 = icmp ne i8 %this, %y, !dbg !1529
  ret i1 %0, !dbg !1529
}

define ptr @Pointer_U8_val_ref_create_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr null
}

define noalias align 32 dereferenceable_or_null(1) ptr @Pointer_U8_val_ref__alloc_pZo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = call ptr @pony_ctx()
  %3 = call ptr @pony_alloc(ptr %2, i32 %1)
  ret ptr %3
}

define noalias align 32 dereferenceable_or_null(1) ptr @Pointer_U8_val_ref__realloc_ZZo(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = call ptr @pony_ctx()
  %4 = call ptr @pony_realloc(ptr %3, ptr %0, i32 %1, i32 %2)
  ret ptr %4
}

define ptr @Pointer_U8_val_tag__unsafe_o(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret ptr %0
}

define i8 @Pointer_U8_val_box__apply_ZC(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define i8 @Pointer_U8_val_ref__apply_ZC(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define i8 @Pointer_U8_val_val__apply_ZC(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  %3 = load i8, ptr %2, align 1
  ret i8 %3
}

define i8 @Pointer_U8_val_ref__update_ZCC(ptr %0, i32 %1, i8 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  %3 = getelementptr inbounds i8, ptr %0, i32 %1
  %4 = load i8, ptr %3, align 1
  store i8 %2, ptr %3, align 1
  ret i8 %4
}

define ptr @Pointer_U8_val_box__offset_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  ret ptr %2
}

define ptr @Pointer_U8_val_ref__offset_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  ret ptr %2
}

define ptr @Pointer_U8_val_val__offset_Zo(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds i8, ptr %0, i32 %1
  ret ptr %2
}

define i32 @Pointer_U8_val_tag__min_alloc_Z(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  ret i32 32
}

define ptr @Pointer_U8_val_box__copy_to_oZo(ptr %0, ptr %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %1, ptr align 1 %0, i32 %2, i1 false)
  ret ptr %0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #5

define ptr @Pointer_U8_val_ref__copy_to_oZo(ptr %0, ptr %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %1, ptr align 1 %0, i32 %2, i1 false)
  ret ptr %0
}

define ptr @Pointer_U8_val_val__copy_to_oZo(ptr %0, ptr %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
  call void @llvm.memcpy.p0.p0.i32(ptr align 1 %1, ptr align 1 %0, i32 %2, i1 false)
  ret ptr %0
}

define i1 @Pointer_U8_val_tag_is_null_b(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = icmp eq ptr %0, null
  ret i1 %1
}

declare ptr @pony_os_stderr()

declare ptr @pony_os_stdout()

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #5

declare i32 @pony_os_stdin_read(ptr, i32)

declare void @pony_asio_event_unsubscribe(ptr)

declare void @pony_asio_event_destroy(ptr)

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) #6

declare i32 @USize_val_u32_I(i32)

declare i32 @U32_val_usize_Z(i32)

declare void @pony_os_stdout_setup()

declare i1 @pony_os_stdin_setup()

define i32 @U32_val_op_and_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !104, !DIExpression(), !106)
    #dbg_value(i32 %1, !107, !DIExpression(), !106)
  %4 = and i32 %3, %1, !dbg !108
  ret i32 %4
}

define i32 @U32_box_op_and_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !112, !DIExpression(), !113)
    #dbg_value(i32 %1, !114, !DIExpression(), !113)
  %4 = and i32 %3, %1, !dbg !115
  ret i32 %4
}

define i32 @U32_val_shl_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !119, !DIExpression(), !120)
    #dbg_value(i32 %1, !121, !DIExpression(), !120)
  %4 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !122
  %5 = shl i32 %3, %4, !dbg !122
  ret i32 %5
}

define i32 @U32_box_shl_II_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !126, !DIExpression(), !127)
    #dbg_value(i32 %1, !128, !DIExpression(), !127)
  %4 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !129
  %5 = shl i32 %3, %4, !dbg !129
  ret i32 %5
}

declare i32 @U32_box_usize_Z(i32)

define i32 @U32_box_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  %3 = call i32 @U32_box_usize_Z(i32 %2)
  ret i32 %3
}

define i32 @U32_val_usize_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  %3 = call i32 @U32_val_usize_Z(i32 %2)
  ret i32 %3
}

define i1 @U32_val_ne_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !135, !DIExpression(), !136)
    #dbg_value(i32 %1, !137, !DIExpression(), !136)
  %4 = icmp ne i32 %3, %1, !dbg !138
  ret i1 %4
}

define i1 @U32_box_ne_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !142, !DIExpression(), !143)
    #dbg_value(i32 %1, !144, !DIExpression(), !143)
  %4 = icmp ne i32 %3, %1, !dbg !145
  ret i1 %4
}

define i1 @U32_box_eq_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !149, !DIExpression(), !150)
    #dbg_value(i32 %1, !151, !DIExpression(), !150)
  %4 = icmp eq i32 %3, %1, !dbg !152
  ret i1 %4
}

define i1 @U32_val_eq_Ib_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !156, !DIExpression(), !157)
    #dbg_value(i32 %1, !158, !DIExpression(), !157)
  %4 = icmp eq i32 %3, %1, !dbg !159
  ret i1 %4
}

define i32 @U32_val_create_pII_Unbox(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i32 %1, !163, !DIExpression(), !164)
    #dbg_value(i32 %2, !165, !DIExpression(), !164)
  ret i32 %2
}

define i1 @Bool_box_op_not_b_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i8, ptr %1, align 1
  %3 = trunc i8 %2 to i1
    #dbg_value(i1 %3, !530, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !532)
  %4 = xor i1 %3, true, !dbg !533
  ret i1 %4
}

define i1 @Bool_val_op_not_b_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i8, ptr %1, align 1
  %3 = trunc i8 %2 to i1
    #dbg_value(i1 %3, !537, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !538)
  %4 = xor i1 %3, true, !dbg !539
  ret i1 %4
}

define i1 @Bool_val_create_pbb_Unbox(ptr %0, i1 %1, i1 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i1 %1, !545, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !546)
    #dbg_value(i1 %2, !547, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !546)
  ret i1 %2
}

define i1 @Bool_box_op_and_bb_Unbox(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
  %4 = trunc i8 %3 to i1
    #dbg_value(i1 %4, !552, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !553)
    #dbg_value(i1 %1, !554, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !553)
  br i1 %4, label %sc_right.i, label %Bool_box_op_and_bb.exit, !dbg !555

sc_right.i:                                       ; preds = %entry
  br label %Bool_box_op_and_bb.exit, !dbg !555

Bool_box_op_and_bb.exit:                          ; preds = %entry, %sc_right.i
  %5 = phi i1 [ false, %entry ], [ %1, %sc_right.i ], !dbg !555
  ret i1 %5
}

define i1 @Bool_val_op_and_bb_Unbox(ptr %0, i1 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
  %4 = trunc i8 %3 to i1
    #dbg_value(i1 %4, !559, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !560)
    #dbg_value(i1 %1, !561, !DIExpression(DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_stack_value), !560)
  br i1 %4, label %sc_right.i, label %Bool_val_op_and_bb.exit, !dbg !562

sc_right.i:                                       ; preds = %entry
  br label %Bool_val_op_and_bb.exit, !dbg !562

Bool_val_op_and_bb.exit:                          ; preds = %entry, %sc_right.i
  %5 = phi i1 [ false, %entry ], [ %1, %sc_right.i ], !dbg !562
  ret i1 %5
}

define i32 @I32_val_create_pii_Unbox(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i32 %1, !911, !DIExpression(), !913)
    #dbg_value(i32 %2, !914, !DIExpression(), !913)
  ret i32 %2
}

define i1 @U64_val_eq_Wb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i64, ptr %2, align 4
    #dbg_value(i64 %3, !922, !DIExpression(), !924)
    #dbg_value(i64 %1, !925, !DIExpression(), !924)
  %4 = icmp eq i64 %3, %1, !dbg !926
  ret i1 %4
}

define i1 @U64_box_eq_Wb_Unbox(ptr %0, i64 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i64, ptr %2, align 4
    #dbg_value(i64 %3, !930, !DIExpression(), !931)
    #dbg_value(i64 %1, !932, !DIExpression(), !931)
  %4 = icmp eq i64 %3, %1, !dbg !933
  ret i1 %4
}

define i64 @U64_val_create_pWW_Unbox(ptr %0, i64 %1, i64 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i64 %1, !939, !DIExpression(), !940)
    #dbg_value(i64 %2, !941, !DIExpression(), !940)
  ret i64 %2
}

define i32 @USize_val_bitwidth_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !460, !DIExpression(), !943)
  ret i32 32
}

define i32 @USize_box_bitwidth_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !948, !DIExpression(), !949)
  ret i32 32
}

define i32 @USize_box_sub_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !954, !DIExpression(), !955)
    #dbg_value(i32 %1, !956, !DIExpression(), !955)
  %4 = sub i32 %3, %1, !dbg !957
  ret i32 %4
}

define i32 @USize_val_sub_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !961, !DIExpression(), !962)
    #dbg_value(i32 %1, !963, !DIExpression(), !962)
  %4 = sub i32 %3, %1, !dbg !964
  ret i32 %4
}

define i32 @USize_val_shl_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !968, !DIExpression(), !969)
    #dbg_value(i32 %1, !970, !DIExpression(), !969)
  %4 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !971
  %5 = shl i32 %3, %4, !dbg !971
  ret i32 %5
}

define i32 @USize_box_shl_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !975, !DIExpression(), !976)
    #dbg_value(i32 %1, !977, !DIExpression(), !976)
  %4 = call i32 @llvm.umin.i32(i32 %1, i32 31), !dbg !978
  %5 = shl i32 %3, %4, !dbg !978
  ret i32 %5
}

define i1 @USize_val_ne_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !984, !DIExpression(), !985)
    #dbg_value(i32 %1, !986, !DIExpression(), !985)
  %4 = icmp ne i32 %3, %1, !dbg !987
  ret i1 %4
}

define i1 @USize_box_ne_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !991, !DIExpression(), !992)
    #dbg_value(i32 %1, !993, !DIExpression(), !992)
  %4 = icmp ne i32 %3, %1, !dbg !994
  ret i1 %4
}

define i32 @USize_val_max_value_Z_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i32 %1, !327, !DIExpression(), !995)
  ret i32 -1
}

define i32 @USize_val_add_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1000, !DIExpression(), !1001)
    #dbg_value(i32 %1, !1002, !DIExpression(), !1001)
  %4 = add i32 %3, %1, !dbg !1003
  ret i32 %4
}

define i32 @USize_box_add_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1007, !DIExpression(), !1008)
    #dbg_value(i32 %1, !1009, !DIExpression(), !1008)
  %4 = add i32 %3, %1, !dbg !1010
  ret i32 %4
}

declare i32 @USize_box_u32_I(i32)

define i32 @USize_box_u32_I_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  %3 = call i32 @USize_box_u32_I(i32 %2)
  ret i32 %3
}

define i32 @USize_val_u32_I_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
  %3 = call i32 @USize_val_u32_I(i32 %2)
  ret i32 %3
}

define i32 @USize_val_next_pow2_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !438, !DIExpression(), !1011)
  %3 = add i32 %2, -1, !dbg !1012
    #dbg_value(i32 %3, !447, !DIExpression(), !1013)
  %4 = call i32 @USize_val_u32_I(i32 %3), !dbg !1015
  %5 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %4, i1 false), !dbg !1016
  %6 = call i32 @U32_val_usize_Z(i32 %5), !dbg !1017
    #dbg_value(i32 %6, !442, !DIExpression(), !1011)
  %7 = icmp eq i32 %6, 0, !dbg !1018
  br i1 %7, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_next_pow2_Z.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(i32 %2, !460, !DIExpression(), !1019)
  %8 = sub i32 32, %6
  %9 = call i32 @llvm.umin.i32(i32 %8, i32 31)
  br label %USize_val_next_pow2_Z.exit

USize_val_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %10 = phi i32 [ 0, %if_then.i ], [ %9, %if_else.i ]
  %11 = shl nuw i32 1, %10
  ret i32 %11
}

define i32 @USize_box_next_pow2_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !1025, !DIExpression(), !1027)
  %3 = add i32 %2, -1, !dbg !1028
    #dbg_value(i32 %3, !447, !DIExpression(), !1029)
  %4 = call i32 @USize_val_u32_I(i32 %3), !dbg !1031
  %5 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %4, i1 false), !dbg !1032
  %6 = call i32 @U32_val_usize_Z(i32 %5), !dbg !1033
    #dbg_value(i32 %6, !1026, !DIExpression(), !1027)
  %7 = icmp eq i32 %6, 0, !dbg !1034
  br i1 %7, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_next_pow2_Z.exit

if_else.i:                                        ; preds = %entry
    #dbg_value(i32 %2, !460, !DIExpression(), !1036)
  %8 = sub i32 32, %6
  %9 = call i32 @llvm.umin.i32(i32 %8, i32 31)
  br label %USize_box_next_pow2_Z.exit

USize_box_next_pow2_Z.exit:                       ; preds = %if_then.i, %if_else.i
  %10 = phi i32 [ 0, %if_then.i ], [ %9, %if_else.i ]
  %11 = shl nuw i32 1, %10
  ret i32 %11
}

define i1 @USize_box_eq_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1043, !DIExpression(), !1044)
    #dbg_value(i32 %1, !1045, !DIExpression(), !1044)
  %4 = icmp eq i32 %3, %1, !dbg !1046
  ret i1 %4
}

define i1 @USize_val_eq_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1050, !DIExpression(), !1051)
    #dbg_value(i32 %1, !1052, !DIExpression(), !1051)
  %4 = icmp eq i32 %3, %1, !dbg !1053
  ret i1 %4
}

define i32 @USize_box_clz_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !1057, !DIExpression(), !1058)
  %3 = call i32 @USize_val_u32_I(i32 %2), !dbg !1059
  %4 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %3, i1 false), !dbg !1062
  %5 = call i32 @U32_val_usize_Z(i32 %4), !dbg !1063
  ret i32 %5
}

define i32 @USize_val_clz_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !447, !DIExpression(), !1065)
  %3 = call i32 @USize_val_u32_I(i32 %2), !dbg !1066
  %4 = call range(i32 0, 33) i32 @llvm.ctlz.i32(i32 %3, i1 false), !dbg !1067
  %5 = call i32 @U32_val_usize_Z(i32 %4), !dbg !1068
  ret i32 %5
}

define i32 @USize_val_max_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !347, !DIExpression(), !1070)
    #dbg_value(i32 %1, !353, !DIExpression(), !1070)
  %4 = icmp ugt i32 %3, %1, !dbg !1071
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_max_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_max_ZZ.exit

USize_val_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i32 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i32 %5
}

define i32 @USize_box_max_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1076, !DIExpression(), !1077)
    #dbg_value(i32 %1, !1078, !DIExpression(), !1077)
  %4 = icmp ugt i32 %3, %1, !dbg !1079
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_max_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_box_max_ZZ.exit

USize_box_max_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i32 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i32 %5
}

define i32 @USize_val_neg_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !1085, !DIExpression(), !1086)
  %3 = sub i32 0, %2, !dbg !1087
  ret i32 %3
}

define i32 @USize_box_neg_Z_Unbox(ptr %0) unnamed_addr #4 !pony.abi !4 {
entry:
  %1 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %2 = load i32, ptr %1, align 4
    #dbg_value(i32 %2, !1091, !DIExpression(), !1092)
  %3 = sub i32 0, %2, !dbg !1093
  ret i32 %3
}

define i32 @USize_val_min_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !336, !DIExpression(), !1094)
    #dbg_value(i32 %1, !344, !DIExpression(), !1094)
  %4 = icmp ult i32 %3, %1, !dbg !1095
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_val_min_ZZ.exit

USize_val_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i32 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i32 %5
}

define i32 @USize_box_min_ZZ_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1100, !DIExpression(), !1101)
    #dbg_value(i32 %1, !1102, !DIExpression(), !1101)
  %4 = icmp ult i32 %3, %1, !dbg !1103
  br i1 %4, label %if_then.i, label %if_else.i

if_then.i:                                        ; preds = %entry
  br label %USize_box_min_ZZ.exit

if_else.i:                                        ; preds = %entry
  br label %USize_box_min_ZZ.exit

USize_box_min_ZZ.exit:                            ; preds = %if_then.i, %if_else.i
  %5 = phi i32 [ %3, %if_then.i ], [ %1, %if_else.i ]
  ret i32 %5
}

define i32 @USize_val_create_pZZ_Unbox(ptr %0, i32 %1, i32 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i32 %1, !1109, !DIExpression(), !1110)
    #dbg_value(i32 %2, !1111, !DIExpression(), !1110)
  ret i32 %2
}

define i1 @USize_val_lt_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1116, !DIExpression(), !1117)
    #dbg_value(i32 %1, !1118, !DIExpression(), !1117)
  %4 = icmp ult i32 %3, %1, !dbg !1119
  ret i1 %4
}

define i1 @USize_box_lt_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1123, !DIExpression(), !1124)
    #dbg_value(i32 %1, !1125, !DIExpression(), !1124)
  %4 = icmp ult i32 %3, %1, !dbg !1126
  ret i1 %4
}

define i1 @USize_val_gt_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1130, !DIExpression(), !1131)
    #dbg_value(i32 %1, !1132, !DIExpression(), !1131)
  %4 = icmp ugt i32 %3, %1, !dbg !1133
  ret i1 %4
}

define i1 @USize_box_gt_Zb_Unbox(ptr %0, i32 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i32, ptr %2, align 4
    #dbg_value(i32 %3, !1137, !DIExpression(), !1138)
    #dbg_value(i32 %1, !1139, !DIExpression(), !1138)
  %4 = icmp ugt i32 %3, %1, !dbg !1140
  ret i1 %4
}

define i1 @U8_val_eq_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
    #dbg_value(i8 %3, !1495, !DIExpression(), !1497)
    #dbg_value(i8 %1, !1498, !DIExpression(), !1497)
  %4 = icmp eq i8 %3, %1, !dbg !1499
  ret i1 %4
}

define i1 @U8_box_eq_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
    #dbg_value(i8 %3, !1503, !DIExpression(), !1504)
    #dbg_value(i8 %1, !1505, !DIExpression(), !1504)
  %4 = icmp eq i8 %3, %1, !dbg !1506
  ret i1 %4
}

define i8 @U8_val_create_pCC_Unbox(ptr %0, i8 %1, i8 %2) unnamed_addr #4 !pony.abi !4 {
entry:
    #dbg_value(i8 %1, !1512, !DIExpression(), !1513)
    #dbg_value(i8 %2, !1514, !DIExpression(), !1513)
  ret i8 %2
}

define i1 @U8_val_ne_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
    #dbg_value(i8 %3, !1519, !DIExpression(), !1520)
    #dbg_value(i8 %1, !1521, !DIExpression(), !1520)
  %4 = icmp ne i8 %3, %1, !dbg !1522
  ret i1 %4
}

define i1 @U8_box_ne_Cb_Unbox(ptr %0, i8 %1) unnamed_addr #4 !pony.abi !4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %3 = load i8, ptr %2, align 1
    #dbg_value(i8 %3, !1526, !DIExpression(), !1527)
    #dbg_value(i8 %1, !1528, !DIExpression(), !1527)
  %4 = icmp ne i8 %3, %1, !dbg !1529
  ret i1 %4
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #7

; Function Attrs: nounwind
declare void @pony_send_next(ptr, ptr readnone) #8

; Function Attrs: nounwind memory(argmem: readwrite)
declare void @pony_chain(ptr captures(none), ptr readnone) #9

attributes #0 = { nounwind memory(none) }
attributes #1 = { nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) }
attributes #2 = { nounwind memory(argmem: read) }
attributes #3 = { noreturn }
attributes #4 = { "target-cpu" "target-features"="+sse2" }
attributes #5 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #7 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #8 = { nounwind }
attributes #9 = { nounwind memory(argmem: readwrite) }

!llvm.module.flags = !{!0, !1}
!llvm.dbg.cu = !{!2}

!0 = !{i32 2, !"Dwarf Version", i32 4}
!1 = !{i32 2, !"Debug Info Version", i32 3}
!2 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus, file: !3, producer: "ponyc-0.78.2-e780f37e1", isOptimized: true, flags: "--gc-root-audit --triple=i386-unknown-linux-gnu -r ir -b audit -o <experiment>/i386 test/gc-root-audit ", runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false)
!3 = !DIFile(filename: "builtin", directory: "<checkout>/packages/builtin")
!4 = !{}
!5 = !DILocalVariable(name: "this", arg: 1, scope: !6, file: !7, line: 58, type: !19, flags: DIFlagArtificial)
!6 = distinct !DISubprogram(name: "_err", linkageName: "StdStream_tag__err_o", scope: !7, file: !7, line: 58, type: !8, scopeLine: 58, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !17, retainedNodes: !18)
!7 = !DIFile(filename: "<checkout>/packages/builtin/std_stream.pony", directory: "")
!8 = !DISubroutineType(types: !9)
!9 = !{!10, !10}
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 32, align: 32, dwarfAddressSpace: 0)
!11 = !DICompositeType(tag: DW_TAG_structure_type, name: "StdStream", file: !7, line: 51, size: 2432, align: 32, elements: !12, identifier: "StdStream")
!12 = !{!13}
!13 = !DIDerivedType(tag: DW_TAG_member, name: "_stream", file: !7, line: 50, baseType: !14, size: 32, align: 32, offset: 2400, flags: DIFlagPrivate)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 32, align: 32, dwarfAddressSpace: 0)
!15 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_U8_val", file: !16, line: 52, elements: !4, identifier: "Pointer_U8_val")
!16 = !DIFile(filename: "<checkout>/packages/builtin/pointer.pony", directory: "")
!17 = !DISubprogram(name: "_err", linkageName: "StdStream_tag__err_o", scope: !11, file: !7, line: 58, type: !8, scopeLine: 58, spFlags: 0)
!18 = !{!5}
!19 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !11, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!20 = !DILocation(line: 0, scope: !6)
!21 = !DILocation(line: 62, column: 15, scope: !6)
!22 = !DILocation(line: 62, column: 13, scope: !6)
!23 = !DILocalVariable(name: "this", arg: 1, scope: !24, file: !7, line: 52, type: !19, flags: DIFlagArtificial)
!24 = distinct !DISubprogram(name: "_out", linkageName: "StdStream_tag__out_o", scope: !7, file: !7, line: 52, type: !8, scopeLine: 52, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !25, retainedNodes: !26)
!25 = !DISubprogram(name: "_out", linkageName: "StdStream_tag__out_o", scope: !11, file: !7, line: 52, type: !8, scopeLine: 52, spFlags: 0)
!26 = !{!23}
!27 = !DILocation(line: 0, scope: !24)
!28 = !DILocation(line: 56, column: 15, scope: !24)
!29 = !DILocation(line: 56, column: 13, scope: !24)
!30 = !DILocalVariable(name: "this", arg: 1, scope: !31, file: !32, line: 74, type: !50, flags: DIFlagArtificial)
!31 = distinct !DISubprogram(name: "_create", linkageName: "Stdin_tag__create_pbo", scope: !32, file: !32, line: 74, type: !33, scopeLine: 74, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !48, retainedNodes: !49)
!32 = !DIFile(filename: "<checkout>/packages/builtin/stdin.pony", directory: "")
!33 = !DISubroutineType(types: !34)
!34 = !{!35, !35, !47}
!35 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 32, align: 32, dwarfAddressSpace: 0)
!36 = !DICompositeType(tag: DW_TAG_structure_type, name: "Stdin", file: !32, line: 49, size: 2528, align: 32, elements: !37, identifier: "Stdin")
!37 = !{!38, !41, !43, !46}
!38 = !DIDerivedType(tag: DW_TAG_member, name: "_notify", file: !32, line: 69, baseType: !39, size: 32, align: 32, offset: 2400, flags: DIFlagPrivate)
!39 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !40, size: 32, align: 32, dwarfAddressSpace: 0)
!40 = !DICompositeType(tag: DW_TAG_structure_type, name: "u2_InputNotify_ref_None_val", file: !32, line: 69, elements: !4, identifier: "u2_InputNotify_ref_None_val")
!41 = !DIDerivedType(tag: DW_TAG_member, name: "_chunk_size", file: !32, line: 70, baseType: !42, size: 32, align: 32, offset: 2432, flags: DIFlagPrivate)
!42 = !DIBasicType(name: "USize", size: 32, encoding: DW_ATE_unsigned)
!43 = !DIDerivedType(tag: DW_TAG_member, name: "_event", file: !32, line: 71, baseType: !44, size: 32, align: 32, offset: 2464, flags: DIFlagPrivate)
!44 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !45, size: 32, align: 32, dwarfAddressSpace: 0)
!45 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_AsioEvent_val", file: !16, line: 1, elements: !4, identifier: "Pointer_AsioEvent_val")
!46 = !DIDerivedType(tag: DW_TAG_member, name: "_use_event", file: !32, line: 72, baseType: !47, size: 8, align: 8, offset: 2496, flags: DIFlagPrivate)
!47 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean)
!48 = !DISubprogram(name: "_create", linkageName: "Stdin_tag__create_pbo", scope: !36, file: !32, line: 74, type: !33, scopeLine: 74, spFlags: 0)
!49 = !{!30}
!50 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !36, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!51 = !DILocation(line: 0, scope: !31)
!52 = !DILocalVariable(name: "use_event", arg: 2, scope: !31, file: !32, line: 74, type: !47)
!53 = !DILocalVariable(name: "this", arg: 1, scope: !54, file: !55, line: 1, type: !62, flags: DIFlagArtificial)
!54 = distinct !DISubprogram(name: "create", linkageName: "None_val_create_o", scope: !55, file: !55, line: 1, type: !56, scopeLine: 1, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !60, retainedNodes: !61)
!55 = !DIFile(filename: "<checkout>/packages/builtin/none.pony", directory: "")
!56 = !DISubroutineType(types: !57)
!57 = !{!58, !58}
!58 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !59, size: 32, align: 32, dwarfAddressSpace: 0)
!59 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", file: !55, line: 5, size: 32, align: 32, elements: !4, identifier: "None")
!60 = !DISubprogram(name: "create", linkageName: "None_val_create_o", scope: !59, file: !55, line: 1, type: !56, scopeLine: 1, spFlags: 0)
!61 = !{!53}
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !59, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!63 = !DILocation(line: 0, scope: !54, inlinedAt: !64)
!64 = distinct !DILocation(line: 69, column: 39, scope: !31)
!65 = !DILocation(line: 69, column: 3, scope: !31)
!66 = !DILocation(line: 70, column: 3, scope: !31)
!67 = !DILocalVariable(name: "this", arg: 1, scope: !68, file: !69, line: 6, type: !76, flags: DIFlagArtificial)
!68 = distinct !DISubprogram(name: "create", linkageName: "AsioEvent_val_create_o", scope: !69, file: !69, line: 6, type: !70, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !74, retainedNodes: !75)
!69 = !DIFile(filename: "<checkout>/packages/builtin/asio_event.pony", directory: "")
!70 = !DISubroutineType(types: !71)
!71 = !{!72, !72}
!72 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 32, align: 32, dwarfAddressSpace: 0)
!73 = !DICompositeType(tag: DW_TAG_structure_type, name: "AsioEvent", file: !69, line: 1, size: 32, align: 32, elements: !4, identifier: "AsioEvent")
!74 = !DISubprogram(name: "create", linkageName: "AsioEvent_val_create_o", scope: !73, file: !69, line: 6, type: !70, scopeLine: 6, spFlags: 0)
!75 = !{!67}
!76 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!77 = !DILocation(line: 0, scope: !68, inlinedAt: !78)
!78 = distinct !DILocation(line: 71, column: 38, scope: !31)
!79 = !DILocalVariable(name: "this", arg: 1, scope: !80, file: !69, line: 10, type: !76, flags: DIFlagArtificial)
!80 = distinct !DISubprogram(name: "none", linkageName: "AsioEvent_val_none_o", scope: !69, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !83, retainedNodes: !84)
!81 = !DISubroutineType(types: !82)
!82 = !{!44, !72}
!83 = !DISubprogram(name: "none", linkageName: "AsioEvent_val_none_o", scope: !73, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: 0)
!84 = !{!79}
!85 = !DILocation(line: 0, scope: !80, inlinedAt: !86)
!86 = distinct !DILocation(line: 71, column: 43, scope: !31)
!87 = !DILocation(line: 71, column: 3, scope: !31)
!88 = !DILocation(line: 78, column: 16, scope: !31)
!89 = !DILocalVariable(name: "this", arg: 1, scope: !90, file: !32, line: 143, type: !50, flags: DIFlagArtificial)
!90 = distinct !DISubprogram(name: "_read_again", linkageName: "Stdin_tag__read_again_o", scope: !32, file: !32, line: 143, type: !91, scopeLine: 143, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !93, retainedNodes: !94)
!91 = !DISubroutineType(types: !92)
!92 = !{!58, !35}
!93 = !DISubprogram(name: "_read_again", linkageName: "Stdin_tag__read_again_o", scope: !36, file: !32, line: 143, type: !91, scopeLine: 143, spFlags: 0)
!94 = !{!89}
!95 = !DILocation(line: 0, scope: !90)
!96 = !DILocation(line: 147, column: 10, scope: !90)
!97 = distinct !DISubprogram(name: "op_and", linkageName: "U32_val_op_and_II", scope: !98, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !102, retainedNodes: !103)
!98 = !DIFile(filename: "<checkout>/packages/builtin/unsigned.pony", directory: "")
!99 = !DISubroutineType(types: !100)
!100 = !{!101, !101, !101}
!101 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned)
!102 = !DISubprogram(name: "op_and", linkageName: "U32_val_op_and_II", scope: !101, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: 0)
!103 = !{!104}
!104 = !DILocalVariable(name: "this", arg: 1, scope: !97, file: !98, line: 384, type: !105, flags: DIFlagArtificial)
!105 = !DIBasicType(name: "U32", size: 32, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!106 = !DILocation(line: 0, scope: !97)
!107 = !DILocalVariable(name: "y", arg: 2, scope: !97, file: !98, line: 384, type: !101)
!108 = !DILocation(line: 384, column: 31, scope: !97)
!109 = distinct !DISubprogram(name: "op_and", linkageName: "U32_box_op_and_II", scope: !98, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !110, retainedNodes: !111)
!110 = !DISubprogram(name: "op_and", linkageName: "U32_box_op_and_II", scope: !101, file: !98, line: 384, type: !99, scopeLine: 384, spFlags: 0)
!111 = !{!112}
!112 = !DILocalVariable(name: "this", arg: 1, scope: !109, file: !98, line: 384, type: !105, flags: DIFlagArtificial)
!113 = !DILocation(line: 0, scope: !109)
!114 = !DILocalVariable(name: "y", arg: 2, scope: !109, file: !98, line: 384, type: !101)
!115 = !DILocation(line: 384, column: 31, scope: !109)
!116 = distinct !DISubprogram(name: "shl", linkageName: "U32_val_shl_II", scope: !98, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !117, retainedNodes: !118)
!117 = !DISubprogram(name: "shl", linkageName: "U32_val_shl_II", scope: !101, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: 0)
!118 = !{!119}
!119 = !DILocalVariable(name: "this", arg: 1, scope: !116, file: !98, line: 445, type: !105, flags: DIFlagArtificial)
!120 = !DILocation(line: 0, scope: !116)
!121 = !DILocalVariable(name: "y", arg: 2, scope: !116, file: !98, line: 445, type: !101)
!122 = !DILocation(line: 445, column: 28, scope: !116)
!123 = distinct !DISubprogram(name: "shl", linkageName: "U32_box_shl_II", scope: !98, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !124, retainedNodes: !125)
!124 = !DISubprogram(name: "shl", linkageName: "U32_box_shl_II", scope: !101, file: !98, line: 445, type: !99, scopeLine: 445, spFlags: 0)
!125 = !{!126}
!126 = !DILocalVariable(name: "this", arg: 1, scope: !123, file: !98, line: 445, type: !105, flags: DIFlagArtificial)
!127 = !DILocation(line: 0, scope: !123)
!128 = !DILocalVariable(name: "y", arg: 2, scope: !123, file: !98, line: 445, type: !101)
!129 = !DILocation(line: 445, column: 28, scope: !123)
!130 = distinct !DISubprogram(name: "ne", linkageName: "U32_val_ne_Ib", scope: !98, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !133, retainedNodes: !134)
!131 = !DISubroutineType(types: !132)
!132 = !{!47, !101, !101}
!133 = !DISubprogram(name: "ne", linkageName: "U32_val_ne_Ib", scope: !101, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: 0)
!134 = !{!135}
!135 = !DILocalVariable(name: "this", arg: 1, scope: !130, file: !98, line: 173, type: !105, flags: DIFlagArtificial)
!136 = !DILocation(line: 0, scope: !130)
!137 = !DILocalVariable(name: "y", arg: 2, scope: !130, file: !98, line: 173, type: !101)
!138 = !DILocation(line: 173, column: 35, scope: !130)
!139 = distinct !DISubprogram(name: "ne", linkageName: "U32_box_ne_Ib", scope: !98, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !140, retainedNodes: !141)
!140 = !DISubprogram(name: "ne", linkageName: "U32_box_ne_Ib", scope: !101, file: !98, line: 173, type: !131, scopeLine: 173, spFlags: 0)
!141 = !{!142}
!142 = !DILocalVariable(name: "this", arg: 1, scope: !139, file: !98, line: 173, type: !105, flags: DIFlagArtificial)
!143 = !DILocation(line: 0, scope: !139)
!144 = !DILocalVariable(name: "y", arg: 2, scope: !139, file: !98, line: 173, type: !101)
!145 = !DILocation(line: 173, column: 35, scope: !139)
!146 = distinct !DISubprogram(name: "eq", linkageName: "U32_box_eq_Ib", scope: !98, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !147, retainedNodes: !148)
!147 = !DISubprogram(name: "eq", linkageName: "U32_box_eq_Ib", scope: !101, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: 0)
!148 = !{!149}
!149 = !DILocalVariable(name: "this", arg: 1, scope: !146, file: !98, line: 172, type: !105, flags: DIFlagArtificial)
!150 = !DILocation(line: 0, scope: !146)
!151 = !DILocalVariable(name: "y", arg: 2, scope: !146, file: !98, line: 172, type: !101)
!152 = !DILocation(line: 172, column: 35, scope: !146)
!153 = distinct !DISubprogram(name: "eq", linkageName: "U32_val_eq_Ib", scope: !98, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !154, retainedNodes: !155)
!154 = !DISubprogram(name: "eq", linkageName: "U32_val_eq_Ib", scope: !101, file: !98, line: 172, type: !131, scopeLine: 172, spFlags: 0)
!155 = !{!156}
!156 = !DILocalVariable(name: "this", arg: 1, scope: !153, file: !98, line: 172, type: !105, flags: DIFlagArtificial)
!157 = !DILocation(line: 0, scope: !153)
!158 = !DILocalVariable(name: "y", arg: 2, scope: !153, file: !98, line: 172, type: !101)
!159 = !DILocation(line: 172, column: 35, scope: !153)
!160 = distinct !DISubprogram(name: "create", linkageName: "U32_val_create_pII", scope: !98, file: !98, line: 187, type: !99, scopeLine: 187, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !161, retainedNodes: !162)
!161 = !DISubprogram(name: "create", linkageName: "U32_val_create_pII", scope: !101, file: !98, line: 187, type: !99, scopeLine: 187, spFlags: 0)
!162 = !{!163}
!163 = !DILocalVariable(name: "this", arg: 1, scope: !160, file: !98, line: 187, type: !105, flags: DIFlagArtificial)
!164 = !DILocation(line: 0, scope: !160)
!165 = !DILocalVariable(name: "value", arg: 2, scope: !160, file: !98, line: 187, type: !101)
!166 = !DILocation(line: 187, column: 29, scope: !160)
!167 = distinct !DISubprogram(name: "create", linkageName: "$0$16_val_create_o", scope: !168, file: !168, line: 56, type: !169, scopeLine: 56, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !173, retainedNodes: !174)
!168 = !DIFile(filename: "<checkout>/packages/builtin/env.pony", directory: "")
!169 = !DISubroutineType(types: !170)
!170 = !{!171, !171}
!171 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !172, size: 32, align: 32, dwarfAddressSpace: 0)
!172 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$16", file: !168, line: 56, size: 32, align: 32, elements: !4, identifier: "$0$16")
!173 = !DISubprogram(name: "create", linkageName: "$0$16_val_create_o", scope: !172, file: !168, line: 56, type: !169, scopeLine: 56, spFlags: 0)
!174 = !{!175}
!175 = !DILocalVariable(name: "this", arg: 1, scope: !167, file: !168, line: 56, type: !176, flags: DIFlagArtificial)
!176 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !172, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!177 = !DILocation(line: 0, scope: !167)
!178 = !DILocation(line: 56, column: 16, scope: !167)
!179 = distinct !DISubprogram(name: "_create", linkageName: "AmbientAuth_val__create_o", scope: !180, file: !180, line: 15, type: !181, scopeLine: 15, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !185, retainedNodes: !186)
!180 = !DIFile(filename: "<checkout>/packages/builtin/ambient_auth.pony", directory: "")
!181 = !DISubroutineType(types: !182)
!182 = !{!183, !183}
!183 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !184, size: 32, align: 32, dwarfAddressSpace: 0)
!184 = !DICompositeType(tag: DW_TAG_structure_type, name: "AmbientAuth", file: !180, line: 9, size: 32, align: 32, elements: !4, identifier: "AmbientAuth")
!185 = !DISubprogram(name: "_create", linkageName: "AmbientAuth_val__create_o", scope: !184, file: !180, line: 15, type: !181, scopeLine: 15, spFlags: 0)
!186 = !{!187}
!187 = !DILocalVariable(name: "this", arg: 1, scope: !179, file: !180, line: 15, type: !188, flags: DIFlagArtificial)
!188 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !184, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!189 = !DILocation(line: 0, scope: !179)
!190 = !DILocation(line: 0, scope: !54, inlinedAt: !191)
!191 = distinct !DILocation(line: 16, column: 5, scope: !179)
!192 = !DILocation(line: 16, column: 5, scope: !179)
!193 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_ref_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !203, retainedNodes: !204)
!194 = !DIFile(filename: "<checkout>/packages/builtin/string.pony", directory: "")
!195 = !DISubroutineType(types: !196)
!196 = !{!47, !197}
!197 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 32, align: 32, dwarfAddressSpace: 0)
!198 = !DICompositeType(tag: DW_TAG_structure_type, name: "String", file: !194, line: 25, size: 128, align: 32, elements: !199, identifier: "String")
!199 = !{!200, !201, !202}
!200 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !194, line: 50, baseType: !42, size: 32, align: 32, offset: 32, flags: DIFlagPrivate)
!201 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !194, line: 51, baseType: !42, size: 32, align: 32, offset: 64, flags: DIFlagPrivate)
!202 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !194, line: 52, baseType: !14, size: 32, align: 32, offset: 96, flags: DIFlagPrivate)
!203 = !DISubprogram(name: "is_null_terminated", linkageName: "String_ref_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!204 = !{!205}
!205 = !DILocalVariable(name: "this", arg: 1, scope: !193, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!206 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !198, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!207 = !DILocation(line: 0, scope: !193)
!208 = !DILocation(line: 491, column: 40, scope: !193)
!209 = !DILocation(line: 491, column: 18, scope: !193)
!210 = !DILocation(line: 491, column: 13, scope: !193)
!211 = !DILocation(line: 491, column: 30, scope: !193)
!212 = !DILocation(line: 491, column: 64, scope: !193)
!213 = !DILocation(line: 491, column: 56, scope: !193)
!214 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_box_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !215, retainedNodes: !216)
!215 = !DISubprogram(name: "is_null_terminated", linkageName: "String_box_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!216 = !{!217}
!217 = !DILocalVariable(name: "this", arg: 1, scope: !214, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!218 = !DILocation(line: 0, scope: !214)
!219 = !DILocation(line: 491, column: 40, scope: !214)
!220 = !DILocation(line: 491, column: 18, scope: !214)
!221 = !DILocation(line: 491, column: 13, scope: !214)
!222 = !DILocation(line: 491, column: 30, scope: !214)
!223 = !DILocation(line: 491, column: 64, scope: !214)
!224 = !DILocation(line: 491, column: 56, scope: !214)
!225 = distinct !DISubprogram(name: "is_null_terminated", linkageName: "String_val_is_null_terminated_b", scope: !194, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !226, retainedNodes: !227)
!226 = !DISubprogram(name: "is_null_terminated", linkageName: "String_val_is_null_terminated_b", scope: !198, file: !194, line: 482, type: !195, scopeLine: 482, spFlags: 0)
!227 = !{!228}
!228 = !DILocalVariable(name: "this", arg: 1, scope: !225, file: !194, line: 482, type: !206, flags: DIFlagArtificial)
!229 = !DILocation(line: 0, scope: !225)
!230 = !DILocation(line: 491, column: 40, scope: !225)
!231 = !DILocation(line: 491, column: 18, scope: !225)
!232 = !DILocation(line: 491, column: 13, scope: !225)
!233 = !DILocation(line: 491, column: 30, scope: !225)
!234 = !DILocation(line: 491, column: 64, scope: !225)
!235 = !DILocation(line: 491, column: 56, scope: !225)
!236 = distinct !DISubprogram(name: "cstring", linkageName: "String_box_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !239, retainedNodes: !240)
!237 = !DISubroutineType(types: !238)
!238 = !{!14, !197}
!239 = !DISubprogram(name: "cstring", linkageName: "String_box_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!240 = !{!241, !242}
!241 = !DILocalVariable(name: "this", arg: 1, scope: !236, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!242 = !DILocalVariable(name: "ptr", scope: !236, file: !194, line: 236, type: !14, align: 32)
!243 = !DILocation(line: 0, scope: !236)
!244 = !DILocation(line: 0, scope: !214, inlinedAt: !245)
!245 = distinct !DILocation(line: 232, column: 26, scope: !246)
!246 = distinct !DILexicalBlock(scope: !236, file: !194, line: 232, column: 5)
!247 = !DILocation(line: 491, column: 13, scope: !214, inlinedAt: !245)
!248 = !DILocation(line: 491, column: 30, scope: !214, inlinedAt: !245)
!249 = !DILocation(line: 491, column: 64, scope: !214, inlinedAt: !245)
!250 = !DILocation(line: 491, column: 56, scope: !214, inlinedAt: !245)
!251 = !DILocation(line: 233, column: 7, scope: !252)
!252 = distinct !DILexicalBlock(scope: !246, file: !194, line: 233, column: 7)
!253 = !DILocation(line: 0, scope: !54, inlinedAt: !254)
!254 = distinct !DILocation(line: 233, column: 14, scope: !255)
!255 = distinct !DILexicalBlock(scope: !246, file: !194, line: 233, column: 14)
!256 = !DILocation(line: 236, column: 40, scope: !236)
!257 = !DILocation(line: 236, column: 33, scope: !236)
!258 = !DILocation(line: 237, column: 18, scope: !236)
!259 = !DILocation(line: 238, column: 16, scope: !236)
!260 = !DILocation(line: 239, column: 5, scope: !236)
!261 = distinct !DISubprogram(name: "cstring", linkageName: "String_val_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !262, retainedNodes: !263)
!262 = !DISubprogram(name: "cstring", linkageName: "String_val_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!263 = !{!264, !265}
!264 = !DILocalVariable(name: "this", arg: 1, scope: !261, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!265 = !DILocalVariable(name: "ptr", scope: !261, file: !194, line: 236, type: !14, align: 32)
!266 = !DILocation(line: 0, scope: !261)
!267 = !DILocation(line: 0, scope: !225, inlinedAt: !268)
!268 = distinct !DILocation(line: 232, column: 26, scope: !269)
!269 = distinct !DILexicalBlock(scope: !261, file: !194, line: 232, column: 5)
!270 = !DILocation(line: 491, column: 13, scope: !225, inlinedAt: !268)
!271 = !DILocation(line: 491, column: 30, scope: !225, inlinedAt: !268)
!272 = !DILocation(line: 491, column: 64, scope: !225, inlinedAt: !268)
!273 = !DILocation(line: 491, column: 56, scope: !225, inlinedAt: !268)
!274 = !DILocation(line: 233, column: 7, scope: !275)
!275 = distinct !DILexicalBlock(scope: !269, file: !194, line: 233, column: 7)
!276 = !DILocation(line: 0, scope: !54, inlinedAt: !277)
!277 = distinct !DILocation(line: 233, column: 14, scope: !278)
!278 = distinct !DILexicalBlock(scope: !269, file: !194, line: 233, column: 14)
!279 = !DILocation(line: 236, column: 40, scope: !261)
!280 = !DILocation(line: 236, column: 33, scope: !261)
!281 = !DILocation(line: 237, column: 18, scope: !261)
!282 = !DILocation(line: 238, column: 16, scope: !261)
!283 = !DILocation(line: 239, column: 5, scope: !261)
!284 = distinct !DISubprogram(name: "cstring", linkageName: "String_ref_cstring_o", scope: !194, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !285, retainedNodes: !286)
!285 = !DISubprogram(name: "cstring", linkageName: "String_ref_cstring_o", scope: !198, file: !194, line: 224, type: !237, scopeLine: 224, spFlags: 0)
!286 = !{!287, !288}
!287 = !DILocalVariable(name: "this", arg: 1, scope: !284, file: !194, line: 224, type: !206, flags: DIFlagArtificial)
!288 = !DILocalVariable(name: "ptr", scope: !284, file: !194, line: 236, type: !14, align: 32)
!289 = !DILocation(line: 0, scope: !284)
!290 = !DILocation(line: 0, scope: !193, inlinedAt: !291)
!291 = distinct !DILocation(line: 232, column: 26, scope: !292)
!292 = distinct !DILexicalBlock(scope: !284, file: !194, line: 232, column: 5)
!293 = !DILocation(line: 491, column: 13, scope: !193, inlinedAt: !291)
!294 = !DILocation(line: 491, column: 30, scope: !193, inlinedAt: !291)
!295 = !DILocation(line: 491, column: 64, scope: !193, inlinedAt: !291)
!296 = !DILocation(line: 491, column: 56, scope: !193, inlinedAt: !291)
!297 = !DILocation(line: 233, column: 7, scope: !298)
!298 = distinct !DILexicalBlock(scope: !292, file: !194, line: 233, column: 7)
!299 = !DILocation(line: 0, scope: !54, inlinedAt: !300)
!300 = distinct !DILocation(line: 233, column: 14, scope: !301)
!301 = distinct !DILexicalBlock(scope: !292, file: !194, line: 233, column: 14)
!302 = !DILocation(line: 236, column: 40, scope: !284)
!303 = !DILocation(line: 236, column: 33, scope: !284)
!304 = !DILocation(line: 237, column: 18, scope: !284)
!305 = !DILocation(line: 238, column: 16, scope: !284)
!306 = !DILocation(line: 239, column: 5, scope: !284)
!307 = distinct !DISubprogram(name: "_set", linkageName: "String_ref__set_ZCC", scope: !194, file: !194, line: 1700, type: !308, scopeLine: 1700, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !311, retainedNodes: !312)
!308 = !DISubroutineType(types: !309)
!309 = !{!310, !197, !42, !310}
!310 = !DIBasicType(name: "U8", size: 8, encoding: DW_ATE_unsigned)
!311 = !DISubprogram(name: "_set", linkageName: "String_ref__set_ZCC", scope: !198, file: !194, line: 1700, type: !308, scopeLine: 1700, spFlags: 0)
!312 = !{!313}
!313 = !DILocalVariable(name: "this", arg: 1, scope: !307, file: !194, line: 1700, type: !206, flags: DIFlagArtificial)
!314 = !DILocation(line: 0, scope: !307)
!315 = !DILocalVariable(name: "i", arg: 2, scope: !307, file: !194, line: 1700, type: !42)
!316 = !DILocalVariable(name: "value", arg: 3, scope: !307, file: !194, line: 1700, type: !310)
!317 = !DILocation(line: 1704, column: 17, scope: !307)
!318 = distinct !DISubprogram(name: "create", linkageName: "String_ref_create_pZo", scope: !194, file: !194, line: 54, type: !319, scopeLine: 54, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !321, retainedNodes: !322)
!319 = !DISubroutineType(types: !320)
!320 = !{!197, !197, !42}
!321 = !DISubprogram(name: "create", linkageName: "String_ref_create_pZo", scope: !198, file: !194, line: 54, type: !319, scopeLine: 54, spFlags: 0)
!322 = !{!323}
!323 = !DILocalVariable(name: "this", arg: 1, scope: !318, file: !194, line: 54, type: !206, flags: DIFlagArtificial)
!324 = !DILocation(line: 0, scope: !318)
!325 = !DILocalVariable(name: "len", arg: 2, scope: !318, file: !194, line: 54, type: !42)
!326 = !DILocation(line: 58, column: 11, scope: !318)
!327 = !DILocalVariable(name: "this", arg: 1, scope: !328, file: !98, line: 490, type: !333, flags: DIFlagArtificial)
!328 = distinct !DISubprogram(name: "max_value", linkageName: "USize_val_max_value_Z", scope: !98, file: !98, line: 490, type: !329, scopeLine: 490, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !331, retainedNodes: !332)
!329 = !DISubroutineType(types: !330)
!330 = !{!42, !42}
!331 = !DISubprogram(name: "max_value", linkageName: "USize_val_max_value_Z", scope: !42, file: !98, line: 490, type: !329, scopeLine: 490, spFlags: 0)
!332 = !{!327}
!333 = !DIBasicType(name: "USize", size: 32, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!334 = !DILocation(line: 0, scope: !328, inlinedAt: !335)
!335 = distinct !DILocation(line: 59, column: 36, scope: !318)
!336 = !DILocalVariable(name: "this", arg: 1, scope: !337, file: !98, line: 564, type: !333, flags: DIFlagArtificial)
!337 = distinct !DISubprogram(name: "min", linkageName: "USize_val_min_ZZ", scope: !98, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !340, retainedNodes: !341)
!338 = !DISubroutineType(types: !339)
!339 = !{!42, !42, !42}
!340 = !DISubprogram(name: "min", linkageName: "USize_val_min_ZZ", scope: !42, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: 0)
!341 = !{!336}
!342 = !DILocation(line: 0, scope: !337, inlinedAt: !343)
!343 = distinct !DILocation(line: 59, column: 22, scope: !318)
!344 = !DILocalVariable(name: "y", arg: 2, scope: !337, file: !98, line: 564, type: !42)
!345 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !343)
!346 = distinct !DILexicalBlock(scope: !337, file: !98, line: 564, column: 31)
!347 = !DILocalVariable(name: "this", arg: 1, scope: !348, file: !98, line: 565, type: !333, flags: DIFlagArtificial)
!348 = distinct !DISubprogram(name: "max", linkageName: "USize_val_max_ZZ", scope: !98, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !349, retainedNodes: !350)
!349 = !DISubprogram(name: "max", linkageName: "USize_val_max_ZZ", scope: !42, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: 0)
!350 = !{!347}
!351 = !DILocation(line: 0, scope: !348, inlinedAt: !352)
!352 = distinct !DILocation(line: 59, column: 52, scope: !318)
!353 = !DILocalVariable(name: "y", arg: 2, scope: !348, file: !98, line: 565, type: !42)
!354 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !352)
!355 = distinct !DILexicalBlock(scope: !348, file: !98, line: 565, column: 31)
!356 = !DILocation(line: 59, column: 12, scope: !318)
!357 = !DILocation(line: 60, column: 30, scope: !318)
!358 = !DILocation(line: 60, column: 10, scope: !318)
!359 = !DILocation(line: 0, scope: !307, inlinedAt: !360)
!360 = distinct !DILocation(line: 61, column: 9, scope: !318)
!361 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !360)
!362 = !DILocation(line: 61, column: 9, scope: !318)
!363 = distinct !DISubprogram(name: "copy_cstring", linkageName: "String_ref_copy_cstring_moo", scope: !194, file: !194, line: 145, type: !364, scopeLine: 145, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !366, retainedNodes: !367)
!364 = !DISubroutineType(types: !365)
!365 = !{!197, !197, !14}
!366 = !DISubprogram(name: "copy_cstring", linkageName: "String_ref_copy_cstring_moo", scope: !198, file: !194, line: 145, type: !364, scopeLine: 145, spFlags: 0)
!367 = !{!368, !369}
!368 = !DILocalVariable(name: "this", arg: 1, scope: !363, file: !194, line: 145, type: !206, flags: DIFlagArtificial)
!369 = !DILocalVariable(name: "i", scope: !370, file: !194, line: 158, type: !42, align: 32)
!370 = distinct !DILexicalBlock(scope: !371, file: !194, line: 158, column: 7)
!371 = distinct !DILexicalBlock(scope: !363, file: !194, line: 152, column: 5)
!372 = !DILocation(line: 0, scope: !363)
!373 = !DILocalVariable(name: "str", arg: 2, scope: !363, file: !194, line: 145, type: !14)
!374 = !DILocation(line: 152, column: 19, scope: !371)
!375 = !DILocation(line: 153, column: 13, scope: !376)
!376 = distinct !DILexicalBlock(scope: !371, file: !194, line: 153, column: 7)
!377 = !DILocation(line: 154, column: 14, scope: !376)
!378 = !DILocation(line: 155, column: 32, scope: !376)
!379 = !DILocation(line: 155, column: 12, scope: !376)
!380 = !DILocation(line: 0, scope: !307, inlinedAt: !381)
!381 = distinct !DILocation(line: 156, column: 11, scope: !376)
!382 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !381)
!383 = !DILocation(line: 0, scope: !370)
!384 = !DILocation(line: 160, column: 23, scope: !385)
!385 = distinct !DILexicalBlock(scope: !370, file: !194, line: 160, column: 7)
!386 = !DILocation(line: 161, column: 15, scope: !387)
!387 = distinct !DILexicalBlock(scope: !385, file: !194, line: 161, column: 9)
!388 = !DILocation(line: 0, scope: !54, inlinedAt: !389)
!389 = distinct !DILocation(line: 161, column: 17, scope: !390)
!390 = distinct !DILexicalBlock(scope: !385, file: !194, line: 161, column: 17)
!391 = !DILocation(line: 164, column: 13, scope: !370)
!392 = !DILocation(line: 165, column: 19, scope: !370)
!393 = !DILocation(line: 0, scope: !348, inlinedAt: !394)
!394 = distinct !DILocation(line: 165, column: 27, scope: !370)
!395 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !394)
!396 = !DILocation(line: 165, column: 14, scope: !370)
!397 = !DILocation(line: 166, column: 32, scope: !370)
!398 = !DILocation(line: 166, column: 12, scope: !370)
!399 = !DILocation(line: 168, column: 28, scope: !370)
!400 = !DILocation(line: 168, column: 19, scope: !370)
!401 = !DILocation(line: 152, column: 5, scope: !363)
!402 = distinct !DISubprogram(name: "push", linkageName: "Array_String_val_ref_push_oo", scope: !403, file: !403, line: 653, type: !404, scopeLine: 653, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !414, retainedNodes: !415)
!403 = !DIFile(filename: "<checkout>/packages/builtin/array.pony", directory: "")
!404 = !DISubroutineType(types: !405)
!405 = !{!58, !406, !197}
!406 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 32, align: 32, dwarfAddressSpace: 0)
!407 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_String_val", file: !403, line: 25, size: 128, align: 32, elements: !408, identifier: "Array_String_val")
!408 = !{!409, !410, !411}
!409 = !DIDerivedType(tag: DW_TAG_member, name: "_size", file: !403, line: 89, baseType: !42, size: 32, align: 32, offset: 32, flags: DIFlagPrivate)
!410 = !DIDerivedType(tag: DW_TAG_member, name: "_alloc", file: !403, line: 90, baseType: !42, size: 32, align: 32, offset: 64, flags: DIFlagPrivate)
!411 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !403, line: 91, baseType: !412, size: 32, align: 32, offset: 96, flags: DIFlagPrivate)
!412 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !413, size: 32, align: 32, dwarfAddressSpace: 0)
!413 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_String_val", file: !16, line: 91, elements: !4, identifier: "Pointer_String_val")
!414 = !DISubprogram(name: "push", linkageName: "Array_String_val_ref_push_oo", scope: !407, file: !403, line: 653, type: !404, scopeLine: 653, spFlags: 0)
!415 = !{!416}
!416 = !DILocalVariable(name: "this", arg: 1, scope: !402, file: !403, line: 653, type: !417, flags: DIFlagArtificial)
!417 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !407, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!418 = !DILocation(line: 0, scope: !402)
!419 = !DILocalVariable(name: "value", arg: 2, scope: !402, file: !403, line: 653, type: !197)
!420 = !DILocation(line: 657, column: 19, scope: !402)
!421 = !DILocation(line: 657, column: 12, scope: !402)
!422 = !DILocation(line: 658, column: 17, scope: !402)
!423 = !DILocation(line: 659, column: 19, scope: !402)
!424 = !DILocation(line: 659, column: 11, scope: !402)
!425 = !DILocation(line: 0, scope: !54, inlinedAt: !426)
!426 = distinct !DILocation(line: 654, column: 5, scope: !402)
!427 = !DILocation(line: 654, column: 5, scope: !402)
!428 = distinct !DISubprogram(name: "reserve", linkageName: "Array_String_val_ref_reserve_Zo", scope: !403, file: !403, line: 178, type: !429, scopeLine: 178, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !431, retainedNodes: !432)
!429 = !DISubroutineType(types: !430)
!430 = !{!58, !406, !42}
!431 = !DISubprogram(name: "reserve", linkageName: "Array_String_val_ref_reserve_Zo", scope: !407, file: !403, line: 178, type: !429, scopeLine: 178, spFlags: 0)
!432 = !{!433}
!433 = !DILocalVariable(name: "this", arg: 1, scope: !428, file: !403, line: 178, type: !417, flags: DIFlagArtificial)
!434 = !DILocation(line: 0, scope: !428)
!435 = !DILocalVariable(name: "len", arg: 2, scope: !428, file: !403, line: 178, type: !42)
!436 = !DILocation(line: 185, column: 15, scope: !437)
!437 = distinct !DILexicalBlock(scope: !428, file: !403, line: 185, column: 5)
!438 = !DILocalVariable(name: "this", arg: 1, scope: !439, file: !98, line: 497, type: !333, flags: DIFlagArtificial)
!439 = distinct !DISubprogram(name: "next_pow2", linkageName: "USize_val_next_pow2_Z", scope: !98, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !440, retainedNodes: !441)
!440 = !DISubprogram(name: "next_pow2", linkageName: "USize_val_next_pow2_Z", scope: !42, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: 0)
!441 = !{!438, !442}
!442 = !DILocalVariable(name: "x", scope: !439, file: !98, line: 498, type: !42, align: 32)
!443 = !DILocation(line: 0, scope: !439, inlinedAt: !444)
!444 = distinct !DILocation(line: 186, column: 29, scope: !445)
!445 = distinct !DILexicalBlock(scope: !437, file: !403, line: 186, column: 7)
!446 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !444)
!447 = !DILocalVariable(name: "this", arg: 1, scope: !448, file: !98, line: 524, type: !333, flags: DIFlagArtificial)
!448 = distinct !DISubprogram(name: "clz", linkageName: "USize_val_clz_Z", scope: !98, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !449, retainedNodes: !450)
!449 = !DISubprogram(name: "clz", linkageName: "USize_val_clz_Z", scope: !42, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: 0)
!450 = !{!447}
!451 = !DILocation(line: 0, scope: !448, inlinedAt: !452)
!452 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !444)
!453 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !452)
!454 = distinct !DILexicalBlock(scope: !455, file: !98, line: 526, column: 7)
!455 = distinct !DILexicalBlock(scope: !448, file: !98, line: 525, column: 5)
!456 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !452)
!457 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !452)
!458 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !444)
!459 = distinct !DILexicalBlock(scope: !439, file: !98, line: 499, column: 11)
!460 = !DILocalVariable(name: "this", arg: 1, scope: !461, file: !98, line: 560, type: !333, flags: DIFlagArtificial)
!461 = distinct !DISubprogram(name: "bitwidth", linkageName: "USize_val_bitwidth_Z", scope: !98, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !462, retainedNodes: !463)
!462 = !DISubprogram(name: "bitwidth", linkageName: "USize_val_bitwidth_Z", scope: !42, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: 0)
!463 = !{!460}
!464 = !DILocation(line: 0, scope: !461, inlinedAt: !465)
!465 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !444)
!466 = distinct !DILexicalBlock(scope: !459, file: !98, line: 499, column: 33)
!467 = !DILocation(line: 0, scope: !348, inlinedAt: !468)
!468 = distinct !DILocation(line: 186, column: 35, scope: !445)
!469 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !468)
!470 = !DILocation(line: 0, scope: !348, inlinedAt: !471)
!471 = distinct !DILocation(line: 186, column: 44, scope: !445)
!472 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !471)
!473 = !DILocation(line: 0, scope: !348, inlinedAt: !474)
!474 = distinct !DILocation(line: 186, column: 51, scope: !445)
!475 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !474)
!476 = !DILocation(line: 186, column: 14, scope: !445)
!477 = !DILocation(line: 187, column: 27, scope: !445)
!478 = !DILocation(line: 187, column: 12, scope: !445)
!479 = !DILocation(line: 0, scope: !54, inlinedAt: !480)
!480 = distinct !DILocation(line: 187, column: 41, scope: !481)
!481 = distinct !DILexicalBlock(scope: !437, file: !403, line: 187, column: 41)
!482 = !DILocation(line: 0, scope: !54, inlinedAt: !483)
!483 = distinct !DILocation(line: 179, column: 5, scope: !428)
!484 = !DILocation(line: 179, column: 5, scope: !428)
!485 = distinct !DISubprogram(name: "create", linkageName: "Array_String_val_ref_create_pZo", scope: !403, file: !403, line: 93, type: !486, scopeLine: 93, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !488, retainedNodes: !489)
!486 = !DISubroutineType(types: !487)
!487 = !{!406, !406, !42}
!488 = !DISubprogram(name: "create", linkageName: "Array_String_val_ref_create_pZo", scope: !407, file: !403, line: 93, type: !486, scopeLine: 93, spFlags: 0)
!489 = !{!490}
!490 = !DILocalVariable(name: "this", arg: 1, scope: !485, file: !403, line: 93, type: !417, flags: DIFlagArtificial)
!491 = !DILocation(line: 0, scope: !485)
!492 = !DILocalVariable(name: "len", arg: 2, scope: !485, file: !403, line: 93, type: !42)
!493 = !DILocation(line: 97, column: 11, scope: !485)
!494 = !DILocation(line: 99, column: 12, scope: !495)
!495 = distinct !DILexicalBlock(scope: !485, file: !403, line: 99, column: 5)
!496 = !DILocation(line: 0, scope: !439, inlinedAt: !497)
!497 = distinct !DILocation(line: 100, column: 29, scope: !498)
!498 = distinct !DILexicalBlock(scope: !495, file: !403, line: 100, column: 7)
!499 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !497)
!500 = !DILocation(line: 0, scope: !448, inlinedAt: !501)
!501 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !497)
!502 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !501)
!503 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !501)
!504 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !501)
!505 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !497)
!506 = !DILocation(line: 0, scope: !461, inlinedAt: !507)
!507 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !497)
!508 = !DILocation(line: 0, scope: !348, inlinedAt: !509)
!509 = distinct !DILocation(line: 100, column: 35, scope: !498)
!510 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !509)
!511 = !DILocation(line: 0, scope: !348, inlinedAt: !512)
!512 = distinct !DILocation(line: 100, column: 44, scope: !498)
!513 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !512)
!514 = !DILocation(line: 0, scope: !348, inlinedAt: !515)
!515 = distinct !DILocation(line: 100, column: 51, scope: !498)
!516 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !515)
!517 = !DILocation(line: 100, column: 14, scope: !498)
!518 = !DILocation(line: 101, column: 31, scope: !498)
!519 = !DILocation(line: 101, column: 12, scope: !498)
!520 = !DILocation(line: 103, column: 14, scope: !521)
!521 = distinct !DILexicalBlock(scope: !495, file: !403, line: 103, column: 7)
!522 = !DILocation(line: 104, column: 12, scope: !521)
!523 = !DILocation(line: 99, column: 5, scope: !485)
!524 = distinct !DISubprogram(name: "op_not", linkageName: "Bool_box_op_not_b", scope: !525, file: !525, line: 9, type: !526, scopeLine: 9, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !528, retainedNodes: !529)
!525 = !DIFile(filename: "<checkout>/packages/builtin/bool.pony", directory: "")
!526 = !DISubroutineType(types: !527)
!527 = !{!47, !47}
!528 = !DISubprogram(name: "op_not", linkageName: "Bool_box_op_not_b", scope: !47, file: !525, line: 9, type: !526, scopeLine: 9, spFlags: 0)
!529 = !{!530}
!530 = !DILocalVariable(name: "this", arg: 1, scope: !524, file: !525, line: 9, type: !531, flags: DIFlagArtificial)
!531 = !DIBasicType(name: "Bool", size: 8, encoding: DW_ATE_boolean, flags: DIFlagArtificial)
!532 = !DILocation(line: 0, scope: !524)
!533 = !DILocation(line: 9, column: 25, scope: !524)
!534 = distinct !DISubprogram(name: "op_not", linkageName: "Bool_val_op_not_b", scope: !525, file: !525, line: 9, type: !526, scopeLine: 9, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !535, retainedNodes: !536)
!535 = !DISubprogram(name: "op_not", linkageName: "Bool_val_op_not_b", scope: !47, file: !525, line: 9, type: !526, scopeLine: 9, spFlags: 0)
!536 = !{!537}
!537 = !DILocalVariable(name: "this", arg: 1, scope: !534, file: !525, line: 9, type: !531, flags: DIFlagArtificial)
!538 = !DILocation(line: 0, scope: !534)
!539 = !DILocation(line: 9, column: 25, scope: !534)
!540 = distinct !DISubprogram(name: "create", linkageName: "Bool_val_create_pbb", scope: !525, file: !525, line: 2, type: !541, scopeLine: 2, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !543, retainedNodes: !544)
!541 = !DISubroutineType(types: !542)
!542 = !{!47, !47, !47}
!543 = !DISubprogram(name: "create", linkageName: "Bool_val_create_pbb", scope: !47, file: !525, line: 2, type: !541, scopeLine: 2, spFlags: 0)
!544 = !{!545}
!545 = !DILocalVariable(name: "this", arg: 1, scope: !540, file: !525, line: 2, type: !531, flags: DIFlagArtificial)
!546 = !DILocation(line: 0, scope: !540)
!547 = !DILocalVariable(name: "from", arg: 2, scope: !540, file: !525, line: 2, type: !47)
!548 = !DILocation(line: 2, column: 29, scope: !540)
!549 = distinct !DISubprogram(name: "op_and", linkageName: "Bool_box_op_and_bb", scope: !525, file: !525, line: 6, type: !541, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !550, retainedNodes: !551)
!550 = !DISubprogram(name: "op_and", linkageName: "Bool_box_op_and_bb", scope: !47, file: !525, line: 6, type: !541, scopeLine: 6, spFlags: 0)
!551 = !{!552}
!552 = !DILocalVariable(name: "this", arg: 1, scope: !549, file: !525, line: 6, type: !531, flags: DIFlagArtificial)
!553 = !DILocation(line: 0, scope: !549)
!554 = !DILocalVariable(name: "y", arg: 2, scope: !549, file: !525, line: 6, type: !47)
!555 = !DILocation(line: 6, column: 37, scope: !549)
!556 = distinct !DISubprogram(name: "op_and", linkageName: "Bool_val_op_and_bb", scope: !525, file: !525, line: 6, type: !541, scopeLine: 6, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !557, retainedNodes: !558)
!557 = !DISubprogram(name: "op_and", linkageName: "Bool_val_op_and_bb", scope: !47, file: !525, line: 6, type: !541, scopeLine: 6, spFlags: 0)
!558 = !{!559}
!559 = !DILocalVariable(name: "this", arg: 1, scope: !556, file: !525, line: 6, type: !531, flags: DIFlagArtificial)
!560 = !DILocation(line: 0, scope: !556)
!561 = !DILocalVariable(name: "y", arg: 2, scope: !556, file: !525, line: 6, type: !47)
!562 = !DILocation(line: 6, column: 37, scope: !556)
!563 = distinct !DISubprogram(name: "_read", linkageName: "Stdin_ref__read_b", scope: !32, file: !32, line: 149, type: !564, scopeLine: 149, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !566, retainedNodes: !567)
!564 = !DISubroutineType(types: !565)
!565 = !{!47, !35}
!566 = !DISubprogram(name: "_read", linkageName: "Stdin_ref__read_b", scope: !36, file: !32, line: 149, type: !564, scopeLine: 149, spFlags: 0)
!567 = !{!568, !569, !575, !576, !577, !580, !585}
!568 = !DILocalVariable(name: "this", arg: 1, scope: !563, file: !32, line: 149, type: !50, flags: DIFlagArtificial)
!569 = !DILocalVariable(name: "$0$15", scope: !570, file: !32, line: 155, type: !573, align: 32)
!570 = distinct !DILexicalBlock(scope: !571, file: !32, line: 155, column: 28)
!571 = distinct !DILexicalBlock(scope: !572, file: !32, line: 155, column: 28)
!572 = distinct !DILexicalBlock(scope: !563, file: !32, line: 155, column: 7)
!573 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !574, size: 32, align: 32, dwarfAddressSpace: 0)
!574 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputNotify", file: !32, line: 69, elements: !4, identifier: "InputNotify")
!575 = !DILocalVariable(name: "notify", scope: !572, file: !32, line: 155, type: !573, align: 32)
!576 = !DILocalVariable(name: "sum", scope: !572, file: !32, line: 156, type: !42, align: 32)
!577 = !DILocalVariable(name: "chunk_size", scope: !578, file: !32, line: 159, type: !42, align: 32)
!578 = distinct !DILexicalBlock(scope: !579, file: !32, line: 159, column: 9)
!579 = distinct !DILexicalBlock(scope: !572, file: !32, line: 158, column: 7)
!580 = !DILocalVariable(name: "data", scope: !578, file: !32, line: 160, type: !581, align: 32)
!581 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !582, size: 32, align: 32, dwarfAddressSpace: 0)
!582 = !DICompositeType(tag: DW_TAG_structure_type, name: "Array_U8_val", file: !403, line: 11, size: 128, align: 32, elements: !583, identifier: "Array_U8_val")
!583 = !{!409, !410, !584}
!584 = !DIDerivedType(tag: DW_TAG_member, name: "_ptr", file: !403, line: 91, baseType: !14, size: 32, align: 32, offset: 96, flags: DIFlagPrivate)
!585 = !DILocalVariable(name: "len", scope: !578, file: !32, line: 162, type: !42, align: 32)
!586 = !DILocation(line: 0, scope: !563)
!587 = !DILocation(line: 0, scope: !570)
!588 = !DILocation(line: 155, column: 28, scope: !589)
!589 = distinct !DILexicalBlock(scope: !590, file: !32, line: 155, column: 28)
!590 = distinct !DILexicalBlock(scope: !571, file: !32, line: 155, column: 28)
!591 = !DILocation(line: 0, scope: !572)
!592 = !DILocation(line: 0, scope: !578)
!593 = !DILocalVariable(name: "this", arg: 1, scope: !594, file: !403, line: 93, type: !599, flags: DIFlagArtificial)
!594 = distinct !DISubprogram(name: "create", linkageName: "Array_U8_val_ref_create_pZo", scope: !403, file: !403, line: 93, type: !595, scopeLine: 93, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !597, retainedNodes: !598)
!595 = !DISubroutineType(types: !596)
!596 = !{!581, !581, !42}
!597 = !DISubprogram(name: "create", linkageName: "Array_U8_val_ref_create_pZo", scope: !582, file: !403, line: 93, type: !595, scopeLine: 93, spFlags: 0)
!598 = !{!593}
!599 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !582, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!600 = !DILocation(line: 0, scope: !594, inlinedAt: !601)
!601 = distinct !DILocation(line: 160, column: 38, scope: !602)
!602 = distinct !DILexicalBlock(scope: !578, file: !32, line: 160, column: 28)
!603 = !DILocalVariable(name: "len", arg: 2, scope: !594, file: !403, line: 93, type: !42)
!604 = !DILocation(line: 97, column: 11, scope: !594, inlinedAt: !601)
!605 = !DILocation(line: 103, column: 14, scope: !606, inlinedAt: !601)
!606 = distinct !DILexicalBlock(scope: !607, file: !403, line: 103, column: 7)
!607 = distinct !DILexicalBlock(scope: !594, file: !403, line: 99, column: 5)
!608 = !DILocation(line: 104, column: 12, scope: !606, inlinedAt: !601)
!609 = !DILocalVariable(name: "this", arg: 1, scope: !610, file: !403, line: 214, type: !599, flags: DIFlagArtificial)
!610 = distinct !DISubprogram(name: "undefined", linkageName: "Array_U8_val_ref_undefined_U8_val_Zo", scope: !403, file: !403, line: 214, type: !611, scopeLine: 214, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !613, retainedNodes: !614)
!611 = !DISubroutineType(types: !612)
!612 = !{!58, !581, !42}
!613 = !DISubprogram(name: "undefined", linkageName: "Array_U8_val_ref_undefined_U8_val_Zo", scope: !582, file: !403, line: 214, type: !611, scopeLine: 214, spFlags: 0)
!614 = !{!609}
!615 = !DILocation(line: 0, scope: !610, inlinedAt: !616)
!616 = distinct !DILocation(line: 160, column: 50, scope: !602)
!617 = !DILocalVariable(name: "len", arg: 2, scope: !610, file: !403, line: 214, type: !42)
!618 = !DILocalVariable(name: "this", arg: 1, scope: !619, file: !403, line: 178, type: !599, flags: DIFlagArtificial)
!619 = distinct !DISubprogram(name: "reserve", linkageName: "Array_U8_val_ref_reserve_Zo", scope: !403, file: !403, line: 178, type: !611, scopeLine: 178, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !620, retainedNodes: !621)
!620 = !DISubprogram(name: "reserve", linkageName: "Array_U8_val_ref_reserve_Zo", scope: !582, file: !403, line: 178, type: !611, scopeLine: 178, spFlags: 0)
!621 = !{!618}
!622 = !DILocation(line: 0, scope: !619, inlinedAt: !623)
!623 = distinct !DILocation(line: 219, column: 12, scope: !610, inlinedAt: !616)
!624 = !DILocalVariable(name: "len", arg: 2, scope: !619, file: !403, line: 178, type: !42)
!625 = !DILocation(line: 185, column: 15, scope: !626, inlinedAt: !623)
!626 = distinct !DILexicalBlock(scope: !619, file: !403, line: 185, column: 5)
!627 = !DILocation(line: 0, scope: !439, inlinedAt: !628)
!628 = distinct !DILocation(line: 186, column: 29, scope: !629, inlinedAt: !623)
!629 = distinct !DILexicalBlock(scope: !626, file: !403, line: 186, column: 7)
!630 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !628)
!631 = !DILocation(line: 0, scope: !448, inlinedAt: !632)
!632 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !628)
!633 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !632)
!634 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !632)
!635 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !632)
!636 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !628)
!637 = !DILocation(line: 0, scope: !461, inlinedAt: !638)
!638 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !628)
!639 = !DILocation(line: 0, scope: !348, inlinedAt: !640)
!640 = distinct !DILocation(line: 186, column: 35, scope: !629, inlinedAt: !623)
!641 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !640)
!642 = !DILocation(line: 0, scope: !348, inlinedAt: !643)
!643 = distinct !DILocation(line: 186, column: 44, scope: !629, inlinedAt: !623)
!644 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !643)
!645 = !DILocation(line: 0, scope: !348, inlinedAt: !646)
!646 = distinct !DILocation(line: 186, column: 51, scope: !629, inlinedAt: !623)
!647 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !646)
!648 = !DILocation(line: 186, column: 14, scope: !629, inlinedAt: !623)
!649 = !DILocation(line: 187, column: 27, scope: !629, inlinedAt: !623)
!650 = !DILocation(line: 187, column: 12, scope: !629, inlinedAt: !623)
!651 = !DILocation(line: 0, scope: !54, inlinedAt: !652)
!652 = distinct !DILocation(line: 187, column: 41, scope: !653, inlinedAt: !623)
!653 = distinct !DILexicalBlock(scope: !626, file: !403, line: 187, column: 41)
!654 = !DILocation(line: 0, scope: !54, inlinedAt: !655)
!655 = distinct !DILocation(line: 179, column: 5, scope: !619, inlinedAt: !623)
!656 = !DILocation(line: 220, column: 11, scope: !610, inlinedAt: !616)
!657 = !DILocation(line: 0, scope: !54, inlinedAt: !658)
!658 = distinct !DILocation(line: 215, column: 5, scope: !610, inlinedAt: !616)
!659 = !DILocalVariable(name: "this", arg: 1, scope: !660, file: !403, line: 160, type: !599, flags: DIFlagArtificial)
!660 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_ref_cpointer_Zo", scope: !403, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !663, retainedNodes: !664)
!661 = !DISubroutineType(types: !662)
!662 = !{!14, !581, !42}
!663 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_ref_cpointer_Zo", scope: !582, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: 0)
!664 = !{!659}
!665 = !DILocation(line: 0, scope: !660, inlinedAt: !666)
!666 = distinct !DILocation(line: 162, column: 52, scope: !578)
!667 = !DILocalVariable(name: "offset", arg: 2, scope: !660, file: !403, line: 160, type: !42)
!668 = !DILocalVariable(name: "this", arg: 1, scope: !669, file: !403, line: 166, type: !599, flags: DIFlagArtificial)
!669 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_ref_size_Z", scope: !403, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !672, retainedNodes: !673)
!670 = !DISubroutineType(types: !671)
!671 = !{!42, !581}
!672 = !DISubprogram(name: "size", linkageName: "Array_U8_val_ref_size_Z", scope: !582, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: 0)
!673 = !{!668}
!674 = !DILocation(line: 0, scope: !669, inlinedAt: !675)
!675 = distinct !DILocation(line: 162, column: 65, scope: !578)
!676 = !DILocation(line: 162, column: 19, scope: !578)
!677 = !DILocation(line: 0, scope: !54, inlinedAt: !678)
!678 = distinct !DILocation(line: 204, column: 7, scope: !679)
!679 = distinct !DILexicalBlock(scope: !680, file: !32, line: 204, column: 7)
!680 = distinct !DILexicalBlock(scope: !681, file: !32, line: 165, column: 9)
!681 = distinct !DILexicalBlock(scope: !578, file: !32, line: 164, column: 9)
!682 = !DILocation(line: 166, column: 11, scope: !680)
!683 = !DILocalVariable(name: "this", arg: 1, scope: !684, file: !32, line: 207, type: !50, flags: DIFlagArtificial)
!684 = distinct !DISubprogram(name: "_close_event", linkageName: "Stdin_ref__close_event_o", scope: !32, file: !32, line: 207, type: !91, scopeLine: 207, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !685, retainedNodes: !686)
!685 = !DISubprogram(name: "_close_event", linkageName: "Stdin_ref__close_event_o", scope: !36, file: !32, line: 207, type: !91, scopeLine: 207, spFlags: 0)
!686 = !{!683}
!687 = !DILocation(line: 0, scope: !684, inlinedAt: !688)
!688 = distinct !DILocation(line: 168, column: 23, scope: !689)
!689 = distinct !DILexicalBlock(scope: !681, file: !32, line: 167, column: 9)
!690 = !DILocation(line: 211, column: 10, scope: !691, inlinedAt: !688)
!691 = distinct !DILexicalBlock(scope: !684, file: !32, line: 211, column: 7)
!692 = !DILocation(line: 211, column: 28, scope: !691, inlinedAt: !688)
!693 = !DILocation(line: 212, column: 9, scope: !694, inlinedAt: !688)
!694 = distinct !DILexicalBlock(scope: !691, file: !32, line: 212, column: 9)
!695 = !DILocation(line: 0, scope: !68, inlinedAt: !696)
!696 = distinct !DILocation(line: 213, column: 27, scope: !694, inlinedAt: !688)
!697 = !DILocation(line: 0, scope: !80, inlinedAt: !698)
!698 = distinct !DILocation(line: 213, column: 32, scope: !694, inlinedAt: !688)
!699 = !DILocation(line: 213, column: 16, scope: !694, inlinedAt: !688)
!700 = !DILocation(line: 0, scope: !54, inlinedAt: !701)
!701 = distinct !DILocation(line: 213, column: 33, scope: !702, inlinedAt: !688)
!702 = distinct !DILexicalBlock(scope: !691, file: !32, line: 213, column: 33)
!703 = !DILocation(line: 0, scope: !54, inlinedAt: !704)
!704 = distinct !DILocation(line: 208, column: 7, scope: !684, inlinedAt: !688)
!705 = !DILocation(line: 169, column: 25, scope: !689)
!706 = !DILocation(line: 0, scope: !54, inlinedAt: !707)
!707 = distinct !DILocation(line: 170, column: 21, scope: !689)
!708 = !DILocation(line: 170, column: 19, scope: !689)
!709 = !DILocation(line: 0, scope: !54, inlinedAt: !710)
!710 = distinct !DILocation(line: 204, column: 7, scope: !711)
!711 = distinct !DILexicalBlock(scope: !689, file: !32, line: 204, column: 7)
!712 = !DILocation(line: 171, column: 11, scope: !689)
!713 = !DILocation(line: 0, scope: !684, inlinedAt: !714)
!714 = distinct !DILocation(line: 173, column: 23, scope: !715)
!715 = distinct !DILexicalBlock(scope: !681, file: !32, line: 172, column: 9)
!716 = !DILocation(line: 211, column: 10, scope: !691, inlinedAt: !714)
!717 = !DILocation(line: 211, column: 28, scope: !691, inlinedAt: !714)
!718 = !DILocation(line: 212, column: 9, scope: !694, inlinedAt: !714)
!719 = !DILocation(line: 0, scope: !68, inlinedAt: !720)
!720 = distinct !DILocation(line: 213, column: 27, scope: !694, inlinedAt: !714)
!721 = !DILocation(line: 0, scope: !80, inlinedAt: !722)
!722 = distinct !DILocation(line: 213, column: 32, scope: !694, inlinedAt: !714)
!723 = !DILocation(line: 213, column: 16, scope: !694, inlinedAt: !714)
!724 = !DILocation(line: 0, scope: !54, inlinedAt: !725)
!725 = distinct !DILocation(line: 213, column: 33, scope: !702, inlinedAt: !714)
!726 = !DILocation(line: 0, scope: !54, inlinedAt: !727)
!727 = distinct !DILocation(line: 208, column: 7, scope: !684, inlinedAt: !714)
!728 = !DILocation(line: 174, column: 29, scope: !715)
!729 = !DILocation(line: 175, column: 25, scope: !715)
!730 = !DILocation(line: 0, scope: !54, inlinedAt: !731)
!731 = distinct !DILocation(line: 176, column: 21, scope: !715)
!732 = !DILocation(line: 176, column: 19, scope: !715)
!733 = !DILocation(line: 0, scope: !54, inlinedAt: !734)
!734 = distinct !DILocation(line: 204, column: 7, scope: !735)
!735 = distinct !DILexicalBlock(scope: !715, file: !32, line: 204, column: 7)
!736 = !DILocation(line: 177, column: 11, scope: !715)
!737 = !DILocation(line: 0, scope: !54, inlinedAt: !738)
!738 = distinct !DILocation(line: 177, column: 18, scope: !739)
!739 = distinct !DILexicalBlock(scope: !740, file: !32, line: 177, column: 18)
!740 = distinct !DILexicalBlock(scope: !681, file: !32, line: 177, column: 18)
!741 = !DILocalVariable(name: "this", arg: 1, scope: !742, file: !403, line: 391, type: !599, flags: DIFlagArtificial)
!742 = distinct !DISubprogram(name: "truncate", linkageName: "Array_U8_val_ref_truncate_Zo", scope: !403, file: !403, line: 391, type: !611, scopeLine: 391, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !743, retainedNodes: !744)
!743 = !DISubprogram(name: "truncate", linkageName: "Array_U8_val_ref_truncate_Zo", scope: !582, file: !403, line: 391, type: !611, scopeLine: 391, spFlags: 0)
!744 = !{!741}
!745 = !DILocation(line: 0, scope: !742, inlinedAt: !746)
!746 = distinct !DILocation(line: 180, column: 22, scope: !578)
!747 = !DILocalVariable(name: "len", arg: 2, scope: !742, file: !403, line: 391, type: !42)
!748 = !DILocation(line: 0, scope: !337, inlinedAt: !749)
!749 = distinct !DILocation(line: 396, column: 22, scope: !742, inlinedAt: !746)
!750 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !749)
!751 = !DILocation(line: 396, column: 11, scope: !742, inlinedAt: !746)
!752 = !DILocation(line: 0, scope: !54, inlinedAt: !753)
!753 = distinct !DILocation(line: 392, column: 5, scope: !742, inlinedAt: !746)
!754 = !DILocation(line: 181, column: 15, scope: !578)
!755 = !DILocation(line: 0, scope: !54, inlinedAt: !756)
!756 = distinct !DILocation(line: 187, column: 11, scope: !757)
!757 = distinct !DILexicalBlock(scope: !758, file: !32, line: 187, column: 11)
!758 = distinct !DILexicalBlock(scope: !578, file: !32, line: 183, column: 9)
!759 = !DILocation(line: 190, column: 19, scope: !578)
!760 = !DILocation(line: 194, column: 24, scope: !761)
!761 = distinct !DILexicalBlock(scope: !762, file: !32, line: 194, column: 13)
!762 = distinct !DILexicalBlock(scope: !763, file: !32, line: 193, column: 11)
!763 = distinct !DILexicalBlock(scope: !764, file: !32, line: 193, column: 11)
!764 = distinct !DILexicalBlock(scope: !578, file: !32, line: 192, column: 9)
!765 = !DILocation(line: 0, scope: !54, inlinedAt: !766)
!766 = distinct !DILocation(line: 194, column: 25, scope: !767)
!767 = distinct !DILexicalBlock(scope: !762, file: !32, line: 194, column: 25)
!768 = !DILocation(line: 197, column: 11, scope: !763)
!769 = !DILocation(line: 0, scope: !54, inlinedAt: !770)
!770 = distinct !DILocation(line: 197, column: 11, scope: !771)
!771 = distinct !DILexicalBlock(scope: !764, file: !32, line: 197, column: 11)
!772 = !DILocation(line: 0, scope: !54, inlinedAt: !773)
!773 = distinct !DILocation(line: 198, column: 9, scope: !774)
!774 = distinct !DILexicalBlock(scope: !579, file: !32, line: 198, column: 9)
!775 = !DILocation(line: 0, scope: !54, inlinedAt: !776)
!776 = distinct !DILocation(line: 204, column: 7, scope: !777)
!777 = distinct !DILexicalBlock(scope: !563, file: !32, line: 204, column: 7)
!778 = !DILocation(line: 0, scope: !684, inlinedAt: !779)
!779 = distinct !DILocation(line: 203, column: 19, scope: !780)
!780 = distinct !DILexicalBlock(scope: !563, file: !32, line: 203, column: 7)
!781 = !DILocation(line: 211, column: 10, scope: !691, inlinedAt: !779)
!782 = !DILocation(line: 211, column: 28, scope: !691, inlinedAt: !779)
!783 = !DILocation(line: 212, column: 9, scope: !694, inlinedAt: !779)
!784 = !DILocation(line: 0, scope: !68, inlinedAt: !785)
!785 = distinct !DILocation(line: 213, column: 27, scope: !694, inlinedAt: !779)
!786 = !DILocation(line: 0, scope: !80, inlinedAt: !787)
!787 = distinct !DILocation(line: 213, column: 32, scope: !694, inlinedAt: !779)
!788 = !DILocation(line: 213, column: 16, scope: !694, inlinedAt: !779)
!789 = !DILocation(line: 0, scope: !54, inlinedAt: !790)
!790 = distinct !DILocation(line: 213, column: 33, scope: !702, inlinedAt: !779)
!791 = !DILocation(line: 0, scope: !54, inlinedAt: !792)
!792 = distinct !DILocation(line: 208, column: 7, scope: !684, inlinedAt: !779)
!793 = !DILocation(line: 0, scope: !54, inlinedAt: !794)
!794 = distinct !DILocation(line: 204, column: 7, scope: !795)
!795 = distinct !DILexicalBlock(scope: !563, file: !32, line: 204, column: 7)
!796 = !DILocation(line: 154, column: 5, scope: !563)
!797 = !DILocation(line: 0, scope: !684)
!798 = !DILocation(line: 211, column: 10, scope: !691)
!799 = !DILocation(line: 211, column: 28, scope: !691)
!800 = !DILocation(line: 212, column: 9, scope: !694)
!801 = !DILocation(line: 0, scope: !68, inlinedAt: !802)
!802 = distinct !DILocation(line: 213, column: 27, scope: !694)
!803 = !DILocation(line: 0, scope: !80, inlinedAt: !804)
!804 = distinct !DILocation(line: 213, column: 32, scope: !694)
!805 = !DILocation(line: 213, column: 16, scope: !694)
!806 = !DILocation(line: 0, scope: !54, inlinedAt: !807)
!807 = distinct !DILocation(line: 213, column: 33, scope: !702)
!808 = !DILocation(line: 0, scope: !54, inlinedAt: !809)
!809 = distinct !DILocation(line: 208, column: 7, scope: !684)
!810 = !DILocation(line: 208, column: 7, scope: !684)
!811 = distinct !DISubprogram(name: "_event_notify", linkageName: "Stdin_tag__event_notify_topIpIo", scope: !32, file: !32, line: 125, type: !812, scopeLine: 125, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !814, retainedNodes: !815)
!812 = !DISubroutineType(types: !813)
!813 = !{!58, !35, !44, !101, !101}
!814 = !DISubprogram(name: "_event_notify", linkageName: "Stdin_tag__event_notify_topIpIo", scope: !36, file: !32, line: 125, type: !812, scopeLine: 125, spFlags: 0)
!815 = !{!816, !817, !824}
!816 = !DILocalVariable(name: "this", arg: 1, scope: !811, file: !32, line: 125, type: !50, flags: DIFlagArtificial)
!817 = !DILocalVariable(name: "$0$14", scope: !818, file: !32, line: 134, type: !573, align: 32)
!818 = distinct !DILexicalBlock(scope: !819, file: !32, line: 134, column: 30)
!819 = distinct !DILexicalBlock(scope: !820, file: !32, line: 134, column: 30)
!820 = distinct !DILexicalBlock(scope: !821, file: !32, line: 134, column: 9)
!821 = distinct !DILexicalBlock(scope: !822, file: !32, line: 132, column: 7)
!822 = distinct !DILexicalBlock(scope: !823, file: !32, line: 131, column: 5)
!823 = distinct !DILexicalBlock(scope: !811, file: !32, line: 129, column: 5)
!824 = !DILocalVariable(name: "notify", scope: !820, file: !32, line: 134, type: !573, align: 32)
!825 = !DILocation(line: 0, scope: !811)
!826 = !DILocalVariable(name: "event", arg: 2, scope: !811, file: !32, line: 125, type: !44)
!827 = !DILocalVariable(name: "flags", arg: 3, scope: !811, file: !32, line: 125, type: !101)
!828 = !DILocalVariable(name: "arg", arg: 4, scope: !811, file: !32, line: 125, type: !101)
!829 = !DILocation(line: 0, scope: !68, inlinedAt: !830)
!830 = distinct !DILocation(line: 129, column: 17, scope: !823)
!831 = !DILocalVariable(name: "this", arg: 1, scope: !832, file: !69, line: 28, type: !76, flags: DIFlagArtificial)
!832 = distinct !DISubprogram(name: "disposable", linkageName: "AsioEvent_val_disposable_Ib", scope: !69, file: !69, line: 28, type: !833, scopeLine: 28, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !835, retainedNodes: !836)
!833 = !DISubroutineType(types: !834)
!834 = !{!47, !72, !101}
!835 = !DISubprogram(name: "disposable", linkageName: "AsioEvent_val_disposable_Ib", scope: !73, file: !69, line: 28, type: !833, scopeLine: 28, spFlags: 0)
!836 = !{!831}
!837 = !DILocation(line: 0, scope: !832, inlinedAt: !838)
!838 = distinct !DILocation(line: 129, column: 28, scope: !823)
!839 = !DILocalVariable(name: "flags", arg: 2, scope: !832, file: !69, line: 28, type: !101)
!840 = !DILocation(line: 32, column: 11, scope: !832, inlinedAt: !838)
!841 = !DILocation(line: 130, column: 7, scope: !842)
!842 = distinct !DILexicalBlock(scope: !823, file: !32, line: 130, column: 7)
!843 = !DILocation(line: 131, column: 30, scope: !822)
!844 = !DILocation(line: 131, column: 20, scope: !822)
!845 = !DILocation(line: 0, scope: !68, inlinedAt: !846)
!846 = distinct !DILocation(line: 131, column: 43, scope: !822)
!847 = !DILocalVariable(name: "this", arg: 1, scope: !848, file: !69, line: 34, type: !76, flags: DIFlagArtificial)
!848 = distinct !DISubprogram(name: "errored", linkageName: "AsioEvent_val_errored_Ib", scope: !69, file: !69, line: 34, type: !833, scopeLine: 34, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !849, retainedNodes: !850)
!849 = !DISubprogram(name: "errored", linkageName: "AsioEvent_val_errored_Ib", scope: !73, file: !69, line: 34, type: !833, scopeLine: 34, spFlags: 0)
!850 = !{!847}
!851 = !DILocation(line: 0, scope: !848, inlinedAt: !852)
!852 = distinct !DILocation(line: 131, column: 51, scope: !822)
!853 = !DILocalVariable(name: "flags", arg: 2, scope: !848, file: !69, line: 34, type: !101)
!854 = !DILocation(line: 0, scope: !684, inlinedAt: !855)
!855 = distinct !DILocation(line: 132, column: 19, scope: !821)
!856 = !DILocation(line: 211, column: 10, scope: !691, inlinedAt: !855)
!857 = !DILocation(line: 211, column: 28, scope: !691, inlinedAt: !855)
!858 = !DILocation(line: 212, column: 9, scope: !694, inlinedAt: !855)
!859 = !DILocation(line: 0, scope: !68, inlinedAt: !860)
!860 = distinct !DILocation(line: 213, column: 27, scope: !694, inlinedAt: !855)
!861 = !DILocation(line: 0, scope: !80, inlinedAt: !862)
!862 = distinct !DILocation(line: 213, column: 32, scope: !694, inlinedAt: !855)
!863 = !DILocation(line: 213, column: 16, scope: !694, inlinedAt: !855)
!864 = !DILocation(line: 0, scope: !54, inlinedAt: !865)
!865 = distinct !DILocation(line: 213, column: 33, scope: !702, inlinedAt: !855)
!866 = !DILocation(line: 0, scope: !54, inlinedAt: !867)
!867 = distinct !DILocation(line: 208, column: 7, scope: !684, inlinedAt: !855)
!868 = !DILocation(line: 0, scope: !818)
!869 = !DILocation(line: 134, column: 30, scope: !870)
!870 = distinct !DILexicalBlock(scope: !871, file: !32, line: 134, column: 30)
!871 = distinct !DILexicalBlock(scope: !819, file: !32, line: 134, column: 30)
!872 = !DILocation(line: 0, scope: !820)
!873 = !DILocation(line: 135, column: 27, scope: !820)
!874 = !DILocation(line: 136, column: 23, scope: !820)
!875 = !DILocation(line: 0, scope: !54, inlinedAt: !876)
!876 = distinct !DILocation(line: 136, column: 24, scope: !877)
!877 = distinct !DILexicalBlock(scope: !821, file: !32, line: 136, column: 24)
!878 = !DILocation(line: 0, scope: !54, inlinedAt: !879)
!879 = distinct !DILocation(line: 136, column: 24, scope: !880)
!880 = distinct !DILexicalBlock(scope: !821, file: !32, line: 136, column: 24)
!881 = !DILocation(line: 0, scope: !54, inlinedAt: !882)
!882 = distinct !DILocation(line: 136, column: 24, scope: !883)
!883 = distinct !DILexicalBlock(scope: !821, file: !32, line: 136, column: 24)
!884 = !DILocation(line: 0, scope: !54, inlinedAt: !885)
!885 = distinct !DILocation(line: 138, column: 17, scope: !821)
!886 = !DILocation(line: 138, column: 15, scope: !821)
!887 = !DILocation(line: 139, column: 30, scope: !888)
!888 = distinct !DILexicalBlock(scope: !822, file: !32, line: 139, column: 5)
!889 = !DILocation(line: 139, column: 20, scope: !888)
!890 = !DILocation(line: 0, scope: !68, inlinedAt: !891)
!891 = distinct !DILocation(line: 139, column: 43, scope: !888)
!892 = !DILocalVariable(name: "this", arg: 1, scope: !893, file: !69, line: 16, type: !76, flags: DIFlagArtificial)
!893 = distinct !DISubprogram(name: "readable", linkageName: "AsioEvent_val_readable_Ib", scope: !69, file: !69, line: 16, type: !833, scopeLine: 16, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !894, retainedNodes: !895)
!894 = !DISubprogram(name: "readable", linkageName: "AsioEvent_val_readable_Ib", scope: !73, file: !69, line: 16, type: !833, scopeLine: 16, spFlags: 0)
!895 = !{!892}
!896 = !DILocation(line: 0, scope: !893, inlinedAt: !897)
!897 = distinct !DILocation(line: 139, column: 52, scope: !888)
!898 = !DILocalVariable(name: "flags", arg: 2, scope: !893, file: !69, line: 16, type: !101)
!899 = !DILocation(line: 140, column: 12, scope: !900)
!900 = distinct !DILexicalBlock(scope: !888, file: !32, line: 140, column: 7)
!901 = !DILocation(line: 0, scope: !54, inlinedAt: !902)
!902 = distinct !DILocation(line: 140, column: 13, scope: !903)
!903 = distinct !DILexicalBlock(scope: !888, file: !32, line: 140, column: 13)
!904 = distinct !DISubprogram(name: "create", linkageName: "I32_val_create_pii", scope: !905, file: !905, line: 202, type: !906, scopeLine: 202, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !909, retainedNodes: !910)
!905 = !DIFile(filename: "<checkout>/packages/builtin/signed.pony", directory: "")
!906 = !DISubroutineType(types: !907)
!907 = !{!908, !908, !908}
!908 = !DIBasicType(name: "I32", size: 32, encoding: DW_ATE_signed)
!909 = !DISubprogram(name: "create", linkageName: "I32_val_create_pii", scope: !908, file: !905, line: 202, type: !906, scopeLine: 202, spFlags: 0)
!910 = !{!911}
!911 = !DILocalVariable(name: "this", arg: 1, scope: !904, file: !905, line: 202, type: !912, flags: DIFlagArtificial)
!912 = !DIBasicType(name: "I32", size: 32, encoding: DW_ATE_signed, flags: DIFlagArtificial)
!913 = !DILocation(line: 0, scope: !904)
!914 = !DILocalVariable(name: "value", arg: 2, scope: !904, file: !905, line: 202, type: !908)
!915 = !DILocation(line: 202, column: 29, scope: !904)
!916 = distinct !DISubprogram(name: "eq", linkageName: "U64_val_eq_Wb", scope: !98, file: !98, line: 172, type: !917, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !920, retainedNodes: !921)
!917 = !DISubroutineType(types: !918)
!918 = !{!47, !919, !919}
!919 = !DIBasicType(name: "U64", size: 64, encoding: DW_ATE_unsigned)
!920 = !DISubprogram(name: "eq", linkageName: "U64_val_eq_Wb", scope: !919, file: !98, line: 172, type: !917, scopeLine: 172, spFlags: 0)
!921 = !{!922}
!922 = !DILocalVariable(name: "this", arg: 1, scope: !916, file: !98, line: 172, type: !923, flags: DIFlagArtificial)
!923 = !DIBasicType(name: "U64", size: 64, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!924 = !DILocation(line: 0, scope: !916)
!925 = !DILocalVariable(name: "y", arg: 2, scope: !916, file: !98, line: 172, type: !919)
!926 = !DILocation(line: 172, column: 35, scope: !916)
!927 = distinct !DISubprogram(name: "eq", linkageName: "U64_box_eq_Wb", scope: !98, file: !98, line: 172, type: !917, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !928, retainedNodes: !929)
!928 = !DISubprogram(name: "eq", linkageName: "U64_box_eq_Wb", scope: !919, file: !98, line: 172, type: !917, scopeLine: 172, spFlags: 0)
!929 = !{!930}
!930 = !DILocalVariable(name: "this", arg: 1, scope: !927, file: !98, line: 172, type: !923, flags: DIFlagArtificial)
!931 = !DILocation(line: 0, scope: !927)
!932 = !DILocalVariable(name: "y", arg: 2, scope: !927, file: !98, line: 172, type: !919)
!933 = !DILocation(line: 172, column: 35, scope: !927)
!934 = distinct !DISubprogram(name: "create", linkageName: "U64_val_create_pWW", scope: !98, file: !98, line: 259, type: !935, scopeLine: 259, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !937, retainedNodes: !938)
!935 = !DISubroutineType(types: !936)
!936 = !{!919, !919, !919}
!937 = !DISubprogram(name: "create", linkageName: "U64_val_create_pWW", scope: !919, file: !98, line: 259, type: !935, scopeLine: 259, spFlags: 0)
!938 = !{!939}
!939 = !DILocalVariable(name: "this", arg: 1, scope: !934, file: !98, line: 259, type: !923, flags: DIFlagArtificial)
!940 = !DILocation(line: 0, scope: !934)
!941 = !DILocalVariable(name: "value", arg: 2, scope: !934, file: !98, line: 259, type: !919)
!942 = !DILocation(line: 259, column: 29, scope: !934)
!943 = !DILocation(line: 0, scope: !461)
!944 = !DILocation(line: 560, column: 28, scope: !461)
!945 = distinct !DISubprogram(name: "bitwidth", linkageName: "USize_box_bitwidth_Z", scope: !98, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !946, retainedNodes: !947)
!946 = !DISubprogram(name: "bitwidth", linkageName: "USize_box_bitwidth_Z", scope: !42, file: !98, line: 560, type: !329, scopeLine: 560, spFlags: 0)
!947 = !{!948}
!948 = !DILocalVariable(name: "this", arg: 1, scope: !945, file: !98, line: 560, type: !333, flags: DIFlagArtificial)
!949 = !DILocation(line: 0, scope: !945)
!950 = !DILocation(line: 560, column: 28, scope: !945)
!951 = distinct !DISubprogram(name: "sub", linkageName: "USize_box_sub_ZZ", scope: !98, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !952, retainedNodes: !953)
!952 = !DISubprogram(name: "sub", linkageName: "USize_box_sub_ZZ", scope: !42, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: 0)
!953 = !{!954}
!954 = !DILocalVariable(name: "this", arg: 1, scope: !951, file: !98, line: 142, type: !333, flags: DIFlagArtificial)
!955 = !DILocation(line: 0, scope: !951)
!956 = !DILocalVariable(name: "y", arg: 2, scope: !951, file: !98, line: 142, type: !42)
!957 = !DILocation(line: 142, column: 28, scope: !951)
!958 = distinct !DISubprogram(name: "sub", linkageName: "USize_val_sub_ZZ", scope: !98, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !959, retainedNodes: !960)
!959 = !DISubprogram(name: "sub", linkageName: "USize_val_sub_ZZ", scope: !42, file: !98, line: 142, type: !338, scopeLine: 142, spFlags: 0)
!960 = !{!961}
!961 = !DILocalVariable(name: "this", arg: 1, scope: !958, file: !98, line: 142, type: !333, flags: DIFlagArtificial)
!962 = !DILocation(line: 0, scope: !958)
!963 = !DILocalVariable(name: "y", arg: 2, scope: !958, file: !98, line: 142, type: !42)
!964 = !DILocation(line: 142, column: 28, scope: !958)
!965 = distinct !DISubprogram(name: "shl", linkageName: "USize_val_shl_ZZ", scope: !98, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !966, retainedNodes: !967)
!966 = !DISubprogram(name: "shl", linkageName: "USize_val_shl_ZZ", scope: !42, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: 0)
!967 = !{!968}
!968 = !DILocalVariable(name: "this", arg: 1, scope: !965, file: !98, line: 445, type: !333, flags: DIFlagArtificial)
!969 = !DILocation(line: 0, scope: !965)
!970 = !DILocalVariable(name: "y", arg: 2, scope: !965, file: !98, line: 445, type: !42)
!971 = !DILocation(line: 445, column: 28, scope: !965)
!972 = distinct !DISubprogram(name: "shl", linkageName: "USize_box_shl_ZZ", scope: !98, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !973, retainedNodes: !974)
!973 = !DISubprogram(name: "shl", linkageName: "USize_box_shl_ZZ", scope: !42, file: !98, line: 445, type: !338, scopeLine: 445, spFlags: 0)
!974 = !{!975}
!975 = !DILocalVariable(name: "this", arg: 1, scope: !972, file: !98, line: 445, type: !333, flags: DIFlagArtificial)
!976 = !DILocation(line: 0, scope: !972)
!977 = !DILocalVariable(name: "y", arg: 2, scope: !972, file: !98, line: 445, type: !42)
!978 = !DILocation(line: 445, column: 28, scope: !972)
!979 = distinct !DISubprogram(name: "ne", linkageName: "USize_val_ne_Zb", scope: !98, file: !98, line: 173, type: !980, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !982, retainedNodes: !983)
!980 = !DISubroutineType(types: !981)
!981 = !{!47, !42, !42}
!982 = !DISubprogram(name: "ne", linkageName: "USize_val_ne_Zb", scope: !42, file: !98, line: 173, type: !980, scopeLine: 173, spFlags: 0)
!983 = !{!984}
!984 = !DILocalVariable(name: "this", arg: 1, scope: !979, file: !98, line: 173, type: !333, flags: DIFlagArtificial)
!985 = !DILocation(line: 0, scope: !979)
!986 = !DILocalVariable(name: "y", arg: 2, scope: !979, file: !98, line: 173, type: !42)
!987 = !DILocation(line: 173, column: 35, scope: !979)
!988 = distinct !DISubprogram(name: "ne", linkageName: "USize_box_ne_Zb", scope: !98, file: !98, line: 173, type: !980, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !989, retainedNodes: !990)
!989 = !DISubprogram(name: "ne", linkageName: "USize_box_ne_Zb", scope: !42, file: !98, line: 173, type: !980, scopeLine: 173, spFlags: 0)
!990 = !{!991}
!991 = !DILocalVariable(name: "this", arg: 1, scope: !988, file: !98, line: 173, type: !333, flags: DIFlagArtificial)
!992 = !DILocation(line: 0, scope: !988)
!993 = !DILocalVariable(name: "y", arg: 2, scope: !988, file: !98, line: 173, type: !42)
!994 = !DILocation(line: 173, column: 35, scope: !988)
!995 = !DILocation(line: 0, scope: !328)
!996 = !DILocation(line: 491, column: 5, scope: !328)
!997 = distinct !DISubprogram(name: "add", linkageName: "USize_val_add_ZZ", scope: !98, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !998, retainedNodes: !999)
!998 = !DISubprogram(name: "add", linkageName: "USize_val_add_ZZ", scope: !42, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: 0)
!999 = !{!1000}
!1000 = !DILocalVariable(name: "this", arg: 1, scope: !997, file: !98, line: 141, type: !333, flags: DIFlagArtificial)
!1001 = !DILocation(line: 0, scope: !997)
!1002 = !DILocalVariable(name: "y", arg: 2, scope: !997, file: !98, line: 141, type: !42)
!1003 = !DILocation(line: 141, column: 28, scope: !997)
!1004 = distinct !DISubprogram(name: "add", linkageName: "USize_box_add_ZZ", scope: !98, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1005, retainedNodes: !1006)
!1005 = !DISubprogram(name: "add", linkageName: "USize_box_add_ZZ", scope: !42, file: !98, line: 141, type: !338, scopeLine: 141, spFlags: 0)
!1006 = !{!1007}
!1007 = !DILocalVariable(name: "this", arg: 1, scope: !1004, file: !98, line: 141, type: !333, flags: DIFlagArtificial)
!1008 = !DILocation(line: 0, scope: !1004)
!1009 = !DILocalVariable(name: "y", arg: 2, scope: !1004, file: !98, line: 141, type: !42)
!1010 = !DILocation(line: 141, column: 28, scope: !1004)
!1011 = !DILocation(line: 0, scope: !439)
!1012 = !DILocation(line: 498, column: 19, scope: !439)
!1013 = !DILocation(line: 0, scope: !448, inlinedAt: !1014)
!1014 = distinct !DILocation(line: 498, column: 27, scope: !439)
!1015 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1014)
!1016 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1014)
!1017 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1014)
!1018 = !DILocation(line: 499, column: 16, scope: !459)
!1019 = !DILocation(line: 0, scope: !461, inlinedAt: !1020)
!1020 = distinct !DILocation(line: 499, column: 41, scope: !466)
!1021 = !DILocation(line: 499, column: 7, scope: !439)
!1022 = distinct !DISubprogram(name: "next_pow2", linkageName: "USize_box_next_pow2_Z", scope: !98, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1023, retainedNodes: !1024)
!1023 = !DISubprogram(name: "next_pow2", linkageName: "USize_box_next_pow2_Z", scope: !42, file: !98, line: 497, type: !329, scopeLine: 497, spFlags: 0)
!1024 = !{!1025, !1026}
!1025 = !DILocalVariable(name: "this", arg: 1, scope: !1022, file: !98, line: 497, type: !333, flags: DIFlagArtificial)
!1026 = !DILocalVariable(name: "x", scope: !1022, file: !98, line: 498, type: !42, align: 32)
!1027 = !DILocation(line: 0, scope: !1022)
!1028 = !DILocation(line: 498, column: 19, scope: !1022)
!1029 = !DILocation(line: 0, scope: !448, inlinedAt: !1030)
!1030 = distinct !DILocation(line: 498, column: 27, scope: !1022)
!1031 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1030)
!1032 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1030)
!1033 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1030)
!1034 = !DILocation(line: 499, column: 16, scope: !1035)
!1035 = distinct !DILexicalBlock(scope: !1022, file: !98, line: 499, column: 11)
!1036 = !DILocation(line: 0, scope: !461, inlinedAt: !1037)
!1037 = distinct !DILocation(line: 499, column: 41, scope: !1038)
!1038 = distinct !DILexicalBlock(scope: !1035, file: !98, line: 499, column: 33)
!1039 = !DILocation(line: 499, column: 7, scope: !1022)
!1040 = distinct !DISubprogram(name: "eq", linkageName: "USize_box_eq_Zb", scope: !98, file: !98, line: 172, type: !980, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1041, retainedNodes: !1042)
!1041 = !DISubprogram(name: "eq", linkageName: "USize_box_eq_Zb", scope: !42, file: !98, line: 172, type: !980, scopeLine: 172, spFlags: 0)
!1042 = !{!1043}
!1043 = !DILocalVariable(name: "this", arg: 1, scope: !1040, file: !98, line: 172, type: !333, flags: DIFlagArtificial)
!1044 = !DILocation(line: 0, scope: !1040)
!1045 = !DILocalVariable(name: "y", arg: 2, scope: !1040, file: !98, line: 172, type: !42)
!1046 = !DILocation(line: 172, column: 35, scope: !1040)
!1047 = distinct !DISubprogram(name: "eq", linkageName: "USize_val_eq_Zb", scope: !98, file: !98, line: 172, type: !980, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1048, retainedNodes: !1049)
!1048 = !DISubprogram(name: "eq", linkageName: "USize_val_eq_Zb", scope: !42, file: !98, line: 172, type: !980, scopeLine: 172, spFlags: 0)
!1049 = !{!1050}
!1050 = !DILocalVariable(name: "this", arg: 1, scope: !1047, file: !98, line: 172, type: !333, flags: DIFlagArtificial)
!1051 = !DILocation(line: 0, scope: !1047)
!1052 = !DILocalVariable(name: "y", arg: 2, scope: !1047, file: !98, line: 172, type: !42)
!1053 = !DILocation(line: 172, column: 35, scope: !1047)
!1054 = distinct !DISubprogram(name: "clz", linkageName: "USize_box_clz_Z", scope: !98, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1055, retainedNodes: !1056)
!1055 = !DISubprogram(name: "clz", linkageName: "USize_box_clz_Z", scope: !42, file: !98, line: 524, type: !329, scopeLine: 524, spFlags: 0)
!1056 = !{!1057}
!1057 = !DILocalVariable(name: "this", arg: 1, scope: !1054, file: !98, line: 524, type: !333, flags: DIFlagArtificial)
!1058 = !DILocation(line: 0, scope: !1054)
!1059 = !DILocation(line: 526, column: 32, scope: !1060)
!1060 = distinct !DILexicalBlock(scope: !1061, file: !98, line: 526, column: 7)
!1061 = distinct !DILexicalBlock(scope: !1054, file: !98, line: 525, column: 5)
!1062 = !DILocation(line: 526, column: 7, scope: !1060)
!1063 = !DILocation(line: 526, column: 48, scope: !1060)
!1064 = !DILocation(line: 525, column: 5, scope: !1054)
!1065 = !DILocation(line: 0, scope: !448)
!1066 = !DILocation(line: 526, column: 32, scope: !454)
!1067 = !DILocation(line: 526, column: 7, scope: !454)
!1068 = !DILocation(line: 526, column: 48, scope: !454)
!1069 = !DILocation(line: 525, column: 5, scope: !448)
!1070 = !DILocation(line: 0, scope: !348)
!1071 = !DILocation(line: 565, column: 39, scope: !355)
!1072 = !DILocation(line: 565, column: 31, scope: !348)
!1073 = distinct !DISubprogram(name: "max", linkageName: "USize_box_max_ZZ", scope: !98, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1074, retainedNodes: !1075)
!1074 = !DISubprogram(name: "max", linkageName: "USize_box_max_ZZ", scope: !42, file: !98, line: 565, type: !338, scopeLine: 565, spFlags: 0)
!1075 = !{!1076}
!1076 = !DILocalVariable(name: "this", arg: 1, scope: !1073, file: !98, line: 565, type: !333, flags: DIFlagArtificial)
!1077 = !DILocation(line: 0, scope: !1073)
!1078 = !DILocalVariable(name: "y", arg: 2, scope: !1073, file: !98, line: 565, type: !42)
!1079 = !DILocation(line: 565, column: 39, scope: !1080)
!1080 = distinct !DILexicalBlock(scope: !1073, file: !98, line: 565, column: 31)
!1081 = !DILocation(line: 565, column: 31, scope: !1073)
!1082 = distinct !DISubprogram(name: "neg", linkageName: "USize_val_neg_Z", scope: !98, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1083, retainedNodes: !1084)
!1083 = !DISubprogram(name: "neg", linkageName: "USize_val_neg_Z", scope: !42, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: 0)
!1084 = !{!1085}
!1085 = !DILocalVariable(name: "this", arg: 1, scope: !1082, file: !98, line: 159, type: !333, flags: DIFlagArtificial)
!1086 = !DILocation(line: 0, scope: !1082)
!1087 = !DILocation(line: 159, column: 19, scope: !1082)
!1088 = distinct !DISubprogram(name: "neg", linkageName: "USize_box_neg_Z", scope: !98, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1089, retainedNodes: !1090)
!1089 = !DISubprogram(name: "neg", linkageName: "USize_box_neg_Z", scope: !42, file: !98, line: 159, type: !329, scopeLine: 159, spFlags: 0)
!1090 = !{!1091}
!1091 = !DILocalVariable(name: "this", arg: 1, scope: !1088, file: !98, line: 159, type: !333, flags: DIFlagArtificial)
!1092 = !DILocation(line: 0, scope: !1088)
!1093 = !DILocation(line: 159, column: 19, scope: !1088)
!1094 = !DILocation(line: 0, scope: !337)
!1095 = !DILocation(line: 564, column: 39, scope: !346)
!1096 = !DILocation(line: 564, column: 31, scope: !337)
!1097 = distinct !DISubprogram(name: "min", linkageName: "USize_box_min_ZZ", scope: !98, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1098, retainedNodes: !1099)
!1098 = !DISubprogram(name: "min", linkageName: "USize_box_min_ZZ", scope: !42, file: !98, line: 564, type: !338, scopeLine: 564, spFlags: 0)
!1099 = !{!1100}
!1100 = !DILocalVariable(name: "this", arg: 1, scope: !1097, file: !98, line: 564, type: !333, flags: DIFlagArtificial)
!1101 = !DILocation(line: 0, scope: !1097)
!1102 = !DILocalVariable(name: "y", arg: 2, scope: !1097, file: !98, line: 564, type: !42)
!1103 = !DILocation(line: 564, column: 39, scope: !1104)
!1104 = distinct !DILexicalBlock(scope: !1097, file: !98, line: 564, column: 31)
!1105 = !DILocation(line: 564, column: 31, scope: !1097)
!1106 = distinct !DISubprogram(name: "create", linkageName: "USize_val_create_pZZ", scope: !98, file: !98, line: 485, type: !338, scopeLine: 485, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1107, retainedNodes: !1108)
!1107 = !DISubprogram(name: "create", linkageName: "USize_val_create_pZZ", scope: !42, file: !98, line: 485, type: !338, scopeLine: 485, spFlags: 0)
!1108 = !{!1109}
!1109 = !DILocalVariable(name: "this", arg: 1, scope: !1106, file: !98, line: 485, type: !333, flags: DIFlagArtificial)
!1110 = !DILocation(line: 0, scope: !1106)
!1111 = !DILocalVariable(name: "value", arg: 2, scope: !1106, file: !98, line: 485, type: !42)
!1112 = !DILocation(line: 485, column: 31, scope: !1106)
!1113 = distinct !DISubprogram(name: "lt", linkageName: "USize_val_lt_Zb", scope: !98, file: !98, line: 174, type: !980, scopeLine: 174, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1114, retainedNodes: !1115)
!1114 = !DISubprogram(name: "lt", linkageName: "USize_val_lt_Zb", scope: !42, file: !98, line: 174, type: !980, scopeLine: 174, spFlags: 0)
!1115 = !{!1116}
!1116 = !DILocalVariable(name: "this", arg: 1, scope: !1113, file: !98, line: 174, type: !333, flags: DIFlagArtificial)
!1117 = !DILocation(line: 0, scope: !1113)
!1118 = !DILocalVariable(name: "y", arg: 2, scope: !1113, file: !98, line: 174, type: !42)
!1119 = !DILocation(line: 174, column: 35, scope: !1113)
!1120 = distinct !DISubprogram(name: "lt", linkageName: "USize_box_lt_Zb", scope: !98, file: !98, line: 174, type: !980, scopeLine: 174, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1121, retainedNodes: !1122)
!1121 = !DISubprogram(name: "lt", linkageName: "USize_box_lt_Zb", scope: !42, file: !98, line: 174, type: !980, scopeLine: 174, spFlags: 0)
!1122 = !{!1123}
!1123 = !DILocalVariable(name: "this", arg: 1, scope: !1120, file: !98, line: 174, type: !333, flags: DIFlagArtificial)
!1124 = !DILocation(line: 0, scope: !1120)
!1125 = !DILocalVariable(name: "y", arg: 2, scope: !1120, file: !98, line: 174, type: !42)
!1126 = !DILocation(line: 174, column: 35, scope: !1120)
!1127 = distinct !DISubprogram(name: "gt", linkageName: "USize_val_gt_Zb", scope: !98, file: !98, line: 177, type: !980, scopeLine: 177, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1128, retainedNodes: !1129)
!1128 = !DISubprogram(name: "gt", linkageName: "USize_val_gt_Zb", scope: !42, file: !98, line: 177, type: !980, scopeLine: 177, spFlags: 0)
!1129 = !{!1130}
!1130 = !DILocalVariable(name: "this", arg: 1, scope: !1127, file: !98, line: 177, type: !333, flags: DIFlagArtificial)
!1131 = !DILocation(line: 0, scope: !1127)
!1132 = !DILocalVariable(name: "y", arg: 2, scope: !1127, file: !98, line: 177, type: !42)
!1133 = !DILocation(line: 177, column: 35, scope: !1127)
!1134 = distinct !DISubprogram(name: "gt", linkageName: "USize_box_gt_Zb", scope: !98, file: !98, line: 177, type: !980, scopeLine: 177, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1135, retainedNodes: !1136)
!1135 = !DISubprogram(name: "gt", linkageName: "USize_box_gt_Zb", scope: !42, file: !98, line: 177, type: !980, scopeLine: 177, spFlags: 0)
!1136 = !{!1137}
!1137 = !DILocalVariable(name: "this", arg: 1, scope: !1134, file: !98, line: 177, type: !333, flags: DIFlagArtificial)
!1138 = !DILocation(line: 0, scope: !1134)
!1139 = !DILocalVariable(name: "y", arg: 2, scope: !1134, file: !98, line: 177, type: !42)
!1140 = !DILocation(line: 177, column: 35, scope: !1134)
!1141 = !DILocation(line: 0, scope: !669)
!1142 = !DILocation(line: 170, column: 5, scope: !669)
!1143 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_val_size_Z", scope: !403, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1144, retainedNodes: !1145)
!1144 = !DISubprogram(name: "size", linkageName: "Array_U8_val_val_size_Z", scope: !582, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: 0)
!1145 = !{!1146}
!1146 = !DILocalVariable(name: "this", arg: 1, scope: !1143, file: !403, line: 166, type: !599, flags: DIFlagArtificial)
!1147 = !DILocation(line: 0, scope: !1143)
!1148 = !DILocation(line: 170, column: 5, scope: !1143)
!1149 = distinct !DISubprogram(name: "size", linkageName: "Array_U8_val_box_size_Z", scope: !403, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1150, retainedNodes: !1151)
!1150 = !DISubprogram(name: "size", linkageName: "Array_U8_val_box_size_Z", scope: !582, file: !403, line: 166, type: !670, scopeLine: 166, spFlags: 0)
!1151 = !{!1152}
!1152 = !DILocalVariable(name: "this", arg: 1, scope: !1149, file: !403, line: 166, type: !599, flags: DIFlagArtificial)
!1153 = !DILocation(line: 0, scope: !1149)
!1154 = !DILocation(line: 170, column: 5, scope: !1149)
!1155 = !DILocation(line: 0, scope: !619)
!1156 = !DILocation(line: 185, column: 15, scope: !626)
!1157 = !DILocation(line: 0, scope: !439, inlinedAt: !1158)
!1158 = distinct !DILocation(line: 186, column: 29, scope: !629)
!1159 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !1158)
!1160 = !DILocation(line: 0, scope: !448, inlinedAt: !1161)
!1161 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !1158)
!1162 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1161)
!1163 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1161)
!1164 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1161)
!1165 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !1158)
!1166 = !DILocation(line: 0, scope: !461, inlinedAt: !1167)
!1167 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !1158)
!1168 = !DILocation(line: 0, scope: !348, inlinedAt: !1169)
!1169 = distinct !DILocation(line: 186, column: 35, scope: !629)
!1170 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1169)
!1171 = !DILocation(line: 0, scope: !348, inlinedAt: !1172)
!1172 = distinct !DILocation(line: 186, column: 44, scope: !629)
!1173 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1172)
!1174 = !DILocation(line: 0, scope: !348, inlinedAt: !1175)
!1175 = distinct !DILocation(line: 186, column: 51, scope: !629)
!1176 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1175)
!1177 = !DILocation(line: 186, column: 14, scope: !629)
!1178 = !DILocation(line: 187, column: 27, scope: !629)
!1179 = !DILocation(line: 187, column: 12, scope: !629)
!1180 = !DILocation(line: 0, scope: !54, inlinedAt: !1181)
!1181 = distinct !DILocation(line: 187, column: 41, scope: !653)
!1182 = !DILocation(line: 0, scope: !54, inlinedAt: !1183)
!1183 = distinct !DILocation(line: 179, column: 5, scope: !619)
!1184 = !DILocation(line: 179, column: 5, scope: !619)
!1185 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_box_cpointer_Zo", scope: !403, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1186, retainedNodes: !1187)
!1186 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_box_cpointer_Zo", scope: !582, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: 0)
!1187 = !{!1188}
!1188 = !DILocalVariable(name: "this", arg: 1, scope: !1185, file: !403, line: 160, type: !599, flags: DIFlagArtificial)
!1189 = !DILocation(line: 0, scope: !1185)
!1190 = !DILocalVariable(name: "offset", arg: 2, scope: !1185, file: !403, line: 160, type: !42)
!1191 = !DILocation(line: 164, column: 17, scope: !1185)
!1192 = distinct !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_val_cpointer_Zo", scope: !403, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1193, retainedNodes: !1194)
!1193 = !DISubprogram(name: "cpointer", linkageName: "Array_U8_val_val_cpointer_Zo", scope: !582, file: !403, line: 160, type: !661, scopeLine: 160, spFlags: 0)
!1194 = !{!1195}
!1195 = !DILocalVariable(name: "this", arg: 1, scope: !1192, file: !403, line: 160, type: !599, flags: DIFlagArtificial)
!1196 = !DILocation(line: 0, scope: !1192)
!1197 = !DILocalVariable(name: "offset", arg: 2, scope: !1192, file: !403, line: 160, type: !42)
!1198 = !DILocation(line: 164, column: 17, scope: !1192)
!1199 = !DILocation(line: 0, scope: !660)
!1200 = !DILocation(line: 164, column: 17, scope: !660)
!1201 = !DILocation(line: 0, scope: !610)
!1202 = !DILocation(line: 0, scope: !619, inlinedAt: !1203)
!1203 = distinct !DILocation(line: 219, column: 12, scope: !610)
!1204 = !DILocation(line: 185, column: 15, scope: !626, inlinedAt: !1203)
!1205 = !DILocation(line: 0, scope: !439, inlinedAt: !1206)
!1206 = distinct !DILocation(line: 186, column: 29, scope: !629, inlinedAt: !1203)
!1207 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !1206)
!1208 = !DILocation(line: 0, scope: !448, inlinedAt: !1209)
!1209 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !1206)
!1210 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1209)
!1211 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1209)
!1212 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1209)
!1213 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !1206)
!1214 = !DILocation(line: 0, scope: !461, inlinedAt: !1215)
!1215 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !1206)
!1216 = !DILocation(line: 0, scope: !348, inlinedAt: !1217)
!1217 = distinct !DILocation(line: 186, column: 35, scope: !629, inlinedAt: !1203)
!1218 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1217)
!1219 = !DILocation(line: 0, scope: !348, inlinedAt: !1220)
!1220 = distinct !DILocation(line: 186, column: 44, scope: !629, inlinedAt: !1203)
!1221 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1220)
!1222 = !DILocation(line: 0, scope: !348, inlinedAt: !1223)
!1223 = distinct !DILocation(line: 186, column: 51, scope: !629, inlinedAt: !1203)
!1224 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1223)
!1225 = !DILocation(line: 186, column: 14, scope: !629, inlinedAt: !1203)
!1226 = !DILocation(line: 187, column: 27, scope: !629, inlinedAt: !1203)
!1227 = !DILocation(line: 187, column: 12, scope: !629, inlinedAt: !1203)
!1228 = !DILocation(line: 0, scope: !54, inlinedAt: !1229)
!1229 = distinct !DILocation(line: 187, column: 41, scope: !653, inlinedAt: !1203)
!1230 = !DILocation(line: 0, scope: !54, inlinedAt: !1231)
!1231 = distinct !DILocation(line: 179, column: 5, scope: !619, inlinedAt: !1203)
!1232 = !DILocation(line: 220, column: 11, scope: !610)
!1233 = !DILocation(line: 0, scope: !54, inlinedAt: !1234)
!1234 = distinct !DILocation(line: 215, column: 5, scope: !610)
!1235 = !DILocation(line: 215, column: 5, scope: !610)
!1236 = !DILocation(line: 0, scope: !594)
!1237 = !DILocation(line: 97, column: 11, scope: !594)
!1238 = !DILocation(line: 99, column: 12, scope: !607)
!1239 = !DILocation(line: 0, scope: !439, inlinedAt: !1240)
!1240 = distinct !DILocation(line: 100, column: 29, scope: !1241)
!1241 = distinct !DILexicalBlock(scope: !607, file: !403, line: 100, column: 7)
!1242 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !1240)
!1243 = !DILocation(line: 0, scope: !448, inlinedAt: !1244)
!1244 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !1240)
!1245 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1244)
!1246 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1244)
!1247 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1244)
!1248 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !1240)
!1249 = !DILocation(line: 0, scope: !461, inlinedAt: !1250)
!1250 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !1240)
!1251 = !DILocation(line: 0, scope: !348, inlinedAt: !1252)
!1252 = distinct !DILocation(line: 100, column: 35, scope: !1241)
!1253 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1252)
!1254 = !DILocation(line: 0, scope: !348, inlinedAt: !1255)
!1255 = distinct !DILocation(line: 100, column: 44, scope: !1241)
!1256 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1255)
!1257 = !DILocation(line: 0, scope: !348, inlinedAt: !1258)
!1258 = distinct !DILocation(line: 100, column: 51, scope: !1241)
!1259 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1258)
!1260 = !DILocation(line: 100, column: 14, scope: !1241)
!1261 = !DILocation(line: 101, column: 31, scope: !1241)
!1262 = !DILocation(line: 101, column: 12, scope: !1241)
!1263 = !DILocation(line: 103, column: 14, scope: !606)
!1264 = !DILocation(line: 104, column: 12, scope: !606)
!1265 = !DILocation(line: 99, column: 5, scope: !594)
!1266 = !DILocation(line: 0, scope: !742)
!1267 = !DILocation(line: 0, scope: !337, inlinedAt: !1268)
!1268 = distinct !DILocation(line: 396, column: 22, scope: !742)
!1269 = !DILocation(line: 564, column: 39, scope: !346, inlinedAt: !1268)
!1270 = !DILocation(line: 396, column: 11, scope: !742)
!1271 = !DILocation(line: 0, scope: !54, inlinedAt: !1272)
!1272 = distinct !DILocation(line: 392, column: 5, scope: !742)
!1273 = !DILocation(line: 392, column: 5, scope: !742)
!1274 = distinct !DISubprogram(name: "_create", linkageName: "Env_ref__create_pIioioo", scope: !168, file: !168, line: 37, type: !1275, scopeLine: 37, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1295, retainedNodes: !1296)
!1275 = !DISubroutineType(types: !1276)
!1276 = !{!1277, !1277, !101, !1293, !1293}
!1277 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1278, size: 32, align: 32, dwarfAddressSpace: 0)
!1278 = !DICompositeType(tag: DW_TAG_structure_type, name: "Env", file: !168, line: 75, size: 256, align: 32, elements: !1279, identifier: "Env")
!1279 = !{!1280, !1281, !1284, !1287, !1288, !1289, !1290}
!1280 = !DIDerivedType(tag: DW_TAG_member, name: "root", file: !168, line: 9, baseType: !183, size: 32, align: 32, offset: 32)
!1281 = !DIDerivedType(tag: DW_TAG_member, name: "input", file: !168, line: 14, baseType: !1282, size: 32, align: 32, offset: 64)
!1282 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1283, size: 32, align: 32, dwarfAddressSpace: 0)
!1283 = !DICompositeType(tag: DW_TAG_structure_type, name: "InputStream", file: !32, line: 14, elements: !4, identifier: "InputStream")
!1284 = !DIDerivedType(tag: DW_TAG_member, name: "out", file: !168, line: 19, baseType: !1285, size: 32, align: 32, offset: 96)
!1285 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1286, size: 32, align: 32, dwarfAddressSpace: 0)
!1286 = !DICompositeType(tag: DW_TAG_structure_type, name: "OutStream", file: !7, line: 19, elements: !4, identifier: "OutStream")
!1287 = !DIDerivedType(tag: DW_TAG_member, name: "err", file: !168, line: 22, baseType: !1285, size: 32, align: 32, offset: 128)
!1288 = !DIDerivedType(tag: DW_TAG_member, name: "args", file: !168, line: 25, baseType: !406, size: 32, align: 32, offset: 160)
!1289 = !DIDerivedType(tag: DW_TAG_member, name: "vars", file: !168, line: 28, baseType: !406, size: 32, align: 32, offset: 192)
!1290 = !DIDerivedType(tag: DW_TAG_member, name: "exitcode", file: !168, line: 31, baseType: !1291, size: 32, align: 32, offset: 224)
!1291 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1292, size: 32, align: 32, dwarfAddressSpace: 0)
!1292 = !DICompositeType(tag: DW_TAG_structure_type, name: "$0$6", file: !168, line: 31, elements: !4, identifier: "$0$6")
!1293 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1294, size: 32, align: 32, dwarfAddressSpace: 0)
!1294 = !DICompositeType(tag: DW_TAG_structure_type, name: "Pointer_Pointer_U8_val_ref", file: !16, line: 39, elements: !4, identifier: "Pointer_Pointer_U8_val_ref")
!1295 = !DISubprogram(name: "_create", linkageName: "Env_ref__create_pIioioo", scope: !1278, file: !168, line: 37, type: !1275, scopeLine: 37, spFlags: 0)
!1296 = !{!1297}
!1297 = !DILocalVariable(name: "this", arg: 1, scope: !1274, file: !168, line: 37, type: !1298, flags: DIFlagArtificial)
!1298 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !1278, size: 32, align: 32, flags: DIFlagArtificial, dwarfAddressSpace: 0)
!1299 = !DILocation(line: 0, scope: !1274)
!1300 = !DILocalVariable(name: "argc", arg: 2, scope: !1274, file: !168, line: 37, type: !101)
!1301 = !DILocalVariable(name: "argv", arg: 3, scope: !1274, file: !168, line: 37, type: !1293)
!1302 = !DILocalVariable(name: "envp", arg: 4, scope: !1274, file: !168, line: 37, type: !1293)
!1303 = !DILocation(line: 0, scope: !179, inlinedAt: !1304)
!1304 = distinct !DILocation(line: 46, column: 31, scope: !1274)
!1305 = !DILocation(line: 0, scope: !54, inlinedAt: !1306)
!1306 = distinct !DILocation(line: 16, column: 5, scope: !179, inlinedAt: !1304)
!1307 = !DILocation(line: 46, column: 10, scope: !1274)
!1308 = !DILocation(line: 47, column: 5, scope: !1274)
!1309 = !DILocation(line: 49, column: 27, scope: !1274)
!1310 = !DILocation(line: 49, column: 26, scope: !1274)
!1311 = !DILocation(line: 49, column: 11, scope: !1274)
!1312 = !DILocation(line: 50, column: 25, scope: !1274)
!1313 = !DILocation(line: 50, column: 9, scope: !1274)
!1314 = !DILocation(line: 51, column: 25, scope: !1274)
!1315 = !DILocation(line: 51, column: 9, scope: !1274)
!1316 = !DILocation(line: 53, column: 51, scope: !1274)
!1317 = !DILocation(line: 53, column: 34, scope: !1274)
!1318 = !DILocation(line: 53, column: 10, scope: !1274)
!1319 = !DILocalVariable(name: "this", arg: 1, scope: !1320, file: !168, line: 76, type: !1298, flags: DIFlagArtificial)
!1320 = distinct !DISubprogram(name: "_count_strings", linkageName: "Env_tag__count_strings_oZ", scope: !168, file: !168, line: 76, type: !1321, scopeLine: 76, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1323, retainedNodes: !1324)
!1321 = !DISubroutineType(types: !1322)
!1322 = !{!42, !1277, !1293}
!1323 = !DISubprogram(name: "_count_strings", linkageName: "Env_tag__count_strings_oZ", scope: !1278, file: !168, line: 76, type: !1321, scopeLine: 76, spFlags: 0)
!1324 = !{!1319, !1325, !1326}
!1325 = !DILocalVariable(name: "i", scope: !1320, file: !168, line: 81, type: !42, align: 32)
!1326 = !DILocalVariable(name: "entry", scope: !1327, file: !168, line: 84, type: !14, align: 32)
!1327 = distinct !DILexicalBlock(scope: !1320, file: !168, line: 83, column: 5)
!1328 = !DILocation(line: 0, scope: !1320, inlinedAt: !1329)
!1329 = distinct !DILocation(line: 54, column: 55, scope: !1274)
!1330 = !DILocalVariable(name: "data", arg: 2, scope: !1320, file: !168, line: 76, type: !1293)
!1331 = !DILocation(line: 77, column: 20, scope: !1332, inlinedAt: !1329)
!1332 = distinct !DILexicalBlock(scope: !1320, file: !168, line: 77, column: 5)
!1333 = !DILocation(line: 78, column: 7, scope: !1334, inlinedAt: !1329)
!1334 = distinct !DILexicalBlock(scope: !1332, file: !168, line: 78, column: 7)
!1335 = !DILocation(line: 0, scope: !54, inlinedAt: !1336)
!1336 = distinct !DILocation(line: 78, column: 14, scope: !1337, inlinedAt: !1329)
!1337 = distinct !DILexicalBlock(scope: !1332, file: !168, line: 78, column: 14)
!1338 = !DILocation(line: 84, column: 30, scope: !1327, inlinedAt: !1329)
!1339 = !DILocation(line: 0, scope: !1327, inlinedAt: !1329)
!1340 = !DILocation(line: 85, column: 24, scope: !1327, inlinedAt: !1329)
!1341 = !DILocation(line: 87, column: 13, scope: !1342, inlinedAt: !1329)
!1342 = distinct !DILexicalBlock(scope: !1327, file: !168, line: 87, column: 7)
!1343 = !DILocation(line: 0, scope: !54, inlinedAt: !1344)
!1344 = distinct !DILocation(line: 87, column: 15, scope: !1345, inlinedAt: !1329)
!1345 = distinct !DILexicalBlock(scope: !1327, file: !168, line: 87, column: 15)
!1346 = !DILocation(line: 89, column: 5, scope: !1320, inlinedAt: !1329)
!1347 = !DILocation(line: 54, column: 34, scope: !1274)
!1348 = !DILocation(line: 54, column: 10, scope: !1274)
!1349 = !DILocation(line: 0, scope: !167, inlinedAt: !1350)
!1350 = distinct !DILocation(line: 56, column: 16, scope: !1274)
!1351 = !DILocation(line: 56, column: 14, scope: !1274)
!1352 = !DILocation(line: 0, scope: !1320)
!1353 = !DILocation(line: 77, column: 20, scope: !1332)
!1354 = !DILocation(line: 78, column: 7, scope: !1334)
!1355 = !DILocation(line: 0, scope: !54, inlinedAt: !1356)
!1356 = distinct !DILocation(line: 78, column: 14, scope: !1337)
!1357 = !DILocation(line: 84, column: 30, scope: !1327)
!1358 = !DILocation(line: 0, scope: !1327)
!1359 = !DILocation(line: 85, column: 24, scope: !1327)
!1360 = !DILocation(line: 87, column: 13, scope: !1342)
!1361 = !DILocation(line: 0, scope: !54, inlinedAt: !1362)
!1362 = distinct !DILocation(line: 87, column: 15, scope: !1345)
!1363 = !DILocation(line: 89, column: 5, scope: !1320)
!1364 = distinct !DISubprogram(name: "_strings_from_pointers", linkageName: "Env_tag__strings_from_pointers_oZo", scope: !168, file: !168, line: 91, type: !1365, scopeLine: 91, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1367, retainedNodes: !1368)
!1365 = !DISubroutineType(types: !1366)
!1366 = !{!406, !1277, !1293, !42}
!1367 = !DISubprogram(name: "_strings_from_pointers", linkageName: "Env_tag__strings_from_pointers_oZo", scope: !1278, file: !168, line: 91, type: !1365, scopeLine: 91, spFlags: 0)
!1368 = !{!1369, !1370, !1371, !1372}
!1369 = !DILocalVariable(name: "this", arg: 1, scope: !1364, file: !168, line: 91, type: !1298, flags: DIFlagArtificial)
!1370 = !DILocalVariable(name: "array", scope: !1364, file: !168, line: 96, type: !406, align: 32)
!1371 = !DILocalVariable(name: "i", scope: !1364, file: !168, line: 97, type: !42, align: 32)
!1372 = !DILocalVariable(name: "entry", scope: !1373, file: !168, line: 100, type: !14, align: 32)
!1373 = distinct !DILexicalBlock(scope: !1374, file: !168, line: 100, column: 7)
!1374 = distinct !DILexicalBlock(scope: !1364, file: !168, line: 99, column: 5)
!1375 = !DILocation(line: 0, scope: !1364)
!1376 = !DILocalVariable(name: "data", arg: 2, scope: !1364, file: !168, line: 91, type: !1293)
!1377 = !DILocalVariable(name: "len", arg: 3, scope: !1364, file: !168, line: 91, type: !42)
!1378 = !DILocation(line: 0, scope: !485, inlinedAt: !1379)
!1379 = distinct !DILocation(line: 96, column: 38, scope: !1380)
!1380 = distinct !DILexicalBlock(scope: !1364, file: !168, line: 96, column: 25)
!1381 = !DILocation(line: 97, column: 11, scope: !485, inlinedAt: !1379)
!1382 = !DILocation(line: 99, column: 12, scope: !495, inlinedAt: !1379)
!1383 = !DILocation(line: 0, scope: !439, inlinedAt: !1384)
!1384 = distinct !DILocation(line: 100, column: 29, scope: !498, inlinedAt: !1379)
!1385 = !DILocation(line: 498, column: 19, scope: !439, inlinedAt: !1384)
!1386 = !DILocation(line: 0, scope: !448, inlinedAt: !1387)
!1387 = distinct !DILocation(line: 498, column: 27, scope: !439, inlinedAt: !1384)
!1388 = !DILocation(line: 526, column: 32, scope: !454, inlinedAt: !1387)
!1389 = !DILocation(line: 526, column: 7, scope: !454, inlinedAt: !1387)
!1390 = !DILocation(line: 526, column: 48, scope: !454, inlinedAt: !1387)
!1391 = !DILocation(line: 499, column: 16, scope: !459, inlinedAt: !1384)
!1392 = !DILocation(line: 0, scope: !461, inlinedAt: !1393)
!1393 = distinct !DILocation(line: 499, column: 41, scope: !466, inlinedAt: !1384)
!1394 = !DILocation(line: 0, scope: !348, inlinedAt: !1395)
!1395 = distinct !DILocation(line: 100, column: 35, scope: !498, inlinedAt: !1379)
!1396 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1395)
!1397 = !DILocation(line: 0, scope: !348, inlinedAt: !1398)
!1398 = distinct !DILocation(line: 100, column: 44, scope: !498, inlinedAt: !1379)
!1399 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1398)
!1400 = !DILocation(line: 0, scope: !348, inlinedAt: !1401)
!1401 = distinct !DILocation(line: 100, column: 51, scope: !498, inlinedAt: !1379)
!1402 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1401)
!1403 = !DILocation(line: 100, column: 14, scope: !498, inlinedAt: !1379)
!1404 = !DILocation(line: 101, column: 31, scope: !498, inlinedAt: !1379)
!1405 = !DILocation(line: 101, column: 12, scope: !498, inlinedAt: !1379)
!1406 = !DILocation(line: 103, column: 14, scope: !521, inlinedAt: !1379)
!1407 = !DILocation(line: 104, column: 12, scope: !521, inlinedAt: !1379)
!1408 = !DILocation(line: 99, column: 13, scope: !1374)
!1409 = !DILocation(line: 0, scope: !1373)
!1410 = !DILocation(line: 100, column: 37, scope: !1373)
!1411 = !DILocation(line: 100, column: 30, scope: !1373)
!1412 = !DILocation(line: 0, scope: !363, inlinedAt: !1413)
!1413 = distinct !DILocation(line: 101, column: 45, scope: !1414)
!1414 = distinct !DILexicalBlock(scope: !1373, file: !168, line: 101, column: 26)
!1415 = !DILocation(line: 152, column: 19, scope: !371, inlinedAt: !1413)
!1416 = !DILocation(line: 153, column: 13, scope: !376, inlinedAt: !1413)
!1417 = !DILocation(line: 154, column: 14, scope: !376, inlinedAt: !1413)
!1418 = !DILocation(line: 155, column: 32, scope: !376, inlinedAt: !1413)
!1419 = !DILocation(line: 155, column: 12, scope: !376, inlinedAt: !1413)
!1420 = !DILocation(line: 0, scope: !307, inlinedAt: !1421)
!1421 = distinct !DILocation(line: 156, column: 11, scope: !376, inlinedAt: !1413)
!1422 = !DILocation(line: 1704, column: 17, scope: !307, inlinedAt: !1421)
!1423 = !DILocation(line: 0, scope: !370, inlinedAt: !1413)
!1424 = !DILocation(line: 160, column: 23, scope: !385, inlinedAt: !1413)
!1425 = !DILocation(line: 161, column: 15, scope: !387, inlinedAt: !1413)
!1426 = !DILocation(line: 0, scope: !54, inlinedAt: !1427)
!1427 = distinct !DILocation(line: 161, column: 17, scope: !390, inlinedAt: !1413)
!1428 = !DILocation(line: 164, column: 13, scope: !370, inlinedAt: !1413)
!1429 = !DILocation(line: 165, column: 19, scope: !370, inlinedAt: !1413)
!1430 = !DILocation(line: 0, scope: !348, inlinedAt: !1431)
!1431 = distinct !DILocation(line: 165, column: 27, scope: !370, inlinedAt: !1413)
!1432 = !DILocation(line: 565, column: 39, scope: !355, inlinedAt: !1431)
!1433 = !DILocation(line: 165, column: 14, scope: !370, inlinedAt: !1413)
!1434 = !DILocation(line: 166, column: 32, scope: !370, inlinedAt: !1413)
!1435 = !DILocation(line: 166, column: 12, scope: !370, inlinedAt: !1413)
!1436 = !DILocation(line: 168, column: 28, scope: !370, inlinedAt: !1413)
!1437 = !DILocation(line: 168, column: 19, scope: !370, inlinedAt: !1413)
!1438 = !DILocation(line: 0, scope: !402, inlinedAt: !1439)
!1439 = distinct !DILocation(line: 101, column: 17, scope: !1373)
!1440 = !DILocation(line: 657, column: 19, scope: !402, inlinedAt: !1439)
!1441 = !DILocation(line: 657, column: 12, scope: !402, inlinedAt: !1439)
!1442 = !DILocation(line: 658, column: 17, scope: !402, inlinedAt: !1439)
!1443 = !DILocation(line: 659, column: 19, scope: !402, inlinedAt: !1439)
!1444 = !DILocation(line: 659, column: 11, scope: !402, inlinedAt: !1439)
!1445 = !DILocation(line: 0, scope: !54, inlinedAt: !1446)
!1446 = distinct !DILocation(line: 654, column: 5, scope: !402, inlinedAt: !1439)
!1447 = !DILocation(line: 0, scope: !54, inlinedAt: !1448)
!1448 = distinct !DILocation(line: 101, column: 56, scope: !1449)
!1449 = distinct !DILexicalBlock(scope: !1374, file: !168, line: 101, column: 56)
!1450 = !DILocation(line: 104, column: 5, scope: !1364)
!1451 = !DILocation(line: 0, scope: !54)
!1452 = !DILocation(line: 1, column: 1, scope: !54)
!1453 = !DILocation(line: 0, scope: !893)
!1454 = !DILocation(line: 20, column: 26, scope: !893)
!1455 = distinct !DISubprogram(name: "readable", linkageName: "AsioEvent_box_readable_Ib", scope: !69, file: !69, line: 16, type: !833, scopeLine: 16, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1456, retainedNodes: !1457)
!1456 = !DISubprogram(name: "readable", linkageName: "AsioEvent_box_readable_Ib", scope: !73, file: !69, line: 16, type: !833, scopeLine: 16, spFlags: 0)
!1457 = !{!1458}
!1458 = !DILocalVariable(name: "this", arg: 1, scope: !1455, file: !69, line: 16, type: !76, flags: DIFlagArtificial)
!1459 = !DILocation(line: 0, scope: !1455)
!1460 = !DILocalVariable(name: "flags", arg: 2, scope: !1455, file: !69, line: 16, type: !101)
!1461 = !DILocation(line: 20, column: 26, scope: !1455)
!1462 = distinct !DISubprogram(name: "errored", linkageName: "AsioEvent_box_errored_Ib", scope: !69, file: !69, line: 34, type: !833, scopeLine: 34, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1463, retainedNodes: !1464)
!1463 = !DISubprogram(name: "errored", linkageName: "AsioEvent_box_errored_Ib", scope: !73, file: !69, line: 34, type: !833, scopeLine: 34, spFlags: 0)
!1464 = !{!1465}
!1465 = !DILocalVariable(name: "this", arg: 1, scope: !1462, file: !69, line: 34, type: !76, flags: DIFlagArtificial)
!1466 = !DILocation(line: 0, scope: !1462)
!1467 = !DILocalVariable(name: "flags", arg: 2, scope: !1462, file: !69, line: 34, type: !101)
!1468 = !DILocation(line: 40, column: 26, scope: !1462)
!1469 = !DILocation(line: 0, scope: !848)
!1470 = !DILocation(line: 40, column: 26, scope: !848)
!1471 = distinct !DISubprogram(name: "disposable", linkageName: "AsioEvent_box_disposable_Ib", scope: !69, file: !69, line: 28, type: !833, scopeLine: 28, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1472, retainedNodes: !1473)
!1472 = !DISubprogram(name: "disposable", linkageName: "AsioEvent_box_disposable_Ib", scope: !73, file: !69, line: 28, type: !833, scopeLine: 28, spFlags: 0)
!1473 = !{!1474}
!1474 = !DILocalVariable(name: "this", arg: 1, scope: !1471, file: !69, line: 28, type: !76, flags: DIFlagArtificial)
!1475 = !DILocation(line: 0, scope: !1471)
!1476 = !DILocalVariable(name: "flags", arg: 2, scope: !1471, file: !69, line: 28, type: !101)
!1477 = !DILocation(line: 32, column: 11, scope: !1471)
!1478 = !DILocation(line: 0, scope: !832)
!1479 = !DILocation(line: 32, column: 11, scope: !832)
!1480 = distinct !DISubprogram(name: "none", linkageName: "AsioEvent_box_none_o", scope: !69, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1481, retainedNodes: !1482)
!1481 = !DISubprogram(name: "none", linkageName: "AsioEvent_box_none_o", scope: !73, file: !69, line: 10, type: !81, scopeLine: 10, spFlags: 0)
!1482 = !{!1483}
!1483 = !DILocalVariable(name: "this", arg: 1, scope: !1480, file: !69, line: 10, type: !76, flags: DIFlagArtificial)
!1484 = !DILocation(line: 0, scope: !1480)
!1485 = !DILocation(line: 14, column: 5, scope: !1480)
!1486 = !DILocation(line: 0, scope: !80)
!1487 = !DILocation(line: 14, column: 5, scope: !80)
!1488 = !DILocation(line: 0, scope: !68)
!1489 = !DILocation(line: 6, column: 1, scope: !68)
!1490 = distinct !DISubprogram(name: "eq", linkageName: "U8_val_eq_Cb", scope: !98, file: !98, line: 172, type: !1491, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1493, retainedNodes: !1494)
!1491 = !DISubroutineType(types: !1492)
!1492 = !{!47, !310, !310}
!1493 = !DISubprogram(name: "eq", linkageName: "U8_val_eq_Cb", scope: !310, file: !98, line: 172, type: !1491, scopeLine: 172, spFlags: 0)
!1494 = !{!1495}
!1495 = !DILocalVariable(name: "this", arg: 1, scope: !1490, file: !98, line: 172, type: !1496, flags: DIFlagArtificial)
!1496 = !DIBasicType(name: "U8", size: 8, encoding: DW_ATE_unsigned, flags: DIFlagArtificial)
!1497 = !DILocation(line: 0, scope: !1490)
!1498 = !DILocalVariable(name: "y", arg: 2, scope: !1490, file: !98, line: 172, type: !310)
!1499 = !DILocation(line: 172, column: 35, scope: !1490)
!1500 = distinct !DISubprogram(name: "eq", linkageName: "U8_box_eq_Cb", scope: !98, file: !98, line: 172, type: !1491, scopeLine: 172, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1501, retainedNodes: !1502)
!1501 = !DISubprogram(name: "eq", linkageName: "U8_box_eq_Cb", scope: !310, file: !98, line: 172, type: !1491, scopeLine: 172, spFlags: 0)
!1502 = !{!1503}
!1503 = !DILocalVariable(name: "this", arg: 1, scope: !1500, file: !98, line: 172, type: !1496, flags: DIFlagArtificial)
!1504 = !DILocation(line: 0, scope: !1500)
!1505 = !DILocalVariable(name: "y", arg: 2, scope: !1500, file: !98, line: 172, type: !310)
!1506 = !DILocation(line: 172, column: 35, scope: !1500)
!1507 = distinct !DISubprogram(name: "create", linkageName: "U8_val_create_pCC", scope: !98, file: !98, line: 43, type: !1508, scopeLine: 43, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1510, retainedNodes: !1511)
!1508 = !DISubroutineType(types: !1509)
!1509 = !{!310, !310, !310}
!1510 = !DISubprogram(name: "create", linkageName: "U8_val_create_pCC", scope: !310, file: !98, line: 43, type: !1508, scopeLine: 43, spFlags: 0)
!1511 = !{!1512}
!1512 = !DILocalVariable(name: "this", arg: 1, scope: !1507, file: !98, line: 43, type: !1496, flags: DIFlagArtificial)
!1513 = !DILocation(line: 0, scope: !1507)
!1514 = !DILocalVariable(name: "value", arg: 2, scope: !1507, file: !98, line: 43, type: !310)
!1515 = !DILocation(line: 43, column: 28, scope: !1507)
!1516 = distinct !DISubprogram(name: "ne", linkageName: "U8_val_ne_Cb", scope: !98, file: !98, line: 173, type: !1491, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1517, retainedNodes: !1518)
!1517 = !DISubprogram(name: "ne", linkageName: "U8_val_ne_Cb", scope: !310, file: !98, line: 173, type: !1491, scopeLine: 173, spFlags: 0)
!1518 = !{!1519}
!1519 = !DILocalVariable(name: "this", arg: 1, scope: !1516, file: !98, line: 173, type: !1496, flags: DIFlagArtificial)
!1520 = !DILocation(line: 0, scope: !1516)
!1521 = !DILocalVariable(name: "y", arg: 2, scope: !1516, file: !98, line: 173, type: !310)
!1522 = !DILocation(line: 173, column: 35, scope: !1516)
!1523 = distinct !DISubprogram(name: "ne", linkageName: "U8_box_ne_Cb", scope: !98, file: !98, line: 173, type: !1491, scopeLine: 173, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, declaration: !1524, retainedNodes: !1525)
!1524 = !DISubprogram(name: "ne", linkageName: "U8_box_ne_Cb", scope: !310, file: !98, line: 173, type: !1491, scopeLine: 173, spFlags: 0)
!1525 = !{!1526}
!1526 = !DILocalVariable(name: "this", arg: 1, scope: !1523, file: !98, line: 173, type: !1496, flags: DIFlagArtificial)
!1527 = !DILocation(line: 0, scope: !1523)
!1528 = !DILocalVariable(name: "y", arg: 2, scope: !1523, file: !98, line: 173, type: !310)
!1529 = !DILocation(line: 173, column: 35, scope: !1523)
