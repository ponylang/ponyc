#include <errno.h>
#include <stdio.h>
int main(void)
{
  errno = 2;
  fprintf(stderr, "record\n");
  return errno;
}
