actor Main
  new create(env: Env) => tick()
  be \noalloc\ tick() => None
