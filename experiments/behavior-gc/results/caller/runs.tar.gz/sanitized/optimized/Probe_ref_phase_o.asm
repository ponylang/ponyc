
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002a8740 <Probe_ref_phase_o>:
  2a8740:	53                   	push   %rbx
  2a8741:	e8 aa fe ff ff       	call   2a85f0 <Probe_ref_allocate_garbage_o>
  2a8746:	48 89 c3             	mov    %rax,%rbx
  2a8749:	e8 3a 46 f8 ff       	call   22cd88 <caller_poll>
  2a874e:	e8 75 55 f8 ff       	call   22dcc8 <caller_leave_phase>
  2a8753:	48 89 d8             	mov    %rbx,%rax
  2a8756:	5b                   	pop    %rbx
  2a8757:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
