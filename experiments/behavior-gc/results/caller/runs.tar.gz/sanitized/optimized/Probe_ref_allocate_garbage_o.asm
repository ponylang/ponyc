
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002a85f0 <Probe_ref_allocate_garbage_o>:
  2a85f0:	41 57                	push   %r15
  2a85f2:	41 56                	push   %r14
  2a85f4:	53                   	push   %rbx
  2a85f5:	45 31 f6             	xor    %r14d,%r14d
  2a85f8:	e8 5b 20 fa ff       	call   24a658 <pony_ctx>
  2a85fd:	48 89 c3             	mov    %rax,%rbx
  2a8600:	4c 8d 3d 69 30 00 00 	lea    0x3069(%rip),%r15        # 2ab670 <Cell_Desc>
  2a8607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  2a860e:	00 00 
  2a8610:	48 89 df             	mov    %rbx,%rdi
  2a8613:	31 f6                	xor    %esi,%esi
  2a8615:	e8 fe e7 f4 ff       	call   1f6e18 <pony_alloc_small>
  2a861a:	4c 89 38             	mov    %r15,(%rax)
  2a861d:	4c 89 70 08          	mov    %r14,0x8(%rax)
  2a8621:	48 89 c7             	mov    %rax,%rdi
  2a8624:	e8 df 41 f8 ff       	call   22c808 <caller_garbage>
  2a8629:	49 ff c6             	inc    %r14
  2a862c:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
  2a8633:	75 db                	jne    2a8610 <Probe_ref_allocate_garbage_o+0x20>
  2a8635:	48 8d 05 24 38 00 00 	lea    0x3824(%rip),%rax        # 2abe60 <None_Inst>
  2a863c:	5b                   	pop    %rbx
  2a863d:	41 5e                	pop    %r14
  2a863f:	41 5f                	pop    %r15
  2a8641:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
