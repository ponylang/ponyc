
measure:     file format elf64-x86-64


Disassembly of section .text:

000000000022cd88 <caller_poll>:
  22cd88:	55                   	push   %rbp
  22cd89:	48 89 e5             	mov    %rsp,%rbp
  22cd8c:	48 81 ec e0 01 00 00 	sub    $0x1e0,%rsp
  22cd93:	b0 00                	mov    $0x0,%al
  22cd95:	e8 be d8 01 00       	call   24a658 <pony_ctx>
  22cd9a:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
  22cd9e:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22cda2:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
  22cda6:	48 83 f9 00          	cmp    $0x0,%rcx
  22cdaa:	0f 95 c0             	setne  %al
  22cdad:	48 83 e1 07          	and    $0x7,%rcx
  22cdb1:	48 83 f9 00          	cmp    $0x0,%rcx
  22cdb5:	0f 94 c1             	sete   %cl
  22cdb8:	20 c8                	and    %cl,%al
  22cdba:	a8 01                	test   $0x1,%al
  22cdbc:	75 10                	jne    22cdce <caller_poll+0x46>
  22cdbe:	48 8b 75 e8          	mov    -0x18(%rbp),%rsi
  22cdc2:	48 8d 3d 27 69 09 00 	lea    0x96927(%rip),%rdi        # 2c36f0 <_ZL17kSuppressionTypes+0x13ba0>
  22cdc9:	e8 62 d8 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22cdce:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
  22cdd2:	48 83 c1 08          	add    $0x8,%rcx
  22cdd6:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
  22cdda:	48 83 f9 00          	cmp    $0x0,%rcx
  22cdde:	0f 95 c0             	setne  %al
  22cde1:	48 83 e1 07          	and    $0x7,%rcx
  22cde5:	48 83 f9 00          	cmp    $0x0,%rcx
  22cde9:	0f 94 c1             	sete   %cl
  22cdec:	20 c8                	and    %cl,%al
  22cdee:	a8 01                	test   $0x1,%al
  22cdf0:	75 10                	jne    22ce02 <caller_poll+0x7a>
  22cdf2:	48 8b 75 e0          	mov    -0x20(%rbp),%rsi
  22cdf6:	48 8d 3d 13 69 09 00 	lea    0x96913(%rip),%rdi        # 2c3710 <_ZL17kSuppressionTypes+0x13bc0>
  22cdfd:	e8 2e d8 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22ce02:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
  22ce06:	48 c1 e8 03          	shr    $0x3,%rax
  22ce0a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22ce11:	74 09                	je     22ce1c <caller_poll+0x94>
  22ce13:	48 8b 7d e0          	mov    -0x20(%rbp),%rdi
  22ce17:	e8 c4 68 f8 ff       	call   1b36e0 <__asan_report_load8>
  22ce1c:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
  22ce20:	48 8b 00             	mov    (%rax),%rax
  22ce23:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
  22ce27:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ce2e:	25 00 00 00 00 
  22ce33:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22ce3a:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
  22ce3e:	48 83 e0 07          	and    $0x7,%rax
  22ce42:	48 83 f8 00          	cmp    $0x0,%rax
  22ce46:	74 10                	je     22ce58 <caller_poll+0xd0>
  22ce48:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
  22ce4c:	48 8d 3d dd 68 09 00 	lea    0x968dd(%rip),%rdi        # 2c3730 <_ZL17kSuppressionTypes+0x13be0>
  22ce53:	e8 d8 d7 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22ce58:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22ce5c:	48 c1 e8 03          	shr    $0x3,%rax
  22ce60:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22ce66:	88 45 d7             	mov    %al,-0x29(%rbp)
  22ce69:	3c 00                	cmp    $0x0,%al
  22ce6b:	74 1c                	je     22ce89 <caller_poll+0x101>
  22ce6d:	8a 4d d7             	mov    -0x29(%rbp),%cl
  22ce70:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22ce74:	48 83 e0 07          	and    $0x7,%rax
  22ce78:	48 83 c0 03          	add    $0x3,%rax
  22ce7c:	38 c8                	cmp    %cl,%al
  22ce7e:	7c 09                	jl     22ce89 <caller_poll+0x101>
  22ce80:	48 8b 7d d8          	mov    -0x28(%rbp),%rdi
  22ce84:	e8 67 67 f8 ff       	call   1b35f0 <__asan_report_load4>
  22ce89:	48 8b 4d d8          	mov    -0x28(%rbp),%rcx
  22ce8d:	31 c0                	xor    %eax,%eax
  22ce8f:	83 39 01             	cmpl   $0x1,(%rcx)
  22ce92:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22ce95:	0f 85 cb 00 00 00    	jne    22cf66 <caller_poll+0x1de>
  22ce9b:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  22ce9f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  22cea3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ceaa:	25 00 00 00 00 
  22ceaf:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22ceb6:	48 83 c0 08          	add    $0x8,%rax
  22ceba:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
  22cebe:	48 83 e0 07          	and    $0x7,%rax
  22cec2:	48 83 f8 00          	cmp    $0x0,%rax
  22cec6:	74 10                	je     22ced8 <caller_poll+0x150>
  22cec8:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
  22cecc:	48 8d 3d 7d 68 09 00 	lea    0x9687d(%rip),%rdi        # 2c3750 <_ZL17kSuppressionTypes+0x13c00>
  22ced3:	e8 58 d7 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22ced8:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  22cedc:	48 c1 e8 03          	shr    $0x3,%rax
  22cee0:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22cee7:	74 09                	je     22cef2 <caller_poll+0x16a>
  22cee9:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
  22ceed:	e8 ee 67 f8 ff       	call   1b36e0 <__asan_report_load8>
  22cef2:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
  22cef6:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
  22cefa:	31 c0                	xor    %eax,%eax
  22cefc:	48 3b 0a             	cmp    (%rdx),%rcx
  22ceff:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22cf02:	75 62                	jne    22cf66 <caller_poll+0x1de>
  22cf04:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22cf0b:	25 00 00 00 00 
  22cf10:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22cf17:	48 05 20 20 00 00    	add    $0x2020,%rax
  22cf1d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  22cf21:	48 83 e0 07          	and    $0x7,%rax
  22cf25:	48 83 f8 00          	cmp    $0x0,%rax
  22cf29:	74 10                	je     22cf3b <caller_poll+0x1b3>
  22cf2b:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
  22cf2f:	48 8d 3d 3a 68 09 00 	lea    0x9683a(%rip),%rdi        # 2c3770 <_ZL17kSuppressionTypes+0x13c20>
  22cf36:	e8 f5 d6 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22cf3b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  22cf3f:	48 c1 e8 03          	shr    $0x3,%rax
  22cf43:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22cf4a:	74 09                	je     22cf55 <caller_poll+0x1cd>
  22cf4c:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
  22cf50:	e8 8b 67 f8 ff       	call   1b36e0 <__asan_report_load8>
  22cf55:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  22cf59:	48 81 38 00 04 00 00 	cmpq   $0x400,(%rax)
  22cf60:	0f 94 c0             	sete   %al
  22cf63:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22cf66:	8a 45 d6             	mov    -0x2a(%rbp),%al
  22cf69:	0f b6 f8             	movzbl %al,%edi
  22cf6c:	83 e7 01             	and    $0x1,%edi
  22cf6f:	48 8d 35 6a d6 e8 ff 	lea    -0x172996(%rip),%rsi        # ba5e0 <.str.18>
  22cf76:	e8 ed f5 ff ff       	call   22c568 <require>
  22cf7b:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22cf7f:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
  22cf83:	48 83 f9 00          	cmp    $0x0,%rcx
  22cf87:	0f 95 c0             	setne  %al
  22cf8a:	48 83 e1 07          	and    $0x7,%rcx
  22cf8e:	48 83 f9 00          	cmp    $0x0,%rcx
  22cf92:	0f 94 c1             	sete   %cl
  22cf95:	20 c8                	and    %cl,%al
  22cf97:	a8 01                	test   $0x1,%al
  22cf99:	75 10                	jne    22cfab <caller_poll+0x223>
  22cf9b:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
  22cf9f:	48 8d 3d ea 67 09 00 	lea    0x967ea(%rip),%rdi        # 2c3790 <_ZL17kSuppressionTypes+0x13c40>
  22cfa6:	e8 85 d6 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22cfab:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
  22cfaf:	48 83 c1 20          	add    $0x20,%rcx
  22cfb3:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
  22cfb7:	48 83 f9 00          	cmp    $0x0,%rcx
  22cfbb:	0f 95 c0             	setne  %al
  22cfbe:	48 83 e1 07          	and    $0x7,%rcx
  22cfc2:	48 83 f9 00          	cmp    $0x0,%rcx
  22cfc6:	0f 94 c1             	sete   %cl
  22cfc9:	20 c8                	and    %cl,%al
  22cfcb:	a8 01                	test   $0x1,%al
  22cfcd:	75 10                	jne    22cfdf <caller_poll+0x257>
  22cfcf:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
  22cfd3:	48 8d 3d d6 67 09 00 	lea    0x967d6(%rip),%rdi        # 2c37b0 <_ZL17kSuppressionTypes+0x13c60>
  22cfda:	e8 51 d6 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22cfdf:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  22cfe3:	48 c1 e8 03          	shr    $0x3,%rax
  22cfe7:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22cfee:	74 09                	je     22cff9 <caller_poll+0x271>
  22cff0:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
  22cff4:	e8 e7 66 f8 ff       	call   1b36e0 <__asan_report_load8>
  22cff9:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
  22cffd:	31 c0                	xor    %eax,%eax
  22cfff:	48 83 39 00          	cmpq   $0x0,(%rcx)
  22d003:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d006:	0f 85 4e 02 00 00    	jne    22d25a <caller_poll+0x4d2>
  22d00c:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22d010:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
  22d014:	48 83 f9 00          	cmp    $0x0,%rcx
  22d018:	0f 95 c0             	setne  %al
  22d01b:	48 83 e1 07          	and    $0x7,%rcx
  22d01f:	48 83 f9 00          	cmp    $0x0,%rcx
  22d023:	0f 94 c1             	sete   %cl
  22d026:	20 c8                	and    %cl,%al
  22d028:	a8 01                	test   $0x1,%al
  22d02a:	75 10                	jne    22d03c <caller_poll+0x2b4>
  22d02c:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
  22d030:	48 8d 3d 99 67 09 00 	lea    0x96799(%rip),%rdi        # 2c37d0 <_ZL17kSuppressionTypes+0x13c80>
  22d037:	e8 f4 d5 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d03c:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
  22d040:	48 83 c1 48          	add    $0x48,%rcx
  22d044:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
  22d048:	48 83 f9 00          	cmp    $0x0,%rcx
  22d04c:	0f 95 c0             	setne  %al
  22d04f:	48 83 e1 07          	and    $0x7,%rcx
  22d053:	48 83 f9 00          	cmp    $0x0,%rcx
  22d057:	0f 94 c1             	sete   %cl
  22d05a:	20 c8                	and    %cl,%al
  22d05c:	a8 01                	test   $0x1,%al
  22d05e:	75 10                	jne    22d070 <caller_poll+0x2e8>
  22d060:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
  22d064:	48 8d 3d 85 67 09 00 	lea    0x96785(%rip),%rdi        # 2c37f0 <_ZL17kSuppressionTypes+0x13ca0>
  22d06b:	e8 c0 d5 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d070:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  22d074:	48 c1 e8 03          	shr    $0x3,%rax
  22d078:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d07f:	74 09                	je     22d08a <caller_poll+0x302>
  22d081:	48 8b 7d 90          	mov    -0x70(%rbp),%rdi
  22d085:	e8 56 66 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d08a:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
  22d08e:	31 c0                	xor    %eax,%eax
  22d090:	48 83 39 00          	cmpq   $0x0,(%rcx)
  22d094:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d097:	0f 85 bd 01 00 00    	jne    22d25a <caller_poll+0x4d2>
  22d09d:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22d0a1:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
  22d0a5:	48 83 f9 00          	cmp    $0x0,%rcx
  22d0a9:	0f 95 c0             	setne  %al
  22d0ac:	48 83 e1 07          	and    $0x7,%rcx
  22d0b0:	48 83 f9 00          	cmp    $0x0,%rcx
  22d0b4:	0f 94 c1             	sete   %cl
  22d0b7:	20 c8                	and    %cl,%al
  22d0b9:	a8 01                	test   $0x1,%al
  22d0bb:	75 10                	jne    22d0cd <caller_poll+0x345>
  22d0bd:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
  22d0c1:	48 8d 3d 48 67 09 00 	lea    0x96748(%rip),%rdi        # 2c3810 <_ZL17kSuppressionTypes+0x13cc0>
  22d0c8:	e8 63 d5 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d0cd:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
  22d0d1:	48 83 c7 28          	add    $0x28,%rdi
  22d0d5:	e8 0e 76 fd ff       	call   2046e8 <ponyint_actormap_size>
  22d0da:	48 89 c1             	mov    %rax,%rcx
  22d0dd:	31 c0                	xor    %eax,%eax
  22d0df:	48 83 f9 00          	cmp    $0x0,%rcx
  22d0e3:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d0e6:	0f 85 6e 01 00 00    	jne    22d25a <caller_poll+0x4d2>
  22d0ec:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22d0f0:	48 89 4d 80          	mov    %rcx,-0x80(%rbp)
  22d0f4:	48 83 f9 00          	cmp    $0x0,%rcx
  22d0f8:	0f 95 c0             	setne  %al
  22d0fb:	48 83 e1 3f          	and    $0x3f,%rcx
  22d0ff:	48 83 f9 00          	cmp    $0x0,%rcx
  22d103:	0f 94 c1             	sete   %cl
  22d106:	20 c8                	and    %cl,%al
  22d108:	a8 01                	test   $0x1,%al
  22d10a:	75 10                	jne    22d11c <caller_poll+0x394>
  22d10c:	48 8b 75 80          	mov    -0x80(%rbp),%rsi
  22d110:	48 8d 3d 19 67 09 00 	lea    0x96719(%rip),%rdi        # 2c3830 <_ZL17kSuppressionTypes+0x13ce0>
  22d117:	e8 14 d5 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d11c:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
  22d120:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  22d127:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
  22d12e:	48 83 f9 00          	cmp    $0x0,%rcx
  22d132:	0f 95 c0             	setne  %al
  22d135:	48 83 e1 07          	and    $0x7,%rcx
  22d139:	48 83 f9 00          	cmp    $0x0,%rcx
  22d13d:	0f 94 c1             	sete   %cl
  22d140:	20 c8                	and    %cl,%al
  22d142:	a8 01                	test   $0x1,%al
  22d144:	75 13                	jne    22d159 <caller_poll+0x3d1>
  22d146:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
  22d14d:	48 8d 3d fc 66 09 00 	lea    0x966fc(%rip),%rdi        # 2c3850 <_ZL17kSuppressionTypes+0x13d00>
  22d154:	e8 d7 d4 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d159:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
  22d160:	48 83 c7 10          	add    $0x10,%rdi
  22d164:	e8 2f d3 ff ff       	call   22a498 <ponyint_objectmap_size>
  22d169:	48 89 c1             	mov    %rax,%rcx
  22d16c:	31 c0                	xor    %eax,%eax
  22d16e:	48 83 f9 00          	cmp    $0x0,%rcx
  22d172:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d175:	0f 85 df 00 00 00    	jne    22d25a <caller_poll+0x4d2>
  22d17b:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22d17f:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
  22d186:	48 83 f9 00          	cmp    $0x0,%rcx
  22d18a:	0f 95 c0             	setne  %al
  22d18d:	48 83 e1 3f          	and    $0x3f,%rcx
  22d191:	48 83 f9 00          	cmp    $0x0,%rcx
  22d195:	0f 94 c1             	sete   %cl
  22d198:	20 c8                	and    %cl,%al
  22d19a:	a8 01                	test   $0x1,%al
  22d19c:	75 13                	jne    22d1b1 <caller_poll+0x429>
  22d19e:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
  22d1a5:	48 8d 3d c4 66 09 00 	lea    0x966c4(%rip),%rdi        # 2c3870 <_ZL17kSuppressionTypes+0x13d20>
  22d1ac:	e8 7f d4 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d1b1:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
  22d1b8:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  22d1bf:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
  22d1c6:	48 83 f9 00          	cmp    $0x0,%rcx
  22d1ca:	0f 95 c0             	setne  %al
  22d1cd:	48 83 e1 07          	and    $0x7,%rcx
  22d1d1:	48 83 f9 00          	cmp    $0x0,%rcx
  22d1d5:	0f 94 c1             	sete   %cl
  22d1d8:	20 c8                	and    %cl,%al
  22d1da:	a8 01                	test   $0x1,%al
  22d1dc:	75 13                	jne    22d1f1 <caller_poll+0x469>
  22d1de:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
  22d1e5:	48 8d 3d a4 66 09 00 	lea    0x966a4(%rip),%rdi        # 2c3890 <_ZL17kSuppressionTypes+0x13d40>
  22d1ec:	e8 3f d4 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d1f1:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
  22d1f8:	48 83 c7 30          	add    $0x30,%rdi
  22d1fc:	e8 e7 74 fd ff       	call   2046e8 <ponyint_actormap_size>
  22d201:	48 89 c1             	mov    %rax,%rcx
  22d204:	31 c0                	xor    %eax,%eax
  22d206:	48 83 f9 00          	cmp    $0x0,%rcx
  22d20a:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d20d:	75 4b                	jne    22d25a <caller_poll+0x4d2>
  22d20f:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22d213:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
  22d21a:	48 83 f9 00          	cmp    $0x0,%rcx
  22d21e:	0f 95 c0             	setne  %al
  22d221:	48 83 e1 3f          	and    $0x3f,%rcx
  22d225:	48 83 f9 00          	cmp    $0x0,%rcx
  22d229:	0f 94 c1             	sete   %cl
  22d22c:	20 c8                	and    %cl,%al
  22d22e:	a8 01                	test   $0x1,%al
  22d230:	75 13                	jne    22d245 <caller_poll+0x4bd>
  22d232:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
  22d239:	48 8d 3d 70 66 09 00 	lea    0x96670(%rip),%rdi        # 2c38b0 <_ZL17kSuppressionTypes+0x13d60>
  22d240:	e8 eb d3 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d245:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
  22d24c:	48 83 c7 40          	add    $0x40,%rdi
  22d250:	e8 63 3f 00 00       	call   2311b8 <ponyint_heap_has_finalisers>
  22d255:	34 ff                	xor    $0xff,%al
  22d257:	88 45 a7             	mov    %al,-0x59(%rbp)
  22d25a:	8a 45 a7             	mov    -0x59(%rbp),%al
  22d25d:	0f b6 f8             	movzbl %al,%edi
  22d260:	83 e7 01             	and    $0x1,%edi
  22d263:	48 8d 35 d6 d3 e8 ff 	lea    -0x172c2a(%rip),%rsi        # ba640 <.str.19>
  22d26a:	e8 f9 f2 ff ff       	call   22c568 <require>
  22d26f:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22d273:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
  22d27a:	48 83 f9 00          	cmp    $0x0,%rcx
  22d27e:	0f 95 c0             	setne  %al
  22d281:	48 83 e1 3f          	and    $0x3f,%rcx
  22d285:	48 83 f9 00          	cmp    $0x0,%rcx
  22d289:	0f 94 c1             	sete   %cl
  22d28c:	20 c8                	and    %cl,%al
  22d28e:	a8 01                	test   $0x1,%al
  22d290:	75 13                	jne    22d2a5 <caller_poll+0x51d>
  22d292:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  22d299:	48 8d 3d 30 66 09 00 	lea    0x96630(%rip),%rdi        # 2c38d0 <_ZL17kSuppressionTypes+0x13d80>
  22d2a0:	e8 8b d3 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d2a5:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
  22d2ac:	48 83 c1 40          	add    $0x40,%rcx
  22d2b0:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
  22d2b7:	48 83 f9 00          	cmp    $0x0,%rcx
  22d2bb:	0f 95 c0             	setne  %al
  22d2be:	48 83 e1 3f          	and    $0x3f,%rcx
  22d2c2:	48 83 f9 00          	cmp    $0x0,%rcx
  22d2c6:	0f 94 c1             	sete   %cl
  22d2c9:	20 c8                	and    %cl,%al
  22d2cb:	a8 01                	test   $0x1,%al
  22d2cd:	75 13                	jne    22d2e2 <caller_poll+0x55a>
  22d2cf:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
  22d2d6:	48 8d 3d 13 66 09 00 	lea    0x96613(%rip),%rdi        # 2c38f0 <_ZL17kSuppressionTypes+0x13da0>
  22d2dd:	e8 4e d3 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d2e2:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
  22d2e9:	48 81 c1 80 00 00 00 	add    $0x80,%rcx
  22d2f0:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
  22d2f7:	48 83 f9 00          	cmp    $0x0,%rcx
  22d2fb:	0f 95 c0             	setne  %al
  22d2fe:	48 83 e1 3f          	and    $0x3f,%rcx
  22d302:	48 83 f9 00          	cmp    $0x0,%rcx
  22d306:	0f 94 c1             	sete   %cl
  22d309:	20 c8                	and    %cl,%al
  22d30b:	a8 01                	test   $0x1,%al
  22d30d:	75 13                	jne    22d322 <caller_poll+0x59a>
  22d30f:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
  22d316:	48 8d 3d f3 65 09 00 	lea    0x965f3(%rip),%rdi        # 2c3910 <_ZL17kSuppressionTypes+0x13dc0>
  22d31d:	e8 0e d3 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d322:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  22d329:	48 c1 e8 03          	shr    $0x3,%rax
  22d32d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d334:	74 0c                	je     22d342 <caller_poll+0x5ba>
  22d336:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
  22d33d:	e8 9e 63 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d342:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  22d349:	48 8b 00             	mov    (%rax),%rax
  22d34c:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
  22d353:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d35a:	25 00 00 00 00 
  22d35f:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d366:	48 05 30 20 00 00    	add    $0x2030,%rax
  22d36c:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
  22d373:	48 83 e0 07          	and    $0x7,%rax
  22d377:	48 83 f8 00          	cmp    $0x0,%rax
  22d37b:	74 13                	je     22d390 <caller_poll+0x608>
  22d37d:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  22d384:	48 8d 3d a5 65 09 00 	lea    0x965a5(%rip),%rdi        # 2c3930 <_ZL17kSuppressionTypes+0x13de0>
  22d38b:	e8 a0 d2 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d390:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  22d397:	48 c1 e8 03          	shr    $0x3,%rax
  22d39b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d3a2:	74 0c                	je     22d3b0 <caller_poll+0x628>
  22d3a4:	48 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%rdi
  22d3ab:	e8 30 63 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d3b0:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
  22d3b7:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
  22d3be:	48 3b 01             	cmp    (%rcx),%rax
  22d3c1:	0f 94 c0             	sete   %al
  22d3c4:	0f b6 f8             	movzbl %al,%edi
  22d3c7:	83 e7 01             	and    $0x1,%edi
  22d3ca:	48 8d 35 af d2 e8 ff 	lea    -0x172d51(%rip),%rsi        # ba680 <.str.20>
  22d3d1:	e8 92 f1 ff ff       	call   22c568 <require>
  22d3d6:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22d3da:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
  22d3e1:	48 83 f9 00          	cmp    $0x0,%rcx
  22d3e5:	0f 95 c0             	setne  %al
  22d3e8:	48 83 e1 3f          	and    $0x3f,%rcx
  22d3ec:	48 83 f9 00          	cmp    $0x0,%rcx
  22d3f0:	0f 94 c1             	sete   %cl
  22d3f3:	20 c8                	and    %cl,%al
  22d3f5:	a8 01                	test   $0x1,%al
  22d3f7:	75 13                	jne    22d40c <caller_poll+0x684>
  22d3f9:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
  22d400:	48 8d 3d 49 65 09 00 	lea    0x96549(%rip),%rdi        # 2c3950 <_ZL17kSuppressionTypes+0x13e00>
  22d407:	e8 24 d2 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d40c:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
  22d413:	48 83 c1 40          	add    $0x40,%rcx
  22d417:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
  22d41e:	48 83 f9 00          	cmp    $0x0,%rcx
  22d422:	0f 95 c0             	setne  %al
  22d425:	48 83 e1 3f          	and    $0x3f,%rcx
  22d429:	48 83 f9 00          	cmp    $0x0,%rcx
  22d42d:	0f 94 c1             	sete   %cl
  22d430:	20 c8                	and    %cl,%al
  22d432:	a8 01                	test   $0x1,%al
  22d434:	75 13                	jne    22d449 <caller_poll+0x6c1>
  22d436:	48 8b b5 28 ff ff ff 	mov    -0xd8(%rbp),%rsi
  22d43d:	48 8d 3d 2c 65 09 00 	lea    0x9652c(%rip),%rdi        # 2c3970 <_ZL17kSuppressionTypes+0x13e20>
  22d444:	e8 e7 d1 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d449:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  22d450:	48 83 c1 78          	add    $0x78,%rcx
  22d454:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
  22d45b:	48 83 f9 00          	cmp    $0x0,%rcx
  22d45f:	0f 95 c0             	setne  %al
  22d462:	48 83 e1 07          	and    $0x7,%rcx
  22d466:	48 83 f9 00          	cmp    $0x0,%rcx
  22d46a:	0f 94 c1             	sete   %cl
  22d46d:	20 c8                	and    %cl,%al
  22d46f:	a8 01                	test   $0x1,%al
  22d471:	75 13                	jne    22d486 <caller_poll+0x6fe>
  22d473:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
  22d47a:	48 8d 3d 0f 65 09 00 	lea    0x9650f(%rip),%rdi        # 2c3990 <_ZL17kSuppressionTypes+0x13e40>
  22d481:	e8 aa d1 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d486:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
  22d48d:	48 c1 e8 03          	shr    $0x3,%rax
  22d491:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d498:	74 0c                	je     22d4a6 <caller_poll+0x71e>
  22d49a:	48 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%rdi
  22d4a1:	e8 3a 62 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d4a6:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
  22d4ad:	48 8b 00             	mov    (%rax),%rax
  22d4b0:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
  22d4b7:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d4be:	25 00 00 00 00 
  22d4c3:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d4ca:	48 05 38 20 00 00    	add    $0x2038,%rax
  22d4d0:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
  22d4d7:	48 83 e0 07          	and    $0x7,%rax
  22d4db:	48 83 f8 00          	cmp    $0x0,%rax
  22d4df:	74 13                	je     22d4f4 <caller_poll+0x76c>
  22d4e1:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
  22d4e8:	48 8d 3d c1 64 09 00 	lea    0x964c1(%rip),%rdi        # 2c39b0 <_ZL17kSuppressionTypes+0x13e60>
  22d4ef:	e8 3c d1 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d4f4:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
  22d4fb:	48 c1 e8 03          	shr    $0x3,%rax
  22d4ff:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d506:	74 0c                	je     22d514 <caller_poll+0x78c>
  22d508:	48 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%rdi
  22d50f:	e8 7c 66 f8 ff       	call   1b3b90 <__asan_report_store8>
  22d514:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
  22d51b:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
  22d522:	48 89 08             	mov    %rcx,(%rax)
  22d525:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d52c:	25 00 00 00 00 
  22d531:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d538:	48 05 38 20 00 00    	add    $0x2038,%rax
  22d53e:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
  22d545:	48 83 e0 07          	and    $0x7,%rax
  22d549:	48 83 f8 00          	cmp    $0x0,%rax
  22d54d:	74 13                	je     22d562 <caller_poll+0x7da>
  22d54f:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
  22d556:	48 8d 3d 73 64 09 00 	lea    0x96473(%rip),%rdi        # 2c39d0 <_ZL17kSuppressionTypes+0x13e80>
  22d55d:	e8 ce d0 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d562:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
  22d569:	48 c1 e8 03          	shr    $0x3,%rax
  22d56d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d574:	74 0c                	je     22d582 <caller_poll+0x7fa>
  22d576:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
  22d57d:	e8 5e 61 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d582:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
  22d589:	48 8b 00             	mov    (%rax),%rax
  22d58c:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
  22d593:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d59a:	25 00 00 00 00 
  22d59f:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d5a6:	48 05 30 20 00 00    	add    $0x2030,%rax
  22d5ac:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  22d5b3:	48 83 e0 07          	and    $0x7,%rax
  22d5b7:	48 83 f8 00          	cmp    $0x0,%rax
  22d5bb:	74 13                	je     22d5d0 <caller_poll+0x848>
  22d5bd:	48 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%rsi
  22d5c4:	48 8d 3d 25 64 09 00 	lea    0x96425(%rip),%rdi        # 2c39f0 <_ZL17kSuppressionTypes+0x13ea0>
  22d5cb:	e8 60 d0 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d5d0:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  22d5d7:	48 c1 e8 03          	shr    $0x3,%rax
  22d5db:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d5e2:	74 0c                	je     22d5f0 <caller_poll+0x868>
  22d5e4:	48 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%rdi
  22d5eb:	e8 f0 60 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d5f0:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  22d5f7:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
  22d5fe:	48 3b 01             	cmp    (%rcx),%rax
  22d601:	0f 97 c0             	seta   %al
  22d604:	88 85 e7 fe ff ff    	mov    %al,-0x119(%rbp)
  22d60a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d611:	25 00 00 00 00 
  22d616:	8a 8d e7 fe ff ff    	mov    -0x119(%rbp),%cl
  22d61c:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d623:	48 05 49 20 00 00    	add    $0x2049,%rax
  22d629:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
  22d630:	80 e1 01             	and    $0x1,%cl
  22d633:	88 8d f6 fe ff ff    	mov    %cl,-0x10a(%rbp)
  22d639:	48 c1 e8 03          	shr    $0x3,%rax
  22d63d:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22d643:	88 85 f7 fe ff ff    	mov    %al,-0x109(%rbp)
  22d649:	3c 00                	cmp    $0x0,%al
  22d64b:	74 21                	je     22d66e <caller_poll+0x8e6>
  22d64d:	8a 8d f7 fe ff ff    	mov    -0x109(%rbp),%cl
  22d653:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  22d65a:	48 83 e0 07          	and    $0x7,%rax
  22d65e:	38 c8                	cmp    %cl,%al
  22d660:	7c 0c                	jl     22d66e <caller_poll+0x8e6>
  22d662:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
  22d669:	e8 52 62 f8 ff       	call   1b38c0 <__asan_report_store1>
  22d66e:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  22d675:	8a 8d f6 fe ff ff    	mov    -0x10a(%rbp),%cl
  22d67b:	88 08                	mov    %cl,(%rax)
  22d67d:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d684:	25 00 00 00 00 
  22d689:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d690:	48 83 c0 10          	add    $0x10,%rax
  22d694:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
  22d69b:	48 83 e0 07          	and    $0x7,%rax
  22d69f:	48 83 f8 00          	cmp    $0x0,%rax
  22d6a3:	74 13                	je     22d6b8 <caller_poll+0x930>
  22d6a5:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  22d6ac:	48 8d 3d 5d 63 09 00 	lea    0x9635d(%rip),%rdi        # 2c3a10 <_ZL17kSuppressionTypes+0x13ec0>
  22d6b3:	e8 78 cf fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d6b8:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  22d6bf:	48 c1 e8 03          	shr    $0x3,%rax
  22d6c3:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d6ca:	74 0c                	je     22d6d8 <caller_poll+0x950>
  22d6cc:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  22d6d3:	e8 08 60 f8 ff       	call   1b36e0 <__asan_report_load8>
  22d6d8:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  22d6df:	48 83 38 00          	cmpq   $0x0,(%rax)
  22d6e3:	0f 95 c0             	setne  %al
  22d6e6:	88 85 cf fe ff ff    	mov    %al,-0x131(%rbp)
  22d6ec:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d6f3:	25 00 00 00 00 
  22d6f8:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d6ff:	48 05 4a 20 00 00    	add    $0x204a,%rax
  22d705:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
  22d70c:	48 83 e0 01          	and    $0x1,%rax
  22d710:	48 83 f8 00          	cmp    $0x0,%rax
  22d714:	74 13                	je     22d729 <caller_poll+0x9a1>
  22d716:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
  22d71d:	48 8d 3d 0c 63 09 00 	lea    0x9630c(%rip),%rdi        # 2c3a30 <_ZL17kSuppressionTypes+0x13ee0>
  22d724:	e8 07 cf fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d729:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22d730:	8a 8d cf fe ff ff    	mov    -0x131(%rbp),%cl
  22d736:	80 e1 01             	and    $0x1,%cl
  22d739:	88 8d cd fe ff ff    	mov    %cl,-0x133(%rbp)
  22d73f:	48 c1 e8 03          	shr    $0x3,%rax
  22d743:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22d749:	88 85 ce fe ff ff    	mov    %al,-0x132(%rbp)
  22d74f:	3c 00                	cmp    $0x0,%al
  22d751:	74 21                	je     22d774 <caller_poll+0x9ec>
  22d753:	8a 8d ce fe ff ff    	mov    -0x132(%rbp),%cl
  22d759:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22d760:	48 83 e0 07          	and    $0x7,%rax
  22d764:	38 c8                	cmp    %cl,%al
  22d766:	7c 0c                	jl     22d774 <caller_poll+0x9ec>
  22d768:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
  22d76f:	e8 4c 61 f8 ff       	call   1b38c0 <__asan_report_store1>
  22d774:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22d77b:	8a 8d cd fe ff ff    	mov    -0x133(%rbp),%cl
  22d781:	88 08                	mov    %cl,(%rax)
  22d783:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d78a:	25 00 00 00 00 
  22d78f:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d796:	48 05 49 20 00 00    	add    $0x2049,%rax
  22d79c:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
  22d7a3:	48 c1 e8 03          	shr    $0x3,%rax
  22d7a7:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22d7ad:	88 85 cc fe ff ff    	mov    %al,-0x134(%rbp)
  22d7b3:	3c 00                	cmp    $0x0,%al
  22d7b5:	74 21                	je     22d7d8 <caller_poll+0xa50>
  22d7b7:	8a 8d cc fe ff ff    	mov    -0x134(%rbp),%cl
  22d7bd:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  22d7c4:	48 83 e0 07          	and    $0x7,%rax
  22d7c8:	38 c8                	cmp    %cl,%al
  22d7ca:	7c 0c                	jl     22d7d8 <caller_poll+0xa50>
  22d7cc:	48 8b bd c0 fe ff ff 	mov    -0x140(%rbp),%rdi
  22d7d3:	e8 38 5c f8 ff       	call   1b3410 <__asan_report_load1>
  22d7d8:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  22d7df:	8a 00                	mov    (%rax),%al
  22d7e1:	88 85 bf fe ff ff    	mov    %al,-0x141(%rbp)
  22d7e7:	3c 01                	cmp    $0x1,%al
  22d7e9:	76 17                	jbe    22d802 <caller_poll+0xa7a>
  22d7eb:	8a 85 bf fe ff ff    	mov    -0x141(%rbp),%al
  22d7f1:	0f b6 c0             	movzbl %al,%eax
  22d7f4:	89 c6                	mov    %eax,%esi
  22d7f6:	48 8d 3d 53 62 09 00 	lea    0x96253(%rip),%rdi        # 2c3a50 <_ZL17kSuppressionTypes+0x13f00>
  22d7fd:	e8 2e f3 fb ff       	call   1ecb30 <__ubsan_handle_load_invalid_value>
  22d802:	8a 85 bf fe ff ff    	mov    -0x141(%rbp),%al
  22d808:	3c 00                	cmp    $0x0,%al
  22d80a:	0f 84 69 02 00 00    	je     22da79 <caller_poll+0xcf1>
  22d810:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d817:	25 00 00 00 00 
  22d81c:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d823:	48 05 4a 20 00 00    	add    $0x204a,%rax
  22d829:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
  22d830:	48 83 e0 01          	and    $0x1,%rax
  22d834:	48 83 f8 00          	cmp    $0x0,%rax
  22d838:	74 13                	je     22d84d <caller_poll+0xac5>
  22d83a:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
  22d841:	48 8d 3d 28 62 09 00 	lea    0x96228(%rip),%rdi        # 2c3a70 <_ZL17kSuppressionTypes+0x13f20>
  22d848:	e8 e3 cd fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d84d:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22d854:	48 c1 e8 03          	shr    $0x3,%rax
  22d858:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22d85e:	88 85 af fe ff ff    	mov    %al,-0x151(%rbp)
  22d864:	3c 00                	cmp    $0x0,%al
  22d866:	74 21                	je     22d889 <caller_poll+0xb01>
  22d868:	8a 8d af fe ff ff    	mov    -0x151(%rbp),%cl
  22d86e:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22d875:	48 83 e0 07          	and    $0x7,%rax
  22d879:	38 c8                	cmp    %cl,%al
  22d87b:	7c 0c                	jl     22d889 <caller_poll+0xb01>
  22d87d:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
  22d884:	e8 87 5b f8 ff       	call   1b3410 <__asan_report_load1>
  22d889:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22d890:	8a 00                	mov    (%rax),%al
  22d892:	88 85 ae fe ff ff    	mov    %al,-0x152(%rbp)
  22d898:	3c 01                	cmp    $0x1,%al
  22d89a:	76 17                	jbe    22d8b3 <caller_poll+0xb2b>
  22d89c:	8a 85 ae fe ff ff    	mov    -0x152(%rbp),%al
  22d8a2:	0f b6 c0             	movzbl %al,%eax
  22d8a5:	89 c6                	mov    %eax,%esi
  22d8a7:	48 8d 3d e2 61 09 00 	lea    0x961e2(%rip),%rdi        # 2c3a90 <_ZL17kSuppressionTypes+0x13f40>
  22d8ae:	e8 7d f2 fb ff       	call   1ecb30 <__ubsan_handle_load_invalid_value>
  22d8b3:	8a 85 ae fe ff ff    	mov    -0x152(%rbp),%al
  22d8b9:	3c 00                	cmp    $0x0,%al
  22d8bb:	0f 84 b8 01 00 00    	je     22da79 <caller_poll+0xcf1>
  22d8c1:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d8c8:	25 00 00 00 00 
  22d8cd:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d8d4:	48 05 48 20 00 00    	add    $0x2048,%rax
  22d8da:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
  22d8e1:	48 83 e0 07          	and    $0x7,%rax
  22d8e5:	48 83 f8 00          	cmp    $0x0,%rax
  22d8e9:	74 13                	je     22d8fe <caller_poll+0xb76>
  22d8eb:	48 8b b5 a0 fe ff ff 	mov    -0x160(%rbp),%rsi
  22d8f2:	48 8d 3d b7 61 09 00 	lea    0x961b7(%rip),%rdi        # 2c3ab0 <_ZL17kSuppressionTypes+0x13f60>
  22d8f9:	e8 32 cd fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d8fe:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22d905:	48 c1 e8 03          	shr    $0x3,%rax
  22d909:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22d90f:	88 85 9f fe ff ff    	mov    %al,-0x161(%rbp)
  22d915:	3c 00                	cmp    $0x0,%al
  22d917:	74 21                	je     22d93a <caller_poll+0xbb2>
  22d919:	8a 8d 9f fe ff ff    	mov    -0x161(%rbp),%cl
  22d91f:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22d926:	48 83 e0 07          	and    $0x7,%rax
  22d92a:	38 c8                	cmp    %cl,%al
  22d92c:	7c 0c                	jl     22d93a <caller_poll+0xbb2>
  22d92e:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  22d935:	e8 d6 5a f8 ff       	call   1b3410 <__asan_report_load1>
  22d93a:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22d941:	8a 00                	mov    (%rax),%al
  22d943:	88 85 9e fe ff ff    	mov    %al,-0x162(%rbp)
  22d949:	3c 01                	cmp    $0x1,%al
  22d94b:	76 17                	jbe    22d964 <caller_poll+0xbdc>
  22d94d:	8a 85 9e fe ff ff    	mov    -0x162(%rbp),%al
  22d953:	0f b6 c0             	movzbl %al,%eax
  22d956:	89 c6                	mov    %eax,%esi
  22d958:	48 8d 3d 71 61 09 00 	lea    0x96171(%rip),%rdi        # 2c3ad0 <_ZL17kSuppressionTypes+0x13f80>
  22d95f:	e8 cc f1 fb ff       	call   1ecb30 <__ubsan_handle_load_invalid_value>
  22d964:	8a 85 9e fe ff ff    	mov    -0x162(%rbp),%al
  22d96a:	3c 00                	cmp    $0x0,%al
  22d96c:	0f 84 07 01 00 00    	je     22da79 <caller_poll+0xcf1>
  22d972:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  22d976:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
  22d97d:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  22d981:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
  22d988:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22d98f:	25 00 00 00 00 
  22d994:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22d99b:	48 83 c0 10          	add    $0x10,%rax
  22d99f:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
  22d9a6:	48 83 e0 07          	and    $0x7,%rax
  22d9aa:	48 83 f8 00          	cmp    $0x0,%rax
  22d9ae:	74 13                	je     22d9c3 <caller_poll+0xc3b>
  22d9b0:	48 8b b5 90 fe ff ff 	mov    -0x170(%rbp),%rsi
  22d9b7:	48 8d 3d 32 61 09 00 	lea    0x96132(%rip),%rdi        # 2c3af0 <_ZL17kSuppressionTypes+0x13fa0>
  22d9be:	e8 6d cc fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22d9c3:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
  22d9ca:	48 c1 e8 03          	shr    $0x3,%rax
  22d9ce:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22d9d5:	74 0c                	je     22d9e3 <caller_poll+0xc5b>
  22d9d7:	48 8b bd 90 fe ff ff 	mov    -0x170(%rbp),%rdi
  22d9de:	e8 fd 5c f8 ff       	call   1b36e0 <__asan_report_load8>
  22d9e3:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
  22d9ea:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
  22d9f1:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
  22d9f8:	48 8b 10             	mov    (%rax),%rdx
  22d9fb:	e8 18 19 fc ff       	call   1ef318 <probe_collect>
  22da00:	88 85 6f fe ff ff    	mov    %al,-0x191(%rbp)
  22da06:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22da0d:	25 00 00 00 00 
  22da12:	8a 8d 6f fe ff ff    	mov    -0x191(%rbp),%cl
  22da18:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22da1f:	48 05 4b 20 00 00    	add    $0x204b,%rax
  22da25:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
  22da2c:	80 e1 01             	and    $0x1,%cl
  22da2f:	88 8d 7e fe ff ff    	mov    %cl,-0x182(%rbp)
  22da35:	48 c1 e8 03          	shr    $0x3,%rax
  22da39:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22da3f:	88 85 7f fe ff ff    	mov    %al,-0x181(%rbp)
  22da45:	3c 00                	cmp    $0x0,%al
  22da47:	74 21                	je     22da6a <caller_poll+0xce2>
  22da49:	8a 8d 7f fe ff ff    	mov    -0x181(%rbp),%cl
  22da4f:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  22da56:	48 83 e0 07          	and    $0x7,%rax
  22da5a:	38 c8                	cmp    %cl,%al
  22da5c:	7c 0c                	jl     22da6a <caller_poll+0xce2>
  22da5e:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
  22da65:	e8 56 5e f8 ff       	call   1b38c0 <__asan_report_store1>
  22da6a:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  22da71:	8a 8d 7e fe ff ff    	mov    -0x182(%rbp),%cl
  22da77:	88 08                	mov    %cl,(%rax)
  22da79:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22da80:	25 00 00 00 00 
  22da85:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22da8c:	48 83 c0 10          	add    $0x10,%rax
  22da90:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
  22da97:	48 83 e0 07          	and    $0x7,%rax
  22da9b:	48 83 f8 00          	cmp    $0x0,%rax
  22da9f:	74 13                	je     22dab4 <caller_poll+0xd2c>
  22daa1:	48 8b b5 60 fe ff ff 	mov    -0x1a0(%rbp),%rsi
  22daa8:	48 8d 3d 61 60 09 00 	lea    0x96061(%rip),%rdi        # 2c3b10 <_ZL17kSuppressionTypes+0x13fc0>
  22daaf:	e8 7c cb fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22dab4:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  22dabb:	48 c1 e8 03          	shr    $0x3,%rax
  22dabf:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22dac6:	74 0c                	je     22dad4 <caller_poll+0xd4c>
  22dac8:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
  22dacf:	e8 bc 60 f8 ff       	call   1b3b90 <__asan_report_store8>
  22dad4:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  22dadb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  22dae2:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22dae6:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
  22daed:	48 83 f9 00          	cmp    $0x0,%rcx
  22daf1:	0f 95 c0             	setne  %al
  22daf4:	48 83 e1 3f          	and    $0x3f,%rcx
  22daf8:	48 83 f9 00          	cmp    $0x0,%rcx
  22dafc:	0f 94 c1             	sete   %cl
  22daff:	20 c8                	and    %cl,%al
  22db01:	a8 01                	test   $0x1,%al
  22db03:	75 13                	jne    22db18 <caller_poll+0xd90>
  22db05:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
  22db0c:	48 8d 3d 1d 60 09 00 	lea    0x9601d(%rip),%rdi        # 2c3b30 <_ZL17kSuppressionTypes+0x13fe0>
  22db13:	e8 18 cb fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22db18:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
  22db1f:	48 83 c1 40          	add    $0x40,%rcx
  22db23:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
  22db2a:	48 83 f9 00          	cmp    $0x0,%rcx
  22db2e:	0f 95 c0             	setne  %al
  22db31:	48 83 e1 3f          	and    $0x3f,%rcx
  22db35:	48 83 f9 00          	cmp    $0x0,%rcx
  22db39:	0f 94 c1             	sete   %cl
  22db3c:	20 c8                	and    %cl,%al
  22db3e:	a8 01                	test   $0x1,%al
  22db40:	75 13                	jne    22db55 <caller_poll+0xdcd>
  22db42:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
  22db49:	48 8d 3d 00 60 09 00 	lea    0x96000(%rip),%rdi        # 2c3b50 <_ZL17kSuppressionTypes+0x14000>
  22db50:	e8 db ca fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22db55:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
  22db5c:	48 83 c1 78          	add    $0x78,%rcx
  22db60:	48 89 8d 48 fe ff ff 	mov    %rcx,-0x1b8(%rbp)
  22db67:	48 83 f9 00          	cmp    $0x0,%rcx
  22db6b:	0f 95 c0             	setne  %al
  22db6e:	48 83 e1 07          	and    $0x7,%rcx
  22db72:	48 83 f9 00          	cmp    $0x0,%rcx
  22db76:	0f 94 c1             	sete   %cl
  22db79:	20 c8                	and    %cl,%al
  22db7b:	a8 01                	test   $0x1,%al
  22db7d:	75 13                	jne    22db92 <caller_poll+0xe0a>
  22db7f:	48 8b b5 48 fe ff ff 	mov    -0x1b8(%rbp),%rsi
  22db86:	48 8d 3d e3 5f 09 00 	lea    0x95fe3(%rip),%rdi        # 2c3b70 <_ZL17kSuppressionTypes+0x14020>
  22db8d:	e8 9e ca fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22db92:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
  22db99:	48 c1 e8 03          	shr    $0x3,%rax
  22db9d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22dba4:	74 0c                	je     22dbb2 <caller_poll+0xe2a>
  22dba6:	48 8b bd 48 fe ff ff 	mov    -0x1b8(%rbp),%rdi
  22dbad:	e8 2e 5b f8 ff       	call   1b36e0 <__asan_report_load8>
  22dbb2:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
  22dbb9:	48 8b 00             	mov    (%rax),%rax
  22dbbc:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
  22dbc3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22dbca:	25 00 00 00 00 
  22dbcf:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22dbd6:	48 05 40 20 00 00    	add    $0x2040,%rax
  22dbdc:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
  22dbe3:	48 83 e0 07          	and    $0x7,%rax
  22dbe7:	48 83 f8 00          	cmp    $0x0,%rax
  22dbeb:	74 13                	je     22dc00 <caller_poll+0xe78>
  22dbed:	48 8b b5 40 fe ff ff 	mov    -0x1c0(%rbp),%rsi
  22dbf4:	48 8d 3d 95 5f 09 00 	lea    0x95f95(%rip),%rdi        # 2c3b90 <_ZL17kSuppressionTypes+0x14040>
  22dbfb:	e8 30 ca fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22dc00:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  22dc07:	48 c1 e8 03          	shr    $0x3,%rax
  22dc0b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22dc12:	74 0c                	je     22dc20 <caller_poll+0xe98>
  22dc14:	48 8b bd 40 fe ff ff 	mov    -0x1c0(%rbp),%rdi
  22dc1b:	e8 70 5f f8 ff       	call   1b3b90 <__asan_report_store8>
  22dc20:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  22dc27:	48 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%rcx
  22dc2e:	48 89 08             	mov    %rcx,(%rax)
  22dc31:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22dc38:	25 00 00 00 00 
  22dc3d:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22dc44:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
  22dc4b:	48 83 e0 07          	and    $0x7,%rax
  22dc4f:	48 83 f8 00          	cmp    $0x0,%rax
  22dc53:	74 13                	je     22dc68 <caller_poll+0xee0>
  22dc55:	48 8b b5 30 fe ff ff 	mov    -0x1d0(%rbp),%rsi
  22dc5c:	48 8d 3d 4d 5f 09 00 	lea    0x95f4d(%rip),%rdi        # 2c3bb0 <_ZL17kSuppressionTypes+0x14060>
  22dc63:	e8 c8 c9 fb ff       	call   1ea630 <__ubsan_handle_type_mismatch_v1>
  22dc68:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22dc6f:	48 c1 e8 03          	shr    $0x3,%rax
  22dc73:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22dc79:	88 85 2f fe ff ff    	mov    %al,-0x1d1(%rbp)
  22dc7f:	3c 00                	cmp    $0x0,%al
  22dc81:	74 25                	je     22dca8 <caller_poll+0xf20>
  22dc83:	8a 8d 2f fe ff ff    	mov    -0x1d1(%rbp),%cl
  22dc89:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22dc90:	48 83 e0 07          	and    $0x7,%rax
  22dc94:	48 83 c0 03          	add    $0x3,%rax
  22dc98:	38 c8                	cmp    %cl,%al
  22dc9a:	7c 0c                	jl     22dca8 <caller_poll+0xf20>
  22dc9c:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
  22dca3:	e8 f8 5d f8 ff       	call   1b3aa0 <__asan_report_store4>
  22dca8:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22dcaf:	c7 00 02 00 00 00    	movl   $0x2,(%rax)
  22dcb5:	48 81 c4 e0 01 00 00 	add    $0x1e0,%rsp
  22dcbc:	5d                   	pop    %rbp
  22dcbd:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
