
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002a8370 <Probe_Dispatch>:
  2a8370:	55                   	push   %rbp
  2a8371:	41 57                	push   %r15
  2a8373:	41 56                	push   %r14
  2a8375:	41 55                	push   %r13
  2a8377:	41 54                	push   %r12
  2a8379:	53                   	push   %rbx
  2a837a:	48 83 ec 38          	sub    $0x38,%rsp
  2a837e:	48 89 f3             	mov    %rsi,%rbx
  2a8381:	83 7a 04 06          	cmpl   $0x6,0x4(%rdx)
  2a8385:	4c 8b 7a 10          	mov    0x10(%rdx),%r15
  2a8389:	75 40                	jne    2a83cb <Probe_Dispatch+0x5b>
  2a838b:	49 89 fe             	mov    %rdi,%r14
  2a838e:	e8 c5 22 fa ff       	call   24a658 <pony_ctx>
  2a8393:	bf 01 00 00 00       	mov    $0x1,%edi
  2a8398:	be 01 00 00 00       	mov    $0x1,%esi
  2a839d:	e8 96 be f4 ff       	call   1f4238 <pony_alloc_msg>
  2a83a2:	4c 89 78 10          	mov    %r15,0x10(%rax)
  2a83a6:	4c 89 f7             	mov    %r14,%rdi
  2a83a9:	48 89 de             	mov    %rbx,%rsi
  2a83ac:	48 89 c2             	mov    %rax,%rdx
  2a83af:	48 89 c1             	mov    %rax,%rcx
  2a83b2:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  2a83b8:	48 83 c4 38          	add    $0x38,%rsp
  2a83bc:	5b                   	pop    %rbx
  2a83bd:	41 5c                	pop    %r12
  2a83bf:	41 5d                	pop    %r13
  2a83c1:	41 5e                	pop    %r14
  2a83c3:	41 5f                	pop    %r15
  2a83c5:	5d                   	pop    %rbp
  2a83c6:	e9 4d c0 f4 ff       	jmp    1f4418 <pony_sendv>
  2a83cb:	e8 88 22 fa ff       	call   24a658 <pony_ctx>
  2a83d0:	49 89 c6             	mov    %rax,%r14
  2a83d3:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  2a83d8:	48 8d 05 db e2 df ff 	lea    -0x201d25(%rip),%rax        # a66ba <_ZN11__sanitizerL10kExtraRegsE+0x7f2a>
  2a83df:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  2a83e4:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  2a83e9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2a83ee:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
  2a83f3:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  2a83f8:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2a83ff:	00 
  2a8400:	48 8d 2d 99 0b e2 ff 	lea    -0x1df467(%rip),%rbp        # c8fa0 <.str.162+0x20>
  2a8407:	4c 89 f7             	mov    %r14,%rdi
  2a840a:	48 89 de             	mov    %rbx,%rsi
  2a840d:	48 89 ea             	mov    %rbp,%rdx
  2a8410:	b9 11 00 00 00       	mov    $0x11,%ecx
  2a8415:	41 b8 0e 00 00 00    	mov    $0xe,%r8d
  2a841b:	45 31 c9             	xor    %r9d,%r9d
  2a841e:	e8 15 2f f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a8423:	4c 89 f7             	mov    %r14,%rdi
  2a8426:	31 f6                	xor    %esi,%esi
  2a8428:	e8 eb e9 f4 ff       	call   1f6e18 <pony_alloc_small>
  2a842d:	49 89 c4             	mov    %rax,%r12
  2a8430:	48 8d 05 39 32 00 00 	lea    0x3239(%rip),%rax        # 2ab670 <Cell_Desc>
  2a8437:	49 89 04 24          	mov    %rax,(%r12)
  2a843b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
  2a8440:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  2a8445:	48 8d 05 f8 89 df ff 	lea    -0x207608(%rip),%rax        # a0e44 <_ZN11__sanitizerL10kExtraRegsE+0x26b4>
  2a844c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2a8451:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  2a8456:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2a845b:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  2a8460:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2a8467:	00 
  2a8468:	4c 89 f7             	mov    %r14,%rdi
  2a846b:	48 89 de             	mov    %rbx,%rsi
  2a846e:	48 89 ea             	mov    %rbp,%rdx
  2a8471:	b9 12 00 00 00       	mov    $0x12,%ecx
  2a8476:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
  2a847c:	45 31 c9             	xor    %r9d,%r9d
  2a847f:	e8 b4 2e f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a8484:	e8 b7 02 00 00       	call   2a8740 <Probe_ref_phase_o>
  2a8489:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2a848d:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2a8492:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2a8499:	00 00 
  2a849b:	4c 8d 2d ce 0b e2 ff 	lea    -0x1df432(%rip),%r13        # c9070 <.str.162+0xf0>
  2a84a2:	4c 89 f7             	mov    %r14,%rdi
  2a84a5:	48 89 de             	mov    %rbx,%rsi
  2a84a8:	48 89 ea             	mov    %rbp,%rdx
  2a84ab:	49 89 ef             	mov    %rbp,%r15
  2a84ae:	b9 13 00 00 00       	mov    $0x13,%ecx
  2a84b3:	41 b8 15 00 00 00    	mov    $0x15,%r8d
  2a84b9:	4d 89 e9             	mov    %r13,%r9
  2a84bc:	e8 77 2e f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a84c1:	4c 89 f7             	mov    %r14,%rdi
  2a84c4:	31 f6                	xor    %esi,%esi
  2a84c6:	e8 4d e9 f4 ff       	call   1f6e18 <pony_alloc_small>
  2a84cb:	48 89 c5             	mov    %rax,%rbp
  2a84ce:	48 8d 05 9b 31 00 00 	lea    0x319b(%rip),%rax        # 2ab670 <Cell_Desc>
  2a84d5:	48 89 45 00          	mov    %rax,0x0(%rbp)
  2a84d9:	48 c7 45 08 d3 00 00 	movq   $0xd3,0x8(%rbp)
  2a84e0:	00 
  2a84e1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2a84e5:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2a84ea:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2a84f1:	00 00 
  2a84f3:	4c 89 f7             	mov    %r14,%rdi
  2a84f6:	48 89 de             	mov    %rbx,%rsi
  2a84f9:	4c 89 fa             	mov    %r15,%rdx
  2a84fc:	b9 14 00 00 00       	mov    $0x14,%ecx
  2a8501:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2a8507:	4d 89 e9             	mov    %r13,%r9
  2a850a:	e8 29 2e f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a850f:	4c 89 e7             	mov    %r12,%rdi
  2a8512:	48 89 ee             	mov    %rbp,%rsi
  2a8515:	e8 ae 59 f8 ff       	call   22dec8 <caller_addresses>
  2a851a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2a851e:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2a8523:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2a852a:	00 00 
  2a852c:	4c 89 f7             	mov    %r14,%rdi
  2a852f:	48 89 de             	mov    %rbx,%rsi
  2a8532:	4c 89 fa             	mov    %r15,%rdx
  2a8535:	4d 89 fd             	mov    %r15,%r13
  2a8538:	b9 15 00 00 00       	mov    $0x15,%ecx
  2a853d:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  2a8543:	4c 8d 0d 26 0b e2 ff 	lea    -0x1df4da(%rip),%r9        # c9070 <.str.162+0xf0>
  2a854a:	e8 e9 2d f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a854f:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  2a8554:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2a8558:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2a855d:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2a8564:	00 00 
  2a8566:	4c 89 f7             	mov    %r14,%rdi
  2a8569:	48 89 de             	mov    %rbx,%rsi
  2a856c:	4c 89 ea             	mov    %r13,%rdx
  2a856f:	b9 16 00 00 00       	mov    $0x16,%ecx
  2a8574:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  2a857a:	4c 8d 0d ef 0a e2 ff 	lea    -0x1df511(%rip),%r9        # c9070 <.str.162+0xf0>
  2a8581:	e8 b2 2d f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a8586:	49 8d 47 05          	lea    0x5(%r15),%rax
  2a858a:	49 89 44 24 08       	mov    %rax,0x8(%r12)
  2a858f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2a8593:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2a8598:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2a859f:	00 00 
  2a85a1:	4c 89 f7             	mov    %r14,%rdi
  2a85a4:	48 89 de             	mov    %rbx,%rsi
  2a85a7:	4c 89 ea             	mov    %r13,%rdx
  2a85aa:	b9 17 00 00 00       	mov    $0x17,%ecx
  2a85af:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2a85b5:	4c 8d 0d b4 0a e2 ff 	lea    -0x1df54c(%rip),%r9        # c9070 <.str.162+0xf0>
  2a85bc:	e8 77 2d f8 ff       	call   22b338 <ponyint_gc_root_audit>
  2a85c1:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  2a85c6:	48 8b 55 08          	mov    0x8(%rbp),%rdx
  2a85ca:	4c 89 ff             	mov    %r15,%rdi
  2a85cd:	e8 e6 5d f8 ff       	call   22e3b8 <caller_result>
  2a85d2:	48 83 c4 38          	add    $0x38,%rsp
  2a85d6:	5b                   	pop    %rbx
  2a85d7:	41 5c                	pop    %r12
  2a85d9:	41 5d                	pop    %r13
  2a85db:	41 5e                	pop    %r14
  2a85dd:	41 5f                	pop    %r15
  2a85df:	5d                   	pop    %rbp
  2a85e0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
