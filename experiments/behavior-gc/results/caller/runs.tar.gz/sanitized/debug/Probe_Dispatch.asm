
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002aa250 <Probe_Dispatch>:
  2aa250:	50                   	push   %rax
  2aa251:	48 89 f7             	mov    %rsi,%rdi
  2aa254:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
  2aa258:	75 0b                	jne    2aa265 <Probe_Dispatch+0x15>
  2aa25a:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  2aa25e:	e8 bd 03 00 00       	call   2aa620 <Probe_tag_measure_pWo>
  2aa263:	58                   	pop    %rax
  2aa264:	c3                   	ret
  2aa265:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  2aa269:	e8 52 03 00 00       	call   2aa5c0 <Probe_tag_create_pWo>
  2aa26e:	58                   	pop    %rax
  2aa26f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
