
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002aa480 <Probe_ref_phase_o>:
  2aa480:	50                   	push   %rax
  2aa481:	48 89 3c 24          	mov    %rdi,(%rsp)
  2aa485:	e8 e6 fd ff ff       	call   2aa270 <Probe_ref_allocate_garbage_o>
  2aa48a:	e8 59 47 f8 ff       	call   22ebe8 <caller_poll>
  2aa48f:	e8 94 56 f8 ff       	call   22fb28 <caller_leave_phase>
  2aa494:	48 8d 3d e5 53 00 00 	lea    0x53e5(%rip),%rdi        # 2af880 <None_Inst>
  2aa49b:	e8 70 09 00 00       	call   2aae10 <None_val_create_o>
  2aa4a0:	59                   	pop    %rcx
  2aa4a1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
