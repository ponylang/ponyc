
measure:     file format elf64-x86-64


Disassembly of section .text:

000000000022ebe8 <caller_poll>:
  22ebe8:	55                   	push   %rbp
  22ebe9:	48 89 e5             	mov    %rsp,%rbp
  22ebec:	48 81 ec e0 01 00 00 	sub    $0x1e0,%rsp
  22ebf3:	b0 00                	mov    $0x0,%al
  22ebf5:	e8 be d8 01 00       	call   24c4b8 <pony_ctx>
  22ebfa:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
  22ebfe:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22ec02:	48 89 4d e8          	mov    %rcx,-0x18(%rbp)
  22ec06:	48 83 f9 00          	cmp    $0x0,%rcx
  22ec0a:	0f 95 c0             	setne  %al
  22ec0d:	48 83 e1 07          	and    $0x7,%rcx
  22ec11:	48 83 f9 00          	cmp    $0x0,%rcx
  22ec15:	0f 94 c1             	sete   %cl
  22ec18:	20 c8                	and    %cl,%al
  22ec1a:	a8 01                	test   $0x1,%al
  22ec1c:	75 10                	jne    22ec2e <caller_poll+0x46>
  22ec1e:	48 8b 75 e8          	mov    -0x18(%rbp),%rsi
  22ec22:	48 8d 3d e7 84 09 00 	lea    0x984e7(%rip),%rdi        # 2c7110 <_ZL17kSuppressionTypes+0x13ba0>
  22ec29:	e8 62 d8 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ec2e:	48 8b 4d e8          	mov    -0x18(%rbp),%rcx
  22ec32:	48 83 c1 08          	add    $0x8,%rcx
  22ec36:	48 89 4d e0          	mov    %rcx,-0x20(%rbp)
  22ec3a:	48 83 f9 00          	cmp    $0x0,%rcx
  22ec3e:	0f 95 c0             	setne  %al
  22ec41:	48 83 e1 07          	and    $0x7,%rcx
  22ec45:	48 83 f9 00          	cmp    $0x0,%rcx
  22ec49:	0f 94 c1             	sete   %cl
  22ec4c:	20 c8                	and    %cl,%al
  22ec4e:	a8 01                	test   $0x1,%al
  22ec50:	75 10                	jne    22ec62 <caller_poll+0x7a>
  22ec52:	48 8b 75 e0          	mov    -0x20(%rbp),%rsi
  22ec56:	48 8d 3d d3 84 09 00 	lea    0x984d3(%rip),%rdi        # 2c7130 <_ZL17kSuppressionTypes+0x13bc0>
  22ec5d:	e8 2e d8 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ec62:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
  22ec66:	48 c1 e8 03          	shr    $0x3,%rax
  22ec6a:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22ec71:	74 09                	je     22ec7c <caller_poll+0x94>
  22ec73:	48 8b 7d e0          	mov    -0x20(%rbp),%rdi
  22ec77:	e8 c4 68 f8 ff       	call   1b5540 <__asan_report_load8>
  22ec7c:	48 8b 45 e0          	mov    -0x20(%rbp),%rax
  22ec80:	48 8b 00             	mov    (%rax),%rax
  22ec83:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
  22ec87:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ec8e:	25 00 00 00 00 
  22ec93:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22ec9a:	48 89 45 d8          	mov    %rax,-0x28(%rbp)
  22ec9e:	48 83 e0 07          	and    $0x7,%rax
  22eca2:	48 83 f8 00          	cmp    $0x0,%rax
  22eca6:	74 10                	je     22ecb8 <caller_poll+0xd0>
  22eca8:	48 8b 75 d8          	mov    -0x28(%rbp),%rsi
  22ecac:	48 8d 3d 9d 84 09 00 	lea    0x9849d(%rip),%rdi        # 2c7150 <_ZL17kSuppressionTypes+0x13be0>
  22ecb3:	e8 d8 d7 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ecb8:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22ecbc:	48 c1 e8 03          	shr    $0x3,%rax
  22ecc0:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22ecc6:	88 45 d7             	mov    %al,-0x29(%rbp)
  22ecc9:	3c 00                	cmp    $0x0,%al
  22eccb:	74 1c                	je     22ece9 <caller_poll+0x101>
  22eccd:	8a 4d d7             	mov    -0x29(%rbp),%cl
  22ecd0:	48 8b 45 d8          	mov    -0x28(%rbp),%rax
  22ecd4:	48 83 e0 07          	and    $0x7,%rax
  22ecd8:	48 83 c0 03          	add    $0x3,%rax
  22ecdc:	38 c8                	cmp    %cl,%al
  22ecde:	7c 09                	jl     22ece9 <caller_poll+0x101>
  22ece0:	48 8b 7d d8          	mov    -0x28(%rbp),%rdi
  22ece4:	e8 67 67 f8 ff       	call   1b5450 <__asan_report_load4>
  22ece9:	48 8b 4d d8          	mov    -0x28(%rbp),%rcx
  22eced:	31 c0                	xor    %eax,%eax
  22ecef:	83 39 01             	cmpl   $0x1,(%rcx)
  22ecf2:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22ecf5:	0f 85 cb 00 00 00    	jne    22edc6 <caller_poll+0x1de>
  22ecfb:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  22ecff:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
  22ed03:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ed0a:	25 00 00 00 00 
  22ed0f:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22ed16:	48 83 c0 08          	add    $0x8,%rax
  22ed1a:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
  22ed1e:	48 83 e0 07          	and    $0x7,%rax
  22ed22:	48 83 f8 00          	cmp    $0x0,%rax
  22ed26:	74 10                	je     22ed38 <caller_poll+0x150>
  22ed28:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
  22ed2c:	48 8d 3d 3d 84 09 00 	lea    0x9843d(%rip),%rdi        # 2c7170 <_ZL17kSuppressionTypes+0x13c00>
  22ed33:	e8 58 d7 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ed38:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  22ed3c:	48 c1 e8 03          	shr    $0x3,%rax
  22ed40:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22ed47:	74 09                	je     22ed52 <caller_poll+0x16a>
  22ed49:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
  22ed4d:	e8 ee 67 f8 ff       	call   1b5540 <__asan_report_load8>
  22ed52:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
  22ed56:	48 8b 55 c8          	mov    -0x38(%rbp),%rdx
  22ed5a:	31 c0                	xor    %eax,%eax
  22ed5c:	48 3b 0a             	cmp    (%rdx),%rcx
  22ed5f:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22ed62:	75 62                	jne    22edc6 <caller_poll+0x1de>
  22ed64:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22ed6b:	25 00 00 00 00 
  22ed70:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22ed77:	48 05 20 20 00 00    	add    $0x2020,%rax
  22ed7d:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
  22ed81:	48 83 e0 07          	and    $0x7,%rax
  22ed85:	48 83 f8 00          	cmp    $0x0,%rax
  22ed89:	74 10                	je     22ed9b <caller_poll+0x1b3>
  22ed8b:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
  22ed8f:	48 8d 3d fa 83 09 00 	lea    0x983fa(%rip),%rdi        # 2c7190 <_ZL17kSuppressionTypes+0x13c20>
  22ed96:	e8 f5 d6 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ed9b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  22ed9f:	48 c1 e8 03          	shr    $0x3,%rax
  22eda3:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22edaa:	74 09                	je     22edb5 <caller_poll+0x1cd>
  22edac:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
  22edb0:	e8 8b 67 f8 ff       	call   1b5540 <__asan_report_load8>
  22edb5:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  22edb9:	48 81 38 00 04 00 00 	cmpq   $0x400,(%rax)
  22edc0:	0f 94 c0             	sete   %al
  22edc3:	88 45 d6             	mov    %al,-0x2a(%rbp)
  22edc6:	8a 45 d6             	mov    -0x2a(%rbp),%al
  22edc9:	0f b6 f8             	movzbl %al,%edi
  22edcc:	83 e7 01             	and    $0x1,%edi
  22edcf:	48 8d 35 aa c2 e8 ff 	lea    -0x173d56(%rip),%rsi        # bb080 <.str.18>
  22edd6:	e8 ed f5 ff ff       	call   22e3c8 <require>
  22eddb:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22eddf:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
  22ede3:	48 83 f9 00          	cmp    $0x0,%rcx
  22ede7:	0f 95 c0             	setne  %al
  22edea:	48 83 e1 07          	and    $0x7,%rcx
  22edee:	48 83 f9 00          	cmp    $0x0,%rcx
  22edf2:	0f 94 c1             	sete   %cl
  22edf5:	20 c8                	and    %cl,%al
  22edf7:	a8 01                	test   $0x1,%al
  22edf9:	75 10                	jne    22ee0b <caller_poll+0x223>
  22edfb:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
  22edff:	48 8d 3d aa 83 09 00 	lea    0x983aa(%rip),%rdi        # 2c71b0 <_ZL17kSuppressionTypes+0x13c40>
  22ee06:	e8 85 d6 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ee0b:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
  22ee0f:	48 83 c1 20          	add    $0x20,%rcx
  22ee13:	48 89 4d a8          	mov    %rcx,-0x58(%rbp)
  22ee17:	48 83 f9 00          	cmp    $0x0,%rcx
  22ee1b:	0f 95 c0             	setne  %al
  22ee1e:	48 83 e1 07          	and    $0x7,%rcx
  22ee22:	48 83 f9 00          	cmp    $0x0,%rcx
  22ee26:	0f 94 c1             	sete   %cl
  22ee29:	20 c8                	and    %cl,%al
  22ee2b:	a8 01                	test   $0x1,%al
  22ee2d:	75 10                	jne    22ee3f <caller_poll+0x257>
  22ee2f:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
  22ee33:	48 8d 3d 96 83 09 00 	lea    0x98396(%rip),%rdi        # 2c71d0 <_ZL17kSuppressionTypes+0x13c60>
  22ee3a:	e8 51 d6 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ee3f:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  22ee43:	48 c1 e8 03          	shr    $0x3,%rax
  22ee47:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22ee4e:	74 09                	je     22ee59 <caller_poll+0x271>
  22ee50:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
  22ee54:	e8 e7 66 f8 ff       	call   1b5540 <__asan_report_load8>
  22ee59:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
  22ee5d:	31 c0                	xor    %eax,%eax
  22ee5f:	48 83 39 00          	cmpq   $0x0,(%rcx)
  22ee63:	88 45 a7             	mov    %al,-0x59(%rbp)
  22ee66:	0f 85 4e 02 00 00    	jne    22f0ba <caller_poll+0x4d2>
  22ee6c:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22ee70:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
  22ee74:	48 83 f9 00          	cmp    $0x0,%rcx
  22ee78:	0f 95 c0             	setne  %al
  22ee7b:	48 83 e1 07          	and    $0x7,%rcx
  22ee7f:	48 83 f9 00          	cmp    $0x0,%rcx
  22ee83:	0f 94 c1             	sete   %cl
  22ee86:	20 c8                	and    %cl,%al
  22ee88:	a8 01                	test   $0x1,%al
  22ee8a:	75 10                	jne    22ee9c <caller_poll+0x2b4>
  22ee8c:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
  22ee90:	48 8d 3d 59 83 09 00 	lea    0x98359(%rip),%rdi        # 2c71f0 <_ZL17kSuppressionTypes+0x13c80>
  22ee97:	e8 f4 d5 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ee9c:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
  22eea0:	48 83 c1 48          	add    $0x48,%rcx
  22eea4:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
  22eea8:	48 83 f9 00          	cmp    $0x0,%rcx
  22eeac:	0f 95 c0             	setne  %al
  22eeaf:	48 83 e1 07          	and    $0x7,%rcx
  22eeb3:	48 83 f9 00          	cmp    $0x0,%rcx
  22eeb7:	0f 94 c1             	sete   %cl
  22eeba:	20 c8                	and    %cl,%al
  22eebc:	a8 01                	test   $0x1,%al
  22eebe:	75 10                	jne    22eed0 <caller_poll+0x2e8>
  22eec0:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
  22eec4:	48 8d 3d 45 83 09 00 	lea    0x98345(%rip),%rdi        # 2c7210 <_ZL17kSuppressionTypes+0x13ca0>
  22eecb:	e8 c0 d5 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22eed0:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  22eed4:	48 c1 e8 03          	shr    $0x3,%rax
  22eed8:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22eedf:	74 09                	je     22eeea <caller_poll+0x302>
  22eee1:	48 8b 7d 90          	mov    -0x70(%rbp),%rdi
  22eee5:	e8 56 66 f8 ff       	call   1b5540 <__asan_report_load8>
  22eeea:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
  22eeee:	31 c0                	xor    %eax,%eax
  22eef0:	48 83 39 00          	cmpq   $0x0,(%rcx)
  22eef4:	88 45 a7             	mov    %al,-0x59(%rbp)
  22eef7:	0f 85 bd 01 00 00    	jne    22f0ba <caller_poll+0x4d2>
  22eefd:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
  22ef01:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
  22ef05:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef09:	0f 95 c0             	setne  %al
  22ef0c:	48 83 e1 07          	and    $0x7,%rcx
  22ef10:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef14:	0f 94 c1             	sete   %cl
  22ef17:	20 c8                	and    %cl,%al
  22ef19:	a8 01                	test   $0x1,%al
  22ef1b:	75 10                	jne    22ef2d <caller_poll+0x345>
  22ef1d:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
  22ef21:	48 8d 3d 08 83 09 00 	lea    0x98308(%rip),%rdi        # 2c7230 <_ZL17kSuppressionTypes+0x13cc0>
  22ef28:	e8 63 d5 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ef2d:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
  22ef31:	48 83 c7 28          	add    $0x28,%rdi
  22ef35:	e8 0e 76 fd ff       	call   206548 <ponyint_actormap_size>
  22ef3a:	48 89 c1             	mov    %rax,%rcx
  22ef3d:	31 c0                	xor    %eax,%eax
  22ef3f:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef43:	88 45 a7             	mov    %al,-0x59(%rbp)
  22ef46:	0f 85 6e 01 00 00    	jne    22f0ba <caller_poll+0x4d2>
  22ef4c:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22ef50:	48 89 4d 80          	mov    %rcx,-0x80(%rbp)
  22ef54:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef58:	0f 95 c0             	setne  %al
  22ef5b:	48 83 e1 3f          	and    $0x3f,%rcx
  22ef5f:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef63:	0f 94 c1             	sete   %cl
  22ef66:	20 c8                	and    %cl,%al
  22ef68:	a8 01                	test   $0x1,%al
  22ef6a:	75 10                	jne    22ef7c <caller_poll+0x394>
  22ef6c:	48 8b 75 80          	mov    -0x80(%rbp),%rsi
  22ef70:	48 8d 3d d9 82 09 00 	lea    0x982d9(%rip),%rdi        # 2c7250 <_ZL17kSuppressionTypes+0x13ce0>
  22ef77:	e8 14 d5 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22ef7c:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
  22ef80:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  22ef87:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
  22ef8e:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef92:	0f 95 c0             	setne  %al
  22ef95:	48 83 e1 07          	and    $0x7,%rcx
  22ef99:	48 83 f9 00          	cmp    $0x0,%rcx
  22ef9d:	0f 94 c1             	sete   %cl
  22efa0:	20 c8                	and    %cl,%al
  22efa2:	a8 01                	test   $0x1,%al
  22efa4:	75 13                	jne    22efb9 <caller_poll+0x3d1>
  22efa6:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
  22efad:	48 8d 3d bc 82 09 00 	lea    0x982bc(%rip),%rdi        # 2c7270 <_ZL17kSuppressionTypes+0x13d00>
  22efb4:	e8 d7 d4 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22efb9:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
  22efc0:	48 83 c7 10          	add    $0x10,%rdi
  22efc4:	e8 2f d3 ff ff       	call   22c2f8 <ponyint_objectmap_size>
  22efc9:	48 89 c1             	mov    %rax,%rcx
  22efcc:	31 c0                	xor    %eax,%eax
  22efce:	48 83 f9 00          	cmp    $0x0,%rcx
  22efd2:	88 45 a7             	mov    %al,-0x59(%rbp)
  22efd5:	0f 85 df 00 00 00    	jne    22f0ba <caller_poll+0x4d2>
  22efdb:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22efdf:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
  22efe6:	48 83 f9 00          	cmp    $0x0,%rcx
  22efea:	0f 95 c0             	setne  %al
  22efed:	48 83 e1 3f          	and    $0x3f,%rcx
  22eff1:	48 83 f9 00          	cmp    $0x0,%rcx
  22eff5:	0f 94 c1             	sete   %cl
  22eff8:	20 c8                	and    %cl,%al
  22effa:	a8 01                	test   $0x1,%al
  22effc:	75 13                	jne    22f011 <caller_poll+0x429>
  22effe:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
  22f005:	48 8d 3d 84 82 09 00 	lea    0x98284(%rip),%rdi        # 2c7290 <_ZL17kSuppressionTypes+0x13d20>
  22f00c:	e8 7f d4 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f011:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
  22f018:	48 81 c1 d8 00 00 00 	add    $0xd8,%rcx
  22f01f:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
  22f026:	48 83 f9 00          	cmp    $0x0,%rcx
  22f02a:	0f 95 c0             	setne  %al
  22f02d:	48 83 e1 07          	and    $0x7,%rcx
  22f031:	48 83 f9 00          	cmp    $0x0,%rcx
  22f035:	0f 94 c1             	sete   %cl
  22f038:	20 c8                	and    %cl,%al
  22f03a:	a8 01                	test   $0x1,%al
  22f03c:	75 13                	jne    22f051 <caller_poll+0x469>
  22f03e:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
  22f045:	48 8d 3d 64 82 09 00 	lea    0x98264(%rip),%rdi        # 2c72b0 <_ZL17kSuppressionTypes+0x13d40>
  22f04c:	e8 3f d4 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f051:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
  22f058:	48 83 c7 30          	add    $0x30,%rdi
  22f05c:	e8 e7 74 fd ff       	call   206548 <ponyint_actormap_size>
  22f061:	48 89 c1             	mov    %rax,%rcx
  22f064:	31 c0                	xor    %eax,%eax
  22f066:	48 83 f9 00          	cmp    $0x0,%rcx
  22f06a:	88 45 a7             	mov    %al,-0x59(%rbp)
  22f06d:	75 4b                	jne    22f0ba <caller_poll+0x4d2>
  22f06f:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22f073:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
  22f07a:	48 83 f9 00          	cmp    $0x0,%rcx
  22f07e:	0f 95 c0             	setne  %al
  22f081:	48 83 e1 3f          	and    $0x3f,%rcx
  22f085:	48 83 f9 00          	cmp    $0x0,%rcx
  22f089:	0f 94 c1             	sete   %cl
  22f08c:	20 c8                	and    %cl,%al
  22f08e:	a8 01                	test   $0x1,%al
  22f090:	75 13                	jne    22f0a5 <caller_poll+0x4bd>
  22f092:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
  22f099:	48 8d 3d 30 82 09 00 	lea    0x98230(%rip),%rdi        # 2c72d0 <_ZL17kSuppressionTypes+0x13d60>
  22f0a0:	e8 eb d3 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f0a5:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
  22f0ac:	48 83 c7 40          	add    $0x40,%rdi
  22f0b0:	e8 63 3f 00 00       	call   233018 <ponyint_heap_has_finalisers>
  22f0b5:	34 ff                	xor    $0xff,%al
  22f0b7:	88 45 a7             	mov    %al,-0x59(%rbp)
  22f0ba:	8a 45 a7             	mov    -0x59(%rbp),%al
  22f0bd:	0f b6 f8             	movzbl %al,%edi
  22f0c0:	83 e7 01             	and    $0x1,%edi
  22f0c3:	48 8d 35 16 c0 e8 ff 	lea    -0x173fea(%rip),%rsi        # bb0e0 <.str.19>
  22f0ca:	e8 f9 f2 ff ff       	call   22e3c8 <require>
  22f0cf:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22f0d3:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
  22f0da:	48 83 f9 00          	cmp    $0x0,%rcx
  22f0de:	0f 95 c0             	setne  %al
  22f0e1:	48 83 e1 3f          	and    $0x3f,%rcx
  22f0e5:	48 83 f9 00          	cmp    $0x0,%rcx
  22f0e9:	0f 94 c1             	sete   %cl
  22f0ec:	20 c8                	and    %cl,%al
  22f0ee:	a8 01                	test   $0x1,%al
  22f0f0:	75 13                	jne    22f105 <caller_poll+0x51d>
  22f0f2:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
  22f0f9:	48 8d 3d f0 81 09 00 	lea    0x981f0(%rip),%rdi        # 2c72f0 <_ZL17kSuppressionTypes+0x13d80>
  22f100:	e8 8b d3 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f105:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
  22f10c:	48 83 c1 40          	add    $0x40,%rcx
  22f110:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
  22f117:	48 83 f9 00          	cmp    $0x0,%rcx
  22f11b:	0f 95 c0             	setne  %al
  22f11e:	48 83 e1 3f          	and    $0x3f,%rcx
  22f122:	48 83 f9 00          	cmp    $0x0,%rcx
  22f126:	0f 94 c1             	sete   %cl
  22f129:	20 c8                	and    %cl,%al
  22f12b:	a8 01                	test   $0x1,%al
  22f12d:	75 13                	jne    22f142 <caller_poll+0x55a>
  22f12f:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
  22f136:	48 8d 3d d3 81 09 00 	lea    0x981d3(%rip),%rdi        # 2c7310 <_ZL17kSuppressionTypes+0x13da0>
  22f13d:	e8 4e d3 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f142:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
  22f149:	48 81 c1 80 00 00 00 	add    $0x80,%rcx
  22f150:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
  22f157:	48 83 f9 00          	cmp    $0x0,%rcx
  22f15b:	0f 95 c0             	setne  %al
  22f15e:	48 83 e1 3f          	and    $0x3f,%rcx
  22f162:	48 83 f9 00          	cmp    $0x0,%rcx
  22f166:	0f 94 c1             	sete   %cl
  22f169:	20 c8                	and    %cl,%al
  22f16b:	a8 01                	test   $0x1,%al
  22f16d:	75 13                	jne    22f182 <caller_poll+0x59a>
  22f16f:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
  22f176:	48 8d 3d b3 81 09 00 	lea    0x981b3(%rip),%rdi        # 2c7330 <_ZL17kSuppressionTypes+0x13dc0>
  22f17d:	e8 0e d3 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f182:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  22f189:	48 c1 e8 03          	shr    $0x3,%rax
  22f18d:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f194:	74 0c                	je     22f1a2 <caller_poll+0x5ba>
  22f196:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
  22f19d:	e8 9e 63 f8 ff       	call   1b5540 <__asan_report_load8>
  22f1a2:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
  22f1a9:	48 8b 00             	mov    (%rax),%rax
  22f1ac:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
  22f1b3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f1ba:	25 00 00 00 00 
  22f1bf:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f1c6:	48 05 30 20 00 00    	add    $0x2030,%rax
  22f1cc:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
  22f1d3:	48 83 e0 07          	and    $0x7,%rax
  22f1d7:	48 83 f8 00          	cmp    $0x0,%rax
  22f1db:	74 13                	je     22f1f0 <caller_poll+0x608>
  22f1dd:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
  22f1e4:	48 8d 3d 65 81 09 00 	lea    0x98165(%rip),%rdi        # 2c7350 <_ZL17kSuppressionTypes+0x13de0>
  22f1eb:	e8 a0 d2 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f1f0:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
  22f1f7:	48 c1 e8 03          	shr    $0x3,%rax
  22f1fb:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f202:	74 0c                	je     22f210 <caller_poll+0x628>
  22f204:	48 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%rdi
  22f20b:	e8 30 63 f8 ff       	call   1b5540 <__asan_report_load8>
  22f210:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
  22f217:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
  22f21e:	48 3b 01             	cmp    (%rcx),%rax
  22f221:	0f 94 c0             	sete   %al
  22f224:	0f b6 f8             	movzbl %al,%edi
  22f227:	83 e7 01             	and    $0x1,%edi
  22f22a:	48 8d 35 ef be e8 ff 	lea    -0x174111(%rip),%rsi        # bb120 <.str.20>
  22f231:	e8 92 f1 ff ff       	call   22e3c8 <require>
  22f236:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22f23a:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
  22f241:	48 83 f9 00          	cmp    $0x0,%rcx
  22f245:	0f 95 c0             	setne  %al
  22f248:	48 83 e1 3f          	and    $0x3f,%rcx
  22f24c:	48 83 f9 00          	cmp    $0x0,%rcx
  22f250:	0f 94 c1             	sete   %cl
  22f253:	20 c8                	and    %cl,%al
  22f255:	a8 01                	test   $0x1,%al
  22f257:	75 13                	jne    22f26c <caller_poll+0x684>
  22f259:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
  22f260:	48 8d 3d 09 81 09 00 	lea    0x98109(%rip),%rdi        # 2c7370 <_ZL17kSuppressionTypes+0x13e00>
  22f267:	e8 24 d2 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f26c:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
  22f273:	48 83 c1 40          	add    $0x40,%rcx
  22f277:	48 89 8d 28 ff ff ff 	mov    %rcx,-0xd8(%rbp)
  22f27e:	48 83 f9 00          	cmp    $0x0,%rcx
  22f282:	0f 95 c0             	setne  %al
  22f285:	48 83 e1 3f          	and    $0x3f,%rcx
  22f289:	48 83 f9 00          	cmp    $0x0,%rcx
  22f28d:	0f 94 c1             	sete   %cl
  22f290:	20 c8                	and    %cl,%al
  22f292:	a8 01                	test   $0x1,%al
  22f294:	75 13                	jne    22f2a9 <caller_poll+0x6c1>
  22f296:	48 8b b5 28 ff ff ff 	mov    -0xd8(%rbp),%rsi
  22f29d:	48 8d 3d ec 80 09 00 	lea    0x980ec(%rip),%rdi        # 2c7390 <_ZL17kSuppressionTypes+0x13e20>
  22f2a4:	e8 e7 d1 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f2a9:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
  22f2b0:	48 83 c1 78          	add    $0x78,%rcx
  22f2b4:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
  22f2bb:	48 83 f9 00          	cmp    $0x0,%rcx
  22f2bf:	0f 95 c0             	setne  %al
  22f2c2:	48 83 e1 07          	and    $0x7,%rcx
  22f2c6:	48 83 f9 00          	cmp    $0x0,%rcx
  22f2ca:	0f 94 c1             	sete   %cl
  22f2cd:	20 c8                	and    %cl,%al
  22f2cf:	a8 01                	test   $0x1,%al
  22f2d1:	75 13                	jne    22f2e6 <caller_poll+0x6fe>
  22f2d3:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
  22f2da:	48 8d 3d cf 80 09 00 	lea    0x980cf(%rip),%rdi        # 2c73b0 <_ZL17kSuppressionTypes+0x13e40>
  22f2e1:	e8 aa d1 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f2e6:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
  22f2ed:	48 c1 e8 03          	shr    $0x3,%rax
  22f2f1:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f2f8:	74 0c                	je     22f306 <caller_poll+0x71e>
  22f2fa:	48 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%rdi
  22f301:	e8 3a 62 f8 ff       	call   1b5540 <__asan_report_load8>
  22f306:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
  22f30d:	48 8b 00             	mov    (%rax),%rax
  22f310:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
  22f317:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f31e:	25 00 00 00 00 
  22f323:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f32a:	48 05 38 20 00 00    	add    $0x2038,%rax
  22f330:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
  22f337:	48 83 e0 07          	and    $0x7,%rax
  22f33b:	48 83 f8 00          	cmp    $0x0,%rax
  22f33f:	74 13                	je     22f354 <caller_poll+0x76c>
  22f341:	48 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%rsi
  22f348:	48 8d 3d 81 80 09 00 	lea    0x98081(%rip),%rdi        # 2c73d0 <_ZL17kSuppressionTypes+0x13e60>
  22f34f:	e8 3c d1 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f354:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
  22f35b:	48 c1 e8 03          	shr    $0x3,%rax
  22f35f:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f366:	74 0c                	je     22f374 <caller_poll+0x78c>
  22f368:	48 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%rdi
  22f36f:	e8 7c 66 f8 ff       	call   1b59f0 <__asan_report_store8>
  22f374:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
  22f37b:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
  22f382:	48 89 08             	mov    %rcx,(%rax)
  22f385:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f38c:	25 00 00 00 00 
  22f391:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f398:	48 05 38 20 00 00    	add    $0x2038,%rax
  22f39e:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
  22f3a5:	48 83 e0 07          	and    $0x7,%rax
  22f3a9:	48 83 f8 00          	cmp    $0x0,%rax
  22f3ad:	74 13                	je     22f3c2 <caller_poll+0x7da>
  22f3af:	48 8b b5 08 ff ff ff 	mov    -0xf8(%rbp),%rsi
  22f3b6:	48 8d 3d 33 80 09 00 	lea    0x98033(%rip),%rdi        # 2c73f0 <_ZL17kSuppressionTypes+0x13e80>
  22f3bd:	e8 ce d0 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f3c2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
  22f3c9:	48 c1 e8 03          	shr    $0x3,%rax
  22f3cd:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f3d4:	74 0c                	je     22f3e2 <caller_poll+0x7fa>
  22f3d6:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
  22f3dd:	e8 5e 61 f8 ff       	call   1b5540 <__asan_report_load8>
  22f3e2:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
  22f3e9:	48 8b 00             	mov    (%rax),%rax
  22f3ec:	48 89 85 f8 fe ff ff 	mov    %rax,-0x108(%rbp)
  22f3f3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f3fa:	25 00 00 00 00 
  22f3ff:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f406:	48 05 30 20 00 00    	add    $0x2030,%rax
  22f40c:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
  22f413:	48 83 e0 07          	and    $0x7,%rax
  22f417:	48 83 f8 00          	cmp    $0x0,%rax
  22f41b:	74 13                	je     22f430 <caller_poll+0x848>
  22f41d:	48 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%rsi
  22f424:	48 8d 3d e5 7f 09 00 	lea    0x97fe5(%rip),%rdi        # 2c7410 <_ZL17kSuppressionTypes+0x13ea0>
  22f42b:	e8 60 d0 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f430:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
  22f437:	48 c1 e8 03          	shr    $0x3,%rax
  22f43b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f442:	74 0c                	je     22f450 <caller_poll+0x868>
  22f444:	48 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%rdi
  22f44b:	e8 f0 60 f8 ff       	call   1b5540 <__asan_report_load8>
  22f450:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
  22f457:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
  22f45e:	48 3b 01             	cmp    (%rcx),%rax
  22f461:	0f 97 c0             	seta   %al
  22f464:	88 85 e7 fe ff ff    	mov    %al,-0x119(%rbp)
  22f46a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f471:	25 00 00 00 00 
  22f476:	8a 8d e7 fe ff ff    	mov    -0x119(%rbp),%cl
  22f47c:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f483:	48 05 49 20 00 00    	add    $0x2049,%rax
  22f489:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
  22f490:	80 e1 01             	and    $0x1,%cl
  22f493:	88 8d f6 fe ff ff    	mov    %cl,-0x10a(%rbp)
  22f499:	48 c1 e8 03          	shr    $0x3,%rax
  22f49d:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f4a3:	88 85 f7 fe ff ff    	mov    %al,-0x109(%rbp)
  22f4a9:	3c 00                	cmp    $0x0,%al
  22f4ab:	74 21                	je     22f4ce <caller_poll+0x8e6>
  22f4ad:	8a 8d f7 fe ff ff    	mov    -0x109(%rbp),%cl
  22f4b3:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  22f4ba:	48 83 e0 07          	and    $0x7,%rax
  22f4be:	38 c8                	cmp    %cl,%al
  22f4c0:	7c 0c                	jl     22f4ce <caller_poll+0x8e6>
  22f4c2:	48 8b bd e8 fe ff ff 	mov    -0x118(%rbp),%rdi
  22f4c9:	e8 52 62 f8 ff       	call   1b5720 <__asan_report_store1>
  22f4ce:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
  22f4d5:	8a 8d f6 fe ff ff    	mov    -0x10a(%rbp),%cl
  22f4db:	88 08                	mov    %cl,(%rax)
  22f4dd:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f4e4:	25 00 00 00 00 
  22f4e9:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f4f0:	48 83 c0 10          	add    $0x10,%rax
  22f4f4:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
  22f4fb:	48 83 e0 07          	and    $0x7,%rax
  22f4ff:	48 83 f8 00          	cmp    $0x0,%rax
  22f503:	74 13                	je     22f518 <caller_poll+0x930>
  22f505:	48 8b b5 d8 fe ff ff 	mov    -0x128(%rbp),%rsi
  22f50c:	48 8d 3d 1d 7f 09 00 	lea    0x97f1d(%rip),%rdi        # 2c7430 <_ZL17kSuppressionTypes+0x13ec0>
  22f513:	e8 78 cf fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f518:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  22f51f:	48 c1 e8 03          	shr    $0x3,%rax
  22f523:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f52a:	74 0c                	je     22f538 <caller_poll+0x950>
  22f52c:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
  22f533:	e8 08 60 f8 ff       	call   1b5540 <__asan_report_load8>
  22f538:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
  22f53f:	48 83 38 00          	cmpq   $0x0,(%rax)
  22f543:	0f 95 c0             	setne  %al
  22f546:	88 85 cf fe ff ff    	mov    %al,-0x131(%rbp)
  22f54c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f553:	25 00 00 00 00 
  22f558:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f55f:	48 05 4a 20 00 00    	add    $0x204a,%rax
  22f565:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
  22f56c:	48 83 e0 01          	and    $0x1,%rax
  22f570:	48 83 f8 00          	cmp    $0x0,%rax
  22f574:	74 13                	je     22f589 <caller_poll+0x9a1>
  22f576:	48 8b b5 d0 fe ff ff 	mov    -0x130(%rbp),%rsi
  22f57d:	48 8d 3d cc 7e 09 00 	lea    0x97ecc(%rip),%rdi        # 2c7450 <_ZL17kSuppressionTypes+0x13ee0>
  22f584:	e8 07 cf fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f589:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22f590:	8a 8d cf fe ff ff    	mov    -0x131(%rbp),%cl
  22f596:	80 e1 01             	and    $0x1,%cl
  22f599:	88 8d cd fe ff ff    	mov    %cl,-0x133(%rbp)
  22f59f:	48 c1 e8 03          	shr    $0x3,%rax
  22f5a3:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f5a9:	88 85 ce fe ff ff    	mov    %al,-0x132(%rbp)
  22f5af:	3c 00                	cmp    $0x0,%al
  22f5b1:	74 21                	je     22f5d4 <caller_poll+0x9ec>
  22f5b3:	8a 8d ce fe ff ff    	mov    -0x132(%rbp),%cl
  22f5b9:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22f5c0:	48 83 e0 07          	and    $0x7,%rax
  22f5c4:	38 c8                	cmp    %cl,%al
  22f5c6:	7c 0c                	jl     22f5d4 <caller_poll+0x9ec>
  22f5c8:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
  22f5cf:	e8 4c 61 f8 ff       	call   1b5720 <__asan_report_store1>
  22f5d4:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
  22f5db:	8a 8d cd fe ff ff    	mov    -0x133(%rbp),%cl
  22f5e1:	88 08                	mov    %cl,(%rax)
  22f5e3:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f5ea:	25 00 00 00 00 
  22f5ef:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f5f6:	48 05 49 20 00 00    	add    $0x2049,%rax
  22f5fc:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
  22f603:	48 c1 e8 03          	shr    $0x3,%rax
  22f607:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f60d:	88 85 cc fe ff ff    	mov    %al,-0x134(%rbp)
  22f613:	3c 00                	cmp    $0x0,%al
  22f615:	74 21                	je     22f638 <caller_poll+0xa50>
  22f617:	8a 8d cc fe ff ff    	mov    -0x134(%rbp),%cl
  22f61d:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  22f624:	48 83 e0 07          	and    $0x7,%rax
  22f628:	38 c8                	cmp    %cl,%al
  22f62a:	7c 0c                	jl     22f638 <caller_poll+0xa50>
  22f62c:	48 8b bd c0 fe ff ff 	mov    -0x140(%rbp),%rdi
  22f633:	e8 38 5c f8 ff       	call   1b5270 <__asan_report_load1>
  22f638:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
  22f63f:	8a 00                	mov    (%rax),%al
  22f641:	88 85 bf fe ff ff    	mov    %al,-0x141(%rbp)
  22f647:	3c 01                	cmp    $0x1,%al
  22f649:	76 17                	jbe    22f662 <caller_poll+0xa7a>
  22f64b:	8a 85 bf fe ff ff    	mov    -0x141(%rbp),%al
  22f651:	0f b6 c0             	movzbl %al,%eax
  22f654:	89 c6                	mov    %eax,%esi
  22f656:	48 8d 3d 13 7e 09 00 	lea    0x97e13(%rip),%rdi        # 2c7470 <_ZL17kSuppressionTypes+0x13f00>
  22f65d:	e8 2e f3 fb ff       	call   1ee990 <__ubsan_handle_load_invalid_value>
  22f662:	8a 85 bf fe ff ff    	mov    -0x141(%rbp),%al
  22f668:	3c 00                	cmp    $0x0,%al
  22f66a:	0f 84 69 02 00 00    	je     22f8d9 <caller_poll+0xcf1>
  22f670:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f677:	25 00 00 00 00 
  22f67c:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f683:	48 05 4a 20 00 00    	add    $0x204a,%rax
  22f689:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
  22f690:	48 83 e0 01          	and    $0x1,%rax
  22f694:	48 83 f8 00          	cmp    $0x0,%rax
  22f698:	74 13                	je     22f6ad <caller_poll+0xac5>
  22f69a:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
  22f6a1:	48 8d 3d e8 7d 09 00 	lea    0x97de8(%rip),%rdi        # 2c7490 <_ZL17kSuppressionTypes+0x13f20>
  22f6a8:	e8 e3 cd fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f6ad:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22f6b4:	48 c1 e8 03          	shr    $0x3,%rax
  22f6b8:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f6be:	88 85 af fe ff ff    	mov    %al,-0x151(%rbp)
  22f6c4:	3c 00                	cmp    $0x0,%al
  22f6c6:	74 21                	je     22f6e9 <caller_poll+0xb01>
  22f6c8:	8a 8d af fe ff ff    	mov    -0x151(%rbp),%cl
  22f6ce:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22f6d5:	48 83 e0 07          	and    $0x7,%rax
  22f6d9:	38 c8                	cmp    %cl,%al
  22f6db:	7c 0c                	jl     22f6e9 <caller_poll+0xb01>
  22f6dd:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
  22f6e4:	e8 87 5b f8 ff       	call   1b5270 <__asan_report_load1>
  22f6e9:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
  22f6f0:	8a 00                	mov    (%rax),%al
  22f6f2:	88 85 ae fe ff ff    	mov    %al,-0x152(%rbp)
  22f6f8:	3c 01                	cmp    $0x1,%al
  22f6fa:	76 17                	jbe    22f713 <caller_poll+0xb2b>
  22f6fc:	8a 85 ae fe ff ff    	mov    -0x152(%rbp),%al
  22f702:	0f b6 c0             	movzbl %al,%eax
  22f705:	89 c6                	mov    %eax,%esi
  22f707:	48 8d 3d a2 7d 09 00 	lea    0x97da2(%rip),%rdi        # 2c74b0 <_ZL17kSuppressionTypes+0x13f40>
  22f70e:	e8 7d f2 fb ff       	call   1ee990 <__ubsan_handle_load_invalid_value>
  22f713:	8a 85 ae fe ff ff    	mov    -0x152(%rbp),%al
  22f719:	3c 00                	cmp    $0x0,%al
  22f71b:	0f 84 b8 01 00 00    	je     22f8d9 <caller_poll+0xcf1>
  22f721:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f728:	25 00 00 00 00 
  22f72d:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f734:	48 05 48 20 00 00    	add    $0x2048,%rax
  22f73a:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
  22f741:	48 83 e0 07          	and    $0x7,%rax
  22f745:	48 83 f8 00          	cmp    $0x0,%rax
  22f749:	74 13                	je     22f75e <caller_poll+0xb76>
  22f74b:	48 8b b5 a0 fe ff ff 	mov    -0x160(%rbp),%rsi
  22f752:	48 8d 3d 77 7d 09 00 	lea    0x97d77(%rip),%rdi        # 2c74d0 <_ZL17kSuppressionTypes+0x13f60>
  22f759:	e8 32 cd fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f75e:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22f765:	48 c1 e8 03          	shr    $0x3,%rax
  22f769:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f76f:	88 85 9f fe ff ff    	mov    %al,-0x161(%rbp)
  22f775:	3c 00                	cmp    $0x0,%al
  22f777:	74 21                	je     22f79a <caller_poll+0xbb2>
  22f779:	8a 8d 9f fe ff ff    	mov    -0x161(%rbp),%cl
  22f77f:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22f786:	48 83 e0 07          	and    $0x7,%rax
  22f78a:	38 c8                	cmp    %cl,%al
  22f78c:	7c 0c                	jl     22f79a <caller_poll+0xbb2>
  22f78e:	48 8b bd a0 fe ff ff 	mov    -0x160(%rbp),%rdi
  22f795:	e8 d6 5a f8 ff       	call   1b5270 <__asan_report_load1>
  22f79a:	48 8b 85 a0 fe ff ff 	mov    -0x160(%rbp),%rax
  22f7a1:	8a 00                	mov    (%rax),%al
  22f7a3:	88 85 9e fe ff ff    	mov    %al,-0x162(%rbp)
  22f7a9:	3c 01                	cmp    $0x1,%al
  22f7ab:	76 17                	jbe    22f7c4 <caller_poll+0xbdc>
  22f7ad:	8a 85 9e fe ff ff    	mov    -0x162(%rbp),%al
  22f7b3:	0f b6 c0             	movzbl %al,%eax
  22f7b6:	89 c6                	mov    %eax,%esi
  22f7b8:	48 8d 3d 31 7d 09 00 	lea    0x97d31(%rip),%rdi        # 2c74f0 <_ZL17kSuppressionTypes+0x13f80>
  22f7bf:	e8 cc f1 fb ff       	call   1ee990 <__ubsan_handle_load_invalid_value>
  22f7c4:	8a 85 9e fe ff ff    	mov    -0x162(%rbp),%al
  22f7ca:	3c 00                	cmp    $0x0,%al
  22f7cc:	0f 84 07 01 00 00    	je     22f8d9 <caller_poll+0xcf1>
  22f7d2:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
  22f7d6:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
  22f7dd:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
  22f7e1:	48 89 85 88 fe ff ff 	mov    %rax,-0x178(%rbp)
  22f7e8:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f7ef:	25 00 00 00 00 
  22f7f4:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f7fb:	48 83 c0 10          	add    $0x10,%rax
  22f7ff:	48 89 85 90 fe ff ff 	mov    %rax,-0x170(%rbp)
  22f806:	48 83 e0 07          	and    $0x7,%rax
  22f80a:	48 83 f8 00          	cmp    $0x0,%rax
  22f80e:	74 13                	je     22f823 <caller_poll+0xc3b>
  22f810:	48 8b b5 90 fe ff ff 	mov    -0x170(%rbp),%rsi
  22f817:	48 8d 3d f2 7c 09 00 	lea    0x97cf2(%rip),%rdi        # 2c7510 <_ZL17kSuppressionTypes+0x13fa0>
  22f81e:	e8 6d cc fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f823:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
  22f82a:	48 c1 e8 03          	shr    $0x3,%rax
  22f82e:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f835:	74 0c                	je     22f843 <caller_poll+0xc5b>
  22f837:	48 8b bd 90 fe ff ff 	mov    -0x170(%rbp),%rdi
  22f83e:	e8 fd 5c f8 ff       	call   1b5540 <__asan_report_load8>
  22f843:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
  22f84a:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
  22f851:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
  22f858:	48 8b 10             	mov    (%rax),%rdx
  22f85b:	e8 18 19 fc ff       	call   1f1178 <probe_collect>
  22f860:	88 85 6f fe ff ff    	mov    %al,-0x191(%rbp)
  22f866:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f86d:	25 00 00 00 00 
  22f872:	8a 8d 6f fe ff ff    	mov    -0x191(%rbp),%cl
  22f878:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f87f:	48 05 4b 20 00 00    	add    $0x204b,%rax
  22f885:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
  22f88c:	80 e1 01             	and    $0x1,%cl
  22f88f:	88 8d 7e fe ff ff    	mov    %cl,-0x182(%rbp)
  22f895:	48 c1 e8 03          	shr    $0x3,%rax
  22f899:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22f89f:	88 85 7f fe ff ff    	mov    %al,-0x181(%rbp)
  22f8a5:	3c 00                	cmp    $0x0,%al
  22f8a7:	74 21                	je     22f8ca <caller_poll+0xce2>
  22f8a9:	8a 8d 7f fe ff ff    	mov    -0x181(%rbp),%cl
  22f8af:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  22f8b6:	48 83 e0 07          	and    $0x7,%rax
  22f8ba:	38 c8                	cmp    %cl,%al
  22f8bc:	7c 0c                	jl     22f8ca <caller_poll+0xce2>
  22f8be:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
  22f8c5:	e8 56 5e f8 ff       	call   1b5720 <__asan_report_store1>
  22f8ca:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
  22f8d1:	8a 8d 7e fe ff ff    	mov    -0x182(%rbp),%cl
  22f8d7:	88 08                	mov    %cl,(%rax)
  22f8d9:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22f8e0:	25 00 00 00 00 
  22f8e5:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22f8ec:	48 83 c0 10          	add    $0x10,%rax
  22f8f0:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
  22f8f7:	48 83 e0 07          	and    $0x7,%rax
  22f8fb:	48 83 f8 00          	cmp    $0x0,%rax
  22f8ff:	74 13                	je     22f914 <caller_poll+0xd2c>
  22f901:	48 8b b5 60 fe ff ff 	mov    -0x1a0(%rbp),%rsi
  22f908:	48 8d 3d 21 7c 09 00 	lea    0x97c21(%rip),%rdi        # 2c7530 <_ZL17kSuppressionTypes+0x13fc0>
  22f90f:	e8 7c cb fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f914:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  22f91b:	48 c1 e8 03          	shr    $0x3,%rax
  22f91f:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22f926:	74 0c                	je     22f934 <caller_poll+0xd4c>
  22f928:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
  22f92f:	e8 bc 60 f8 ff       	call   1b59f0 <__asan_report_store8>
  22f934:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
  22f93b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  22f942:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
  22f946:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
  22f94d:	48 83 f9 00          	cmp    $0x0,%rcx
  22f951:	0f 95 c0             	setne  %al
  22f954:	48 83 e1 3f          	and    $0x3f,%rcx
  22f958:	48 83 f9 00          	cmp    $0x0,%rcx
  22f95c:	0f 94 c1             	sete   %cl
  22f95f:	20 c8                	and    %cl,%al
  22f961:	a8 01                	test   $0x1,%al
  22f963:	75 13                	jne    22f978 <caller_poll+0xd90>
  22f965:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
  22f96c:	48 8d 3d dd 7b 09 00 	lea    0x97bdd(%rip),%rdi        # 2c7550 <_ZL17kSuppressionTypes+0x13fe0>
  22f973:	e8 18 cb fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f978:	48 8b 8d 58 fe ff ff 	mov    -0x1a8(%rbp),%rcx
  22f97f:	48 83 c1 40          	add    $0x40,%rcx
  22f983:	48 89 8d 50 fe ff ff 	mov    %rcx,-0x1b0(%rbp)
  22f98a:	48 83 f9 00          	cmp    $0x0,%rcx
  22f98e:	0f 95 c0             	setne  %al
  22f991:	48 83 e1 3f          	and    $0x3f,%rcx
  22f995:	48 83 f9 00          	cmp    $0x0,%rcx
  22f999:	0f 94 c1             	sete   %cl
  22f99c:	20 c8                	and    %cl,%al
  22f99e:	a8 01                	test   $0x1,%al
  22f9a0:	75 13                	jne    22f9b5 <caller_poll+0xdcd>
  22f9a2:	48 8b b5 50 fe ff ff 	mov    -0x1b0(%rbp),%rsi
  22f9a9:	48 8d 3d c0 7b 09 00 	lea    0x97bc0(%rip),%rdi        # 2c7570 <_ZL17kSuppressionTypes+0x14000>
  22f9b0:	e8 db ca fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f9b5:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
  22f9bc:	48 83 c1 78          	add    $0x78,%rcx
  22f9c0:	48 89 8d 48 fe ff ff 	mov    %rcx,-0x1b8(%rbp)
  22f9c7:	48 83 f9 00          	cmp    $0x0,%rcx
  22f9cb:	0f 95 c0             	setne  %al
  22f9ce:	48 83 e1 07          	and    $0x7,%rcx
  22f9d2:	48 83 f9 00          	cmp    $0x0,%rcx
  22f9d6:	0f 94 c1             	sete   %cl
  22f9d9:	20 c8                	and    %cl,%al
  22f9db:	a8 01                	test   $0x1,%al
  22f9dd:	75 13                	jne    22f9f2 <caller_poll+0xe0a>
  22f9df:	48 8b b5 48 fe ff ff 	mov    -0x1b8(%rbp),%rsi
  22f9e6:	48 8d 3d a3 7b 09 00 	lea    0x97ba3(%rip),%rdi        # 2c7590 <_ZL17kSuppressionTypes+0x14020>
  22f9ed:	e8 9e ca fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22f9f2:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
  22f9f9:	48 c1 e8 03          	shr    $0x3,%rax
  22f9fd:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22fa04:	74 0c                	je     22fa12 <caller_poll+0xe2a>
  22fa06:	48 8b bd 48 fe ff ff 	mov    -0x1b8(%rbp),%rdi
  22fa0d:	e8 2e 5b f8 ff       	call   1b5540 <__asan_report_load8>
  22fa12:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
  22fa19:	48 8b 00             	mov    (%rax),%rax
  22fa1c:	48 89 85 38 fe ff ff 	mov    %rax,-0x1c8(%rbp)
  22fa23:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22fa2a:	25 00 00 00 00 
  22fa2f:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22fa36:	48 05 40 20 00 00    	add    $0x2040,%rax
  22fa3c:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
  22fa43:	48 83 e0 07          	and    $0x7,%rax
  22fa47:	48 83 f8 00          	cmp    $0x0,%rax
  22fa4b:	74 13                	je     22fa60 <caller_poll+0xe78>
  22fa4d:	48 8b b5 40 fe ff ff 	mov    -0x1c0(%rbp),%rsi
  22fa54:	48 8d 3d 55 7b 09 00 	lea    0x97b55(%rip),%rdi        # 2c75b0 <_ZL17kSuppressionTypes+0x14040>
  22fa5b:	e8 30 ca fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22fa60:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  22fa67:	48 c1 e8 03          	shr    $0x3,%rax
  22fa6b:	80 b8 00 80 ff 7f 00 	cmpb   $0x0,0x7fff8000(%rax)
  22fa72:	74 0c                	je     22fa80 <caller_poll+0xe98>
  22fa74:	48 8b bd 40 fe ff ff 	mov    -0x1c0(%rbp),%rdi
  22fa7b:	e8 70 5f f8 ff       	call   1b59f0 <__asan_report_store8>
  22fa80:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
  22fa87:	48 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%rcx
  22fa8e:	48 89 08             	mov    %rcx,(%rax)
  22fa91:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
  22fa98:	25 00 00 00 00 
  22fa9d:	48 8d 80 a0 df ff ff 	lea    -0x2060(%rax),%rax
  22faa4:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
  22faab:	48 83 e0 07          	and    $0x7,%rax
  22faaf:	48 83 f8 00          	cmp    $0x0,%rax
  22fab3:	74 13                	je     22fac8 <caller_poll+0xee0>
  22fab5:	48 8b b5 30 fe ff ff 	mov    -0x1d0(%rbp),%rsi
  22fabc:	48 8d 3d 0d 7b 09 00 	lea    0x97b0d(%rip),%rdi        # 2c75d0 <_ZL17kSuppressionTypes+0x14060>
  22fac3:	e8 c8 c9 fb ff       	call   1ec490 <__ubsan_handle_type_mismatch_v1>
  22fac8:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22facf:	48 c1 e8 03          	shr    $0x3,%rax
  22fad3:	8a 80 00 80 ff 7f    	mov    0x7fff8000(%rax),%al
  22fad9:	88 85 2f fe ff ff    	mov    %al,-0x1d1(%rbp)
  22fadf:	3c 00                	cmp    $0x0,%al
  22fae1:	74 25                	je     22fb08 <caller_poll+0xf20>
  22fae3:	8a 8d 2f fe ff ff    	mov    -0x1d1(%rbp),%cl
  22fae9:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22faf0:	48 83 e0 07          	and    $0x7,%rax
  22faf4:	48 83 c0 03          	add    $0x3,%rax
  22faf8:	38 c8                	cmp    %cl,%al
  22fafa:	7c 0c                	jl     22fb08 <caller_poll+0xf20>
  22fafc:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
  22fb03:	e8 f8 5d f8 ff       	call   1b5900 <__asan_report_store4>
  22fb08:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
  22fb0f:	c7 00 02 00 00 00    	movl   $0x2,(%rax)
  22fb15:	48 81 c4 e0 01 00 00 	add    $0x1e0,%rsp
  22fb1c:	5d                   	pop    %rbp
  22fb1d:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
