
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002aa620 <Probe_tag_measure_pWo>:
  2aa620:	55                   	push   %rbp
  2aa621:	41 57                	push   %r15
  2aa623:	41 56                	push   %r14
  2aa625:	41 55                	push   %r13
  2aa627:	41 54                	push   %r12
  2aa629:	53                   	push   %rbx
  2aa62a:	48 83 ec 68          	sub    $0x68,%rsp
  2aa62e:	49 89 f4             	mov    %rsi,%r12
  2aa631:	48 89 fb             	mov    %rdi,%rbx
  2aa634:	e8 7f 1e fa ff       	call   24c4b8 <pony_ctx>
  2aa639:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
  2aa63e:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  2aa643:	49 89 c6             	mov    %rax,%r14
  2aa646:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  2aa64b:	48 8d 05 d7 ca df ff 	lea    -0x203529(%rip),%rax        # a7129 <_ZN11__sanitizerL10kExtraRegsE+0x7f39>
  2aa652:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  2aa657:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
  2aa65c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2aa661:	48 8d 6c 24 48       	lea    0x48(%rsp),%rbp
  2aa666:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2aa66b:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  2aa672:	00 
  2aa673:	4c 8d 3d e6 f3 e1 ff 	lea    -0x1e0c1a(%rip),%r15        # c9a60 <__NumSizeTable+0x20>
  2aa67a:	4c 89 f7             	mov    %r14,%rdi
  2aa67d:	48 89 de             	mov    %rbx,%rsi
  2aa680:	4c 89 fa             	mov    %r15,%rdx
  2aa683:	b9 11 00 00 00       	mov    $0x11,%ecx
  2aa688:	41 b8 0e 00 00 00    	mov    $0xe,%r8d
  2aa68e:	45 31 c9             	xor    %r9d,%r9d
  2aa691:	e8 02 2b f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa696:	4c 89 f7             	mov    %r14,%rdi
  2aa699:	31 f6                	xor    %esi,%esi
  2aa69b:	e8 d8 e5 f4 ff       	call   1f8c78 <pony_alloc_small>
  2aa6a0:	49 89 c5             	mov    %rax,%r13
  2aa6a3:	48 8d 05 26 3f 00 00 	lea    0x3f26(%rip),%rax        # 2ae5d0 <Cell_Desc>
  2aa6aa:	49 89 45 00          	mov    %rax,0x0(%r13)
  2aa6ae:	4c 89 ef             	mov    %r13,%rdi
  2aa6b1:	4c 89 e6             	mov    %r12,%rsi
  2aa6b4:	e8 f7 fe ff ff       	call   2aa5b0 <Cell_ref_create_pWo>
  2aa6b9:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  2aa6be:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  2aa6c3:	48 8d 05 de 71 df ff 	lea    -0x208e22(%rip),%rax        # a18a8 <_ZN11__sanitizerL10kExtraRegsE+0x26b8>
  2aa6ca:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  2aa6cf:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
  2aa6d4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2aa6d9:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  2aa6de:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
  2aa6e5:	00 
  2aa6e6:	4c 89 f7             	mov    %r14,%rdi
  2aa6e9:	48 89 de             	mov    %rbx,%rsi
  2aa6ec:	4c 89 fa             	mov    %r15,%rdx
  2aa6ef:	b9 12 00 00 00       	mov    $0x12,%ecx
  2aa6f4:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
  2aa6fa:	45 31 c9             	xor    %r9d,%r9d
  2aa6fd:	e8 96 2a f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa702:	48 89 df             	mov    %rbx,%rdi
  2aa705:	e8 76 fd ff ff       	call   2aa480 <Probe_ref_phase_o>
  2aa70a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aa70e:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aa713:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aa71a:	00 00 
  2aa71c:	4c 8d 0d 4d f4 e1 ff 	lea    -0x1e0bb3(%rip),%r9        # c9b70 <__NumSizeTable+0x130>
  2aa723:	4c 89 f7             	mov    %r14,%rdi
  2aa726:	48 89 de             	mov    %rbx,%rsi
  2aa729:	4c 89 fa             	mov    %r15,%rdx
  2aa72c:	b9 13 00 00 00       	mov    $0x13,%ecx
  2aa731:	41 b8 15 00 00 00    	mov    $0x15,%r8d
  2aa737:	e8 5c 2a f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa73c:	4c 89 f7             	mov    %r14,%rdi
  2aa73f:	31 f6                	xor    %esi,%esi
  2aa741:	e8 32 e5 f4 ff       	call   1f8c78 <pony_alloc_small>
  2aa746:	49 89 c4             	mov    %rax,%r12
  2aa749:	48 8d 05 80 3e 00 00 	lea    0x3e80(%rip),%rax        # 2ae5d0 <Cell_Desc>
  2aa750:	49 89 04 24          	mov    %rax,(%r12)
  2aa754:	be d3 00 00 00       	mov    $0xd3,%esi
  2aa759:	4c 89 e7             	mov    %r12,%rdi
  2aa75c:	e8 4f fe ff ff       	call   2aa5b0 <Cell_ref_create_pWo>
  2aa761:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
  2aa766:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aa76a:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aa76f:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aa776:	00 00 
  2aa778:	4c 8d 0d f1 f3 e1 ff 	lea    -0x1e0c0f(%rip),%r9        # c9b70 <__NumSizeTable+0x130>
  2aa77f:	4c 89 f7             	mov    %r14,%rdi
  2aa782:	48 89 de             	mov    %rbx,%rsi
  2aa785:	4c 89 fa             	mov    %r15,%rdx
  2aa788:	b9 14 00 00 00       	mov    $0x14,%ecx
  2aa78d:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2aa793:	e8 00 2a f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa798:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  2aa79d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  2aa7a2:	e8 81 55 f8 ff       	call   22fd28 <caller_addresses>
  2aa7a7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aa7ab:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aa7b0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aa7b7:	00 00 
  2aa7b9:	4c 8d 0d b0 f3 e1 ff 	lea    -0x1e0c50(%rip),%r9        # c9b70 <__NumSizeTable+0x130>
  2aa7c0:	4c 89 f7             	mov    %r14,%rdi
  2aa7c3:	48 89 de             	mov    %rbx,%rsi
  2aa7c6:	4c 89 fa             	mov    %r15,%rdx
  2aa7c9:	b9 15 00 00 00       	mov    $0x15,%ecx
  2aa7ce:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  2aa7d4:	e8 bf 29 f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa7d9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  2aa7de:	48 8b 40 08          	mov    0x8(%rax),%rax
  2aa7e2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  2aa7e7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aa7eb:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aa7f0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aa7f7:	00 00 
  2aa7f9:	4c 8d 0d 70 f3 e1 ff 	lea    -0x1e0c90(%rip),%r9        # c9b70 <__NumSizeTable+0x130>
  2aa800:	4c 89 f7             	mov    %r14,%rdi
  2aa803:	48 89 de             	mov    %rbx,%rsi
  2aa806:	4c 89 fa             	mov    %r15,%rdx
  2aa809:	b9 16 00 00 00       	mov    $0x16,%ecx
  2aa80e:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  2aa814:	e8 7f 29 f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa819:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  2aa81e:	48 83 c0 05          	add    $0x5,%rax
  2aa822:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  2aa827:	48 89 41 08          	mov    %rax,0x8(%rcx)
  2aa82b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  2aa82f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
  2aa834:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  2aa83b:	00 00 
  2aa83d:	4c 8d 0d 2c f3 e1 ff 	lea    -0x1e0cd4(%rip),%r9        # c9b70 <__NumSizeTable+0x130>
  2aa844:	4c 89 f7             	mov    %r14,%rdi
  2aa847:	48 89 de             	mov    %rbx,%rsi
  2aa84a:	4c 89 fa             	mov    %r15,%rdx
  2aa84d:	b9 17 00 00 00       	mov    $0x17,%ecx
  2aa852:	41 b8 05 00 00 00    	mov    $0x5,%r8d
  2aa858:	e8 3b 29 f8 ff       	call   22d198 <ponyint_gc_root_audit>
  2aa85d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  2aa862:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  2aa867:	48 8b 70 08          	mov    0x8(%rax),%rsi
  2aa86b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  2aa870:	48 8b 50 08          	mov    0x8(%rax),%rdx
  2aa874:	e8 9f 59 f8 ff       	call   230218 <caller_result>
  2aa879:	48 83 c4 68          	add    $0x68,%rsp
  2aa87d:	5b                   	pop    %rbx
  2aa87e:	41 5c                	pop    %r12
  2aa880:	41 5d                	pop    %r13
  2aa882:	41 5e                	pop    %r14
  2aa884:	41 5f                	pop    %r15
  2aa886:	5d                   	pop    %rbp
  2aa887:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
