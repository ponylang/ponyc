
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000002aa270 <Probe_ref_allocate_garbage_o>:
  2aa270:	41 57                	push   %r15
  2aa272:	41 56                	push   %r14
  2aa274:	41 54                	push   %r12
  2aa276:	53                   	push   %rbx
  2aa277:	48 83 ec 18          	sub    $0x18,%rsp
  2aa27b:	49 89 fe             	mov    %rdi,%r14
  2aa27e:	e8 35 22 fa ff       	call   24c4b8 <pony_ctx>
  2aa283:	48 89 c3             	mov    %rax,%rbx
  2aa286:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  2aa28b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  2aa292:	00 00 
  2aa294:	31 c0                	xor    %eax,%eax
  2aa296:	84 c0                	test   %al,%al
  2aa298:	75 55                	jne    2aa2ef <Probe_ref_allocate_garbage_o+0x7f>
  2aa29a:	4c 8d 25 2f 43 00 00 	lea    0x432f(%rip),%r12        # 2ae5d0 <Cell_Desc>
  2aa2a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2aa2a8:	0f 1f 84 00 00 00 00 
  2aa2af:	00 
  2aa2b0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  2aa2b5:	48 89 df             	mov    %rbx,%rdi
  2aa2b8:	31 f6                	xor    %esi,%esi
  2aa2ba:	e8 b9 e9 f4 ff       	call   1f8c78 <pony_alloc_small>
  2aa2bf:	49 89 c7             	mov    %rax,%r15
  2aa2c2:	4c 89 20             	mov    %r12,(%rax)
  2aa2c5:	48 89 c7             	mov    %rax,%rdi
  2aa2c8:	4c 89 f6             	mov    %r14,%rsi
  2aa2cb:	e8 e0 02 00 00       	call   2aa5b0 <Cell_ref_create_pWo>
  2aa2d0:	4c 89 ff             	mov    %r15,%rdi
  2aa2d3:	e8 90 43 f8 ff       	call   22e668 <caller_garbage>
  2aa2d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  2aa2dd:	48 ff c0             	inc    %rax
  2aa2e0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  2aa2e5:	48 3d 00 04 00 00    	cmp    $0x400,%rax
  2aa2eb:	72 c3                	jb     2aa2b0 <Probe_ref_allocate_garbage_o+0x40>
  2aa2ed:	eb 0c                	jmp    2aa2fb <Probe_ref_allocate_garbage_o+0x8b>
  2aa2ef:	48 8d 3d 8a 55 00 00 	lea    0x558a(%rip),%rdi        # 2af880 <None_Inst>
  2aa2f6:	e8 15 0b 00 00       	call   2aae10 <None_val_create_o>
  2aa2fb:	48 8d 3d 7e 55 00 00 	lea    0x557e(%rip),%rdi        # 2af880 <None_Inst>
  2aa302:	e8 09 0b 00 00       	call   2aae10 <None_val_create_o>
  2aa307:	48 83 c4 18          	add    $0x18,%rsp
  2aa30b:	5b                   	pop    %rbx
  2aa30c:	41 5c                	pop    %r12
  2aa30e:	41 5e                	pop    %r14
  2aa310:	41 5f                	pop    %r15
  2aa312:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
