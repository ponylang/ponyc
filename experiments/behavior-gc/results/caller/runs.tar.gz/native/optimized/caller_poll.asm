
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000000228e0 <caller_poll>:
   228e0:	55                   	push   %rbp
   228e1:	48 89 e5             	mov    %rsp,%rbp
   228e4:	48 83 ec 60          	sub    $0x60,%rsp
   228e8:	b0 00                	mov    $0x0,%al
   228ea:	e8 c1 ae 00 00       	call   2d7b0 <pony_ctx>
   228ef:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
   228f3:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   228f7:	48 8b 40 08          	mov    0x8(%rax),%rax
   228fb:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
   228ff:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22906:	25 00 00 00 00 
   2290b:	48 8d 88 50 df fe ff 	lea    -0x120b0(%rax),%rcx
   22912:	31 c0                	xor    %eax,%eax
   22914:	83 39 01             	cmpl   $0x1,(%rcx)
   22917:	88 45 ef             	mov    %al,-0x11(%rbp)
   2291a:	75 4e                	jne    2296a <caller_poll+0x8a>
   2291c:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22920:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
   22924:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2292b:	25 00 00 00 00 
   22930:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
   22934:	48 8d 90 50 df fe ff 	lea    -0x120b0(%rax),%rdx
   2293b:	31 c0                	xor    %eax,%eax
   2293d:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   22941:	88 45 ef             	mov    %al,-0x11(%rbp)
   22944:	75 24                	jne    2296a <caller_poll+0x8a>
   22946:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2294d:	25 00 00 00 00 
   22952:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22959:	48 81 b8 20 20 00 00 	cmpq   $0x400,0x2020(%rax)
   22960:	00 04 00 00 
   22964:	0f 94 c0             	sete   %al
   22967:	88 45 ef             	mov    %al,-0x11(%rbp)
   2296a:	8a 45 ef             	mov    -0x11(%rbp),%al
   2296d:	0f b6 f8             	movzbl %al,%edi
   22970:	83 e7 01             	and    $0x1,%edi
   22973:	48 8d 35 9a 5b fe ff 	lea    -0x1a466(%rip),%rsi        # 8514 <_IO_stdin_used+0x5104>
   2297a:	e8 c1 fc ff ff       	call   22640 <require>
   2297f:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   22983:	31 c0                	xor    %eax,%eax
   22985:	48 83 79 20 00       	cmpq   $0x0,0x20(%rcx)
   2298a:	88 45 df             	mov    %al,-0x21(%rbp)
   2298d:	0f 85 81 00 00 00    	jne    22a14 <caller_poll+0x134>
   22993:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   22997:	31 c0                	xor    %eax,%eax
   22999:	48 83 79 48 00       	cmpq   $0x0,0x48(%rcx)
   2299e:	88 45 df             	mov    %al,-0x21(%rbp)
   229a1:	75 71                	jne    22a14 <caller_poll+0x134>
   229a3:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
   229a7:	48 83 c7 28          	add    $0x28,%rdi
   229ab:	e8 50 7a ff ff       	call   1a400 <ponyint_actormap_size>
   229b0:	48 89 c1             	mov    %rax,%rcx
   229b3:	31 c0                	xor    %eax,%eax
   229b5:	48 83 f9 00          	cmp    $0x0,%rcx
   229b9:	88 45 df             	mov    %al,-0x21(%rbp)
   229bc:	75 56                	jne    22a14 <caller_poll+0x134>
   229be:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   229c2:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   229c9:	48 83 c7 10          	add    $0x10,%rdi
   229cd:	e8 5e f4 ff ff       	call   21e30 <ponyint_objectmap_size>
   229d2:	48 89 c1             	mov    %rax,%rcx
   229d5:	31 c0                	xor    %eax,%eax
   229d7:	48 83 f9 00          	cmp    $0x0,%rcx
   229db:	88 45 df             	mov    %al,-0x21(%rbp)
   229de:	75 34                	jne    22a14 <caller_poll+0x134>
   229e0:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   229e4:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   229eb:	48 83 c7 30          	add    $0x30,%rdi
   229ef:	e8 0c 7a ff ff       	call   1a400 <ponyint_actormap_size>
   229f4:	48 89 c1             	mov    %rax,%rcx
   229f7:	31 c0                	xor    %eax,%eax
   229f9:	48 83 f9 00          	cmp    $0x0,%rcx
   229fd:	88 45 df             	mov    %al,-0x21(%rbp)
   22a00:	75 12                	jne    22a14 <caller_poll+0x134>
   22a02:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   22a06:	48 83 c7 40          	add    $0x40,%rdi
   22a0a:	e8 b1 10 00 00       	call   23ac0 <ponyint_heap_has_finalisers>
   22a0f:	34 ff                	xor    $0xff,%al
   22a11:	88 45 df             	mov    %al,-0x21(%rbp)
   22a14:	8a 45 df             	mov    -0x21(%rbp),%al
   22a17:	0f b6 f8             	movzbl %al,%edi
   22a1a:	83 e7 01             	and    $0x1,%edi
   22a1d:	48 8d 35 9e 33 fe ff 	lea    -0x1cc62(%rip),%rsi        # 5dc2 <_IO_stdin_used+0x29b2>
   22a24:	e8 17 fc ff ff       	call   22640 <require>
   22a29:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22a2d:	48 8b 80 c0 00 00 00 	mov    0xc0(%rax),%rax
   22a34:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
   22a38:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22a3f:	25 00 00 00 00 
   22a44:	48 89 c1             	mov    %rax,%rcx
   22a47:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
   22a4b:	48 8d 89 50 df fe ff 	lea    -0x120b0(%rcx),%rcx
   22a52:	48 3b 81 30 20 00 00 	cmp    0x2030(%rcx),%rax
   22a59:	0f 94 c0             	sete   %al
   22a5c:	0f b6 f8             	movzbl %al,%edi
   22a5f:	83 e7 01             	and    $0x1,%edi
   22a62:	48 8d 35 9b 55 fe ff 	lea    -0x1aa65(%rip),%rsi        # 8004 <_IO_stdin_used+0x4bf4>
   22a69:	e8 d2 fb ff ff       	call   22640 <require>
   22a6e:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22a72:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   22a79:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
   22a7d:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22a84:	25 00 00 00 00 
   22a89:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
   22a8d:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22a94:	48 89 88 38 20 00 00 	mov    %rcx,0x2038(%rax)
   22a9b:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22aa2:	25 00 00 00 00 
   22aa7:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22aae:	48 8b 80 38 20 00 00 	mov    0x2038(%rax),%rax
   22ab5:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
   22ab9:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22ac0:	25 00 00 00 00 
   22ac5:	48 89 c1             	mov    %rax,%rcx
   22ac8:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
   22acc:	48 8d 89 50 df fe ff 	lea    -0x120b0(%rcx),%rcx
   22ad3:	48 3b 81 30 20 00 00 	cmp    0x2030(%rcx),%rax
   22ada:	0f 97 c0             	seta   %al
   22add:	88 45 dd             	mov    %al,-0x23(%rbp)
   22ae0:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22ae7:	25 00 00 00 00 
   22aec:	8a 4d dd             	mov    -0x23(%rbp),%cl
   22aef:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22af6:	80 e1 01             	and    $0x1,%cl
   22af9:	88 88 49 20 00 00    	mov    %cl,0x2049(%rax)
   22aff:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22b06:	25 00 00 00 00 
   22b0b:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22b12:	48 83 78 10 00       	cmpq   $0x0,0x10(%rax)
   22b17:	0f 95 c0             	setne  %al
   22b1a:	88 45 de             	mov    %al,-0x22(%rbp)
   22b1d:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22b24:	25 00 00 00 00 
   22b29:	8a 4d de             	mov    -0x22(%rbp),%cl
   22b2c:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22b33:	80 e1 01             	and    $0x1,%cl
   22b36:	88 88 4a 20 00 00    	mov    %cl,0x204a(%rax)
   22b3c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22b43:	25 00 00 00 00 
   22b48:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22b4f:	80 b8 49 20 00 00 00 	cmpb   $0x0,0x2049(%rax)
   22b56:	0f 84 8e 00 00 00    	je     22bea <caller_poll+0x30a>
   22b5c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22b63:	25 00 00 00 00 
   22b68:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22b6f:	80 b8 4a 20 00 00 00 	cmpb   $0x0,0x204a(%rax)
   22b76:	74 72                	je     22bea <caller_poll+0x30a>
   22b78:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22b7f:	25 00 00 00 00 
   22b84:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22b8b:	80 b8 48 20 00 00 00 	cmpb   $0x0,0x2048(%rax)
   22b92:	74 56                	je     22bea <caller_poll+0x30a>
   22b94:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   22b98:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
   22b9c:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22ba0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
   22ba4:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22bab:	25 00 00 00 00 
   22bb0:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
   22bb4:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
   22bb8:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22bbf:	48 8b 50 10          	mov    0x10(%rax),%rdx
   22bc3:	e8 b8 33 ff ff       	call   15f80 <probe_collect>
   22bc8:	88 45 bf             	mov    %al,-0x41(%rbp)
   22bcb:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22bd2:	25 00 00 00 00 
   22bd7:	8a 4d bf             	mov    -0x41(%rbp),%cl
   22bda:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22be1:	80 e1 01             	and    $0x1,%cl
   22be4:	88 88 4b 20 00 00    	mov    %cl,0x204b(%rax)
   22bea:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22bf1:	25 00 00 00 00 
   22bf6:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22bfd:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
   22c04:	00 
   22c05:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   22c09:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   22c10:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
   22c14:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22c1b:	25 00 00 00 00 
   22c20:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
   22c24:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22c2b:	48 89 88 40 20 00 00 	mov    %rcx,0x2040(%rax)
   22c32:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   22c39:	25 00 00 00 00 
   22c3e:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   22c45:	c7 00 02 00 00 00    	movl   $0x2,(%rax)
   22c4b:	48 83 c4 60          	add    $0x60,%rsp
   22c4f:	5d                   	pop    %rbp
   22c50:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
