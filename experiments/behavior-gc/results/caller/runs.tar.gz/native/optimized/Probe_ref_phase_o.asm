
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000040840 <Probe_ref_phase_o>:
   40840:	53                   	push   %rbx
   40841:	e8 aa fe ff ff       	call   406f0 <Probe_ref_allocate_garbage_o>
   40846:	48 89 c3             	mov    %rax,%rbx
   40849:	e8 92 20 fe ff       	call   228e0 <caller_poll>
   4084e:	e8 0d 24 fe ff       	call   22c60 <caller_leave_phase>
   40853:	48 89 d8             	mov    %rbx,%rax
   40856:	5b                   	pop    %rbx
   40857:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
