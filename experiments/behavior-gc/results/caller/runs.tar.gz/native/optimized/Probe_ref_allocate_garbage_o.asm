
measure:     file format elf64-x86-64


Disassembly of section .text:

00000000000406f0 <Probe_ref_allocate_garbage_o>:
   406f0:	41 57                	push   %r15
   406f2:	41 56                	push   %r14
   406f4:	53                   	push   %rbx
   406f5:	45 31 f6             	xor    %r14d,%r14d
   406f8:	e8 b3 d0 fe ff       	call   2d7b0 <pony_ctx>
   406fd:	48 89 c3             	mov    %rax,%rbx
   40700:	4c 8d 3d 99 2d 00 00 	lea    0x2d99(%rip),%r15        # 434a0 <Cell_Desc>
   40707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4070e:	00 00 
   40710:	48 89 df             	mov    %rbx,%rdi
   40713:	31 f6                	xor    %esi,%esi
   40715:	e8 b6 72 fd ff       	call   179d0 <pony_alloc_small>
   4071a:	4c 89 38             	mov    %r15,(%rax)
   4071d:	4c 89 70 08          	mov    %r14,0x8(%rax)
   40721:	48 89 c7             	mov    %rax,%rdi
   40724:	e8 07 20 fe ff       	call   22730 <caller_garbage>
   40729:	49 ff c6             	inc    %r14
   4072c:	49 81 fe 00 04 00 00 	cmp    $0x400,%r14
   40733:	75 db                	jne    40710 <Probe_ref_allocate_garbage_o+0x20>
   40735:	48 8d 05 54 35 00 00 	lea    0x3554(%rip),%rax        # 43c90 <None_Inst>
   4073c:	5b                   	pop    %rbx
   4073d:	41 5e                	pop    %r14
   4073f:	41 5f                	pop    %r15
   40741:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
