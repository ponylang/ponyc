
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000040480 <Probe_Dispatch>:
   40480:	55                   	push   %rbp
   40481:	41 57                	push   %r15
   40483:	41 56                	push   %r14
   40485:	41 55                	push   %r13
   40487:	41 54                	push   %r12
   40489:	53                   	push   %rbx
   4048a:	48 83 ec 38          	sub    $0x38,%rsp
   4048e:	48 89 f3             	mov    %rsi,%rbx
   40491:	83 7a 04 06          	cmpl   $0x6,0x4(%rdx)
   40495:	4c 8b 7a 10          	mov    0x10(%rdx),%r15
   40499:	75 3d                	jne    404d8 <Probe_Dispatch+0x58>
   4049b:	49 89 fe             	mov    %rdi,%r14
   4049e:	e8 0d d3 fe ff       	call   2d7b0 <pony_ctx>
   404a3:	31 ff                	xor    %edi,%edi
   404a5:	be 01 00 00 00       	mov    $0x1,%esi
   404aa:	e8 71 6c fd ff       	call   17120 <pony_alloc_msg>
   404af:	4c 89 78 10          	mov    %r15,0x10(%rax)
   404b3:	4c 89 f7             	mov    %r14,%rdi
   404b6:	48 89 de             	mov    %rbx,%rsi
   404b9:	48 89 c2             	mov    %rax,%rdx
   404bc:	48 89 c1             	mov    %rax,%rcx
   404bf:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   404c5:	48 83 c4 38          	add    $0x38,%rsp
   404c9:	5b                   	pop    %rbx
   404ca:	41 5c                	pop    %r12
   404cc:	41 5d                	pop    %r13
   404ce:	41 5e                	pop    %r14
   404d0:	41 5f                	pop    %r15
   404d2:	5d                   	pop    %rbp
   404d3:	e9 98 6c fd ff       	jmp    17170 <pony_sendv>
   404d8:	e8 d3 d2 fe ff       	call   2d7b0 <pony_ctx>
   404dd:	49 89 c6             	mov    %rax,%r14
   404e0:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   404e5:	48 8d 05 7c 4b fc ff 	lea    -0x3b484(%rip),%rax        # 5068 <_IO_stdin_used+0x1c58>
   404ec:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   404f1:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
   404f6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   404fb:	4c 8d 6c 24 28       	lea    0x28(%rsp),%r13
   40500:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   40505:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   4050c:	00 
   4050d:	48 8d 2d ec b7 fc ff 	lea    -0x34814(%rip),%rbp        # bd00 <class_spans+0x1640>
   40514:	4c 89 f7             	mov    %r14,%rdi
   40517:	48 89 de             	mov    %rbx,%rsi
   4051a:	48 89 ea             	mov    %rbp,%rdx
   4051d:	b9 11 00 00 00       	mov    $0x11,%ecx
   40522:	41 b8 0e 00 00 00    	mov    $0xe,%r8d
   40528:	45 31 c9             	xor    %r9d,%r9d
   4052b:	e8 60 1c fe ff       	call   22190 <ponyint_gc_root_audit>
   40530:	4c 89 f7             	mov    %r14,%rdi
   40533:	31 f6                	xor    %esi,%esi
   40535:	e8 96 74 fd ff       	call   179d0 <pony_alloc_small>
   4053a:	49 89 c4             	mov    %rax,%r12
   4053d:	48 8d 05 5c 2f 00 00 	lea    0x2f5c(%rip),%rax        # 434a0 <Cell_Desc>
   40544:	49 89 04 24          	mov    %rax,(%r12)
   40548:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
   4054d:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
   40552:	48 8d 05 c6 36 fc ff 	lea    -0x3c93a(%rip),%rax        # 3c1f <_IO_stdin_used+0x80f>
   40559:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   4055e:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
   40563:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   40568:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
   4056d:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   40574:	00 
   40575:	4c 89 f7             	mov    %r14,%rdi
   40578:	48 89 de             	mov    %rbx,%rsi
   4057b:	48 89 ea             	mov    %rbp,%rdx
   4057e:	b9 12 00 00 00       	mov    $0x12,%ecx
   40583:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
   40589:	45 31 c9             	xor    %r9d,%r9d
   4058c:	e8 ff 1b fe ff       	call   22190 <ponyint_gc_root_audit>
   40591:	e8 aa 02 00 00       	call   40840 <Probe_ref_phase_o>
   40596:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4059a:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   4059f:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   405a6:	00 00 
   405a8:	4c 8d 2d 21 b8 fc ff 	lea    -0x347df(%rip),%r13        # bdd0 <class_spans+0x1710>
   405af:	4c 89 f7             	mov    %r14,%rdi
   405b2:	48 89 de             	mov    %rbx,%rsi
   405b5:	48 89 ea             	mov    %rbp,%rdx
   405b8:	49 89 ef             	mov    %rbp,%r15
   405bb:	b9 13 00 00 00       	mov    $0x13,%ecx
   405c0:	41 b8 15 00 00 00    	mov    $0x15,%r8d
   405c6:	4d 89 e9             	mov    %r13,%r9
   405c9:	e8 c2 1b fe ff       	call   22190 <ponyint_gc_root_audit>
   405ce:	4c 89 f7             	mov    %r14,%rdi
   405d1:	31 f6                	xor    %esi,%esi
   405d3:	e8 f8 73 fd ff       	call   179d0 <pony_alloc_small>
   405d8:	48 89 c5             	mov    %rax,%rbp
   405db:	48 8d 05 be 2e 00 00 	lea    0x2ebe(%rip),%rax        # 434a0 <Cell_Desc>
   405e2:	48 89 45 00          	mov    %rax,0x0(%rbp)
   405e6:	48 c7 45 08 d3 00 00 	movq   $0xd3,0x8(%rbp)
   405ed:	00 
   405ee:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   405f2:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   405f7:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   405fe:	00 00 
   40600:	4c 89 f7             	mov    %r14,%rdi
   40603:	48 89 de             	mov    %rbx,%rsi
   40606:	4c 89 fa             	mov    %r15,%rdx
   40609:	b9 14 00 00 00       	mov    $0x14,%ecx
   4060e:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   40614:	4d 89 e9             	mov    %r13,%r9
   40617:	e8 74 1b fe ff       	call   22190 <ponyint_gc_root_audit>
   4061c:	4c 89 e7             	mov    %r12,%rdi
   4061f:	48 89 ee             	mov    %rbp,%rsi
   40622:	e8 c9 26 fe ff       	call   22cf0 <caller_addresses>
   40627:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4062b:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   40630:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   40637:	00 00 
   40639:	4c 89 f7             	mov    %r14,%rdi
   4063c:	48 89 de             	mov    %rbx,%rsi
   4063f:	4c 89 fa             	mov    %r15,%rdx
   40642:	4d 89 fd             	mov    %r15,%r13
   40645:	b9 15 00 00 00       	mov    $0x15,%ecx
   4064a:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   40650:	4c 8d 0d 79 b7 fc ff 	lea    -0x34887(%rip),%r9        # bdd0 <class_spans+0x1710>
   40657:	e8 34 1b fe ff       	call   22190 <ponyint_gc_root_audit>
   4065c:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
   40661:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   40665:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   4066a:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   40671:	00 00 
   40673:	4c 89 f7             	mov    %r14,%rdi
   40676:	48 89 de             	mov    %rbx,%rsi
   40679:	4c 89 ea             	mov    %r13,%rdx
   4067c:	b9 16 00 00 00       	mov    $0x16,%ecx
   40681:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   40687:	4c 8d 0d 42 b7 fc ff 	lea    -0x348be(%rip),%r9        # bdd0 <class_spans+0x1710>
   4068e:	e8 fd 1a fe ff       	call   22190 <ponyint_gc_root_audit>
   40693:	49 8d 47 05          	lea    0x5(%r15),%rax
   40697:	49 89 44 24 08       	mov    %rax,0x8(%r12)
   4069c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   406a0:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   406a5:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   406ac:	00 00 
   406ae:	4c 89 f7             	mov    %r14,%rdi
   406b1:	48 89 de             	mov    %rbx,%rsi
   406b4:	4c 89 ea             	mov    %r13,%rdx
   406b7:	b9 17 00 00 00       	mov    $0x17,%ecx
   406bc:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   406c2:	4c 8d 0d 07 b7 fc ff 	lea    -0x348f9(%rip),%r9        # bdd0 <class_spans+0x1710>
   406c9:	e8 c2 1a fe ff       	call   22190 <ponyint_gc_root_audit>
   406ce:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
   406d3:	48 8b 55 08          	mov    0x8(%rbp),%rdx
   406d7:	4c 89 ff             	mov    %r15,%rdi
   406da:	e8 a1 27 fe ff       	call   22e80 <caller_result>
   406df:	48 83 c4 38          	add    $0x38,%rsp
   406e3:	5b                   	pop    %rbx
   406e4:	41 5c                	pop    %r12
   406e6:	41 5d                	pop    %r13
   406e8:	41 5e                	pop    %r14
   406ea:	41 5f                	pop    %r15
   406ec:	5d                   	pop    %rbp
   406ed:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
