
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000024730 <caller_poll>:
   24730:	55                   	push   %rbp
   24731:	48 89 e5             	mov    %rsp,%rbp
   24734:	48 83 ec 60          	sub    $0x60,%rsp
   24738:	b0 00                	mov    $0x0,%al
   2473a:	e8 c1 ae 00 00       	call   2f600 <pony_ctx>
   2473f:	48 89 45 f8          	mov    %rax,-0x8(%rbp)
   24743:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   24747:	48 8b 40 08          	mov    0x8(%rax),%rax
   2474b:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
   2474f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24756:	25 00 00 00 00 
   2475b:	48 8d 88 50 df fe ff 	lea    -0x120b0(%rax),%rcx
   24762:	31 c0                	xor    %eax,%eax
   24764:	83 39 01             	cmpl   $0x1,(%rcx)
   24767:	88 45 ef             	mov    %al,-0x11(%rbp)
   2476a:	75 4e                	jne    247ba <caller_poll+0x8a>
   2476c:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   24770:	48 89 45 e0          	mov    %rax,-0x20(%rbp)
   24774:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2477b:	25 00 00 00 00 
   24780:	48 8b 4d e0          	mov    -0x20(%rbp),%rcx
   24784:	48 8d 90 50 df fe ff 	lea    -0x120b0(%rax),%rdx
   2478b:	31 c0                	xor    %eax,%eax
   2478d:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   24791:	88 45 ef             	mov    %al,-0x11(%rbp)
   24794:	75 24                	jne    247ba <caller_poll+0x8a>
   24796:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2479d:	25 00 00 00 00 
   247a2:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   247a9:	48 81 b8 20 20 00 00 	cmpq   $0x400,0x2020(%rax)
   247b0:	00 04 00 00 
   247b4:	0f 94 c0             	sete   %al
   247b7:	88 45 ef             	mov    %al,-0x11(%rbp)
   247ba:	8a 45 ef             	mov    -0x11(%rbp),%al
   247bd:	0f b6 f8             	movzbl %al,%edi
   247c0:	83 e7 01             	and    $0x1,%edi
   247c3:	48 8d 35 ca 47 fe ff 	lea    -0x1b836(%rip),%rsi        # 8f94 <_IO_stdin_used+0x5134>
   247ca:	e8 c1 fc ff ff       	call   24490 <require>
   247cf:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   247d3:	31 c0                	xor    %eax,%eax
   247d5:	48 83 79 20 00       	cmpq   $0x0,0x20(%rcx)
   247da:	88 45 df             	mov    %al,-0x21(%rbp)
   247dd:	0f 85 81 00 00 00    	jne    24864 <caller_poll+0x134>
   247e3:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
   247e7:	31 c0                	xor    %eax,%eax
   247e9:	48 83 79 48 00       	cmpq   $0x0,0x48(%rcx)
   247ee:	88 45 df             	mov    %al,-0x21(%rbp)
   247f1:	75 71                	jne    24864 <caller_poll+0x134>
   247f3:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
   247f7:	48 83 c7 28          	add    $0x28,%rdi
   247fb:	e8 50 7a ff ff       	call   1c250 <ponyint_actormap_size>
   24800:	48 89 c1             	mov    %rax,%rcx
   24803:	31 c0                	xor    %eax,%eax
   24805:	48 83 f9 00          	cmp    $0x0,%rcx
   24809:	88 45 df             	mov    %al,-0x21(%rbp)
   2480c:	75 56                	jne    24864 <caller_poll+0x134>
   2480e:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24812:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   24819:	48 83 c7 10          	add    $0x10,%rdi
   2481d:	e8 5e f4 ff ff       	call   23c80 <ponyint_objectmap_size>
   24822:	48 89 c1             	mov    %rax,%rcx
   24825:	31 c0                	xor    %eax,%eax
   24827:	48 83 f9 00          	cmp    $0x0,%rcx
   2482b:	88 45 df             	mov    %al,-0x21(%rbp)
   2482e:	75 34                	jne    24864 <caller_poll+0x134>
   24830:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24834:	48 81 c7 d8 00 00 00 	add    $0xd8,%rdi
   2483b:	48 83 c7 30          	add    $0x30,%rdi
   2483f:	e8 0c 7a ff ff       	call   1c250 <ponyint_actormap_size>
   24844:	48 89 c1             	mov    %rax,%rcx
   24847:	31 c0                	xor    %eax,%eax
   24849:	48 83 f9 00          	cmp    $0x0,%rcx
   2484d:	88 45 df             	mov    %al,-0x21(%rbp)
   24850:	75 12                	jne    24864 <caller_poll+0x134>
   24852:	48 8b 7d f0          	mov    -0x10(%rbp),%rdi
   24856:	48 83 c7 40          	add    $0x40,%rdi
   2485a:	e8 b1 10 00 00       	call   25910 <ponyint_heap_has_finalisers>
   2485f:	34 ff                	xor    $0xff,%al
   24861:	88 45 df             	mov    %al,-0x21(%rbp)
   24864:	8a 45 df             	mov    -0x21(%rbp),%al
   24867:	0f b6 f8             	movzbl %al,%edi
   2486a:	83 e7 01             	and    $0x1,%edi
   2486d:	48 8d 35 b7 1f fe ff 	lea    -0x1e049(%rip),%rsi        # 682b <_IO_stdin_used+0x29cb>
   24874:	e8 17 fc ff ff       	call   24490 <require>
   24879:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   2487d:	48 8b 80 c0 00 00 00 	mov    0xc0(%rax),%rax
   24884:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
   24888:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   2488f:	25 00 00 00 00 
   24894:	48 89 c1             	mov    %rax,%rcx
   24897:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
   2489b:	48 8d 89 50 df fe ff 	lea    -0x120b0(%rcx),%rcx
   248a2:	48 3b 81 30 20 00 00 	cmp    0x2030(%rcx),%rax
   248a9:	0f 94 c0             	sete   %al
   248ac:	0f b6 f8             	movzbl %al,%edi
   248af:	83 e7 01             	and    $0x1,%edi
   248b2:	48 8d 35 cb 41 fe ff 	lea    -0x1be35(%rip),%rsi        # 8a84 <_IO_stdin_used+0x4c24>
   248b9:	e8 d2 fb ff ff       	call   24490 <require>
   248be:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   248c2:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   248c9:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
   248cd:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   248d4:	25 00 00 00 00 
   248d9:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
   248dd:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   248e4:	48 89 88 38 20 00 00 	mov    %rcx,0x2038(%rax)
   248eb:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   248f2:	25 00 00 00 00 
   248f7:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   248fe:	48 8b 80 38 20 00 00 	mov    0x2038(%rax),%rax
   24905:	48 89 45 d0          	mov    %rax,-0x30(%rbp)
   24909:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24910:	25 00 00 00 00 
   24915:	48 89 c1             	mov    %rax,%rcx
   24918:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
   2491c:	48 8d 89 50 df fe ff 	lea    -0x120b0(%rcx),%rcx
   24923:	48 3b 81 30 20 00 00 	cmp    0x2030(%rcx),%rax
   2492a:	0f 97 c0             	seta   %al
   2492d:	88 45 dd             	mov    %al,-0x23(%rbp)
   24930:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24937:	25 00 00 00 00 
   2493c:	8a 4d dd             	mov    -0x23(%rbp),%cl
   2493f:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24946:	80 e1 01             	and    $0x1,%cl
   24949:	88 88 49 20 00 00    	mov    %cl,0x2049(%rax)
   2494f:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24956:	25 00 00 00 00 
   2495b:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24962:	48 83 78 10 00       	cmpq   $0x0,0x10(%rax)
   24967:	0f 95 c0             	setne  %al
   2496a:	88 45 de             	mov    %al,-0x22(%rbp)
   2496d:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24974:	25 00 00 00 00 
   24979:	8a 4d de             	mov    -0x22(%rbp),%cl
   2497c:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24983:	80 e1 01             	and    $0x1,%cl
   24986:	88 88 4a 20 00 00    	mov    %cl,0x204a(%rax)
   2498c:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24993:	25 00 00 00 00 
   24998:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   2499f:	80 b8 49 20 00 00 00 	cmpb   $0x0,0x2049(%rax)
   249a6:	0f 84 8e 00 00 00    	je     24a3a <caller_poll+0x30a>
   249ac:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   249b3:	25 00 00 00 00 
   249b8:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   249bf:	80 b8 4a 20 00 00 00 	cmpb   $0x0,0x204a(%rax)
   249c6:	74 72                	je     24a3a <caller_poll+0x30a>
   249c8:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   249cf:	25 00 00 00 00 
   249d4:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   249db:	80 b8 48 20 00 00 00 	cmpb   $0x0,0x2048(%rax)
   249e2:	74 56                	je     24a3a <caller_poll+0x30a>
   249e4:	48 8b 45 f8          	mov    -0x8(%rbp),%rax
   249e8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
   249ec:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   249f0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
   249f4:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   249fb:	25 00 00 00 00 
   24a00:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
   24a04:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
   24a08:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24a0f:	48 8b 50 10          	mov    0x10(%rax),%rdx
   24a13:	e8 b8 33 ff ff       	call   17dd0 <probe_collect>
   24a18:	88 45 bf             	mov    %al,-0x41(%rbp)
   24a1b:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24a22:	25 00 00 00 00 
   24a27:	8a 4d bf             	mov    -0x41(%rbp),%cl
   24a2a:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24a31:	80 e1 01             	and    $0x1,%cl
   24a34:	88 88 4b 20 00 00    	mov    %cl,0x204b(%rax)
   24a3a:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24a41:	25 00 00 00 00 
   24a46:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24a4d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
   24a54:	00 
   24a55:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
   24a59:	48 8b 80 b8 00 00 00 	mov    0xb8(%rax),%rax
   24a60:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
   24a64:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24a6b:	25 00 00 00 00 
   24a70:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
   24a74:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24a7b:	48 89 88 40 20 00 00 	mov    %rcx,0x2040(%rax)
   24a82:	66 66 66 64 48 8b 04 	data16 data16 data16 mov %fs:0x0,%rax
   24a89:	25 00 00 00 00 
   24a8e:	48 8d 80 50 df fe ff 	lea    -0x120b0(%rax),%rax
   24a95:	c7 00 02 00 00 00    	movl   $0x2,(%rax)
   24a9b:	48 83 c4 60          	add    $0x60,%rsp
   24a9f:	5d                   	pop    %rbp
   24aa0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
