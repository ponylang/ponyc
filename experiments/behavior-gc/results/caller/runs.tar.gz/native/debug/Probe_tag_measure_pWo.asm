
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042720 <Probe_tag_measure_pWo>:
   42720:	55                   	push   %rbp
   42721:	41 57                	push   %r15
   42723:	41 56                	push   %r14
   42725:	41 55                	push   %r13
   42727:	41 54                	push   %r12
   42729:	53                   	push   %rbx
   4272a:	48 83 ec 68          	sub    $0x68,%rsp
   4272e:	49 89 f4             	mov    %rsi,%r12
   42731:	48 89 fb             	mov    %rdi,%rbx
   42734:	e8 c7 ce fe ff       	call   2f600 <pony_ctx>
   42739:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
   4273e:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
   42743:	49 89 c6             	mov    %rax,%r14
   42746:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   4274b:	48 8d 05 75 33 fc ff 	lea    -0x3cc8b(%rip),%rax        # 5ac7 <_IO_stdin_used+0x1c67>
   42752:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   42757:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   4275c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   42761:	48 8d 6c 24 48       	lea    0x48(%rsp),%rbp
   42766:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   4276b:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
   42772:	00 
   42773:	4c 8d 3d 36 a0 fc ff 	lea    -0x35fca(%rip),%r15        # c7b0 <__NumSizeTable+0x20>
   4277a:	4c 89 f7             	mov    %r14,%rdi
   4277d:	48 89 de             	mov    %rbx,%rsi
   42780:	4c 89 fa             	mov    %r15,%rdx
   42783:	b9 11 00 00 00       	mov    $0x11,%ecx
   42788:	41 b8 0e 00 00 00    	mov    $0xe,%r8d
   4278e:	45 31 c9             	xor    %r9d,%r9d
   42791:	e8 4a 18 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   42796:	4c 89 f7             	mov    %r14,%rdi
   42799:	31 f6                	xor    %esi,%esi
   4279b:	e8 80 70 fd ff       	call   19820 <pony_alloc_small>
   427a0:	49 89 c5             	mov    %rax,%r13
   427a3:	48 8d 05 46 3c 00 00 	lea    0x3c46(%rip),%rax        # 463f0 <Cell_Desc>
   427aa:	49 89 45 00          	mov    %rax,0x0(%r13)
   427ae:	4c 89 ef             	mov    %r13,%rdi
   427b1:	4c 89 e6             	mov    %r12,%rsi
   427b4:	e8 f7 fe ff ff       	call   426b0 <Cell_ref_create_pWo>
   427b9:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   427be:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
   427c3:	48 8d 05 a9 1e fc ff 	lea    -0x3e157(%rip),%rax        # 4673 <_IO_stdin_used+0x813>
   427ca:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   427cf:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   427d4:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   427d9:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   427de:	48 c7 04 24 02 00 00 	movq   $0x2,(%rsp)
   427e5:	00 
   427e6:	4c 89 f7             	mov    %r14,%rdi
   427e9:	48 89 de             	mov    %rbx,%rsi
   427ec:	4c 89 fa             	mov    %r15,%rdx
   427ef:	b9 12 00 00 00       	mov    $0x12,%ecx
   427f4:	41 b8 0a 00 00 00    	mov    $0xa,%r8d
   427fa:	45 31 c9             	xor    %r9d,%r9d
   427fd:	e8 de 17 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   42802:	48 89 df             	mov    %rbx,%rdi
   42805:	e8 76 fd ff ff       	call   42580 <Probe_ref_phase_o>
   4280a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4280e:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   42813:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4281a:	00 00 
   4281c:	4c 8d 0d 9d a0 fc ff 	lea    -0x35f63(%rip),%r9        # c8c0 <__NumSizeTable+0x130>
   42823:	4c 89 f7             	mov    %r14,%rdi
   42826:	48 89 de             	mov    %rbx,%rsi
   42829:	4c 89 fa             	mov    %r15,%rdx
   4282c:	b9 13 00 00 00       	mov    $0x13,%ecx
   42831:	41 b8 15 00 00 00    	mov    $0x15,%r8d
   42837:	e8 a4 17 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   4283c:	4c 89 f7             	mov    %r14,%rdi
   4283f:	31 f6                	xor    %esi,%esi
   42841:	e8 da 6f fd ff       	call   19820 <pony_alloc_small>
   42846:	49 89 c4             	mov    %rax,%r12
   42849:	48 8d 05 a0 3b 00 00 	lea    0x3ba0(%rip),%rax        # 463f0 <Cell_Desc>
   42850:	49 89 04 24          	mov    %rax,(%r12)
   42854:	be d3 00 00 00       	mov    $0xd3,%esi
   42859:	4c 89 e7             	mov    %r12,%rdi
   4285c:	e8 4f fe ff ff       	call   426b0 <Cell_ref_create_pWo>
   42861:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   42866:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4286a:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   4286f:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   42876:	00 00 
   42878:	4c 8d 0d 41 a0 fc ff 	lea    -0x35fbf(%rip),%r9        # c8c0 <__NumSizeTable+0x130>
   4287f:	4c 89 f7             	mov    %r14,%rdi
   42882:	48 89 de             	mov    %rbx,%rsi
   42885:	4c 89 fa             	mov    %r15,%rdx
   42888:	b9 14 00 00 00       	mov    $0x14,%ecx
   4288d:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   42893:	e8 48 17 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   42898:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
   4289d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   428a2:	e8 99 22 fe ff       	call   24b40 <caller_addresses>
   428a7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   428ab:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   428b0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   428b7:	00 00 
   428b9:	4c 8d 0d 00 a0 fc ff 	lea    -0x36000(%rip),%r9        # c8c0 <__NumSizeTable+0x130>
   428c0:	4c 89 f7             	mov    %r14,%rdi
   428c3:	48 89 de             	mov    %rbx,%rsi
   428c6:	4c 89 fa             	mov    %r15,%rdx
   428c9:	b9 15 00 00 00       	mov    $0x15,%ecx
   428ce:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   428d4:	e8 07 17 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   428d9:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   428de:	48 8b 40 08          	mov    0x8(%rax),%rax
   428e2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   428e7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   428eb:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   428f0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   428f7:	00 00 
   428f9:	4c 8d 0d c0 9f fc ff 	lea    -0x36040(%rip),%r9        # c8c0 <__NumSizeTable+0x130>
   42900:	4c 89 f7             	mov    %r14,%rdi
   42903:	48 89 de             	mov    %rbx,%rsi
   42906:	4c 89 fa             	mov    %r15,%rdx
   42909:	b9 16 00 00 00       	mov    $0x16,%ecx
   4290e:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   42914:	e8 c7 16 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   42919:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   4291e:	48 83 c0 05          	add    $0x5,%rax
   42922:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   42927:	48 89 41 08          	mov    %rax,0x8(%rcx)
   4292b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
   4292f:	c5 f8 11 04 24       	vmovups %xmm0,(%rsp)
   42934:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4293b:	00 00 
   4293d:	4c 8d 0d 7c 9f fc ff 	lea    -0x36084(%rip),%r9        # c8c0 <__NumSizeTable+0x130>
   42944:	4c 89 f7             	mov    %r14,%rdi
   42947:	48 89 de             	mov    %rbx,%rsi
   4294a:	4c 89 fa             	mov    %r15,%rdx
   4294d:	b9 17 00 00 00       	mov    $0x17,%ecx
   42952:	41 b8 05 00 00 00    	mov    $0x5,%r8d
   42958:	e8 83 16 fe ff       	call   23fe0 <ponyint_gc_root_audit>
   4295d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
   42962:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
   42967:	48 8b 70 08          	mov    0x8(%rax),%rsi
   4296b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
   42970:	48 8b 50 08          	mov    0x8(%rax),%rdx
   42974:	e8 57 23 fe ff       	call   24cd0 <caller_result>
   42979:	48 83 c4 68          	add    $0x68,%rsp
   4297d:	5b                   	pop    %rbx
   4297e:	41 5c                	pop    %r12
   42980:	41 5d                	pop    %r13
   42982:	41 5e                	pop    %r14
   42984:	41 5f                	pop    %r15
   42986:	5d                   	pop    %rbp
   42987:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
