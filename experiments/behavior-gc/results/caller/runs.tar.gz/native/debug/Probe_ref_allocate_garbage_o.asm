
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042370 <Probe_ref_allocate_garbage_o>:
   42370:	41 57                	push   %r15
   42372:	41 56                	push   %r14
   42374:	41 54                	push   %r12
   42376:	53                   	push   %rbx
   42377:	48 83 ec 18          	sub    $0x18,%rsp
   4237b:	49 89 fe             	mov    %rdi,%r14
   4237e:	e8 7d d2 fe ff       	call   2f600 <pony_ctx>
   42383:	48 89 c3             	mov    %rax,%rbx
   42386:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   4238b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   42392:	00 00 
   42394:	31 c0                	xor    %eax,%eax
   42396:	84 c0                	test   %al,%al
   42398:	75 55                	jne    423ef <Probe_ref_allocate_garbage_o+0x7f>
   4239a:	4c 8d 25 4f 40 00 00 	lea    0x404f(%rip),%r12        # 463f0 <Cell_Desc>
   423a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   423a8:	0f 1f 84 00 00 00 00 
   423af:	00 
   423b0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   423b5:	48 89 df             	mov    %rbx,%rdi
   423b8:	31 f6                	xor    %esi,%esi
   423ba:	e8 61 74 fd ff       	call   19820 <pony_alloc_small>
   423bf:	49 89 c7             	mov    %rax,%r15
   423c2:	4c 89 20             	mov    %r12,(%rax)
   423c5:	48 89 c7             	mov    %rax,%rdi
   423c8:	4c 89 f6             	mov    %r14,%rsi
   423cb:	e8 e0 02 00 00       	call   426b0 <Cell_ref_create_pWo>
   423d0:	4c 89 ff             	mov    %r15,%rdi
   423d3:	e8 a8 21 fe ff       	call   24580 <caller_garbage>
   423d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   423dd:	48 ff c0             	inc    %rax
   423e0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   423e5:	48 3d 00 04 00 00    	cmp    $0x400,%rax
   423eb:	72 c3                	jb     423b0 <Probe_ref_allocate_garbage_o+0x40>
   423ed:	eb 0c                	jmp    423fb <Probe_ref_allocate_garbage_o+0x8b>
   423ef:	48 8d 3d aa 52 00 00 	lea    0x52aa(%rip),%rdi        # 476a0 <None_Inst>
   423f6:	e8 15 0b 00 00       	call   42f10 <None_val_create_o>
   423fb:	48 8d 3d 9e 52 00 00 	lea    0x529e(%rip),%rdi        # 476a0 <None_Inst>
   42402:	e8 09 0b 00 00       	call   42f10 <None_val_create_o>
   42407:	48 83 c4 18          	add    $0x18,%rsp
   4240b:	5b                   	pop    %rbx
   4240c:	41 5c                	pop    %r12
   4240e:	41 5e                	pop    %r14
   42410:	41 5f                	pop    %r15
   42412:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
