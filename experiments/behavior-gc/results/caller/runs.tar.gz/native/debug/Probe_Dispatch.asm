
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042350 <Probe_Dispatch>:
   42350:	50                   	push   %rax
   42351:	48 89 f7             	mov    %rsi,%rdi
   42354:	83 7a 04 01          	cmpl   $0x1,0x4(%rdx)
   42358:	75 0b                	jne    42365 <Probe_Dispatch+0x15>
   4235a:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   4235e:	e8 bd 03 00 00       	call   42720 <Probe_tag_measure_pWo>
   42363:	58                   	pop    %rax
   42364:	c3                   	ret
   42365:	48 8b 72 10          	mov    0x10(%rdx),%rsi
   42369:	e8 52 03 00 00       	call   426c0 <Probe_tag_create_pWo>
   4236e:	58                   	pop    %rax
   4236f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
