
measure:     file format elf64-x86-64


Disassembly of section .text:

0000000000042580 <Probe_ref_phase_o>:
   42580:	50                   	push   %rax
   42581:	48 89 3c 24          	mov    %rdi,(%rsp)
   42585:	e8 e6 fd ff ff       	call   42370 <Probe_ref_allocate_garbage_o>
   4258a:	e8 a1 21 fe ff       	call   24730 <caller_poll>
   4258f:	e8 1c 25 fe ff       	call   24ab0 <caller_leave_phase>
   42594:	48 8d 3d 05 51 00 00 	lea    0x5105(%rip),%rdi        # 476a0 <None_Inst>
   4259b:	e8 70 09 00 00       	call   42f10 <None_val_create_o>
   425a0:	59                   	pop    %rcx
   425a1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
